<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'WC_PDF_Watermark' ) ) {

	class WC_PDF_Watermark {

		/**
		 * Single instance of the class
		 *
		 * @var object
		 */
		private static $_instance = null;

		/**
		 * Plugin version
		 *
		 * @var string
		 */
		public $version;

		/**
		 * Main plugin file
		 *
		 * @var string
		 */
		public $file;

		/**
		 * Stamped file locations
		 *
		 * @var array
		 */
		public $stamped_file = array();

		/**
		 * Constructor
		 *
		 * @return void
		 */
		public function __construct( $file, $version ) {
			$this->file    = $file;
			$this->version = $version;

			// Admin specific functionality.
			if ( is_admin() ) {
				require_once 'class-wc-pdf-watermark-product-data.php';
				add_filter( 'woocommerce_get_settings_pages', array( $this, 'load_settings_class' ), 10, 1 );
				add_action( 'admin_enqueue_scripts', array( $this, 'admin_scripts' ) );

			}

			add_action( 'init', array( $this, 'init' ) );
			// Hook into download function to watermark files, hook in later to accomodate other plugins like Amazon S3 and becuase we use a custom download method.
			add_filter( 'woocommerce_product_file_download_path', array( $this, 'watermark_pdf_file' ), 50, 3 );
			add_filter( 'woocommerce_pdf_watermark_file', array( $this, 'watermark_file' ), 50, 3 );
			// Hook into shutdown to see if we should unlink the stamped file, download method calls exit which calls shutdown hook in WP.
			add_action( 'shutdown', array( $this, 'cleanup_files' ) );
			// Check if we should render a preview file.
			add_action( 'admin_init', array( $this, 'maybe_render_preview' ) );
			// Assess downloadable PDFs for compatibility.
			add_action( 'admin_notices', array( $this, 'file_compatibility_check' ) );
			add_action( 'woocommerce_email_before_order_table', array( $this, 'bbloomer_add_content_specific_email' ) );
			add_action( 'woocommerce_thankyou', array( $this, 'thankyou_callback' ), 10, 1 );
			add_action( 'wp_enqueue_scripts', array( $this, 'watermarknonce_enqueue' ) );

			add_action( 'wp_ajax_process_annotations', array( $this, 'process_annotations_callback' ) );
			add_action( 'wp_ajax_nopriv_process_annotations', array( $this, 'process_annotations_callback' ) );
			add_action( 'wp_ajax_process_index', array( $this, 'process_index_callback' ) );
			add_action( 'wp_ajax_nopriv_process_index', array( $this, 'process_index_callback' ) );
		} // End __construct()

		/**
		 * Function for processing annitations of the PDF.
		 */
		public function process_annotations_callback() {

			if ( isset( $_POST['pdf_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['pdf_nonce'] ) ), 'annot-nonce' ) ) {
				if ( ! isset( $_POST['annotations'] ) ) {
					wp_send_json_error( array( 'message' => 'Missing data.' ) );
				}

				$annotations = wp_unslash( $_POST['annotations'] ); // @codingStandardsIgnoreLine Generic.WhiteSpace.ScopeIndent
				$pdf_index   = isset( $_POST['pdf_index'] ) ? intval( $_POST['pdf_index'] ) : 0;

				session_start();
				$_SESSION['annotations'][ $pdf_index ] = $annotations;

				wp_send_json_success( array( 'message' => "Annotations for PDF index {$pdf_index} processed successfully." ) );
			}
		}

		/**
		 * Function for processing index of the PDF.
		 */
		public function process_index_callback() {

			if ( isset( $_POST['index_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['index_nonce'] ) ), 'index-nonce' ) ) {
				if ( ! isset( $_POST['pdf_index'] ) ) {
					wp_send_json_error( array( 'message' => 'PDF index missing.' ) );
				}

				$index = intval( $_POST['pdf_index'] ); // Sanitize input.

				session_start();
				$_SESSION['pdf_index'] = $index;

				wp_send_json_success(
					array(
						'message'   => "PDF index { $index } stored successfully.",
						'pdf_index' => $index,
					)
				);
			} else {
				wp_send_json_error( array( 'message' => 'Invalid nonce or missing nonce.' ) );
			}
		}

		function watermarknonce_enqueue() {
			// your enqueue will probably look different.
			wp_enqueue_script( 'watermarknonce_script' );

			// Localize the script.
			$data = array(
				'ajax_url' => admin_url( 'admin-ajax.php' ),
				'nonce'    => wp_create_nonce( 'watermark-nonce' ),
			);
			wp_localize_script( 'watermarknonce_script', 'watermarknonce_object', $data );
		}


		/**
		 * Constructor
		 *
		 * @return void
		 * @param array $order Order details.
		 */
		public function bbloomer_add_content_specific_email( $order ) {
			global $product;

			$items        = $order->get_items();
			$downloadable = array();
			foreach ( $items as $key => $item ) {
				$_product       = $order->get_product_from_item( $item );
				$downloadable[] = $_product->is_downloadable();
			}
			$text = get_option( 'woocommerce_pdf_watermark_password_pro' );

			if ( $order->has_status( 'completed' ) && in_array( '1', $downloadable ) && 'yes' == $text ) {
				echo '<p class="email-upsell-p"><b>Thank you for making this purchase! If your document is password protected please use either your email address or order id to unlock the file.</b></p>';
			}
		}

		/**
		 * Get single instance of class
		 *
		 * @return object WC_PDF_Stamper
		 */
		public static function instance( $file, $version ) {
			if ( is_null( self::$_instance ) ) {
				self::$_instance = new self( $file, $version );
			}
			return self::$_instance;
		} // End instance()

		/**
		 * Cloning is forbidden.
		 */
		public function __clone() {
			_doing_it_wrong( __FUNCTION__, esc_html( __( 'Cheatin&#8217; huh?' ) ), '1.0.0' );
		} // End __clone()

		/**
		 * Unserializing instances of this class is forbidden.
		 */
		public function __wakeup() {
			_doing_it_wrong( __FUNCTION__, esc_html( __( 'Cheatin&#8217; huh?' ) ), '1.0.0' );
		} // End __wakeup()

		/**
		 * Include and load the settings class
		 *
		 * @return object
		 */
		public function load_settings_class() {
			$settings[] = include 'class-wc-settings-pdf-watermark.php';
			return $settings;
		} // End load_settings_class()

		/**
		 * Load the textdomain, includes, etc
		 *
		 * @return void
		 */
		public function init() {
			load_plugin_textdomain( 'woocommerce-pdf-watermark', false, dirname( plugin_basename( $this->file ) ) . '/languages/' );
			include_once __DIR__ . '/class-wc-pdf-watermark-privacy.php';
		} // End init()


		/**
		 * Simple check for pdf extension
		 *
		 * @param  string $file_path
		 * @return bool
		 */
		private static function has_pdf_extension( $file_path ) {

			$file_info = pathinfo( $file_path );
			$file_ext = $file_info['extension'];
			$file_ext = strtolower( substr( $file_ext, 0, 3 ) );
			return ( 'pdf' === $file_ext );
		}


		/**
		 * Simple check for local files
		 *
		 * @param  string $file_path
		 * @return bool
		 */
		private static function is_local_file( $file_path ) {
			$upload_dir = wp_upload_dir();
			return ( false !== stripos( $file_path, $upload_dir['basedir'] ) );
		}


		/**
		 * Get a temporary file name (e.g. for bringing a remote file locally for processing)
		 *
		 * @param  string $original_file
		 * @return string
		 */
		private static function get_temporary_file_name( $original_file ) {

			$file_name = basename( $original_file );
			/**
			 * Apply_filters woocommerce_pdf_watermark_horizontal_offset
			 *
			 * @since 2022
			 */
			if ( apply_filters( 'wc_pdf_watermark_use_uploads_dir', false ) ) {
				$order_detail = isset( $_GET['order'] ) ? sanitize_text_field( $_GET['order'] ) : '';
				$file_name += '.' . $order_detail;
			}

			// Remove any query from the remote file name to avoid exposing query parameters and
			// a generally ugly file name to the user (e.g. for S3 served files)
			$file_name = preg_replace( '/[?].*$/', '', $file_name );

			// In the unlikely event that file_name is now empty, use a generic filename
			if ( empty( $file_name ) ) {
				$file_name = 'untitled.pdf';
			}

			return $file_name;
		}


		/**
		 * Get a temporary file folder (e.g. for bringing a remote file locally for processing)
		 *
		 * @return string
		 */
		private static function get_temporary_file_folder() {
			/**
			 * Apply_filters woocommerce_pdf_watermark_horizontal_offset
			 *
			 * @since 2022
			 */
			if ( apply_filters( 'wc_pdf_watermark_use_uploads_dir', false ) ) {
				$wp_upload_dir = wp_upload_dir();
				$new_file_path = $wp_upload_dir['basedir'] . '/wc-pdf-watermark/';

				// Setup dir in wp-content/uploads to store watermarked files
				if ( false === get_transient( 'wc_pdf_watermark_files' ) ) {
					wp_mkdir_p( $new_file_path );

					// Protect the directory from browsing
					if ( ! file_exists( $new_file_path . 'index.php' ) ) {
						@file_put_contents( $new_file_path . 'index.php', '<?php' . PHP_EOL . '// Silence is golden.' );
					}

					// Top level .htaccess
					$rules = 'Options -Indexes';
					if ( file_exists( $new_file_path . '.htaccess' ) ) {
						$contents = @file_get_contents( $new_file_path . '.htaccess' );

						if ( $contents !== $rules || ! $contents ) {
							@file_put_contents( $new_file_path . '.htaccess', $rules );
						}
					}
					set_transient( 'wc_pdf_watermark_files', true, 3600 * 24 );
				}
			} else {
				$new_file_path = trailingslashit( sys_get_temp_dir() );
			}

			return $new_file_path;
		}


		/**
		 * Fetch a remote file to a local path and filename
		 *
		 * @param  string $original_file
		 * @param  string $local_path_and_file
		 * @return void
		 */
		private static function fetch_remote_file( $original_file, $local_path_and_file ) {

			if ( ! file_exists( $local_path_and_file ) ) {
				$response = wp_remote_get( $original_file );
				$remote_file = wp_remote_retrieve_body( $response );
				@file_put_contents( $local_path_and_file, $remote_file );
			}
		}


		/**
		 * Check if we have a PDF file and watermark it based on settings
		 *
		 * @param  string $file_path
		 * @param  object $product
		 * @param  int    $download_id
		 * @return string
		 */
		public function watermark_pdf_file( $file_path, $product, $download_id ) {

			// Make sure this does not fire on the download permissions meta boxes.
			if ( function_exists( 'get_current_screen' ) ) {
				$screen = get_current_screen();
				if ( ! is_null( $screen ) && in_array( $screen->id, array( 'shop_order', 'shop_subscription' ) ) ) {
					return $file_path;
				}
			}

			if ( ! isset( $_GET['download_file'] ) ) {
				return $file_path;
			}

			// Check if we should skip watermark based on product specific settings
			// Check variation level first.
			if ( version_compare( WC_VERSION, '3.0', '<' ) ) {
				if ( isset( $product->variation_id ) && 'yes' == get_post_meta( $product->variation_id, '_pdf_watermark_disable', true ) ) {
					return $file_path;
				}
			} elseif ( $product->is_type( 'variation' ) && 'yes' == get_post_meta( $product->get_id(), '_pdf_watermark_disable', true ) ) {
					return $file_path;
			}

			// Check single product.
			if ( 'yes' == get_post_meta( $product->get_id(), '_pdf_watermark_disable', true ) ) {
				return $file_path;
			}

			$upload_dir = wp_get_upload_dir(); // Get the upload directory details.
			$uploads_base_url = $upload_dir['baseurl'];

			$uploads_base_dir = $upload_dir['basedir'];

			// Setup a new file to process.
			$original_file = str_replace( $uploads_base_url, $uploads_base_dir, $file_path );

			// Setup a new file to process.
			// $original_file = str_replace( WP_CONTENT_URL, WP_CONTENT_DIR, $file_path );.

			$info = pathinfo( $original_file );
			$download_file = isset( $_GET['download_file'] ) ? sanitize_text_field( $_GET['download_file'] ) : '';
			$order = isset( $_GET['order'] ) ? sanitize_text_field( $_GET['order'] ) : '';
			$key = isset( $_GET['key'] ) ? sanitize_text_field( $_GET['key'] ) : '';

			$download_data = $this->get_download_data( absint( $download_file ), wc_clean( $order ), wc_clean( isset( $key ) ? preg_replace( '/\s+/', ' ', $key ) : '' ) );
			$order_id = $download_data->order_id;
			/**
			 * Apply_filters woocommerce_pdf_watermark_horizontal_offset
			 *
			 * @since 2022
			 */
			$do_not_allow_epub = apply_filters( 'woocommerce_pdf_watermark_epub_watermarks', get_option( 'woocommerce_pdf_watermark_epub_watermarks', 'no' ), $order_id, $product->get_id() );

			// Check for epub extension.
			if ( 'epub' == $info['extension'] && 'yes' == $do_not_allow_epub ) {
				return $this->watermark_epub_file( $original_file, $order_id );
			}
			// Make sure we have a pdf file, if not return original file.
			if ( ! self::has_pdf_extension( $original_file ) ) {
				return $file_path;
			}

			// If we made it till here it means the file should be watermarked.

			// Get the product ID to do variation & single level overrides.
			if ( version_compare( WC_VERSION, '3.0', '<' ) && isset( $product->variation_id ) ) {
				$product_id = $product->variation_id;
			} else {
				$product_id = $product->get_id();
			}

			$download_file = isset( $_GET['download_file'] ) ? sanitize_text_field( $_GET['download_file'] ) : '';
			$order = isset( $_GET['order'] ) ? sanitize_text_field( $_GET['order'] ) : '';
			$key = isset( $_GET['key'] ) ? sanitize_text_field( $_GET['key'] ) : '';
			// Get the order id to look up order info.
			$download_data = $this->get_download_data( absint( $download_file ), wc_clean( $order ), wc_clean( isset( $key ) ? preg_replace( '/\s+/', ' ', $key ) : '' ) );
			$order_id = $download_data->order_id;

			$new_file = $this->watermark_file( $original_file, $product_id, $order_id );

			return $new_file;
		} // End stamp_pdf_file()


		/**
		 * Watermark on epub file
		 *
		 * @param  string $original_file
		 */
		public function watermark_epub_file( $original_file, $order_id ) {

			$info = pathinfo( $original_file );
			$extractFolder = $info['filename'];
			$upload = wp_upload_dir();
			$upload_dir = $upload['basedir'];
			$upload_dir_folder = $upload_dir . '/watermark-tmp/' . $extractFolder;
			$upload_dir_tmp = $upload_dir . '/watermark-tmp';

			// Create tmp folder for watermark epub files
			if ( ! is_dir( $upload_dir_tmp ) ) {
				mkdir( $upload_dir_tmp, 0777 );
			}

			// Create folder name with same as epub file name
			if ( ! is_dir( $upload_dir_folder ) ) {
				mkdir( $upload_dir_folder, 0777 );
			}

			$zip = new ZipArchive();
			$res = $zip->open( $original_file );
			if ( true == $res ) {
				// extract it to the path we determined above
				$zip->extractTo( getcwd() . '/wp-content/uploads/watermark-tmp/' . $extractFolder );
				$zip->close();
			}

			$zip = new ZipArchive();
			$filename = $extractFolder . '.epub';
			if ( $zip->open( $filename, ZipArchive::CREATE ) !== true ) {
				exit( 'cannot open <' . esc_html( $filename ) . ">\n" );
			}

			$dir = getcwd() . '/wp-content/uploads/watermark-tmp/' . $extractFolder . '/';
			$dest = getcwd() . '/wp-content/uploads/watermark-tmp/';

			$timestamp = time();
			// $this->epubFile($dir,$dest.$extractFolder.$timestamp.'.epub', false, $extractFolder,$order_id);
			$this->epubFile( $dir, $dest . $extractFolder . $timestamp . '.epub', $extractFolder, $order_id, false );

			$zip->close();
			return $dest . $extractFolder . $timestamp . '.epub';
		}


		/**
		 * Create epub file
		 *
		 * @param  string $source
		 * @param  string $destination
		 * @param  string $extractFolder
		 * @param  int    $order_id
		 * @param  bool   $flag
		 */
		public function epubFile( $source, $destination, $extractFolder, $order_id, $flag = '' ) {
			$text = get_option( 'woocommerce_pdf_watermark_text' );
			$order = wc_get_order( $order_id );
			// $product = wc_get_product( $product_id );
			$user_info = get_userdata( $order->get_customer_id() );

			$first_name = version_compare( WC_VERSION, '3.0', '<' ) ? $order->billing_first_name : $order->get_billing_first_name();
			$last_name = version_compare( WC_VERSION, '3.0', '<' ) ? $order->billing_last_name : $order->get_billing_last_name();
			$username = version_compare( WC_VERSION, '3.0', '<' ) ? $user_info->user_login : $user_info->user_login;
			$email = version_compare( WC_VERSION, '3.0', '<' ) ? $order->billing_email : $order->get_billing_email();
			$billing_company = version_compare( WC_VERSION, '3.0', '<' ) ? $order->billing_company : $order->get_billing_company();
			$order_number = $order->get_order_number();
			$order_date = version_compare( WC_VERSION, '3.0', '<' ) ? $order->order_date : ( $order->get_date_created() ? $order->get_date_created()->date( 'Y-m-d H:i:s' ) : '' );
			$site_name = get_bloginfo( 'name' );
			$site_url = home_url();

			$full_name = $first_name . ' ' . $last_name;
			$text = str_replace( '{username}', $username, $text );
			$text = str_replace( '{first_name}', $first_name, $text );
			$text = str_replace( '{last_name}', $last_name, $text );
			$text = str_replace( '{full_name}', $full_name, $text );
			$text = str_replace( '{email}', $email, $text );
			$text = str_replace( '{billing_company}', $billing_company, $text );
			$text = str_replace( '{order_number}', $order_number, $text );
			$text = str_replace( '{order_date}', $order_date, $text );
			$text = str_replace( '{site_name}', $site_name, $text );
			$text = str_replace( '{site_url}', $site_url, $text );

			// Get WC PDF Watermark Settings
			$type = get_option( 'woocommerce_pdf_watermark_type' );
			$image = get_option( 'woocommerce_pdf_watermark_image' );
			$isBold = ( get_option( 'woocommerce_pdf_watermark_font_style_bold' ) == 'yes' ) ? 'font-weight: bold;' : '';
			$isItalic = ( get_option( 'woocommerce_pdf_watermark_font_style_italics' ) == 'yes' ) ? 'text-decoration: underline;' : '';
			$isunderline = ( get_option( 'woocommerce_pdf_watermark_font_style_underline' ) == 'yes' ) ? 'font-style: italic;' : '';
			$color = ! empty( get_option( 'woocommerce_pdf_watermark_font_colour' ) ) ? get_option( 'woocommerce_pdf_watermark_font_colour' ) : '#000';
			$font = ! empty( get_option( 'woocommerce_pdf_watermark_font' ) ) ? get_option( 'woocommerce_pdf_watermark_font' ) : '';
			$fontSize = ! empty( get_option( 'woocommerce_pdf_watermark_font_size' ) ) ? get_option( 'woocommerce_pdf_watermark_font_size' ) . 'px' : '14px';
			$hposition = ! empty( get_option( 'woocommerce_pdf_watermark_font_horizontal' ) ) ? get_option( 'woocommerce_pdf_watermark_font_horizontal' ) : 'left';
			$vposition = ! empty( get_option( 'woocommerce_pdf_watermark_font_vertical' ) ) ? get_option( 'woocommerce_pdf_watermark_font_vertical' ) : 'top';
			$loffset = ! empty( get_option( 'woocommerce_pdf_watermark_horizontal_offset' ) ) ? get_option( 'woocommerce_pdf_watermark_horizontal_offset' ) . 'px' : '0px';
			$voffset = ! empty( get_option( 'woocommerce_pdf_watermark_vertical_offset' ) ) ? get_option( 'woocommerce_pdf_watermark_vertical_offset' ) . 'px' : '0px';
			$opacity = ! empty( get_option( 'woocommerce_pdf_watermark_opacity' ) ) ? get_option( 'woocommerce_pdf_watermark_opacity' ) : '1';

			$uploads = wp_upload_dir();
			$watermark_image_path = str_replace( $uploads['baseurl'], $uploads['basedir'], $image );
			$ext = pathinfo( $image, PATHINFO_EXTENSION );
			$watermarkLogoName = pathinfo( $image, PATHINFO_FILENAME );

			$watermarkLogo = $watermarkLogoName . '.' . $ext;
			$watermarkLogo = $image;

			if ( ! extension_loaded( 'zip' ) || ! file_exists( $source ) ) {
				return false;
			}

			$zip = new ZipArchive();
			if ( ! $zip->open( $destination, ZIPARCHIVE::CREATE ) ) {
				return false;
			}

			$source = str_replace( '\\', '/', realpath( $source ) );
			if ( $flag ) {
				$flag = basename( $source ) . '/';
				// $zip->addEmptyDir(basename($source) . '/');
			}

			if ( is_dir( $source ) === true ) {
				$files = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $source ), RecursiveIteratorIterator::SELF_FIRST );
				foreach ( $files as $file ) {
					$file = str_replace( '\\', '/', realpath( $file ) );

					if ( is_dir( $file ) === true ) {
						$zip->addEmptyDir( str_replace( $source . '/', '', $flag . $file . '/' ) );
					} else if ( is_file( $file ) === true ) {
						// echo $file; echo '<br>';
						$arr = explode( '/', $file );
						$file_parts = pathinfo( $file );
						if ( 'css' == $file_parts['extension'] ) {
							$fp = fopen( $file, 'a' );
							if ( 'text' == $type ) {
								fwrite( $fp, " body::after {content: '$text';opacity:$opacity;padding-left: $loffset;padding-top: $voffset;position: fixed; $vposition: 0; $hposition: 0;color:$color; font-family: $font; font-size: $fontSize; $isBold $isItalic $isunderline} " );
							} elseif ( 'image' == $type ) {
								// fwrite($fp, " body{background: linear-gradient(rgba(255,255,255,$opacity), rgba(255,255,255,$opacity)), url($image);background-repeat: no-repeat;background-size: 110px;background-attachment: fixed;background-position: $hposition $vposition; }");
								fwrite( $fp, " body{background: linear-gradient(rgba(255,255,255, $opacity), rgba(255,255,255,$opacity)), url($watermarkLogo);background-repeat: no-repeat;background-size: 110px;background-attachment: fixed;background-position: $hposition $vposition; }" );
							} elseif ( 'both' == $type ) {
								fwrite( $fp, " body::after {content: '$text';opacity:$opacity;padding-left: $loffset;padding-top: $voffset;position: fixed; $vposition: 0; $hposition: 0;color:$color; font-family: $font; font-size: $fontSize; $isBold $isItalic $isunderline} " );
								// fwrite($fp, " body{background: linear-gradient(rgba(255,255,255,$opacity), rgba(255,255,255,$opacity)), url($image);background-repeat: no-repeat;background-size: 110px;background-attachment: fixed;background-position: $hposition $vposition;}");
								fwrite( $fp, "body{background: linear-gradient(rgba(255,255,255,$opacity), rgba(255,255,255,$opacity)), url($watermarkLogo);background-repeat: no-repeat;background-size: 110px;background-attachment: fixed;background-position: $hposition $vposition;}" );
							}
							fclose( $fp );
							/*
							 upload image to css folder */
							// $pos = strpos( $file_parts['dirname'], $extractFolder ) === false ? 0 : $pos;
							$pos = strpos( $file_parts['dirname'], $extractFolder );
							$pos = ( false === $pos ) ? 0 : $pos;
							$stringParts = substr( $file_parts['dirname'], $pos );
							$stringParts = str_replace( $extractFolder . '/', '', $stringParts );
							if ( !empty($watermark_image_path) && file_exists($watermark_image_path) ) {
							$content = file_get_contents( $watermark_image_path );
							if ( $stringParts == $extractFolder ) {
								$zip->addFromString( ( $flag . $watermarkLogo ), $content );
							} else {
								$zip->addFromString( ( $stringParts . '/' . $flag . $watermarkLogo ), $content );
							}

							} else {
								// Handle the case where the watermark image path is empty or file doesn't exist
								error_log('Watermark image path is either empty or the file does not exist.');
							}	
						}

						$zip->addFromString( str_replace( $source . '/', '', $flag . $file ), file_get_contents( $file ) );
					}
				}
			} else if ( is_file( $source ) === true ) {
				$file_parts = pathinfo( $source );
				if ( 'css' == $file_parts['extension'] ) {
					$fp = fopen( $file, 'a' );
					if ( 'text' == $type ) {
						fwrite( $fp, " body::after {content: '$text';opacity:$opacity;padding-left: $loffset;padding-top: $voffset;position: fixed; $vposition: 0; $hposition: 0;color:$color; font-family: $font; font-size: $fontSize; $isBold $isItalic $isunderline} " );
					} elseif ( 'image' == $type ) {
						// fwrite($fp, " body{background: linear-gradient(rgba(255,255,255,$opacity), rgba(255,255,255,$opacity)), url($image);background-repeat: no-repeat;background-size: 110px;background-position: $hposition $vposition;background-position-x: $loffset;background-position-y: $voffset;}");
						fwrite( $fp, " body{background: linear-gradient(rgba(255,255,255,$opacity), rgba(255,255,255,$opacity)), url($watermarkLogo);background-repeat: no-repeat;background-size: 110px;background-position: $hposition $vposition;}" );
					} elseif ( 'both' == $type ) {
						fwrite( $fp, " body::after {content: '$text';opacity:$opacity;padding-left: $loffset;padding-top: $voffset;position: fixed; $vposition: 0; $hposition: 0;color:$color; font-family: $font; font-size: $fontSize; $isBold $isItalic $isunderline} " );
						// fwrite($fp, " body{background: linear-gradient(rgba(255,255,255,$opacity), rgba(255,255,255,$opacity)), url($image);background-repeat: no-repeat;background-size: 110px;background-position: $hposition $vposition;background-position-x: $loffset;background-position-y: $voffset;}");
						fwrite( $fp, " body{background: linear-gradient(rgba(255,255,255,$opacity), rgba(255,255,255,$opacity)), url($watermarkLogo);background-repeat: no-repeat;background-size: 110px;background-position: $hposition $vposition;}" );
					}
					fclose( $fp );
					/*
					 upload image to css folder */
					// $pos = strpos( $file_parts['dirname'], $extractFolder ) === false ? 0 : $pos;
					$pos = strpos( $file_parts['dirname'], $extractFolder );
					$pos = ( false === $pos ) ? 0 : $pos;
					$stringParts = substr( $file_parts['dirname'], $pos );
					$stringParts = str_replace( $extractFolder . '/', '', $stringParts );
					$content = file_get_contents( $watermark_image_path );
					if ( $stringParts == $extractFolder ) {
						$zip->addFromString( ( $flag . $watermarkLogo ), $content );
					} else {
						$zip->addFromString( ( $stringParts . '/' . $flag . $watermarkLogo ), $content );
					}
					/* upload image to css folder */
				}

				$zip->addFromString( $flag . basename( $source ), file_get_contents( $source ) );

			}

			// $content = file_get_contents($watermark_image_path);
			// $zip->addFromString(str_replace($source . '/', '', $flag.$watermarkLogo), $content);

			return $zip->close();
		}

		/**
		 * Actual watermark of a PDF file
		 *
		 * @param  string $original_file Original file path
		 * @param  int    $order_id
		 * @param  int    $product_id
		 * @return string New file path
		 */
		public function watermark_file( $original_file, $product_id, $order_id ) {

			if ( ! class_exists( 'WC_PDF_Watermarker' ) ) {
				require_once 'class-wc-pdf-watermarker.php';
			}

			$pdf = new WC_PDF_Watermarker( $original_file );

			// Add fallback to use a custom dir in wp-content/uploads should host not have tmp folder.
			$new_file_path = self::get_temporary_file_folder();
			$file_name = self::get_temporary_file_name( $original_file );

			// Make provision for local and remote hosted files.
			if ( self::is_local_file( $original_file ) ) {
				// We have a local file
				$pdf->watermark( $order_id, $product_id, $original_file, $file_name );
			} else {
				// We have a remote file.
				$remote_name = $file_name . '.remote';
				self::fetch_remote_file( $original_file, $new_file_path . $remote_name );
				$pdf->watermark( $order_id, $product_id, $new_file_path . $remote_name, $file_name );
				// Delete downloaded file.
				unlink( $remote_name );
			}

			$new_file = $file_name;

			// Set the stamped file so we can delete it via shutdown hook.
			$this->stamped_file[] = $new_file;

			return $new_file;
		}

		/**
		 * Fetch the download data for a specific download
		 *
		 * @param  int    $product_id
		 * @param  string $order_key
		 * @param  int    $download_id
		 * @return object
		 */
		public function get_download_data( $product_id, $order_key, $download_id ) {
			global $wpdb;
			$wpdb->woocommerce_downloadable_product_permissions = $wpdb->prefix . 'woocommerce_downloadable_product_permissions ';

			return $wpdb->get_row( $wpdb->prepare( " SELECT * FROM {$wpdb->woocommerce_downloadable_product_permissions} WHERE order_key = %s AND product_id = %s AND download_id = %s ", array( $order_key, $product_id, $download_id ) ) );
		} // End get_download_data()

		/**
		 * Check if there is a stamped file and delete it.
		 *
		 * @return void
		 */
		public function cleanup_files() {
			if ( ! empty( $this->stamped_file ) ) {
				array_map( 'unlink', $this->stamped_file );
				$this->stamped_file = array();
			}
		} // End cleanup_files()

		/**
		 * Get the plugin url
		 *
		 * @return string
		 */
		public function plugin_url() {
			return plugin_dir_url( $this->file );
		} // End plugin_url()

		/**
		 * Check if we must render a preview pdf
		 *
		 * @return void
		 */
		public function maybe_render_preview() {
			// Check if we must generate a preview pdf
			if ( isset( $_GET['pdf-watermark-preview'] ) && 1 == sanitize_text_field( $_GET['pdf-watermark-preview'] ) && isset( $_GET['pdf-watermark-preview-nonce'] ) ) {
				if ( 1 == wp_verify_nonce( sanitize_text_field( $_GET['pdf-watermark-preview-nonce'] ), 'preview-pdf' ) ) {
					if ( ! class_exists( 'WC_PDF_Watermarker' ) ) {
						require_once 'class-wc-pdf-watermarker.php';
					}
					$pdf = new WC_PDF_Watermarker();
					$test_pdf_file = plugin_dir_path( trailingslashit( woocommerce_pdf_watermark()->file ) ) . 'assets/pdf/pdf-sample.pdf';
					$pdf->watermark( null, null, $test_pdf_file, null, true );
					die();
				}
			}
		} // End maybe_render_preview()

		/**
		 * Output settings screen scripts
		 *
		 * @return void
		 */
		public function admin_scripts() {
			$screen = get_current_screen();
			$wc_screen_id = sanitize_title( __( 'WooCommerce', 'woocommerce' ) );
			if ( in_array( $screen->id, array( $wc_screen_id . '_page_wc-settings' ) ) ) {
				wp_enqueue_script( 'wc-pdf-admin-settings', woocommerce_pdf_watermark()->plugin_url() . 'assets/js/admin/settings.js', array( 'jquery' ), woocommerce_pdf_watermark()->version );
			}
		} // End admin_scripts()


		public function file_compatibility_check() {
			global $post;

			$screen = get_current_screen();
			if ( 'product' !== $screen->id ) {
				return;
			}

			$product_id = $post->ID;

			$product = wc_get_product( $product_id );

			if ( ! $product ) {
				return;
			}

			$files_to_evaluate = array();

			// Build a list of files to test, eliminating duplicates

			if ( $product->is_type( 'variable' ) ) {

				$available_variations = $product->get_available_variations();

				foreach ( $product->get_children() as $child_id ) {

					if ( 'yes' == get_post_meta( $child_id, '_pdf_watermark_disable', true ) ) {
						continue;
					}

					$variation = wc_get_product( $child_id );

					$files = is_callable( array( $variation, 'get_downloads' ) ) ? $variation->get_downloads() : $variation->get_files();

					foreach ( (array) $files as $file ) {

						if ( self::has_pdf_extension( $file['file'] ) ) {

							$files_to_evaluate[] = $file;

						}
					}
				}
			} else {

				// Check single product

				if ( 'yes' == get_post_meta( $product_id, '_pdf_watermark_disable', true ) ) {
					return;
				}

				$files = is_callable( array( $product, 'get_downloads' ) ) ? $product->get_downloads() : $product->get_files();

				foreach ( (array) $files as $file ) {

					if ( self::has_pdf_extension( $file['file'] ) ) {

						$files_to_evaluate[] = $file;

					}
				}
			}

			// If we have any files to evaluate, evaluate them now

			if ( 0 === count( $files_to_evaluate ) ) {
				return;
			}

			// Generate a hash of the file array - if it has not changed since the last
			// successful check, don't bother running the compatibility check again
			// since this is kinda expensive, especially for remote files
			$checksum = hash( 'md5', json_encode( $files_to_evaluate ) );
			$last_good_checksum = get_post_meta( $product_id, '_pdf_watermark_compatibility_checksum', true );

			if ( $checksum === $last_good_checksum ) {
				return;
			}

			$incompatible_files = array();

			// evaluate each attached file for compatibility with the watermarker

			if ( ! class_exists( 'WC_PDF_Watermarker' ) ) {
				require_once 'class-wc-pdf-watermarker.php';
			}

			$pdf = new WC_PDF_Watermarker();

			foreach ( (array) $files_to_evaluate as $file_to_evaluate ) {

				$upload_dir = wp_get_upload_dir(); // Get the upload directory details.
				$uploads_base_url = $upload_dir['baseurl'];

				$uploads_base_dir = $upload_dir['basedir'];

				// Setup a new file to process.
				$original_file = str_replace( $uploads_base_url, $uploads_base_dir, $file_to_evaluate['file'] );

				// Attempt to coerce to a local path
				// $original_file = str_replace( WP_CONTENT_URL, WP_CONTENT_DIR, $file_to_evaluate['file'] );

				if ( self::is_local_file( $original_file ) ) {

					if ( false === $pdf->tryOpen( $original_file ) ) {
						$incompatible_files[] = $file_to_evaluate;
					}
				} else {

					$new_file_path = self::get_temporary_file_folder();
					$file_name = self::get_temporary_file_name( $original_file );
					$remote_name = $file_name . '.remote';
					self::fetch_remote_file( $original_file, $new_file_path . $remote_name );

					if ( false === $pdf->tryOpen( $new_file_path . $remote_name ) ) {
						$incompatible_files[] = $file_to_evaluate;
					}

					unlink( $new_file_path . $remote_name );

				}
			}

			if ( 0 === count( $incompatible_files ) ) {
				// update the checksum to avoid running this again until the files change
				$checksum = hash( 'md5', json_encode( $files_to_evaluate ) );
				update_post_meta( $product_id, '_pdf_watermark_compatibility_checksum', $checksum );
				return;
			}

			echo "<div class='error'>";

			echo '<p>';
			esc_html_e( 'The following Downloadable Files are not compatible with PDF Watermarker.  You should disable watermarking on this product or choose different files.', 'woocommerce-pdf-watermark' );
			echo '</p>';

			echo '<ol>';

			foreach ( (array) $incompatible_files as $incompatible_file ) {

				echo '<li>';
				echo esc_html( $incompatible_file['name'] . ' - ' . $incompatible_file['file'] );
				echo '</li>';

			}

			echo '</ol>';

			echo '</div>';
		}
		/**
		 * Tahnkyou page hook callback.
		 */
		public function thankyou_callback( $order_id ) {

			if ( ! $order_id ) {
				return;
			}

			$order = wc_get_order( $order_id );

			if ( ! $order ) {
				return;
			}

			$pdfs = array();

			// Loop through order items to find downloadable products.
			foreach ( $order->get_items() as $item_id => $item ) {
				$product = $item->get_product();
				if ( $product && $product->is_downloadable() ) {
					$downloads = $product->get_downloads();

					// Collect all downloadable file URLs for the product.
					foreach ( $downloads as $download_id => $download_data ) {
						$pdfs[] = $download_data['file']; // Add the file URL to the array.
					}
				}
			}

			// Localize script to pass the file URL to JavaScript.
			if ( ! empty( $pdfs ) ) {

				wp_enqueue_script( 'pdfjs-lib', 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.14.305/pdf.min.js', array( 'jquery' ), '2.14.305', true );
				wp_enqueue_script( 'pdfjs-worker', 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.14.305/pdf.worker.min.js', array( 'jquery' ), '2.14.305', true );
				wp_enqueue_script( 'pdf-custom', plugin_dir_url( __DIR__ ) . 'assets/js/public/pdf-custom.js', array( 'jquery' ), '1.0.0', true );
				wp_localize_script(
					'pdf-custom',
					'pdfAjax',
					array(
						'ajaxurl'     => admin_url( 'admin-ajax.php' ),
						'file_urls'   => $pdfs,
						'pdf_nonce'   => wp_create_nonce( 'annot-nonce' ),
						'index_nonce' => wp_create_nonce( 'index-nonce' ),
					)
				);
			}
			echo "<div class='pdf-containers' style='display:none'>";

			foreach ( $pdfs as $index => $url ) {
				echo '<canvas id="pdf-canvas-' . esc_attr( $index ) . '" data-index="' . esc_attr( $index ) . '" data-file-url="' . esc_url( $url ) . '"></canvas>';
			}

			echo '</div>';
		}
	}

}
