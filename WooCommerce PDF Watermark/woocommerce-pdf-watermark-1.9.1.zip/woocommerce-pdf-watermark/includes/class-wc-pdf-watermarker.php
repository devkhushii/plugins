<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use setasign\Fpdi\Fpdi;
use setasign\FpdiProtection\FpdiProtection;
use LittlePackage\lib\tcpdi\pauln\tcpdi\TCPDI;

if ( ! class_exists( 'WC_PDF_Watermarker' ) ) {

	class WC_PDF_Watermarker {

		private $pdf;

		/**
		 * Constructor
		 *
		 * @return void
		 */
		public function __construct() {
			// Include the PDF libs.

			$this->includes();
			$this->tcpdi = new TCPDI( 'P', 'pt' );
		}

		/**
		 * Include PDF libraries
		 *
		 * @return void
		 */
		public function includes() {
			// Include FPDF.
			if ( ! class_exists( 'FPDF' ) ) {
				require_once 'lib/fpdf/fpdf.php';
			}
			// Include FPDI.
			if ( ! class_exists( 'FPDI' ) ) {
				require_once 'lib/fpdi/autoloadFPDI.php';
			}
			// Include FPDI Protection.
			if ( ! class_exists( 'FPDI_Protection' ) ) {
				require_once 'lib/fpdi/autoloadFPDI_Protection.php';
			}
			if ( ! class_exists( 'TCPDF' ) ) {
				require_once 'lib/tcpdf/tcpdf/tcpdf.php';
			}
			if ( ! class_exists( 'TCPDF_Child' ) ) {
				require_once 'lib/tcpdf/tcpdf_child.php';
			}
			if ( ! class_exists( 'TCPDI' ) ) {
				require_once 'lib/tcpdi/tcpdi.php';
			}
		} // End includes()




		/**
		 * Test file for open-ability
		 *
		 * @return int number of pages in document, false otherwise
		 */
		public function tryOpen( $file ) {

			try {
				$pagecount = $this->tcpdi->setSourceFile( $file );
			} catch ( Exception $e ) {
				return false;
			}

			return $pagecount;
		}

		/**
		 * Apply the watermark to the file.
		 *
		 * @return void
		 */

		public function watermark( $order_id, $product_id, $file, $new_file, $preview = false ) {
			// Set up the PDF file.

			$pagecount = $this->tryOpen( $file );
			if ( false == $pagecount ) {
				wp_die( esc_html( __( 'Unable to serve the file at this time.  The file does not support watermarking.', 'woocommerce-pdf-watermark' ) ) );
			}

			$this->tcpdi->SetAutoPageBreak( 0 );
			$this->tcpdi->SetMargins( 0, 0 );

			session_start();
			$current_pdf_index = isset( $_SESSION['pdf_index'] ) ? sanitize_text_field( $_SESSION['pdf_index'] ) : 0;

			$annotations = isset( $_SESSION['annotations'][ $current_pdf_index ] ) ? $_SESSION['annotations'][ $current_pdf_index ] : array();

			// Get WC PDF Watermark Settings.
			$type     = get_option( 'woocommerce_pdf_watermark_type' );
			$x_pos    = get_option( 'woocommerce_pdf_watermark_font_horizontal' );
			$y_pos    = get_option( 'woocommerce_pdf_watermark_font_vertical' );
			$opacity  = get_option( 'woocommerce_pdf_watermark_opacity', '1' );
			$override = get_post_meta( $product_id, '_pdf_watermark_override', true );
			/**
			 * Apply_filters woocommerce_pdf_watermark_horizontal_offset
			 *
			 * @since 2022
			 */
			$horizontal_offset = apply_filters( 'woocommerce_pdf_watermark_horizontal_offset', intval( get_option( 'woocommerce_pdf_watermark_horizontal_offset', 0 ) ), $order_id, $product_id );
			/**
			 * Apply_filters woocommerce_pdf_watermark_horizontal_offset
			 *
			 * @since 2022
			 */
			$vertical_offset   = apply_filters( 'woocommerce_pdf_watermark_vertical_offset', intval( get_option( 'woocommerce_pdf_watermark_vertical_offset', 0 ) ), $order_id, $product_id );
			/**
			 * Apply_filters woocommerce_pdf_watermark_horizontal_offset
			 *
			 * @since 2022
			 */
			$display_pages     = apply_filters( 'woocommerce_pdf_watermark_page_display', get_option( 'woocommerce_pdf_watermark_page_display', 'all' ), $order_id, $product_id );

			if ( 'yes' == $override ) {
				$type = get_post_meta( $product_id, '_pdf_watermark_type', true );
			}

			if ( $type && 'text' == $type ) {

				// Get settings.
				$text = get_option( 'woocommerce_pdf_watermark_text' );
				if ( 'yes' == $override ) {
					$text = get_post_meta( $product_id, '_pdf_watermark_text', true );
				}
				/**
			 * Apply_filters woocommerce_pdf_watermark_horizontal_offset
				 *
			 * @since 2022
			 */
				$color       = $this->hex2rgb( apply_filters( 'woocommerce_pdf_watermark_font_colour', get_option( 'woocommerce_pdf_watermark_font_colour', '#000' ), $order_id, $product_id ) );
				/**
			 * Apply_filters woocommerce_pdf_watermark_horizontal_offset
				 *
			 * @since 2022
			 */
				$font        = apply_filters( 'woocommerce_pdf_watermark_font', get_option( 'woocommerce_pdf_watermark_font', 'times' ), $order_id, $product_id );
				/**
			 * Apply_filters woocommerce_pdf_watermark_horizontal_offset
				 *
			 * @since 2022
			 */
				$size        = apply_filters( 'woocommerce_pdf_watermark_font_size', get_option( 'woocommerce_pdf_watermark_font_size', '8' ), $order_id, $product_id );
				$line_height = is_numeric( $size ) ? $size : 8;
				/**
			 * Apply_filters woocommerce_pdf_watermark_horizontal_offset
				 *
			 * @since 2022
			 */
				$bold        = apply_filters( 'woocommerce_pdf_watermark_font_style_bold', get_option( 'woocommerce_pdf_watermark_font_style_bold' ), $order_id, $product_id );
				/**
			 * Apply_filters woocommerce_pdf_watermark_horizontal_offset
				 *
			 * @since 2022
			 */
				$italics     = apply_filters( 'woocommerce_pdf_watermark_font_style_italics', get_option( 'woocommerce_pdf_watermark_font_style_italics' ), $order_id, $product_id );
				/**
			 * Apply_filters woocommerce_pdf_watermark_horizontal_offset
				 *
			 * @since 2022
			 */
				$underline   = apply_filters( 'woocommerce_pdf_watermark_font_style_underline', get_option( 'woocommerce_pdf_watermark_font_style_underline' ), $order_id, $product_id );

				// Build style var.
				$style = '';
				if ( $bold && 'yes' == $bold ) {
					$style .= 'B';
				}
				if ( $italics && 'yes' == $italics ) {
					$style .= 'I';
				}
				if ( $underline && 'yes' == $underline ) {
					$style .= 'U';
				}

				// Assign font.
				$this->tcpdi->SetFont( $font, $style, $size );

				$text = $this->parse_template_tags( $order_id, $product_id, $text );
				if ( function_exists( 'iconv' ) ) {
					$text = iconv( 'UTF-8', 'ISO-8859-1//TRANSLIT', $text );
				} else {
					$text = html_entity_decode( mb_convert_encoding( $text, 'UTF-8', 'ISO-8859-1' ), ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML401 );
				}
				$text = html_entity_decode( $text, ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML401 );
				// Get number of lines of text, can use a new line to go to a new line.
				$lines = 1;
				if ( stripos( $text, "\n" ) !== false ) {
					$lines        = explode( "\n", $text );
					$text         = explode( "\n", $text );
					$lines        = count( $lines );
					$longest_text = 0;
					foreach ( $text as $line ) {
						if ( $this->tcpdi->GetStringWidth( $line ) > $this->tcpdi->GetStringWidth( $longest_text ) ) {
							$longest_text = $this->tcpdi->GetStringWidth( $line );
						}
					}
				} else {
					$longest_text = $this->tcpdi->GetStringWidth( $text );
				}
				// Loop through pages to add the watermark.
				for ( $i = 1; $i <= $pagecount; $i++ ) {
					$tplidx = $this->tcpdi->importPage( $i );
					$specs  = $this->tcpdi->getTemplateSize( $tplidx );

					$orientation = ( $specs['h'] > $specs['w'] ? 'P' : 'L' );

					$this->tcpdi->addPage( $orientation, array( $specs['w'], $specs['h'] ) );
					$this->tcpdi->useTemplate( $tplidx );

					// Check if we must skip this page based on the display on page setting.
					if ( 'first' == $display_pages && 1 !== $i ) {
						continue;
					} else if ( 'last' == $display_pages && $i !== $pagecount ) {
						continue;
					} else if ( 'alternate' == $display_pages ) {
						if ( ( $i % 2 ) == 0 ) {
							continue;
						}
					}

					// Horizontal Alignment for Cell function.
					$x = 0;
					if ( 'right' == $x_pos ) {
						$x = $specs['w'];
					} elseif ( 'center' == $x_pos ) {
						$x = ( $specs['w'] / 2 );
					} elseif ( 'left' == $x_pos ) {
						$x = 0;
					}

					// Vertical Alignment for setY function.
					$y = 0;
					if ( 'bottom' == $y_pos ) {
						$y = $specs['height'] - ( ( $line_height * $lines ) + 7 );
					} elseif ( 'middle' == $y_pos ) {
						$y = ( $specs['height'] / 2 ) - ( $line_height / 2 );
					} elseif ( 'top' == $y_pos ) {
						$y = $line_height / 2;
					}

					// Vertical offset.
					$y += $vertical_offset;

					$this->tcpdi->setY( $y );
					$this->tcpdi->SetAlpha( $opacity );
					$this->tcpdi->SetTextColor( $color[0], $color[1], $color[2] );

					// Put the text watermark down with Cell.
					if ( is_array( $text ) ) {
						foreach ( $text as $line ) {
							if ( 'right' == $x_pos ) {
								$_x = $x - ( $this->tcpdi->GetStringWidth( $line ) + 7 );
							} elseif ( 'center' == $x_pos ) {
								$_x = $x - ( $this->tcpdi->GetStringWidth( $line ) / 2 );
							} else {
								$_x = $x;
							}

							// Horizontal Offset
							$_x += $horizontal_offset;

							$this->tcpdi->SetXY( $_x, $y );
							$this->tcpdi->Write( $line_height, $line );
							$this->tcpdi->importAnnotations( $i );
							$y += $line_height;
						}
					} else {
						if ( 'right' == $x_pos ) {
							$_x = $x - ( $this->tcpdi->GetStringWidth( $text ) + 7 );
						} elseif ( 'center' == $x_pos ) {
							$_x = $x - ( $this->tcpdi->GetStringWidth( $text ) / 2 );
						} else {
							$_x = $x;
						}

						// Horizontal Offset.
						$_x += $horizontal_offset;

						$this->tcpdi->SetXY( $_x, $y );
						$this->tcpdi->Write( $line_height, $text );
						$this->tcpdi->importAnnotations( $i );
						$this->importToC( $annotations, $i );

					}
					$this->tcpdi->setAlpha( 1 );

				} // End forloop
			} elseif ( $type && 'image' == $type ) {
				$image      = get_option( 'woocommerce_pdf_watermark_image' );
				if ( 'yes' == $override ) {
					$image = get_post_meta( $product_id, '_pdf_watermark_image', true );
				}

				$upload_dir = wp_get_upload_dir(); // Get the upload directory details.
				$uploads_base_url = $upload_dir['baseurl'];

				$uploads_base_dir = $upload_dir['basedir'];

				// Setup a new file to process.
				$image = str_replace( $uploads_base_url, $uploads_base_dir, $image );

				$image_info = getimagesize( $image );
				$width      = $image_info[0];
				$height     = $image_info[1];

				for ( $i = 1; $i <= $pagecount; $i++ ) {
					$tplidx      = $this->tcpdi->importPage( $i );
					$specs       = $this->tcpdi->getTemplateSize( $tplidx );
					$orientation = ( $specs['h'] > $specs['w'] ? 'P' : 'L' );

					$this->tcpdi->addPage( $orientation, array( $specs['w'], $specs['h'] ) );
					$this->tcpdi->useTemplate( $tplidx );
					$this->tcpdi->importAnnotations( $i );
					$this->importToC( $annotations, $i );
					// Check if we must skip this page based on the display on page setting.
					if ( 'first' == $display_pages && 1 !== $i ) {
						continue;
					} else if ( 'last' == $display_pages && $i !== $pagecount ) {
						continue;
					} else if ( 'alternate' == $display_pages ) {
						if ( ( $i % 2 ) == 0 ) {
							continue;
						}
					}

					// Horizontal alignment.
					$x = 0;
					if ( 'right' == $x_pos ) {
						$x = $specs['w'] - ( $width * 20 / 72 );
					} elseif ( 'center' == $x_pos ) {
						$x = ( $specs['w'] / 2 ) - ( $width * 20 / 72 );
					} elseif ( 'left' == $x_pos ) {
						$x = '0';
					}
					// Horizontal Offset.
					$x += $horizontal_offset;

					// Vertical alignment.
					$y = 0;
					if ( 'bottom' == $y_pos ) {
						$y = $specs['h'] - ( $height );
					} elseif ( 'middle' == $y_pos ) {
						$y = ( $specs['h'] / 2 ) - ( $height );
					} elseif ( 'top' == $y_pos ) {
						$y = '0';
					}
					// Vertical offset.
					$y += $vertical_offset;

					$this->tcpdi->SetAlpha( $opacity );
					$this->tcpdi->Image( $image, $x, $y );
					$this->tcpdi->SetAlpha( 1 );
				} // End forloop
			} else if ( $type && 'both' == $type ) {

				// Get settings.
				$text        = get_option( 'woocommerce_pdf_watermark_text' );
				if ( 'yes' == $override ) {
					$text = get_post_meta( $product_id, '_pdf_watermark_text', true );
				}
				/**
			 * Apply_filters woocommerce_pdf_watermark_horizontal_offset
				 *
			 * @since 2022
			 */
				$color       = $this->hex2rgb( apply_filters( 'woocommerce_pdf_watermark_font_colour', get_option( 'woocommerce_pdf_watermark_font_colour', '#000' ), $order_id, $product_id ) );
				/**
			 * Apply_filters woocommerce_pdf_watermark_horizontal_offset
				 *
			 * @since 2022
			 */
				$font        = apply_filters( 'woocommerce_pdf_watermark_font', get_option( 'woocommerce_pdf_watermark_font', 'times' ), $order_id, $product_id );
				/**
			 * Apply_filters woocommerce_pdf_watermark_horizontal_offset
				 *
			 * @since 2022
			 */
				$size        = apply_filters( 'woocommerce_pdf_watermark_font_size', get_option( 'woocommerce_pdf_watermark_font_size', '8' ), $order_id, $product_id );
				$line_height = is_numeric( $size ) ? $size : 8;
				/**
			 * Apply_filters woocommerce_pdf_watermark_horizontal_offset
				 *
			 * @since 2022
			 */
				$bold        = apply_filters( 'woocommerce_pdf_watermark_font_style_bold', get_option( 'woocommerce_pdf_watermark_font_style_bold' ), $order_id, $product_id );
				/**
			 * Apply_filters woocommerce_pdf_watermark_horizontal_offset
				 *
			 * @since 2022
			 */
				$italics     = apply_filters( 'woocommerce_pdf_watermark_font_style_italics', get_option( 'woocommerce_pdf_watermark_font_style_italics' ), $order_id, $product_id );
				/**
			 * Apply_filters woocommerce_pdf_watermark_horizontal_offset
				 *
			 * @since 2022
			 */
				$underline   = apply_filters( 'woocommerce_pdf_watermark_font_style_underline', get_option( 'woocommerce_pdf_watermark_font_style_underline' ), $order_id, $product_id );

				// Build style var.
				$style = '';
				if ( $bold && 'yes' == $bold ) {
					$style .= 'B';
				}
				if ( $italics && 'yes' == $italics ) {
					$style .= 'I';
				}
				if ( $underline && 'yes' == $underline ) {
					$style .= 'U';
				}

				// Assign font.
				$this->tcpdi->SetFont( $font, $style, $size );

				$text = $this->parse_template_tags( $order_id, $product_id, $text );
				if ( function_exists( 'iconv' ) ) {
					$text = iconv( 'UTF-8', 'ISO-8859-1//TRANSLIT', $text );
				} else {
					$text = html_entity_decode( mb_convert_encoding( $text, 'HTML-ENTITIES', 'UTF-8' ), ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML401 );
				}
				$text = html_entity_decode( $text, ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML401 );
				// Get number of lines of text, can use a new line to go to a new line.
				$lines = 1;
				if ( stripos( $text, "\n" ) !== false ) {
					$lines        = explode( "\n", $text );
					$text         = explode( "\n", $text );
					$lines        = count( $lines );
					$longest_text = 0;
					foreach ( $text as $line ) {
						if ( $this->tcpdi->GetStringWidth( $line ) > $this->tcpdi->GetStringWidth( $longest_text ) ) {
							$longest_text = $this->tcpdi->GetStringWidth( $line );
						}
					}
				} else {
					$longest_text = $this->tcpdi->GetStringWidth( $text );
				}

				// Loop through pages to add the watermark.

				$image = get_option( 'woocommerce_pdf_watermark_image' );
				if ( 'yes' == $override ) {
					$image = get_post_meta( $product_id, '_pdf_watermark_image', true );
				}

				$upload_dir       = wp_get_upload_dir(); // Get the upload directory details.
				$uploads_base_url = $upload_dir['baseurl'];

				$uploads_base_dir = $upload_dir['basedir'];

				// Setup a new file to process.
				$image = str_replace( $uploads_base_url, $uploads_base_dir, $image );

				$image_info = getimagesize( $image );
				$width      = $image_info[0];
				$height     = $image_info[1];

				// Loop through pages to add the watermark.
				for ( $i = 1; $i <= $pagecount; $i++ ) {
					$tplidx      = $this->tcpdi->importPage( $i );
					$specs       = $this->tcpdi->getTemplateSize( $tplidx );
					$orientation = ( $specs['h'] > $specs['w'] ? 'P' : 'L' );

					$this->tcpdi->addPage( $orientation, array( $specs['w'], $specs['h'] ) );
					$this->tcpdi->useTemplate( $tplidx );
					$this->tcpdi->importAnnotations( $i );
					$this->importToC( $annotations, $i );
					// Check if we must skip this page based on the display on page setting.
					if ( 'first' == $display_pages && 1 !== $i ) {
						continue;
					} else if ( 'last' == $display_pages && $i !== $pagecount ) {
						continue;
					} else if ( 'alternate' == $display_pages ) {
						if ( ( $i % 2 ) == 0 ) {
							continue;
						}
					}

					// Horizontal alignment.
					$x = 0;
					if ( 'right' == $x_pos ) {
						$x = $specs['w'] - ( $width * 20 / 72 );
					} elseif ( 'center' == $x_pos ) {
						$x = ( $specs['w'] / 2 ) - ( $width * 20 / 72 );
					} elseif ( 'left' == $x_pos ) {
						$x = '0';
					}

					// Horizontal Offset.
					$x += $horizontal_offset;

					// Vertical alignment.
					$y = 0;
					if ( 'bottom' == $y_pos ) {
						$y = $specs['h'] - ( $height );
					} elseif ( 'middle' == $y_pos ) {
						$y = ( $specs['h'] / 2 ) - ( $height );
					} elseif ( 'top' == $y_pos ) {
						$y = '0';
					}

					// Vertical offset.
					$y += $vertical_offset;

					$this->tcpdi->setY( $y );
					$this->tcpdi->setAlpha( $opacity );
					$this->tcpdi->SetTextColor( $color[0], $color[1], $color[2] );

					// Put the text watermark down with Cell.
					if ( is_array( $text ) ) {
						foreach ( $text as $line ) {
							if ( 'right' == $x_pos ) {
								$_x = $x - ( $this->tcpdi->GetStringWidth( $line ) + 7 );
							} elseif ( 'center' == $x_pos ) {
								$_x = $x - ( $this->tcpdi->GetStringWidth( $line ) / 2 );
							} else {
								$_x = $x;
							}

							// Horizontal Offset.
							$_x += $horizontal_offset;

							$this->tcpdi->SetXY( $_x, $y );
							$this->tcpdi->Write( $line_height, $line );
							$y += $line_height;
						}
					} else {
						if ( 'right' == $x_pos ) {
							$_x = $x - ( $this->tcpdi->GetStringWidth( $text ) + 7 );
						} elseif ( 'center' == $x_pos ) {
							$_x = $x - ( $this->tcpdi->GetStringWidth( $text ) / 2 );
						} else {
							$_x = $x;
						}

						// Horizontal Offset.
						$_x += $horizontal_offset;

						$this->tcpdi->SetXY( $_x, $y );
						$this->tcpdi->Write( $line_height, $text );
					}
					$this->tcpdi->setAlpha( 1 );

					// Horizontal alignment.
					$x = 0;
					if ( 'right' == $x_pos ) {
						$x = $specs['w'] - ( $width * 20 / 72 );
					} elseif ( 'center' == $x_pos ) {
						$x = ( $specs['w'] / 2 ) - ( $width * 20 / 72 );
					} elseif ( 'left' == $x_pos ) {
						$x = '0';
					}
					// Horizontal Offset.
					$x += $horizontal_offset;

					// Horizontal Offset.
					$x += $horizontal_offset;

					// Vertical alignment.
					$y = 0;
					if ( 'bottom' == $y_pos ) {
						$y = $specs['h'] - ( $height );
					} elseif ( 'middle' == $y_pos ) {
						$y = ( $specs['h'] / 2 ) - ( $height );
					} elseif ( 'top' == $y_pos ) {
						$y = '0';
					}
					// Vertical offset.
					$y += $vertical_offset;

					$this->tcpdi->SetAlpha( $opacity );
					$this->tcpdi->Image( $image, $x, $y );
					$this->tcpdi->SetAlpha( 1 );

				} // End forloop
			}
			/**
			 * Apply_filters woocommerce_pdf_watermark_horizontal_offset
			 *
			 * @since 2022
			 */
			$password_protect      = apply_filters( 'woocommerce_pdf_watermark_password_protects', get_option( 'woocommerce_pdf_watermark_password_protects', 'no' ), $order_id, $product_id );
			/**
			 * Apply_filters woocommerce_pdf_watermark_horizontal_offset
			 *
			 * @since 2022
			 */
			$do_not_allow_copy = apply_filters( 'woocommerce_pdf_watermark_copy_protection', get_option( 'woocommerce_pdf_watermark_copy_protection', 'no' ), $order_id, $product_id );
			/**
			 * Apply_filters woocommerce_pdf_watermark_horizontal_offset
			 *
			 * @since 2022
			 */
			$do_not_allow_print = apply_filters( 'woocommerce_pdf_watermark_print_protection', get_option( 'woocommerce_pdf_watermark_print_protection', 'no' ), $order_id, $product_id );
			/**
			 * Apply_filters woocommerce_pdf_watermark_horizontal_offset
			 *
			 * @since 2022
			 */
			$do_not_allow_modify = apply_filters( 'woocommerce_pdf_watermark_modification_protection', get_option( 'woocommerce_pdf_watermark_modification_protection', 'no' ), $order_id, $product_id );
			/**
			 * Apply_filters woocommerce_pdf_watermark_horizontal_offset
			 *
			 * @since 2022
			 */
			$do_not_allow_annotate = apply_filters( 'woocommerce_pdf_watermark_annotate_protection', get_option( 'woocommerce_pdf_watermark_annotate_protection', 'no' ), $order_id, $product_id );
			/**
			 * Apply_filters woocommerce_pdf_watermark_horizontal_offset
			 *
			 * @since 2022
			 */
			$do_not_allow_epub = apply_filters( 'woocommerce_pdf_watermark_epub_watermarks', get_option( 'woocommerce_pdf_watermark_epub_watermarks', 'no' ), $order_id, $product_id );
			$protection_array  = array();
			$user_pass         = '';

			if ( 'yes' == $do_not_allow_copy ) {
				$protection_array[] = 'copy';
			}
			if ( 'yes' == $do_not_allow_print ) {
				$protection_array[] = 'print';
			}
			if ( 'yes' == $do_not_allow_modify ) {
				$protection_array[] = 'modify';
			}
			if ( 'yes' == $do_not_allow_annotate ) {
				$protection_array[] = 'annot-forms';
				$protection_array[] = 'fill-forms';
			}
			if ( 'yes' == $do_not_allow_epub ) {
				// $protection_array[] = 'epub';
			}

			if ( 'yes' == $do_not_allow_copy && 'yes' == $do_not_allow_print && 'yes' == $do_not_allow_modify && 'yes' == $do_not_allow_annotate && 'yes' == $do_not_allow_epub ) {

			} else {

				/**
				 * Apply_filters woocommerce_pdf_watermark_file_password
				 *
				 * @since 2022
				 */
				if ( ! $preview ) {
					$this->tcpdi->setProtection(
						$protection_array, // Permissions.
						apply_filters( 'woocommerce_pdf_watermark_file_password', $user_pass, $order_id, $product_id ), // User password.
						null, // Owner password.
						2 // AES 128-bit encryption.
					);
				}
			}

			if ( get_option( 'woocommerce_pdf_watermark_password_pro' ) == 'yes' ) {
				if ( 'email_id' == $password_protect ) {
					if ( ! $preview ) {
						$order     = wc_get_order( $order_id );
						$user_pass = version_compare( WC_VERSION, '3.0', '<' ) ? $order->billing_email : $order->get_billing_email();
					} else {
						$current_user = wp_get_current_user();
						$user_pass    = $current_user->user_email;
					}
				}

				if ( 'order_id' == $password_protect ) {
					if ( ! $preview ) {
						$user_pass = $order_id;
					} else {
						$current_user = wp_get_current_user();
						$user_pass    = $current_user->user_email;
					}
				}
				/**
				 * Apply_filters woocommerce_pdf_watermark_file_password
				 *
				 * @since 2022
				 */
				if ( ! $preview ) {
					$this->tcpdi->setProtection(
						$protection_array, // Permissions.
						apply_filters( 'woocommerce_pdf_watermark_file_password', $user_pass, $order_id, $product_id ), // User password.
						null, // Owner password.
						2 // AES 128-bit encryption.
					);
				}
			}
			try {
				if ( ! ob_start() ) {
					ob_start();
				}

				if ( ob_get_length() > 0 ) {
					ob_end_clean();
				}

				if ( $preview ) {

					$this->tcpdi->Output();
				} else {
					if ( headers_sent() ) {
						throw new Exception( 'Headers have already been sent. Cannot output PDF.' );
					}

					$original_filename = sanitize_file_name( basename( $file ) );
					$download_filename = $original_filename;

					// Determine the output mode based on the device.
					if ( wp_is_mobile() ) {
						// For mobile devices, display inline.
						$this->tcpdi->Output( $download_filename, 'I' ); // 'I' displays inline
					} else {
						// For desktop devices, force download.
						$this->tcpdi->Output( $download_filename, 'F' ); // 'D' forces download
					}
				}
			} catch ( Exception $e ) {
				error_log( 'Error generating PDF: ' . $e->getMessage() );
				wp_die( esc_html( __( 'Error generating PDF, please check error logs. Unable to create output file!', 'woocommerce-pdf-watermark' ) ) );
			}
		}

		/**
		 * Function to retrive Table of Contents
		 */
		public function importToC( $annotations, $i ) { // @codingStandardsIgnoreLine Generic.WhiteSpace.ScopeIndent
			foreach ( $annotations as $annotation ) {
				if ( $annotation['sourcePage'] == $i ) {
					$templateId = $this->tcpdi->importPage( $i ); // @codingStandardsIgnoreLine Generic.WhiteSpace.ScopeIndent

					// Get the original dimensions of the page.
					$pageDimensions       = $this->tcpdi->getTemplateSize( $templateId ); // @codingStandardsIgnoreLine Generic.WhiteSpace.ScopeIndent
					$page_original_height = $pageDimensions['h'];// @codingStandardsIgnoreLine Generic.WhiteSpace.ScopeIndent

					$raw_x      = $annotation['rect'][0]; // Left edge.
					$raw_y      = $annotation['rect'][1]; // Bottom edge.
					$raw_width  = $annotation['rect'][2] - $annotation['rect'][0]; // Width.
					$raw_height = $annotation['rect'][3] - $annotation['rect'][1]; // Height.

					// Apply scaling.
					$ann_x      = $raw_x;
					$ann_y      = ( $page_original_height - $raw_y ) - $raw_height; // Corrected Y-coordinate calculation.
					$ann_width  = $raw_width;
					$ann_height = $raw_height;

					// Debugging output.
					$this->tcpdi->SetXY( $ann_x, $ann_y );

					// Add a clickable link over the rectangle.
					$link = $this->tcpdi->AddLink();
					$this->tcpdi->SetLink( $link, 0, '*' . $annotation['destPage'] );
					$this->tcpdi->Link( $ann_x, $ann_y, $ann_width, $ann_height, $link );
				}
			}
		}

		/**
		 * Convert HEX color code to RGB
		 *
		 * @param  string $color HEX color code.
		 * @return array
		 */
		public function hex2rgb( $color ) {
			if ( '#' == $color[0] ) {
				$color = substr( $color, 1 );
			}

			if ( strlen( $color ) == 6 ) {
				list( $r, $g, $b ) = array(
					$color[0] . $color[1],
					$color[2] . $color[3],
					$color[4] . $color[5],
				);
			} elseif ( strlen( $color ) == 3 ) {
				list( $r, $g, $b ) = array(
					$color[0] . $color[0],
					$color[1] . $color[1],
					$color[2] . $color[2],
				);
			} else {
				return false;
			}

			$r = hexdec( $r );
			$g = hexdec( $g );
			$b = hexdec( $b );

			return array( $r, $g, $b );
		} // End hex2rgb()

		/**
		 * Parse text for template tags and populate it.
		 *
		 * @param  int    $order_id
		 * @param  string $text
		 * @return string
		 */
		public function parse_template_tags( $order_id, $product_id, $text ) {
			if ( false === strpos( $text, '{' ) ) {
				return $text;
			}

			if ( is_null( $order_id ) || is_null( $product_id ) ) {
				return $text;
			}

			$order     = wc_get_order( $order_id );
			$product   = wc_get_product( $product_id );
			$user_info = get_userdata( $order->get_customer_id() );

			$first_name      = version_compare( WC_VERSION, '3.0', '<' ) ? $order->billing_first_name : $order->get_billing_first_name();
			$last_name       = version_compare( WC_VERSION, '3.0', '<' ) ? $order->billing_last_name : $order->get_billing_last_name();
			$username        = version_compare( WC_VERSION, '3.0', '<' ) ? $user_info->user_login : $user_info->user_login;
			$email           = version_compare( WC_VERSION, '3.0', '<' ) ? $order->billing_email : $order->get_billing_email();
			$billing_company = version_compare( WC_VERSION, '3.0', '<' ) ? $order->billing_company : $order->get_billing_company();
			$order_number    = $order->get_order_number();
			$order_date      = version_compare( WC_VERSION, '3.0', '<' ) ? $order->order_date : ( $order->get_date_created() ? $order->get_date_created()->date( 'Y-m-d H:i:s' ) : '' );

			$site_name = get_bloginfo( 'name' );
			$site_url  = home_url();

			$parsed_text   = $text;
			$unparsed_text = $parsed_text;
			$full_name     = $first_name . ' ' . $last_name;
			$parsed_text   = str_replace( '{username}', $username, $parsed_text );

			$parsed_text = str_replace( '{first_name}', $first_name, $parsed_text );
			$parsed_text = str_replace( '{last_name}', $last_name, $parsed_text );
			$parsed_text = str_replace( '{full_name}', $full_name, $parsed_text );
			$parsed_text = str_replace( '{email}', $email, $parsed_text );
			$parsed_text = str_replace( '{billing_company}', $billing_company, $parsed_text );
			$parsed_text = str_replace( '{order_number}', $order_number, $parsed_text );
			$parsed_text = str_replace( '{order_date}', $order_date, $parsed_text );
			$parsed_text = str_replace( '{site_name}', $site_name, $parsed_text );
			$parsed_text = str_replace( '{site_url}', $site_url, $parsed_text );
			/**
			 * Apply_filters woocommerce_pdf_watermark_horizontal_offset
			 *
			 * @since 2022
			 */
			return apply_filters( 'woocommerce_pdf_watermark_parse_template_tags', $parsed_text, $unparsed_text, $order, $product );
		} // End parse_template_tags()
	}
}
