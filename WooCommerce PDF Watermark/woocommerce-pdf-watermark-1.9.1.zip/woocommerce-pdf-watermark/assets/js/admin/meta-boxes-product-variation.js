jQuery(function($) {
    function updateVariationOptions() {
		
        $('#variable_product_options .woocommerce_variation').each(function() {
            var $variation = $(this);
            var $watermarkDisable = $variation.find('input.variable_pdf_watermark_disable');
            var $watermarkOverride = $variation.find('input.variable_pdf_watermark_override');
            var $watermarkType = $variation.find('select.variable_pdf_watermark_type');

            // Handle PDF Watermark Disable
			
            if ($watermarkDisable.is(':checked')) {
                $variation.find('.hide_if_pdf_disabled').hide();
                $variation.find('.show_if_pdf_override').hide();
                $variation.find('.show_if_pdf_text, .show_if_pdf_image').hide();
				$variation.find('input.variable_pdf_watermark_override').prop('checked', false).change();
            } else {
                $variation.find('.hide_if_pdf_disabled').show();
            }

            // Handle PDF Watermark Override
            if ($watermarkOverride.is(':checked')) {
                $variation.find('.show_if_pdf_override').show();
                $variation.find('.show_if_pdf_text, .show_if_pdf_image').hide();
                $watermarkType.change(); // Trigger change on type selection
            } else {
                $variation.find('.show_if_pdf_override').hide();
            }

            // Handle PDF Watermark Type
            var selectedType = $watermarkType.val();
            $variation.find('.show_if_pdf_text, .show_if_pdf_image').hide();
            if (selectedType && !$watermarkDisable.is(':checked') && $watermarkOverride.is(':checked')) {
                $variation.find('.show_if_pdf_' + selectedType).show();
            }
        });
    }

    // Event listeners
    $('#variable_product_options').on('change', 'input.variable_pdf_watermark_disable', function() {
        var $variation = $(this).closest('.woocommerce_variation');
        $variation.find('.hide_if_pdf_disabled').toggle(!$(this).is(':checked'));
        $variation.find('.show_if_pdf_override').hide();
        $variation.find('.show_if_pdf_text, .show_if_pdf_image').hide();

        if ($(this).is(':checked')) {
            $variation.find('input.variable_pdf_watermark_override').prop('checked', false).change();
        }
    });

    $('#variable_product_options').on('change', 'input.variable_pdf_watermark_override', function() {
        var $variation = $(this).closest('.woocommerce_variation');
        $variation.find('.show_if_pdf_override').toggle($(this).is(':checked'));
        $variation.find('.show_if_pdf_text, .show_if_pdf_image').hide();

        if ($(this).is(':checked')) {
            $variation.find('select.variable_pdf_watermark_type').change();
        }
    });

    $('#variable_product_options').on('change', 'select.variable_pdf_watermark_type', function() {
        var $variation = $(this).closest('.woocommerce_variation');
        $variation.find('.show_if_pdf_text, .show_if_pdf_image').hide();
        $variation.find('.show_if_pdf_' + $(this).val()).show();
    });

    // Check if the variations tab is visible before running the update
    function initializeOnTabVisible() {
		
        if ($('#variable_product_options').is(':visible')) {
            setTimeout(updateVariationOptions, 500);
        }
    }

    // Run on page load
    $(document).ready(function() {
        initializeOnTabVisible();

        // Listen for clicks on the variations tab
        $('.variations_tab a').on('click', function() {
            setTimeout(initializeOnTabVisible, 100); // Delay to ensure tab content is visible
        });
    });
});
