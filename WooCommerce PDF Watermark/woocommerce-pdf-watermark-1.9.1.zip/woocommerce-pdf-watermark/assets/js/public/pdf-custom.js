document.addEventListener("DOMContentLoaded", function () {
    const fileUrls = pdfAjax.file_urls; // Array of PDF file URLs passed from PHP
    if (!fileUrls || fileUrls.length === 0) {
        console.error("No PDF files found.");
        return;
    }

    const downloadLinks = document.querySelectorAll(".download-file a");

    fileUrls.forEach((url, pdfIndex) => {
        const canvasId = `pdf-canvas-${pdfIndex}`;
        const canvas = document.getElementById(canvasId);

        downloadLinks[pdfIndex].setAttribute('data-id', pdfIndex); 

        if (!canvas) {
            console.error(`Canvas for PDF index ${pdfIndex} not found.`);
            return;
        }

        const context = canvas.getContext("2d");

        // Load the PDF and process annotations
        pdfjsLib.getDocument(url).promise.then((pdf) => {
            const totalPages = pdf.numPages;
            const pagesPromises = [];

            for (let i = 1; i <= totalPages; i++) {
                pagesPromises.push(
                    pdf.getPage(i).then((page) => {
                        return page.getAnnotations().then((annotations) => {
                            return { pageNumber: i, annotations };
                        });
                    })
                );
            }

            Promise.all(pagesPromises).then((pagesAnnotations) => {
                const annotationsWithDest = [];

                pagesAnnotations.forEach((pageData) => {
                    pageData.annotations.forEach((annotation) => {
                        if (annotation.subtype === "Link" && annotation.dest) {
                            if (typeof annotation.dest === "string") {
                                annotationsWithDest.push({
                                    sourcePage: pageData.pageNumber,
                                    dest: annotation.dest,
                                    rect: annotation.rect,
                                    pdfIndex,
                                });
                            } else if (Array.isArray(annotation.dest) && annotation.dest.length > 0) {
                                const destObj = annotation.dest[0];
                                if (destObj && typeof destObj === "object" && destObj.num) {
                                    annotationsWithDest.push({
                                        sourcePage: pageData.pageNumber,
                                        destPageObj: destObj.num,
                                        rect: annotation.rect,
                                        dest: annotation.dest,
                                        pdfIndex,
                                    });
                                }
                            }
                        }
                    });
                });

                resolveDestinations(pdf, annotationsWithDest, pdfIndex);
            });
        });
    });

    function resolveDestinations(pdf, annotationsWithDest, pdfIndex) {
        const destinationPromises = annotationsWithDest.map((annotation) => {
            if (annotation.destPageObj) {
                return pdf.getPageIndex({ num: annotation.destPageObj, gen: 0 }).then((destPageNum) => {
                    return {
                        sourcePage: annotation.sourcePage,
                        destPage: destPageNum + 1,
                        rect: annotation.rect,
                        dest: annotation.dest,
                        pdfIndex,
                    };
                }).catch((error) => {
                    console.error("Error resolving numeric destination:", error);
                    return null;
                });
            } else if (annotation.dest) {
                return pdf.getDestination(annotation.dest).then((destArray) => {
                    if (destArray) {
                        return pdf.getPageIndex(destArray[0]).then((pageIndex) => {
                            return {
                                sourcePage: annotation.sourcePage,
                                destPage: pageIndex + 1,
                                rect: annotation.rect,
                                dest: annotation.dest,
                                pdfIndex,
                            };
                        });
                    } else {
                        return null;
                    }
                }).catch((error) => {
                    console.error("Error resolving named destination:", error);
                    return null;
                });
            } else {
                return null;
            }
        });

        Promise.all(destinationPromises).then((resolvedDestinations) => {
            const validDestinations = resolvedDestinations.filter((dest) => dest !== null);

            // Send to server
            jQuery.ajax({
                url: pdfAjax.ajaxurl,
                method: "POST",
                data: {
                    action: "process_annotations",
                    annotations: validDestinations,
                    pdf_index: pdfIndex,
                    pdf_nonce: pdfAjax.pdf_nonce
                },
                success: function (response) {
                    // console.log(`Annotations for PDF ${pdfIndex + 1} processed successfully.`);
                },
                error: function (error) {
                    console.error(`Error processing annotations for PDF ${pdfIndex + 1}:`, error);
                },
            });
        });
    }
});

jQuery('.download-file a').on('click', function(e){
    e.preventDefault();
    var file_index = jQuery(this).attr('data-id');
    var file_url = jQuery(this).attr('href');
    jQuery.ajax({
        url: pdfAjax.ajaxurl,
        method: "POST",
        data: {
            action: "process_index",
            pdf_index: file_index,
            index_nonce: pdfAjax.index_nonce
        },
        success: function (response) {
            window.location.href = file_url;
        }
    })
})
