=== Robin IMage Optimizer premium  ===
Tags: clearfy, boilerplate, component
Contributors: webcraftic
Requires at least: 4.8
Tested up to: 5.7
Requires PHP: 7.0
Stable tag: trunk
License: GPLv2

Короткое описание плагина

== Description ==

Этот шаблон от Webcraftic, предназначен для быстрого создания и развертывания плагинов. Этот плагин может работать, как
самостоятельно, так и в составе плагина Clearfy, как его компонент.

https://wordpress.org/plugins/clearfy/

# Заголовок
от 1 до 5 решёток = H1–H5
Также, можно ставить закрывающие #
# Заголовок #
* Элемент маркированного списка
1. Элемент нумерованного списка
— поставить пробел перед текстом, идущим следом за элементом списка
*   Это внутренности параграфа
> Это цитата
или
<blockquote> Это цитата</blockquote>
**Жирный**
или
<strong>Жирный</strong>
*Наклонный*
или
<em>Наклонный</em>
`readme.txt`
— поставить 4 пробела перед текстом, который нужно вставить как код
http://site.com
[Мой Анкор](http://site.com)
[Мой Анкор](/slug/)
[Мой Анкор с тайтлом](http://site.com/ "Тайтл ссылки")
[youtube http://www.youtube.com/watch?v=CVmGBoPx6Ms]

== Translations ==

* Английский - по умолчанию
* Русский

== Frequently Asked Questions ==

= Вопрос 1 =

Ответ на вопрос 1

= Вопрос 2 =

Ответ на вопрос 2

== Installation ==

1. Upload the plugin folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. The plugin settings can be accessed via the 'Settings' menu in the administration area (either your site administration for single-site installs).

== Screenshots ==
1. Панель управления
2. Панель управления страница 2

== Changelog ==
= 1.0.0=
* Релиз плагина
