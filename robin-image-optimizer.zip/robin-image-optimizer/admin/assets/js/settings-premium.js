jQuery('button[data-value="googlepage"]').attr('disabled', 'disabled');
jQuery('button[data-value="background"]').attr('disabled', 'disabled');
