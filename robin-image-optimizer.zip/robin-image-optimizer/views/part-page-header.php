<?php

defined( 'ABSPATH' ) || die( 'Cheatin’ uh?' );

/**
 * @var array $data
 * @var WRIO_Page $page
 */
?>
<div class="wbcr-factory-page-group-header" style="margin:0;">
    <strong><?php echo $data['title'] ?></strong>
    <p>
		<?php echo $data['description'] ?>
    </p>
</div>

