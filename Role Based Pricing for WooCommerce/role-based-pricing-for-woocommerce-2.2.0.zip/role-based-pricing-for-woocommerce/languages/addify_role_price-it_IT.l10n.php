<?php
return array(
	'project-id-version'        =>'Role Based Pricing for WooCommerce',
	'report-msgid-bugs-to'      =>'',
	'pot-creation-date'         =>'2024-11-05 09:56+0000',
	'po-revision-date'          =>'2024-11-05 10:04+0000',
	'last-translator'           =>'',
	'language-team'             =>'Italian',
	'language'                  =>'it_IT',
	'plural-forms'              =>'nplurals=2; plural=n != 1;',
	'mime-version'              =>'1.0',
	'content-type'              =>'text/plain; charset=UTF-8',
	'content-transfer-encoding' =>'8bit',
	'x-generator'               =>'Loco https://localise.biz/',
	'x-loco-version'            =>'2.6.11; wp-6.6.1',
	'x-domain'                  =>'addify_role_price',
	'messages'                  =>array(),
);
