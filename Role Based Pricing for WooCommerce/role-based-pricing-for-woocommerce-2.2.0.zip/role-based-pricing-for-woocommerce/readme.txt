Role Based Pricing for WooCommerce

Contributors: Addify
Requires at least: 6.5
Requires PHP: 7.0
Tested up to: 6.7
License: GNU General Public License v3.0
Stable tag: 2.2.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html
