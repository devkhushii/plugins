<div class="ts-btn-ctm"><a class="button" href="<?php echo esc_url($verify_url); ?>" target="blank"> <img src= "<?php echo esc_url($tsVerifyBtn); ?>" alt="trustswiftly" width="60%" height="50%" /></a>
</div>

<style type="text/css">

div a.button:hover {
	background: #fff;
}
div a.button {
	background: #fff;
}
.ts-btn-ctm img {
	width: 36%;
}
</style>

