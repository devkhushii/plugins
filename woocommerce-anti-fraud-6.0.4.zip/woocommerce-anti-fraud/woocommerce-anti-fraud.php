<?php

/**
 * Plugin Name: WooCommerce Anti Fraud
 * Plugin URI: https://woocommerce.com/products/woocommerce-anti-fraud/
 * Description: Score each of your transactions, checking for possible fraud, using a set of advanced scoring rules.
 * Version: 6.0.4
 * Author: OPMC Australia Pty Ltd
 * Author URI: https://opmc.biz/
 * Text Domain: woocommerce-anti-fraud
 * Domain Path: /languages
 * License: GPL v3
 * WP tested up to: 6.7
 * WC tested up to: 9.4
 * WC requires at least: 2.6
 * Woo: 500217:955da0ce83ea5a44fc268eb185e46c41
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Copyright (c) 2017 OPMC Australia Pty Ltd.
 */

/**
 * Required functions
 */
add_action( 'plugins_loaded', 'opmc_af_load_textdomain' );

/**
 * Load textdomain for plugin
 *
 * @return void
 */
function opmc_af_load_textdomain() {
	load_plugin_textdomain( 'woocommerce-anti-fraud', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
}

$check_block = 0;

function add_the_theme_page() {
	add_menu_page(
		__( 'Anti Fraud', 'woocommerce-anti-fraud' ),
		__( 'Anti Fraud', 'woocommerce-anti-fraud' ),
		'manage_options',
		'antifraud-dashboard',
		'page_content',
		'dashicons-book-alt'
	);
}

add_action( 'admin_menu', 'add_the_theme_page' );
function page_content() {
	require_once plugin_dir_path( __FILE__ ) . '/templates/dashboard.php';
}

if ( ! function_exists( 'woothemes_queue_update' ) ) {
	require_once plugin_dir_path( __FILE__ ) . '/woo-includes/woo-functions.php';
}
/**
 * Plugin updates
 */
woothemes_queue_update( plugin_basename( __FILE__ ), '955da0ce83ea5a44fc268eb185e46c41', '500217' );

/*function af_load_langauge() {

	$path = dirname( plugin_basename( __FILE__ ) ) . '/languages';
	$result = load_plugin_textdomain( dirname( plugin_basename( __FILE__ ) ), false, $path );
	// var_dump($result);die;
	// if (!$result) {
	// $locale = apply_filters('plugin_locale', get_locale(), dirname( plugin_basename(__FILE__)));
	// die("Could not find $path/" . dirname( plugin_basename(__FILE__)) . "-$locale.mo.");
	// }
}
add_action( 'init', 'af_load_langauge' ); */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

/**
 * This function runs when WordPress completes its upgrade process
 * It iterates through each plugin updated to see if ours is included
 *
 * @param $upgrader_object Array
 * @param $options Array
 */
function wp_opmc_upgrade_completed( $upgrader_object, $options ) {
	// The path to our plugin's main file
	$our_plugin = plugin_basename( __FILE__ );
	// If an update has taken place and the updated type is plugins and the plugins element exists
	if ( 'update' == $options['action'] && 'plugin' == $options['type'] && isset( $options['plugins'] ) ) {
		// Iterate through the plugins being updated and check if ours is there
		foreach ( $options['plugins'] as $plugin ) {
			if ( $plugin == $our_plugin ) {
				// Set a transient to record that our plugin has just been updated
				set_transient( 'wp_opmc_updated', 1 );
				update_option( 'wc_af_fraud_update_state', 'yes' );
			}
		}
	}
}

add_action( 'upgrader_process_complete', 'wp_opmc_upgrade_completed', 10, 2 );

/**
 * Plugin page links
 */
function wc_antifraud_plugin_links( $links ) {

	$plugin_links = array(
		'<a href="' . admin_url( 'admin.php?page=wc-settings&tab=wc_af' ) . '">' . __( 'Settings', 'woocommerce-anti-fraud' ) . '</a>',
		'<a href="https://docs.woocommerce.com/document/woocommerce-anti-fraud/">' . __( 'Docs', 'woocommerce-anti-fraud' ) . '</a>',
	);

	return array_merge( $plugin_links, $links );
}

add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'wc_antifraud_plugin_links' );

define( 'WOOCOMMERCE_ANTI_FRAUD_VERSION', '4.4.0' );
define( 'WOOCOMMERCE_ANTI_FRAUD_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'WOOCOMMERCE_ANTI_FRAUD_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'WOOCOMMERCE_ANTI_FRAUD_SUPPORT_TICKET_URL', esc_url( 'https://woocommerce.com/my-account/create-a-ticket/' ) );

/**
 * Include the Opmc-hpos-compatibility-helper.php file if it hasn't been included before.
 *
 * This code includes the Opmc-hpos-compatibility-helper.php file in the current PHP script. It uses the include_once
 * function to ensure that the file is included only once, even if this code is executed multiple times.
 *
 * @param string $file_path The path to the Opmc-hpos-compatibility-helper.php file.
 *
 * @return bool True if the file is successfully included, false otherwise.
 */
include_once 'includes/opmc-hpos-compatibility-helper.php';
require_once dirname( __FILE__ ) . '/anti-fraud-core/class-wc-af-trust-swiftly.php';

/**
 * Initialized main class WooCommerce_Anti_Fraud
 */
class WooCommerce_Anti_Fraud {


	/**
	 * Get the plugin file
	 *
	 * @static
	 * @return String
	 * @since  1.0.0
	 *
	 */
	public static function get_plugin_file() {
		return __FILE__;
	}

	/**
	 * A static method that will setup the autoloader
	 *
	 * @static
	 * @since  1.0.0
	 */
	private static function setup_autoloader() {
		require_once plugin_dir_path( self::get_plugin_file() ) . '/includes/class-wc-af-privacy.php';
		require_once plugin_dir_path( self::get_plugin_file() ) . '/includes/class-wc-af-autoloader.php';

		// Core loader
		$core_autoloader = new WC_AF_Autoloader( plugin_dir_path( self::get_plugin_file() ) . 'anti-fraud-core/' );
		spl_autoload_register( array( $core_autoloader, 'load' ) );

		// Rule loader

		$rule_autoloader = new WC_AF_Autoloader( plugin_dir_path( self::get_plugin_file() ) . 'rules/' );
		spl_autoload_register( array( $rule_autoloader, 'load' ) );
	}

	/**
	 * Constructor
	 */
	public function __construct() {
		// Code for HPOS. Build Generic code fix and test it.
		add_action(
			'before_woocommerce_init',
			function () {
				if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
					\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
				}
			}
		);

		// Check if WC is activated
		if ( $this->is_wc_active() ) {
			$this->init();
		}
		register_activation_hook( __FILE__, array( $this, 'save_default_settings' ) );

		register_activation_hook( __FILE__, array( $this, 'deactivate_events_on_active_plugin' ) );

		register_deactivation_hook( __FILE__, array( $this, 'deactivate_events' ) );
		$connector = new WC_AF_TRUST_SWIFTLY();
		add_action( 'plugins_loaded', array( $this, 'plugin_load_td' ) );
		add_action( 'admin_init', array( $this, 'admin_scripts' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'switch_onoff' ) );

		add_action( 'wp_ajax_my_action', array( $this, 'my_action' ) );
		add_action( 'wp_ajax_nopriv_my_action', array( $this, 'my_action' ) );
		add_action( 'init', array( $this, 'paypal_verification' ) );
		add_action( 'woocommerce_admin_order_data_after_order_details', array( $this, 'kia_display_order_data_in_admin' ) );

		// Ajax For whitlist email check
		add_action( 'wp_ajax_check_blacklist_whitelist', array( $this, 'check_blacklist_whitelist' ) );
		add_action( 'wp_ajax_nopriv_check_blacklist_whitelist', array( $this, 'check_blacklist_whitelist' ) );

		//Ajax for maxmind & trustswiftly

		add_action( 'wp_ajax_dismiss_maxmind_alert', array( $this, 'dismiss_maxmind_alert_callback' ) );
		add_action( 'wp_ajax_dismiss_trustswiftly_alert', array( $this, 'dismiss_trustswiftly_alert_callback' ) );

		// For MaxMind Device Tracking Script
		add_action( 'admin_head', array( $this, 'get_device_tracking_script' ), 100, 100 );
		add_action( 'wp_head', array( $this, 'get_device_tracking_script' ), 100, 100 );

		add_action( 'wp_ajax_whitelist_email', array( $this, 'whitelist_email' ) );
		// add_action('wp_ajax_nopriv_whitelist_email', array($this, 'whitelist_email'));

		// add_action( 'woocommerce_new_order',  array( $this,'check_for_card_error'));
		// add_action( 'woocommerce_update_order',  array( $this,'check_for_card_error'));

		add_action( 'wp_enqueue_scripts', array( $this, 'add_scripts_to_pages' ), 9999 );
		add_action( 'wp_ajax_my_action_geo_country', array( $this, 'my_action_geo_country' ) );
		add_action( 'wp_ajax_nopriv_my_action_geo_country', array( $this, 'my_action_geo_country' ) );
		add_action( 'wp_ajax_my_dismiss_notice', array( $this, 'my_dismiss_notice' ) );
		if ( empty( get_option( 'my_notice_dismisseds' ) ) ) {
			add_action( 'admin_notices', array( $this, 'my_admin_notice' ) );
		}
		/*
		else {
		if ( !empty( get_option( 'my_notice_dismisseds' ) ) &&  !empty( get_option( 'my_notice_dismisseds_time' ) ) {

		$now = get_option( 'my_notice_dismisseds_time' );
		$open = date_parse($now)['hour'];
		if (24 == $open) {
		delete_option( 'my_notice_dismisseds');
		delete_option( 'my_notice_dismisseds_time');
		add_action( 'admin_notices', array($this, 'my_admin_notice') );
		}
		}
		}*/
		/* Related to oder debug log details */
		add_action( 'woocommerce_thankyou', array( $this, 'create_log_file_before_submit' ), 20 );
		add_action( 'init', array( $this, 'create_log_folder' ), 20 );
		register_activation_hook( __FILE__, array( $this, 'create_table_debuglog_file_downloads' ) );
		/* debug log details end */

		/* Related to Wildcard email */
		add_action( 'woocommerce_checkout_order_processed', array( $this, 'count_order_attempt_action_onsite' ), 10, 3 );
		add_action( 'woocommerce_after_checkout_validation', array( $this, 'wildcard_email_validation' ) );

		add_action( 'profile_update', array( $this, 'sync_woocommerce_email' ), 10, 2 );
		add_action( 'woocommerce_after_checkout_validation', array( $this, 'misha_validate_fname_lname' ), 10, 2 );
		add_action( 'woocommerce_after_checkout_validation', array( $this, 'too_many_order_attempt_validation' ), 10, 2 );
		add_action( 'woocommerce_checkout_order_processed', array( $this, 'wh_pre_paymentcall' ), 10, 2 );
		add_action( 'woocommerce_after_checkout_validation', array( $this, 'max_order_attempt_between_timespan' ), 10, 2 );
		add_action( 'init', array( $this, 'update_blacklist_ips_option' ), 999 );

		add_action( 'wp_ajax_order_level_froud_check', array( $this, 'order_level_froud_check' ) );
		add_action( 'wp_ajax_nopriv_order_level_froud_check', array( $this, 'order_level_froud_check' ) );

		$hposSettingsEnabled = get_option( 'woocommerce_custom_orders_table_enabled', true );

		if ( 'yes' === $hposSettingsEnabled ) {
			add_filter( 'bulk_actions-woocommerce_page_wc-orders', array( $this, 'bulk_fraud_check_action_hook' ) );
			add_filter( 'handle_bulk_actions-woocommerce_page_wc-orders', array( $this, 'bulk_fraud_check_action_hpos' ), 10, 3 );

			add_filter( 'manage_woocommerce_page_wc-orders_columns', array( $this, 'add_order_level_froud_check_column' ), 11 );
			add_action( 'manage_woocommerce_page_wc-orders_custom_column', array( $this, 'add_order_level_froud_check_column_hpos_contents' ), 2, 2 );
		} else {
			add_filter( 'bulk_actions-edit-shop_order', array( $this, 'bulk_fraud_check_action_hook' ) );
			add_filter( 'handle_bulk_actions-edit-shop_order', array( $this, 'bulk_fraud_check_action_not_hpos' ), 10, 3 );
			add_filter( 'manage_edit-shop_order_columns', array( $this, 'add_order_level_froud_check_column' ) );
			add_action( 'manage_shop_order_posts_custom_column', array( $this, 'add_order_level_froud_check_column_not_hpos_contents' ), 10, 2 );
		}

		add_action( 'wp_ajax_bigdatacloud_dismiss_notice', array( $this, 'bigdatacloud_dismiss_notice' ) );

		add_action( 'wp_ajax_nopriv_bigdatacloud_dismiss_notice', array( $this, 'bigdatacloud_dismiss_notice' ) );

		add_action( 'wp_ajax_bigdatacloud_dismiss_notice_save', array( $this, 'bigdatacloud_dismiss_notice_save' ) );

		add_action( 'wp_ajax_nopriv_bigdatacloud_dismiss_notice_save', array( $this, 'bigdatacloud_dismiss_notice_save' ) );

		if ( empty( get_option( 'bigdatacloud_notice_dismisseds_error' ) ) && empty( get_option( 'bigdatacloud_notice_dismisseds_onsave' ) ) && ! empty( get_option( 'bigdatacloud_onetime_notice_dismisseds' ) ) ) {

			add_action( 'admin_notices', array( $this, 'auth_bigdatacloud_error_admin_notice' ) );
		}

		add_action( 'wp_ajax_bigdatacloud_onetime_dismiss', array( $this, 'bigdatacloud_onetime_dismiss' ) );
		add_action( 'wp_ajax_nopriv_bigdatacloud_onetime_dismiss', array( $this, 'bigdatacloud_onetime_dismiss' ) );

		if ( empty( get_option( 'bigdatacloud_notice_dismissedsss' ) ) ) {
			add_action( 'admin_init', array( $this, 'bigdatacloud_onetime_dismiss_notice' ) );
		}

		add_action( 'wp_ajax_dismiss_notice', array( $this, 'dismiss_notice_callback' ) );

		// Hook into the WooCommerce order retry page reCaptcha
		$wc_af_enable_recaptcha_checkout = get_option( 'wc_settings_anti_fraudenable_enable_recaptcha' );
		$wc_af_recaptcha_site_key        = get_option( 'wc_af_recaptcha_site_key' );
		$wc_af_recaptcha_secret_key      = get_option( 'wc_af_recaptcha_secret_key' );

		if ( 'yes' == $wc_af_enable_recaptcha_checkout && ! empty( $wc_af_recaptcha_site_key ) && ! empty( $wc_af_recaptcha_secret_key ) ) {

			// Hook into the WooCommerce order processing
			add_action( 'woocommerce_before_pay_action', array( $this, 'verify_recaptcha_on_order_retry_v2' ), 1 );
			add_action( 'woocommerce_pay_order_before_submit', array( $this, 'add_recaptcha_to_retry_page_v2' ) );

			include_once 'woo-includes/checkout-blocks-initialize.php';
		}

		/* check if notice for geo location is displayed */
		if ( empty( get_option( 'woo_af_geoloc_notice_dismissed' ) ) ) {
			add_action( 'admin_notices', array( $this, 'wc_af_iswhitelist_admin_notice' ) );
			add_option( 'woo_af_geoloc_notice_dismissed', false );
		}

		//PLUGINS-2657
		add_action( 'woocommerce_order_status_failed', array( $this, 'woocommerce_before_thankyou_failed_order' ), 9999, 1 );
		add_action( 'woocommerce_order_status_changed', array( $this, 'woocommerce_before_thankyou_failed_order' ), 9999, 1 );
		add_action( 'woocommerce_thankyou', array( $this, 'custom_process_failed_order' ), 9999, 1 );
		add_action( 'woocommerce_pay_order_after_submit', array( $this, 'count_order_attempt_action_offsite' ), 10, 1 );
		add_action( 'admin_init', array( $this, 'multiple_email_check' ), 1 );

		add_filter( 'admin_body_class', array( $this, 'add_body_class_for_settings_page' ), 10, 1 );
		add_action( 'wp_ajax_dismiss_admin_notice', array( $this, 'dismiss_admin_notice' ) );
		add_action( 'admin_notices', array( $this, 'handle_admin_notices' ) );

		// Check orders just after creating through API
		add_action( 'woocommerce_order_after_calculate_totals', array( $this, 'check_orders_through_api' ), 10, 2 );

		// Blocked orders coming from rest api when the source is unknown
		add_action( 'woocommerce_new_order', array( $this, 'block_unknown_origin_orders' ), 1 );
		add_action( 'woocommerce_checkout_order_processed', array( $this, 'block_unknown_origin_orders' ), 1 );
		add_action( 'woocommerce_api_create_order', array( $this, 'block_unknown_origin_orders' ), 1 );
		add_filter( 'woocommerce_payment_complete_order_status', array( $this, 'blocked_order_status' ), 10, 2 );
	}

	function blocked_order_status( $status, $order_id ) {
		if ( ! $this->block_unknown_origin_orders( $order_id ) ) {
			return 'cancelled';
		}

		return $status;
	}

	function block_unknown_origin_orders( $order_id ) {
		$order           = wc_get_order( $order_id );
		$created_via     = $order->get_created_via();
		$allowed_origins = array(
			'checkout',      // Normal store checkout
			'admin',         // Admin panel
			'rest-api',      // REST API
			'pos',           // Point of sale
			'subscription',  // Subscriptions
			'checkout-draft' // Draft orders
		);

		// Check if origin is unknown or not in allowed list
		if ( empty( $created_via ) || ! in_array( $created_via, $allowed_origins ) ) {
			// Cancel the order
			$order->update_status( 'cancelled', 'Order cancelled - Unknown origin' );

			// Optional: Add order note
			$order->add_order_note( sprintf( 'Order automatically cancelled due to unknown origin: %s', $created_via ? $created_via : 'empty' ) );

			return false;
		}

		return true;
	}

	function check_orders_through_api( $and_taxes, $order ) {
		if ( $order instanceof WC_Order ) {
			$order_id                        = $order->get_id();
			$created_via                     = $order->get_created_via();
			$api_fraud_check                 = get_option( 'wc_af_api_fraud_check', 'no' );
			$throttle_api_based_orders_check = get_option( 'wc_af_throttle_api_based_orders_check', 'no' );
			$max_orders_through_api_per_hour = (int) get_option( 'wc_af_max_orders_through_api_per_hour', '0' );

			if ( $created_via == 'rest-api' && $api_fraud_check == 'yes' ) {
				$score_helper = new WC_AF_Score_Helper();
				$score_helper->do_check( $order_id );
			}

			if ( $throttle_api_based_orders_check === 'yes' ) {
				$orders_in_last_hour = wc_get_orders( array(
					'limit'        => - 1,
					'return'       => 'ids',
					'date_created' => '>=' . date( 'Y-m-d H:i:s', ( current_time( 'timestamp' ) - HOUR_IN_SECONDS ) ),
					'created_via'  => 'rest-api'
				) );

				if ( count( $orders_in_last_hour ) > $max_orders_through_api_per_hour ) {
					$order->delete( true );
					wp_die( new WP_Error( 'rest_order_creation_blocked', __( 'Maximum API orders per hour exceeded.', 'woocommerce-anti-fraud' ), array( 'status' => 429 ) ) );
				}
			}
		}
	}

	function handle_admin_notices() {

		$notices = array();

		if ( get_option( 'wc_settings_anti_fraud_select_recaptcha_version' ) === 'recaptchav3' ) {
			delete_option( 'wc_settings_anti_fraudenable_enable_recaptcha' );
			delete_option( 'wc_settings_anti_fraud_select_recaptcha_version' );
			delete_option( 'recaptcha_secret_key_valid' );
			$notices[] = array(
				'message'   => __( 'You are using reCAPTCHA v3 that is unfortunately ineffective now. Please consider switching to v2 for a balance of security and usability.', 'woocommerce-anti-fraud' ) . ' <a href="' . esc_url( admin_url( 'admin.php?page=wc-settings&tab=wc_af&section=minfraud_recaptcha_settings' ) ) . '">' . __( 'Update reCAPTCHA Settings', 'woocommerce-anti-fraud' ) . '</a>',
				'notice_id' => 'wc_af_recaptcha_v3_notice',
				'classes'   => array( 'notice', 'notice-error', 'is-dismissible' ),
			);
		}

		if ( get_option( 'wc_settings_anti_fraudenable_enable_recaptcha' ) === 'yes' ) {
			$notices[] = array(
				'message'   => __( 'Great! reCAPTCHA v2 is enabled on this website. Please consider checking it manually either it\'s appearing actually or not. If anything goes wrong, ', 'woocommerce-anti-fraud' ) . '<a target="_blank" href="' . WOOCOMMERCE_ANTI_FRAUD_SUPPORT_TICKET_URL . '">' . __( 'Create Support Ticket', 'woocommerce-anti-fraud' ) . '</a>',
				'notice_id' => 'wc_af_recaptcha_manual_check_notice',
				'classes'   => array( 'notice', 'notice-warning', 'is-dismissible' ),
			);
		}

		if ( get_option( 'wc_af_attempt_count_check' ) !== 'yes' ) {
			$notices[] = array(
				'message'   => __( 'Card Attack Protection is currently disabled. Enable it in the Anti-Fraud settings to enhance your store\'s security.', 'woocommerce-anti-fraud' ),
				'notice_id' => 'wc_af_card_attack_disabled',
				'classes'   => array( 'notice', 'notice-warning', 'is-dismissible' ),
			);
		}

		if ( is_array( $notices ) ) {
			foreach ( $notices as $notice ) {
				$message   = isset( $notice['message'] ) ? $notice['message'] : '';
				$notice_id = isset( $notice['notice_id'] ) ? $notice['notice_id'] : '';
				$classes   = isset( $notice['classes'] ) ? $notice['classes'] : array();

				if ( ! empty( $notice_id ) && ! get_transient( $notice_id ) ) {
					printf( '<div class="%s" data-notice-id="%s" data-nonce="%s"><p>%s</p></div>',
						esc_attr( implode( ' ', $classes ) ),
						esc_attr( $notice_id ),
						esc_attr( wp_create_nonce( 'dismiss_admin_notice' ) ),
						$message
					);
				}
			}
		}
	}

	public function dismiss_admin_notice() {
		check_ajax_referer( 'dismiss_admin_notice', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( - 1 );
		}

		$notice_id = isset( $_POST['notice_id'] ) ? sanitize_text_field( $_POST['notice_id'] ) : '';

		if ( $notice_id ) {
			set_transient( $notice_id, true, 7 * DAY_IN_SECONDS );
		}

		if ( $notice_id === 'wc_af_recaptcha_v3_notice' ) {
			delete_option( 'wc_settings_anti_fraud_select_recaptcha_version' );
			delete_option( 'wc_af_v3_recaptcha_site_key' );
			delete_option( 'wc_af_v3_recaptcha_secret_key' );
		}

		wp_die();
	}

	function add_body_class_for_settings_page( $classes ) {

		$current_page = isset( $_GET['page'] ) ? sanitize_text_field( $_GET['page'] ) : '';
		$current_tab  = isset( $_GET['tab'] ) ? sanitize_text_field( $_GET['tab'] ) : '';

		if ( 'wc-settings' == $current_page && 'wc_af' == $current_tab ) {
			$classes .= ' wc-af-settings-page';
		}

		return $classes;
	}

	public function multiple_email_check( $str ) {
		$my_array = get_option( 'wc_settings_anti_fraud_whitelist' );

		if ( ! empty( $my_array ) ) {
			$my_arrays      = explode( ",", $my_array );
			$filtered_array = array();

			foreach ( $my_arrays as $value ) {
				$count_at = substr_count( $value, '@' );

				if ( $count_at <= 1 ) {
					$filtered_array[] = $value;
				}
			}

			if ( ! empty( $filtered_array ) ) {
				$uniqueEmails    = array_unique( $filtered_array );
				$filtered_arrays = implode( ', ', $uniqueEmails );

				update_option( 'wc_settings_anti_fraud_whitelist', $filtered_arrays );
			}
		}
	}

	public function get_current_url() {
		// Check if HTTPS is enabled
		$is_https = ! empty( $_SERVER['HTTPS'] ) && 'off' !== $_SERVER['HTTPS'];

		// Determine the protocol
		$protocol = $is_https ? 'https' : 'http';
		// Get the host name
		$host = '';
		if ( isset( $_SERVER['HTTP_HOST'] ) ) {
			$host = $_SERVER['HTTP_HOST'];
		}

		$request_uri = '';

		if ( isset( $_SERVER['REQUEST_URI'] ) ) {
			$request_uri = sanitize_text_field( $_SERVER['REQUEST_URI'] );
		}
		// Get the request URI (path and query)
		$request_uri = sanitize_text_field( $_SERVER['REQUEST_URI'] );

		// Construct the full URL
		$url = $protocol . '://' . $host . $request_uri;

		return $url;

	}


	public function count_order_attempt_action_offsite() {
		//error_log('Running custom_woocommerce_checkout_order_processed…');
		$enablePaymentAttempt = get_option( 'wc_af_order_payment_attempt_check' );
		$orderPaymentAttempt  = get_option( 'wc_settings_anti_fraud_max_order_payment_attempt' );
		$current_url          = $this->get_current_url();
		$url_parts            = parse_url( $current_url );
		// Extract the path from the URL
		$path = $url_parts['path'];
		// Extract the order ID from the path
		// Assuming the order ID is the last part of the path before query parameters
		$path_parts = explode( '/', trim( $path, '/' ) );
		$order_id   = $path_parts[2];
		$order      = wc_get_order( $order_id );
		if ( $order ) {

			// Ensure options are set and valid
			if ( 'yes' == $enablePaymentAttempt && ! empty( $orderPaymentAttempt ) ) {
				// Retrieve the current payment retry count
				$counter = opmc_hpos_get_post_meta( $order_id, 'order_payment_retry', true );
				if ( ! is_numeric( $counter ) ) {
					$counter = 1;
				} else {
					$counter = $counter;
				}

				if ( isset( $order ) && 'failed' === $order->get_status() ) {

					if ( $counter == $orderPaymentAttempt ) {
						$order->update_status( 'cancelled', 'You have reached the max payment attempt for this order.', true );
						$pre_payment_block_message = 'You have reached the max payment attempt for this order.';
						wc_add_notice( __( 'You have reached the max payment attempt for this order.' ), 'error' );
						//wp_die();

					} else {
						// Update the retry count if payment attempt is not maxed out
						opmc_hpos_update_post_meta( $order_id, 'order_payment_retry', $counter + 1 );

						return false;
					}
				} else {
					if ( isset( $order ) && 'cancelled' === $order->get_status() ) {
						wc_add_notice( __( 'You have reached the max payment attempt for this order.' ), 'error' );
					}
				}
			}
		}
	}


	// Record a credit card decline if checkout fails.
	public function count_order_attempt_action_onsite( $order_id, $posted_data, $order ) {
		//error_log('Running custom_woocommerce_checkout_order_processed…');
		$enablePaymentAttempt = get_option( 'wc_af_order_payment_attempt_check' );
		$orderPaymentAttempt  = get_option( 'wc_settings_anti_fraud_max_order_payment_attempt' );

		// Ensure options are set and valid
		if ( 'yes' == $enablePaymentAttempt && ! empty( $orderPaymentAttempt ) ) {
			// Retrieve the current payment retry count
			$counter = opmc_hpos_get_post_meta( $order_id, 'order_payment_retry', true );
			if ( ! is_numeric( $counter ) ) {
				$counter = 0;
			} else {
				$counter = $counter;
			}

			if ( isset( $order ) && 'failed' === $order->get_status() ) {

				if ( $counter == $orderPaymentAttempt ) {
					//$order->update_status('failed', 'Pre Payment Fraud Check: Calculated risk score is above High Risk Threshold.', true);
					$pre_payment_block_message = 'You have reached the max payment attempt for this order.';
					$return                    = array(
						'result'   => 'failed',
						'messages' => "<ul class='woocommerce-error' role='alert'><li>" . $pre_payment_block_message . '</li></ul>',
					);
					wp_send_json( $return );
					wp_die();

				} else {
					// Update the retry count if payment attempt is not maxed out
					opmc_hpos_update_post_meta( $order_id, 'order_payment_retry', $counter + 1 );

					return false;
				}
			}
		}
	}


	public function custom_process_failed_order( $order_id ) {

		$order = wc_get_order( $order_id );
		if ( $order->has_status( 'failed' ) ) {
			$high_risk     = get_option( 'wc_settings_anti_fraud_higher_risk_threshold' );
			$score_helper  = new WC_AF_Score_Helper();
			$score_points  = opmc_hpos_get_post_meta( $order_id, 'wc_af_score', true );
			$circle_points = WC_AF_Score_Helper::invert_score( $score_points );
			if ( $high_risk <= $circle_points && 'failed' == $order->get_status() ) {
				$order->update_status( 'cancelled', 'Fraud Check Done: Calculated risk score is above High Risk Threshold.', true );

			} else {
				if ( 'cancelled' !== $order->get_status() ) {
					$order->update_status( 'failed', 'Fraud Check Done: Calculated risk score is lower High Risk Threshold.', true );
				}
			}
		}
	}

	// Hook into the WooCommerce order retry page
	public function add_recaptcha_to_retry_page_v2() {
		$wc_af_recaptcha_site_key = get_option( 'wc_af_recaptcha_site_key' );
		?>
        <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
        <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide" style="padding: 0px !important;">
            <label for="reg_captcha"><?php echo esc_html__( 'Captcha', 'woocommerce-anti-fraud' ); ?>&nbsp;<span class="required">*</span></label>
        <div id="wc-af-recaptcha-retry" class="g-recaptcha" data-sitekey="<?php echo esc_attr( $wc_af_recaptcha_site_key ); ?>" data-callback="onRetryPageCaptchaSuccess"></div>
        <input type="hidden" name="retry_captcha_response" id="retry_captcha_response" value="">
        </p>
        <script>
            window.onRetryPageCaptchaSuccess = function (token) {
                document.getElementById('retry_captcha_response').value = token;
            };
        </script>
		<?php
	}

	public function verify_recaptcha_on_order_retry_v2( $order_id ) {
		if ( isset( $_POST['woocommerce-pay-nonce'] ) && ! empty( $_POST['woocommerce-pay-nonce'] ) ) {

			$nonce_value = '';
			if ( isset( $_REQUEST['woocommerce-pay-nonce'] ) || isset( $_REQUEST['_wpnonce'] ) ) {

				if ( isset( $_REQUEST['woocommerce-pay-nonce'] ) && ! empty( $_REQUEST['woocommerce-pay-nonce'] ) ) {

					$nonce_value = sanitize_text_field( $_REQUEST['woocommerce-pay-nonce'] );
				} else if ( isset( $_REQUEST['_wpnonce'] ) && ! empty( $_REQUEST['_wpnonce'] ) ) {

					$nonce_value = sanitize_text_field( $_REQUEST['_wpnonce'] );
				}
			}

			if ( wp_verify_nonce( $nonce_value, 'woocommerce-pay' ) ) {

				if ( 'yes' == get_transient( $nonce_value ) ) {
					return true;
				}

				if ( isset( $_POST['g-recaptcha-response'] ) && ! empty( $_POST['g-recaptcha-response'] ) ) {

					// Google reCAPTCHA API secret key
					$response = sanitize_text_field( $_POST['g-recaptcha-response'] );

					$wc_af_recaptcha_secret_key = get_option( 'wc_af_recaptcha_secret_key' );

					// Verify the reCAPTCHA response
					$verifyResponse = wp_remote_get( 'https://www.google.com/recaptcha/api/siteverify?secret=' . $wc_af_recaptcha_secret_key . '&response=' . $response );
					$current_user   = wp_get_current_user();

					if ( is_array( $verifyResponse ) && ! is_wp_error( $verifyResponse ) && isset( $verifyResponse['body'] ) ) {

						// Decode json data
						$responseData = json_decode( $verifyResponse['body'] );

						// If reCAPTCHA response is valid
						if ( ! $responseData->success ) {

							wc_add_notice( __( 'Invalid recaptcha.' ), 'error' );
						} else {

							if ( 0 != 3 ) {

								set_transient( $nonce_value, 'yes', ( 3 * 60 ) );
							}
						}
					} else {
						wc_add_notice( __( 'Could not get response from recaptcha server.' ), 'error' );
					}
				} else {
					wc_add_notice( __( 'Recaptcha is a required field.' ), 'error' );
				}
			} else {
				wc_add_notice( __( 'Could not verify request.' ), 'error' );
			}
		}

		return true;

		// reCAPTCHA verification passed, process the order retry request
		// Your order retry processing code here
	}

	public function woocommerce_before_thankyou_failed_order( $order_id ) {

		$order = wc_get_order( $order_id );
		if ( $order->has_status( 'failed' ) ) {
			$high_risk = get_option( 'wc_settings_anti_fraud_higher_risk_threshold' );
			opmc_hpos_update_post_meta( $order_id, 'peyment_retry', 'yes' );
			$score_helper = new WC_AF_Score_Helper();
			$score_helper->schedule_fraud_check( $order_id, true );
			$score_points = opmc_hpos_get_post_meta( $order_id, 'wc_af_score', true );

			$circle_points = WC_AF_Score_Helper::invert_score( $score_points );

			//if ($high_risk <= $circle_points) {
		}
	}

	// PLUGINS-2657 end

	/**
	 * Added GeoLocation Admin Notice
	 *
	 * @since 5.8.0
	 */

	public function wc_af_iswhitelist_admin_notice() {
		if ( isset( $bigdatacloud_key ) && $bigdatacloud_key != '' ) {
			?>
            <div class="notice is-dismissible">
                <p><strong><?php echo esc_html_e( 'IP whitelisting settings may request users to share location from their browsers. Please see more in AntiFraud plugin', 'woocommerce-anti-fraud' ); ?> <a href="<?php echo admin_url( 'admin.php?page=wc-settings&tab=wc_af' ); ?>"><?php esc_html_e( 'settings', 'woocommerce-anti-fraud' ); ?></a>.</strong></p>
            </div>
            <script type="text/javascript">
                jQuery(document).ready(function ($) {
                    $(document).on('click', '.notice-dismiss', function () {
                        $.ajax({
                            url: '<?php echo admin_url( 'admin-ajax.php' ); ?>',
                            type: 'POST',
                            data: {
                                action: 'dismiss_notice'
                            },
                        });
                    });
                });
            </script>
			<?php
		}
	}

	/**
	 * Added Geo Location Notice
	 *
	 * @since 5.8.0
	 */

	public function dismiss_notice_callback() {
		update_option( 'woo_af_geoloc_notice_dismissed', true );
	}


	/**
	 * Bigdatacloud_onetime_dismiss_notice
	 *
	 * @since 5.8.0
	 */
	public function bigdatacloud_onetime_dismiss_notice() {
		if ( empty( get_option( 'bigdatacloud_onetime_notice_dismisseds' ) ) ) {
			update_option( 'wc_af_geolocation_order', 'no' );
			update_option( 'bigdatacloud_api_key', '' );
			update_option( 'bigdatacloud_notice_dismisseds_onsave', 1 );
			update_option( 'bigdatacloud_notice_dismisseds_error', 1 );

			add_action( 'admin_notices', array( $this, 'bigdatacloud_onetime_dismiss_notice_message' ) );
		}
	}

	/**
	 * Bigdatacloud_onetime_dismiss_notice_message
	 *
	 * @since 5.8.0
	 */
	public function bigdatacloud_onetime_dismiss_notice_message() {
		?>

        <div class="notice notice-error is-dismissible opmc-antifraud" id="onetime_error">
            <p>
				<?php
				/* translators: 1. start of link, 2. end of link. */
				printf( esc_html__( 'In order to continue %1$s"Geo Location Match"%2$s service, our provider Bigdatacloud now requires you to sign up and get the api key. To obtain an api key you can %3$sregister here%4$s.', 'woocommerce-anti-fraud' ), '<strong>', '</strong>', '<a href="' . esc_url( 'https://www.bigdatacloud.com/" target="_blank"' ) . '">', '</a>' );
				?>
            </p>
        </div>
        <script type="text/javascript">
            jQuery(document).ready(function () {
                jQuery(document).on('click', '.opmc-antifraud button.notice-dismiss', function () {
                    //alert('It will not appear again.');
                    jQuery.ajax({
                        url: ajaxurl,
                        data: {
                            action: 'bigdatacloud_onetime_dismiss'
                        }
                    });
                });
            });
        </script>
		<?php
	}

	/**
	 * Bigdatacloud_onetime_dismiss
	 *
	 * @since 5.8.0
	 */
	public function bigdatacloud_onetime_dismiss() {

		update_option( 'bigdatacloud_onetime_notice_dismisseds', 1 );
		echo 'success';
		wp_die();
	}

	/**
	 * Bigdatacloud_dismiss_notice_save
	 *
	 * @since 5.8.0
	 */
	public function bigdatacloud_dismiss_notice_save() {
		//$now = gmdate( 'Y-m-d H:i:s' );
		update_option( 'bigdatacloud_notice_dismisseds_onsave', 1 );
		update_option( 'bigdatacloud_notice_dismisseds_error', 1 );

		echo 'success';
		wp_die();
	}

	/**
	 * Bigdatacloud_dismiss_notice
	 *
	 * @since 5.8.0
	 */
	public function bigdatacloud_dismiss_notice() {
		//$now = gmdate( 'Y-m-d H:i:s' );
		update_option( 'bigdatacloud_notice_dismisseds_error', 1 );
		update_option( 'bigdatacloud_notice_dismisseds_onsave', 1 );
		echo 'success';
		wp_die();
		// update_option( 'my_notice_dismisseds_time', $now );
	}

	/**
	 * Auth_bigdatacloud_error_admin_notice
	 *
	 * @since 5.8.0
	 */
	public function auth_bigdatacloud_error_admin_notice() {

		?>
        <div class="notice notice-error is-dismissible opmc-antifraud" id="root_error">
            <p><strong><?php echo esc_html_e( 'AntiFraud: Bigdatacloud credentials not authenticate or your quota limit has been exceeded!', 'woocommerce-anti-fraud' ); ?></strong></p>
        </div>
        <script type="text/javascript">
            jQuery(document).ready(function () {
                jQuery(document).on('click', '#root_error button.notice-dismiss', function () {
                    //alert('It will not appear again.');
                    jQuery.ajax({
                        url: ajaxurl,
                        data: {
                            action: 'bigdatacloud_dismiss_notice'
                        }
                    });
                });
            });
        </script>

		<?php
	}


	/*Callback function to dismiss the MaxMind alert.*/
	public function dismiss_maxmind_alert_callback() {

		if ( isset( $_REQUEST['_wpnonce'] ) ) {
			if ( ! wp_verify_nonce( $_REQUEST['_wpnonce'], 'my-nonce' ) ) {
				echo 'Nonce verification failed!';
				die();
			}
		}

		$task = isset( $_POST['task'] ) ? sanitize_text_field( $_POST['task'] ) : '';

		if ( 'maxmind-alert-dismissed' === $task ) {
			// Add user meta
			$user_id    = get_current_user_id();
			$meta_key   = 'opmc-antifraud-maxmind-alert';
			$meta_value = 'yes';
			update_user_meta( $user_id, $meta_key, $meta_value );
		}

		wp_die();
	}

	/* Callback function to dismiss the alert trustswiftly alert.*/
	public function dismiss_trustswiftly_alert_callback() {

		if ( isset( $_REQUEST['_wpnonce'] ) ) {
			if ( ! wp_verify_nonce( $_REQUEST['_wpnonce'], 'my-nonce' ) ) {
				echo 'Nonce verification failed!';
				die();
			}
		}

		$trustswiftly = isset( $_POST['trustswiftly'] ) ? sanitize_text_field( $_POST['trustswiftly'] ) : '';

		if ( 'trustswiftly-alert-dismissed' === $trustswiftly ) {
			// Add user meta
			$user_id    = get_current_user_id();
			$meta_key   = 'opmc-antifraud-trustswiftly-alert';
			$meta_value = 'yes';
			update_user_meta( $user_id, $meta_key, $meta_value );
		}

		wp_die();
	}

	/* Related to Wildcard email */

	public function create_email_pattern( $setting_email, $customer_email ) {

		if ( isset( $setting_email ) && isset( $customer_email ) ) {
			$email                    = $customer_email;
			$allowed_pattern_original = $setting_email;

			// Convert pattern into regex If pattern conatins *
			$allowed_pattern = str_replace( '*', '.*', $allowed_pattern_original );

			// Convert pattern into regex If pattern conatins ?
			$question_mark_arr = array(
				'????????????????????',
				'???????????????????',
				'??????????????????',
				'?????????????????',
				'????????????????',
				'???????????????',
				'??????????????',
				'?????????????',
				'????????????',
				'???????????',
				'??????????',
				'?????????',
				'????????',
				'???????',
				'??????',
				'?????',
				'????',
				'???',
				'??',
				'?',
			);

			$i = 20;
			foreach ( $question_mark_arr as $question_mark ) {
				if ( strpos( $allowed_pattern, $question_mark ) !== false ) {
					$allowed_pattern = str_replace( $question_mark, '.{' . $i . '}', $allowed_pattern );
				}
				$i --;
			}
			// Finally convert pattern into regex
			$allowed_pattern = '/^' . $allowed_pattern . '$/';
			if ( preg_match( $allowed_pattern, $email ) ) {

				return 'true';
			}
		}
	}

	public function wildcard_email_validation() {

		$customer_billing_email = '';
		$whitelist_email        = 'false';

		if ( ! empty( $_POST['billing_email'] ) ) {

			if ( isset( $_REQUEST['_wpnonce'] ) ) {
				if ( ! wp_verify_nonce( $_REQUEST['_wpnonce'], 'my-nonce' ) ) {
					echo 'Nonce verification failed!';
					die();
				}
			}

			$customer_billing_email = sanitize_text_field( $_POST['billing_email'] );
		}

		$get_whitelist_email = get_option( 'wc_settings_anti_fraud_whitelist' );

		if ( '' != $get_whitelist_email ) {

			$email_str_array = explode( PHP_EOL, $get_whitelist_email );

			if ( is_array( $email_str_array ) && count( $email_str_array ) > 0 ) {

				if ( ! empty( $email_str_array ) && is_array( $email_str_array ) ) {

					foreach ( $email_str_array as $setting_whitelisted_email ) {

						$valid_customer = $this->create_email_pattern( $setting_whitelisted_email, $customer_billing_email );

						if ( isset( $valid_customer ) && 'true' == $valid_customer ) {

							$whitelist_email = 'true';
							break;
						}
					}
				}
			}
		}

		// check whitelist ips
		$userIp = WC_Geolocation::get_ip_address();

		$get_all_whitelist_ips = get_option( 'wc_settings_anti_fraud_ips_whitelist' );

		$whitelist_ips = 'false';
		if ( '' != $get_all_whitelist_ips ) {

			$s_whitelist_ips = explode( ',', $get_all_whitelist_ips );

			if ( in_array( $userIp, $s_whitelist_ips ) ) {

				$whitelist_ips = 'true';
			}
		}
		//$ip = '195.181.161.229';

		// check whitelist user role
		$user                       = wp_get_current_user();
		$user_roles                 = $user->roles;
		$wc_af_whitelist_user_roles = get_option( 'wc_af_whitelist_user_roles' );

		if ( empty( $wc_af_whitelist_user_roles ) ) {
			$wc_af_whitelist_user_roles = array();
		}

		$selected_whitelisted_role      = 'false';
		$is_enable_whitelist_user_roles = get_option( 'wc_af_enable_whitelist_user_roles' );
		if ( 'yes' == $is_enable_whitelist_user_roles ) {

			if ( in_array( $user_roles[0], $wc_af_whitelist_user_roles ) ) {

				$selected_whitelisted_role = 'true';
			}
		} // check whitelist user role end

		// check whitelist payment method
		$selected_whitelist_payment_method = 'false';
		if ( get_option( 'wc_af_enable_whitelist_payment_method' ) == 'yes' ) {

			if ( get_option( 'wc_settings_anti_fraud_whitelist_payment_method' ) && null != get_option( 'wc_settings_anti_fraud_whitelist_payment_method' ) ) {

				$get_whitelist_payment_method = get_option( 'wc_settings_anti_fraud_whitelist_payment_method' );

				$payment_method_from_checkout = WC()->session->get( 'chosen_payment_method' );

				if ( in_array( $payment_method_from_checkout, $get_whitelist_payment_method ) ) {
					$selected_whitelist_payment_method = 'true';
				}
			}
		} // check whitelist payment method end

		// check whitelist specific email not wildcard type
		$get_whitelist_email        = get_option( 'wc_settings_anti_fraud_whitelist' );
		$whitelist                  = explode( ',', $get_whitelist_email );
		$selected_whitelisted_email = false;

		$whitelist_array = isset( $_POST['billing_email'] ) ? sanitize_text_field( $_POST['billing_email'] ) : '';
		if ( in_array( $whitelist_array, $whitelist ) ) {
			$selected_whitelisted_email = true;
		} // check whitelist specific email not wildcard type end

		update_option( 'not_whitelisted_email', $selected_whitelisted_role );
		update_option( 'white_payment_methods', $selected_whitelist_payment_method );
		update_option( 'is_whitelisted_roles', $selected_whitelisted_email );
		update_option( 'is_whitelisted_ips', $whitelist_ips );

		$is_enable_blacklist = ( get_option( 'wc_settings_anti_fraudenable_automatic_email_blacklist' ) === 'yes' );
		$get_blacklist_email = get_option( 'wc_settings_anti_fraudblacklist_emails' );

		if ( $is_enable_blacklist ) {

			if ( '' != $get_blacklist_email && '' != $get_whitelist_email ) {

				$s_blacklist_email = explode( ',', $get_blacklist_email );
				$s_whitelist_email = explode( PHP_EOL, $get_whitelist_email );

				$email_str_array = array_diff( $s_blacklist_email, $s_whitelist_email );

				if ( is_array( $email_str_array ) && count( $email_str_array ) > 0 ) {

					foreach ( $email_str_array as $setting_email ) {

						$valid_customer = $this->create_email_pattern( $setting_email, $customer_billing_email );

						if ( isset( $valid_customer ) && 'true' == $valid_customer && ! $selected_whitelisted_email && 'true' != $selected_whitelisted_role && 'true' != $selected_whitelist_payment_method && 'true' != $whitelist_ips ) {

							global $check_block;
							$check_block     = 1;
							$whitelist_email = 'false';
							wc_add_notice( __( 'This email id is blocked.' ), 'error' );
							break;
						}
					}
				}
			}
		}
		update_option( 'wildcard_whitelist_email', $whitelist_email );
		// return $whitelist_email;
	} /* Related to wildcard email end */

	/*
	 * Whildcard email validation callback function to use globally
	 */
	public function call_wildcard_email_validation() {

		$customer_email  = '';
		$whitelist_email = 'false';

		if ( ! empty( $_POST['billing_email'] ) ) {

			if ( isset( $_REQUEST['_wpnonce'] ) ) {
				if ( ! wp_verify_nonce( $_REQUEST['_wpnonce'], 'my-nonce' ) ) {
					echo 'Nonce verification failed!';
					die();
				}
			}

			$customer_email = sanitize_text_field( $_POST['billing_email'] );
		}

		$get_whitelist_email = get_option( 'wc_settings_anti_fraud_whitelist' );

		if ( '' != $get_whitelist_email ) {

			$email_str_array = explode( PHP_EOL, $get_whitelist_email );

			if ( is_array( $email_str_array ) && count( $email_str_array ) > 0 ) {

				if ( ! empty( $email_str_array ) && is_array( $email_str_array ) ) {

					foreach ( $email_str_array as $setting_email ) {

						$valid_customer = $this->create_email_pattern( $setting_email, $customer_email );

						if ( isset( $valid_customer ) && 'true' == $valid_customer ) {

							$whitelist_email = 'true';
							break;
						}
					}
				}
			}
		}

		// check whitelist ips
		$userIp = WC_Geolocation::get_ip_address();

		$get_all_whitelist_ips = get_option( 'wc_settings_anti_fraud_ips_whitelist' );

		$whitelist_ips = 'false';
		if ( '' != $get_all_whitelist_ips ) {

			$s_whitelist_ips = explode( ',', $get_all_whitelist_ips );

			if ( in_array( $userIp, $s_whitelist_ips ) ) {

				$whitelist_ips = 'true';
			}
		}
		//$ip = '195.181.161.229';

		// check whitelist user role
		$user                       = wp_get_current_user();
		$user_roles                 = $user->roles;
		$wc_af_whitelist_user_roles = get_option( 'wc_af_whitelist_user_roles' );

		if ( empty( $wc_af_whitelist_user_roles ) ) {
			$wc_af_whitelist_user_roles = array();
		}

		$selected_whitelisted_role      = 'false';
		$is_enable_whitelist_user_roles = get_option( 'wc_af_enable_whitelist_user_roles' );
		if ( 'yes' == $is_enable_whitelist_user_roles ) {

			foreach ( $user_roles as $role ) {
				if ( in_array( $role, $wc_af_whitelist_user_roles ) ) {
					$selected_whitelisted_role = 'true';
					break;
				}
			}
		} // check whitelist user role end

		// check whitelist payment method
		$selected_whitelist_payment_method = 'false';
		if ( get_option( 'wc_af_enable_whitelist_payment_method' ) == 'yes' ) {

			if ( get_option( 'wc_settings_anti_fraud_whitelist_payment_method' ) && null != get_option( 'wc_settings_anti_fraud_whitelist_payment_method' ) ) {

				$get_whitelist_payment_method = get_option( 'wc_settings_anti_fraud_whitelist_payment_method' );

				$payment_method_from_checkout = WC()->session->get( 'chosen_payment_method' );

				if ( in_array( $payment_method_from_checkout, $get_whitelist_payment_method ) ) {
					$selected_whitelist_payment_method = 'true';
				}
			}
		} // check whitelist payment method end

		// check whitelist specific email not wildcard type
		$get_whitelist_email        = get_option( 'wc_settings_anti_fraud_whitelist' );
		$single_whitelist_email_arr = explode( "\n", $get_whitelist_email );
		$selected_whitelisted_email = false;

		$customer_billing_email = isset( $_POST['billing_email'] ) ? sanitize_text_field( $_POST['billing_email'] ) : '';
		if ( in_array( $customer_billing_email, $single_whitelist_email_arr ) ) {
			$selected_whitelisted_email = true;
		} // check whitelist specific email not wildcard type end

		update_option( 'not_whitelisted_email', $selected_whitelisted_email );
		update_option( 'white_payment_methods', $selected_whitelist_payment_method );
		update_option( 'is_whitelisted_roles', $selected_whitelisted_role );
		update_option( 'is_whitelisted_ips', $whitelist_ips );

		$is_enable_blacklist = get_option( 'wc_settings_anti_fraudenable_automatic_email_blacklist' );
		$get_blacklist_email = get_option( 'wc_settings_anti_fraudblacklist_emails' );

		if ( '' != $get_blacklist_email && '' != $get_whitelist_email ) {

			$s_blacklist_email = explode( ',', $get_blacklist_email );
			$s_whitelist_email = explode( PHP_EOL, $get_whitelist_email );

			$email_str_array = array_diff( $s_blacklist_email, $s_whitelist_email );

			if ( is_array( $email_str_array ) && count( $email_str_array ) > 0 ) {

				foreach ( $email_str_array as $setting_email ) {

					$valid_customer = $this->create_email_pattern( $setting_email, $customer_email );

					if ( isset( $valid_customer ) && 'true' == $valid_customer && ! $selected_whitelisted_email && 'true' != $selected_whitelisted_role && 'true' != $selected_whitelist_payment_method && 'true' != $whitelist_ips ) {

						$whitelist_email = 'false';
						// wc_add_notice( __( 'This email id is blocked.' ), 'error' );
						break;
					}
				}
			}
		}

		// update_option('wildcard_whitelist_email', $whitelist_email);
		return $whitelist_email;
	} /* Related to wildcard email end */

	public function sync_woocommerce_email( $user_id, $old_user_data ) {

		// wc_af_fraud_check_before_payment
		$user           = get_userdata( $user_id );
		$new_user_email = $user->user_email;

		if ( $new_user_email != $old_user_data->user_email ) {
			wp_update_user(
				array(
					'ID'            => $user->ID,
					'billing_email' => $new_user_email,
				)
			);
		}
	}

	// custom code for block order if email or ip in blacklist.

	public function misha_validate_fname_lname( $fields, $errors ) {
		$blocked_email     = get_option( 'wc_settings_anti_fraudblacklist_emails' );
		$blocked_ipaddress = get_option( 'wc_settings_anti_fraudblacklist_ipaddress' );
		$array_mail        = explode( ',', $blocked_email );

		if ( isset( $_REQUEST['_wpnonce'] ) ) {
			if ( ! wp_verify_nonce( $_REQUEST['_wpnonce'], 'my-nonce' ) ) {
				echo 'Nonce verification failed!';
				die();
			}
		}

		$email_whitelist = get_option( 'wc_settings_anti_fraud_whitelist' );
		$is_whitelisted  = '';

		// check whitelist ips
		$userIp = WC_Geolocation::get_ip_address();

		$get_all_whitelist_ips = get_option( 'wc_settings_anti_fraud_ips_whitelist' );

		$whitelist_ips = 'false';
		if ( '' != $get_all_whitelist_ips ) {

			$s_whitelist_ips = explode( ',', $get_all_whitelist_ips );

			if ( in_array( $userIp, $s_whitelist_ips ) ) {

				$whitelist_ips = 'true';
			}
		}
		//$ip = '195.181.161.229';

		// check whitelist user role
		$user                       = wp_get_current_user();
		$user_roles                 = $user->roles;
		$wc_af_whitelist_user_roles = get_option( 'wc_af_whitelist_user_roles' );

		if ( empty( $wc_af_whitelist_user_roles ) ) {
			$wc_af_whitelist_user_roles = array();
		}

		$selected_whitelisted_role      = 'false';
		$is_enable_whitelist_user_roles = get_option( 'wc_af_enable_whitelist_user_roles' );
		if ( 'yes' == $is_enable_whitelist_user_roles ) {

			foreach ( $user_roles as $role ) {
				if ( in_array( $role, $wc_af_whitelist_user_roles ) ) {
					$selected_whitelisted_role = 'true';
					break;
				}
			}
		} // check whitelist user role end

		if ( '' != $email_whitelist ) {
			$whitelist = explode( "\n", $email_whitelist );
			if ( is_array( $whitelist ) && count( $whitelist ) > 0 ) {
				// Trim items to be sure
				foreach ( $whitelist as $k => $v ) {
					$whitelist[ $k ] = trim( $v );
				}
				// Af_Logger::debug('email found : '. print_r($whitelist, true));
			}
			$is_whitelisted = array_intersect( $whitelist, $array_mail );
		}

		// check whitelist payment method
		$selected_whitelist_payment_method = 'false';
		if ( get_option( 'wc_af_enable_whitelist_payment_method' ) == 'yes' ) {

			if ( get_option( 'wc_settings_anti_fraud_whitelist_payment_method' ) && null != get_option( 'wc_settings_anti_fraud_whitelist_payment_method' ) ) {

				$get_whitelist_payment_method = get_option( 'wc_settings_anti_fraud_whitelist_payment_method' );

				$payment_method_from_checkout = WC()->session->get( 'chosen_payment_method' );

				if ( in_array( $payment_method_from_checkout, $get_whitelist_payment_method ) ) {
					$selected_whitelist_payment_method = 'true';
				}
			}
		} // check whitelist payment method end

		// check whitelist specific email not wildcard type
		$get_whitelist_email        = get_option( 'wc_settings_anti_fraud_whitelist' );
		$single_whitelist_email_arr = explode( "\n", $get_whitelist_email );
		$selected_whitelisted_email = false;

		$customer_billing_email = isset( $_POST['billing_email'] ) ? sanitize_text_field( $_POST['billing_email'] ) : '';
		if ( in_array( $customer_billing_email, $single_whitelist_email_arr ) ) {
			$selected_whitelisted_email = true;
		} // check whitelist specific email not wildcard type end

		update_option( 'not_whitelisted_email', $selected_whitelisted_email );
		update_option( 'white_payment_methods', $selected_whitelist_payment_method );
		update_option( 'is_whitelisted_roles', $selected_whitelisted_role );
		update_option( 'is_whitelisted_ips', $whitelist_ips );
		// Callback function for check whildcard email
		$selected_wildcard_whitelisted_email = $this->call_wildcard_email_validation();

		$is_enable_blacklist = ( get_option( 'wc_settings_anti_fraudenable_automatic_email_blacklist' ) === 'yes' );

		if ( $is_enable_blacklist ) {
			if ( '' != $blocked_email ) {
				if ( empty( $is_whitelisted ) ) {
					if ( ! $selected_whitelisted_email ) {
						if ( 'true' != $selected_whitelisted_role ) {
							if ( 'true' != $whitelist_ips ) {
								if ( 'true' != $selected_whitelist_payment_method ) {
									if ( 'true' != $selected_wildcard_whitelisted_email ) {
										foreach ( $array_mail as $single ) {
											if ( trim( $single ) == $_POST['billing_email'] ) {
												// echo esc_html_e('This email id is blocked.', 'woocommerce-anti-fraud');.
												// $errors->add( 'validation', __( 'This email id is blocked.', 'woocommerce-anti-fraud' ) );
												global $check_block;
												if ( 1 != $check_block ) {
													// echo ( $wc_af_is_email_blocked );
													wc_add_notice( __( 'This email id is blocked.' ), 'error' );
												}
											}
										}
									}
								}
							}
						}
					}
				}
			} else {
				if ( ! $selected_whitelisted_email ) {
					if ( 'true' != $selected_whitelisted_role ) {
						if ( 'true' != $whitelist_ips ) {
							if ( 'true' != $selected_whitelist_payment_method ) {
								if ( 'true' != $selected_wildcard_whitelisted_email ) {
									foreach ( $array_mail as $single ) {
										if ( trim( $single ) == $_POST['billing_email'] ) {
											// echo esc_html_e('This email id is blocked.', 'woocommerce-anti-fraud');.
											$errors->add( 'validation', __( 'This email id is blocked.', 'woocommerce-anti-fraud' ) );
										}
									}
								}
							}
						}
					}
				}
			}
		}

		if ( '' != $blocked_ipaddress && ! $selected_whitelisted_email && 'true' != $selected_whitelisted_role && 'true' != $selected_whitelist_payment_method && 'true' != $selected_wildcard_whitelisted_email && 'true' != $whitelist_ips ) {

			$userip          = WC_Geolocation::get_ip_address();
			$array_ipaddress = explode( ',', $blocked_ipaddress );
			foreach ( $array_ipaddress as $singles ) {
				if ( trim( $singles ) == $userip ) {
					$errors->add( 'validation', __( 'This IP Address is blocked.', 'woocommerce-anti-fraud' ) );
				}
			}
		}
	}

	/*
	Limit Number of Orders between Time switch is co-related to the other three whitelisted rules. This is because all of these four rules are evaluated on the checkout page before the payment is processed.
	In this function, we are trying to evaluate "Limit Number of Orders between Time" rule before payment is processed on the checkout page.
	Note: Risk Score is evaluated and generated in the callback function (written within a separate helper file) after payment is processed and order is generated.
	 */
	public function max_order_attempt_between_timespan( $fields, $errors ) {

		// check whitelist ips
		$userIp = WC_Geolocation::get_ip_address();

		$get_all_whitelist_ips = get_option( 'wc_settings_anti_fraud_ips_whitelist' );

		$whitelist_ips = 'false';
		if ( '' != $get_all_whitelist_ips ) {

			$s_whitelist_ips = explode( ',', $get_all_whitelist_ips );

			if ( in_array( $userIp, $s_whitelist_ips ) ) {

				$whitelist_ips = 'true';
			}
		}
		//$ip = '195.181.161.229';

		// check whitelist user role
		$user                       = wp_get_current_user();
		$user_roles                 = $user->roles;
		$wc_af_whitelist_user_roles = get_option( 'wc_af_whitelist_user_roles' );

		if ( empty( $wc_af_whitelist_user_roles ) ) {
			$wc_af_whitelist_user_roles = array();
		}

		$selected_whitelisted_role      = 'false';
		$is_enable_whitelist_user_roles = get_option( 'wc_af_enable_whitelist_user_roles' );
		if ( 'yes' == $is_enable_whitelist_user_roles ) {

			foreach ( $user_roles as $role ) {
				if ( in_array( $role, $wc_af_whitelist_user_roles ) ) {
					$selected_whitelisted_role = 'true';
					break;
				}
			}
		} // check whitelist user role end

		// check whitelist payment method
		$selected_whitelist_payment_method = 'false';
		if ( get_option( 'wc_af_enable_whitelist_payment_method' ) == 'yes' ) {

			if ( get_option( 'wc_settings_anti_fraud_whitelist_payment_method' ) && null != get_option( 'wc_settings_anti_fraud_whitelist_payment_method' ) ) {

				$get_whitelist_payment_method = get_option( 'wc_settings_anti_fraud_whitelist_payment_method' );

				$payment_method_from_checkout = WC()->session->get( 'chosen_payment_method' );

				if ( in_array( $payment_method_from_checkout, $get_whitelist_payment_method ) ) {
					$selected_whitelist_payment_method = 'true';
				}
			}
		} // check whitelist payment method end

		// check whitelist specific email not wildcard type
		$get_whitelist_email        = get_option( 'wc_settings_anti_fraud_whitelist' );
		$single_whitelist_email_arr = explode( "\n", $get_whitelist_email );
		$selected_whitelisted_email = 'false';

		if ( isset( $_REQUEST['_wpnonce'] ) ) {
			if ( ! wp_verify_nonce( $_REQUEST['_wpnonce'], 'my-nonce' ) ) {
				echo 'Nonce verification failed!';
				die();
			}
		}

		$customer_billing_email = isset( $_POST['billing_email'] ) ? sanitize_text_field( $_POST['billing_email'] ) : '';
		if ( in_array( $customer_billing_email, $single_whitelist_email_arr ) ) {
			$selected_whitelisted_email = 'true';
		} // check whitelist specific email not wildcard type end

		update_option( 'not_whitelisted_email', $selected_whitelisted_email );
		update_option( 'white_payment_methods', $selected_whitelist_payment_method );
		update_option( 'is_whitelisted_roles', $selected_whitelisted_role );
		update_option( 'is_whitelisted_ips', $whitelist_ips );

		// Callback function for check whildcard email
		$selected_wildcard_whitelisted_email = $this->call_wildcard_email_validation();

		$order_limit_enabled     = get_option( 'wc_af_limit_order_count' );
		$is_update_status_active = get_option( 'wc_af_fraud_update_state' );

		if ( 'yes' === $order_limit_enabled && 'true' != $selected_whitelisted_email && 'true' != $selected_whitelisted_role && 'true' != $selected_whitelist_payment_method && 'true' != $selected_wildcard_whitelisted_email && 'true' != $whitelist_ips ) {

			$orders_allowed_limit = get_option( 'wc_af_allowed_order_limit' );
			$limit_time_start     = get_option( 'wc_af_limit_time_start' );
			$limit_time_end       = get_option( 'wc_af_limit_time_end' );
			// $is_update_status_active = get_option('wc_af_fraud_update_state');
			if ( 0 <= $orders_allowed_limit && ! empty( $limit_time_start ) && ! empty( $limit_time_end ) ) {

				$start_time = new DateTime( $limit_time_start, wp_timezone() );
				$end_time   = new DateTime( $limit_time_end, wp_timezone() );
				$now        = new DateTime( 'NOW', wp_timezone() );

				if ( ( $now >= $start_time ) && ( $now <= $end_time ) ) {

					$orders_between = wc_get_orders(
						array(
							'limit'        => - 1,
							'type'         => wc_get_order_types( 'order-count' ),
							'date_created' => $start_time->getTimestamp() . '...' . $end_time->getTimestamp(),
						)
					);

					if ( $orders_allowed_limit <= count( $orders_between ) ) {
						wc_add_notice( __( 'Max Order Limit between time reached.' ), 'error' );
					}
				}
			}
		}
	}

	/*
	Too many order switch is co-related to the other three whitelisted rules. This is because all of these four rules are evaluated on the checkout page before the payment is processed.
	In this function, we are trying to evaluate "Too many orders" rule before payment is processed on the checkout page.
	Note: Risk Score is evaluated and generated in the callback function (written within a separate helper file) after payment is processed and order is generated.
	 */

	public function too_many_order_attempt_validation( $fields, $errors ) {
		$too_many_order_switch   = get_option( 'wc_af_attempt_count_check' );
		$fraud_attempt_time_span = get_option( 'wc_settings_anti_fraud_attempt_time_span' );
		$max_orders              = get_option( 'wc_settings_anti_fraud_max_order_attempt_time_span' );

		// check whitelist user role
		$user                       = wp_get_current_user();
		$user_roles                 = $user->roles;
		$wc_af_whitelist_user_roles = get_option( 'wc_af_whitelist_user_roles' );

		if ( empty( $wc_af_whitelist_user_roles ) ) {
			$wc_af_whitelist_user_roles = array();
		}

		// check whitelist ips
		$userIp = WC_Geolocation::get_ip_address();

		$get_all_whitelist_ips = get_option( 'wc_settings_anti_fraud_ips_whitelist' );
		$whitelist_ips         = 'false';

		if ( '' != $get_all_whitelist_ips ) {

			$s_whitelist_ips = explode( ',', $get_all_whitelist_ips );

			if ( in_array( $userIp, $s_whitelist_ips ) ) {

				$whitelist_ips = 'true';
			}
		}
		//$ip = '195.181.161.229';

		$selected_whitelisted_role      = 'false';
		$is_enable_whitelist_user_roles = get_option( 'wc_af_enable_whitelist_user_roles' );
		if ( 'yes' == $is_enable_whitelist_user_roles ) {

			foreach ( $user_roles as $role ) {
				if ( in_array( $role, $wc_af_whitelist_user_roles ) ) {
					$selected_whitelisted_role = 'true';
					break;
				}
			}
		} // check whitelist user role end

		// check whitelist payment method
		$selected_whitelist_payment_method = 'false';
		if ( get_option( 'wc_af_enable_whitelist_payment_method' ) == 'yes' ) {

			if ( get_option( 'wc_settings_anti_fraud_whitelist_payment_method' ) && null != get_option( 'wc_settings_anti_fraud_whitelist_payment_method' ) ) {

				$get_whitelist_payment_method = get_option( 'wc_settings_anti_fraud_whitelist_payment_method' );

				$payment_method_from_checkout = WC()->session->get( 'chosen_payment_method' );

				if ( in_array( $payment_method_from_checkout, $get_whitelist_payment_method ) ) {
					$selected_whitelist_payment_method = 'true';
				}
			}
		} // check whitelist payment method end

		// check whitelist specific email not wildcard type
		$get_whitelist_email        = get_option( 'wc_settings_anti_fraud_whitelist' );
		$single_whitelist_email_arr = explode( "\n", $get_whitelist_email );
		$selected_whitelisted_email = 'false';

		$customer_billing_email = isset( $_POST['billing_email'] ) ? sanitize_text_field( $_POST['billing_email'] ) : '';
		if ( in_array( $customer_billing_email, $single_whitelist_email_arr ) ) {
			$selected_whitelisted_email = 'true';
		} // check whitelist specific email not wildcard type end

		update_option( 'not_whitelisted_email', $selected_whitelisted_email );
		update_option( 'white_payment_methods', $selected_whitelist_payment_method );
		update_option( 'is_whitelisted_roles', $selected_whitelisted_role );
		update_option( 'is_whitelisted_ips', $whitelist_ips );

		// Callback function for check whildcard email
		$selected_wildcard_whitelisted_email = $this->call_wildcard_email_validation();

		if ( 'yes' == $too_many_order_switch && 'true' != $selected_whitelisted_email && 'true' != $selected_whitelisted_role && 'true' != $selected_whitelist_payment_method && 'true' != $selected_wildcard_whitelisted_email && 'true' != $whitelist_ips ) {

			// Calculate the new datetime
			$dt      = new DateTime( 'NOW', wp_timezone() );
			$enddate = $dt;
			$enddate = clone $dt;

			$dt->modify( '-' . $fraud_attempt_time_span . ' hours' );

			// Set the start and send datetime strings
			$start_datetime_string = $dt->format( 'Y-m-d H:i:s' );
			$end_datetime_string   = $enddate->format( 'Y-m-d H:i:s' );
			Af_Logger::debug( 'Start Date : ' . $start_datetime_string );
			Af_Logger::debug( 'End Date : ' . $end_datetime_string );

			$ip_address = WC_Geolocation::get_ip_address();
			Af_Logger::debug( 'ip_address : ' . $ip_address );

			if ( isset( $_REQUEST['_wpnonce'] ) ) {
				if ( ! wp_verify_nonce( $_REQUEST['_wpnonce'], 'my-nonce' ) ) {
					echo 'Nonce verification failed!';
					die();
				}
			}

			$user = get_user_by( 'email', isset( $_POST['billing_email'] ) ? sanitize_text_field( $_POST['billing_email'] ) : '' );
			// if(isset($user->ID)){
			// $meta['key'] = '_customer_user';
			// $meta['value'] = $user->ID;
			// } else {
			// $meta['key'] = '_billing_email';
			// $meta['value'] = $_POST[ 'billing_email' ];
			// }
			// Af_Logger::debug('User Meta : '. print_r($meta, true));

			// Get the Same IP Orders
			$orders_count_ip = wc_get_orders(
				array(
					'limit'               => - 1,
					// 'meta_key'            => '_billing_email',
					// 'meta_value'          => isset($_POST[ 'billing_email' ]) ? sanitize_text_field($_POST['billing_email'] ) : '',
					'customer_ip_address' => $ip_address,
					'type'                => wc_get_order_types( 'order-count' ),
					'date_after'          => $start_datetime_string,
					'date_before'         => $end_datetime_string,
				)
			);

			$orders_count_email = wc_get_orders(
				array(
					'limit' => - 1,

					'meta_key'     => '_billing_email', // Postmeta key field
					'meta_value'   => isset( $_POST['billing_email'] ) ? sanitize_text_field( $_POST['billing_email'] ) : '', // Postmeta value field
					'meta_compare' => '=',
					'type'         => wc_get_order_types( 'order-count' ),
					'date_after'   => $start_datetime_string,
					'date_before'  => $end_datetime_string,
				)
			);

			$orders_count_phone = wc_get_orders(
				array(
					'limit'        => - 1,
					'meta_key'     => '_billing_phone', // Postmeta key field
					'meta_value'   => isset( $_POST['billing_phone'] ) ? sanitize_text_field( $_POST['billing_phone'] ) : '', // Postmeta value field
					'meta_compare' => '=',
					'type'         => wc_get_order_types( 'order-count' ),
					'date_after'   => $start_datetime_string,
					'date_before'  => $end_datetime_string,
				)
			);

			$order_count_user = wc_get_orders(
				array(
					'limit'               => - 1,
					'meta_key'            => '_customer_user',
					'meta_value'          => isset( $user->ID ) ? $user->ID : '',
					'customer_ip_address' => $ip_address,
					'type'                => wc_get_order_types( 'order-count' ),
					'date_after'          => $start_datetime_string,
					'date_before'         => $end_datetime_string,
				)
			);

			// Af_Logger::debug('Orders : '. print_r($orders_count, true));
			Af_Logger::debug( 'Order Count : ' . count( $orders_count_ip ) );
			if ( count( $orders_count_ip ) >= $max_orders || count( $orders_count_email ) >= $max_orders || count( $orders_count_phone ) >= $max_orders ) {
				$errors->add(
					'validation',
					/* translators: %s: order time span */
					sprintf( esc_html__( 'You have reached maximum number of allowed orders in %d hours. Please try again later.', 'woocommerce-anti-fraud' ), $fraud_attempt_time_span )
				);
			}
		}
	}

	/*
	Pre-payment switch is co-related to the other three whitelisted rules. This is because all of these four rules are evaluated on the checkout page before the payment is processed.
	In this function, we are trying to get risk score and evaluate "Pre-payment"  before payment is processed on the checkout page.
	 */
	public function wh_pre_paymentcall( $order_id, $errors ) {

		if ( ! is_numeric( $order_id ) ) {
			return;
		}

		$order = wc_get_order( $order_id );

		$email_whitelist = get_option( 'wc_settings_anti_fraud_whitelist' );

		//$whitelist = explode("\n", $email_whitelist);
		$whitelist = array_map( 'trim', explode( ',', $email_whitelist ) );

		$selected_whitelisted_email = false;
		if ( isset( $_REQUEST['_wpnonce'] ) ) {
			if ( ! wp_verify_nonce( $_REQUEST['_wpnonce'], 'my-nonce' ) ) {
				echo 'Nonce verification failed!';
				die();
			}
		}

		$whitelist_array = isset( $_POST['billing_email'] ) ? sanitize_text_field( $_POST['billing_email'] ) : '';
		if ( in_array( $whitelist_array, $whitelist ) ) {
			$selected_whitelisted_email = true;
			opmc_hpos_update_post_meta( $order_id, 'wc_af_score', 100 );
			opmc_hpos_update_post_meta( $order_id, 'whitelist_action', 'user_email_whitelisted' );
			$order->add_order_note( __( 'Order fraud checks skipped due to whitelisted email.', 'woocommerce-anti-fraud' ) );

			return;
		}

		// check whitelist ips
		$userIp = WC_Geolocation::get_ip_address();

		$get_all_whitelist_ips = get_option( 'wc_settings_anti_fraud_ips_whitelist' );

		$whitelist_ips = 'false';

		if ( '' != $get_all_whitelist_ips ) {

			$s_whitelist_ips = explode( ',', $get_all_whitelist_ips );

			if ( in_array( $userIp, $s_whitelist_ips ) ) {

				$whitelist_ips = 'true';
				opmc_hpos_update_post_meta( $order_id, 'wc_af_score', 100 );
				opmc_hpos_update_post_meta( $order_id, 'whitelist_action', 'user_email_whitelisted' );
				$order->add_order_note( __( 'Order fraud checks skipped due to whitelisted customer IPs.', 'woocommerce-anti-fraud' ) );

				return;
			}
		}
		//$ip = '195.181.161.229';

		// check whitelist user role
		$user                       = wp_get_current_user();
		$user_roles                 = $user->roles;
		$wc_af_whitelist_user_roles = get_option( 'wc_af_whitelist_user_roles' );

		if ( empty( $wc_af_whitelist_user_roles ) ) {
			$wc_af_whitelist_user_roles = array();
		}

		$selected_whitelisted_role      = 'false';
		$is_enable_whitelist_user_roles = get_option( 'wc_af_enable_whitelist_user_roles' );
		if ( 'yes' == $is_enable_whitelist_user_roles ) {

			foreach ( $user_roles as $role ) {
				if ( in_array( $role, $wc_af_whitelist_user_roles ) ) {

					$selected_whitelisted_role = 'true';
					opmc_hpos_update_post_meta( $order_id, 'wc_af_score', 100 );
					opmc_hpos_update_post_meta( $order_id, 'whitelist_action', 'user_email_whitelisted' );
					$order->add_order_note( __( 'Order fraud checks skipped due to whitelisted user role.', 'woocommerce-anti-fraud' ) );
					break;

					return;
				}
			}
		} // check whitelist user role end

		// check whitelist payment method
		$selected_whitelist_payment_method = 'false';
		if ( get_option( 'wc_af_enable_whitelist_payment_method' ) == 'yes' ) {

			if ( get_option( 'wc_settings_anti_fraud_whitelist_payment_method' ) && null != get_option( 'wc_settings_anti_fraud_whitelist_payment_method' ) ) {

				$whitelist_payment_method = get_option( 'wc_settings_anti_fraud_whitelist_payment_method' );

				$payment_method = WC()->session->get( 'chosen_payment_method' );

				if ( in_array( $payment_method, $whitelist_payment_method ) ) {
					$selected_whitelist_payment_method = 'true';
					opmc_hpos_update_post_meta( $order_id, 'wc_af_score', 100 );
					opmc_hpos_update_post_meta( $order_id, 'whitelist_action', 'user_email_whitelisted' );
					$order->add_order_note( __( 'Order fraud checks skipped due to whitelisted payment method.', 'woocommerce-anti-fraud' ) );

					return;
				}
			}
		} // check whitelist payment method end

		$check_before_payment_switch = get_option( 'wc_af_fraud_check_before_payment' );
		// echo $check_before_payment;
		$selected_wildcard_whitelisted_email = $this->call_wildcard_email_validation();

		if ( 'yes' == $check_before_payment_switch && ! $selected_whitelisted_email && 'true' != $selected_whitelisted_role && 'true' != $selected_whitelist_payment_method && 'true' != $selected_wildcard_whitelisted_email && 'true' != $whitelist_ips ) {

			if ( null !== get_option( 'wc_af_pre_payment_message' ) ) {
				$pre_payment_block_message = get_option( 'wc_af_pre_payment_message' );
			} else {
				$pre_payment_block_message = __( 'Website Administrator does not allow you to place this order. Please contact our support team. Sorry for any inconvenience.', 'woocommerce-anti-fraud' );
			}

			$high_risk    = get_option( 'wc_settings_anti_fraud_higher_risk_threshold' );
			$score_helper = new WC_AF_Score_Helper();
			$score_helper->schedule_fraud_check( $order_id, true );

			$score_points  = opmc_hpos_get_post_meta( $order_id, 'wc_af_score', true );
			$circle_points = WC_AF_Score_Helper::invert_score( $score_points );

			if ( $high_risk <= $circle_points ) {

				$order->update_status( 'failed', 'Pre Payment Fraud Check: Calculated risk score is above High Risk Threshold.', true );

				$return = array(
					'result'   => 'failure',
					'messages' => "<ul class='woocommerce-error' role='alert'><li>" . $pre_payment_block_message . '</li></ul>',
				);

				wp_send_json( $return );
				wp_die();
			}
		}
	}

	/* Related to oder debug log details */

	public function create_table_debuglog_file_downloads() {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();
		$table_name      = $wpdb->prefix . 'af_download_url';
		$sql             = 'CREATE TABLE ' . $table_name . " (
	        id int(12) NOT NULL AUTO_INCREMENT,
	        download_url varchar(256) NOT NULL,
	        created_at date NOT NULL,
	        PRIMARY KEY id (id),
	        INDEX created_at (created_at)
	    ) $charset_collate;";

		if ( ! function_exists( 'dbDelta' ) ) {
			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		}

		dbDelta( $sql );
	}

	public function create_log_folder() {

		$uploads_dir = trailingslashit( wp_upload_dir()['basedir'] ) . 'antifraud';
		wp_mkdir_p( $uploads_dir, 777 );
	}

	public function insert_debuglog_download_data( $download_url ) {
		global $wpdb;
		$table_name = $wpdb->prefix . 'af_download_url'; // do not forget about tables prefix
		if ( ! empty( $download_url ) ) {
			$wpdb->insert(
				$table_name,
				array(
					'download_url' => $download_url,
					'created_at'   => gmdate( 'Y-m-d' ),
				)
			);
		}
	}

	public function create_log_file_before_submit( $order_id ) {

		$enable_log_check = get_option( 'wc_af_enable_log_check' );
		if ( ! empty( $enable_log_check ) && 'no' != $enable_log_check ) {

			/* General Settings */
			$settings_anti_fraud_low_risk_threshold    = get_option( 'wc_settings_anti_fraud_low_risk_threshold' );
			$settings_anti_fraud_higher_risk_threshold = get_option( 'wc_settings_anti_fraud_higher_risk_threshold' );
			$fraud_check_before_payment                = get_option( 'wc_af_fraud_check_before_payment' );
			$pre_payment_block_message                 = get_option( 'wc_af_pre_payment_message' );
			$fraud_update_state                        = get_option( 'wc_af_fraud_update_state' );
			$settings_anti_fraud_cancel_score          = get_option( 'wc_settings_anti_fraud_cancel_score' );
			$settings_anti_fraud_hold_score            = get_option( 'wc_settings_anti_fraud_hold_score' );
			$enable_whitelist_payment_method           = get_option( 'wc_af_enable_whitelist_payment_method' );
			$whitelist_payment_method                  = get_option( 'wc_settings_anti_fraud_whitelist_payment_method' );

			if ( ! empty( $whitelist_payment_method ) ) {
				$whitelist_payment_method = implode( ',', $whitelist_payment_method );
			} else {
				$whitelist_payment_method = '';
			}

			$is_enable_whitelist_user_roles = get_option( 'wc_af_enable_whitelist_user_roles' );
			$wc_af_whitelist_user_roles     = get_option( 'wc_af_whitelist_user_roles' );
			if ( ! empty( $wc_af_whitelist_user_roles ) ) {
				$wc_af_whitelist_user_roles = implode( ',', $wc_af_whitelist_user_roles );
			} else {
				$wc_af_whitelist_user_roles = '';
			}

			$email_whitelist        = get_option( 'wc_settings_anti_fraud_whitelist' );
			$start_auto_fraud_check = get_option( 'wc_af_start_auto_fraud_check' );
			$debuglog               = 'no';

			/* General Rule */
			$first_order                                     = get_option( 'wc_af_first_order' );
			$fraud_first_order_weight                        = get_option( 'wc_settings_anti_fraud_first_order_weight' );
			$wc_af_first_order_custom                        = get_option( 'wc_af_first_order_custom' );
			$fraud_first_order_custom_weight                 = get_option( 'wc_settings_anti_fraud_first_order_custom_weight' );
			$ip_geolocation_order                            = get_option( 'wc_af_ip_geolocation_order' );
			$settings_anti_fraud_ip_geolocation_order_weight = get_option( 'wc_settings_anti_fraud_ip_geolocation_order_weight' );
			$bca_order                                       = get_option( 'wc_af_bca_order' );
			$fraud_bca_order_weight                          = get_option( 'wc_settings_anti_fraud_bca_order_weight' );
			$geolocation_order                               = get_option( 'wc_af_geolocation_order' );
			$fraud_geolocation_order_weight                  = get_option( 'wc_settings_anti_fraud_geolocation_order_weight' );
			$billing_phone_number_order                      = get_option( 'wc_af_billing_phone_number_order' );
			$fraud_billing_phone_number_order_weight         = get_option( 'wc_settings_anti_fraud_billing_phone_number_order_weight' );
			$proxy_order                                     = get_option( 'wc_af_proxy_order' );
			$fraud_proxy_order_weight                        = get_option( 'wc_settings_anti_fraud_proxy_order_weight' );
			$ip_multiple_check                               = get_option( 'wc_af_ip_multiple_check' );
			$settings_anti_fraud_ip_multiple_weight          = get_option( 'wc_settings_anti_fraud_ip_multiple_weight' );
			$fraud_ip_multiple_time_span                     = get_option( 'wc_settings_anti_fraud_ip_multiple_time_span' );
			$international_order                             = get_option( 'wc_af_international_order' );
			$settings_anti_fraud_international_order_weight  = get_option( 'wc_settings_anti_fraud_international_order_weight' );
			$unsafe_countries                                = get_option( 'wc_af_unsafe_countries' );
			$settings_anti_fraud_unsafe_countries_weight     = get_option( 'wc_settings_anti_fraud_unsafe_countries_weight' );

			$fraud_define_unsafe_countries_list = get_option( 'wc_settings_anti_fraud_define_unsafe_countries_list' );

			if ( ! empty( $fraud_define_unsafe_countries_list ) ) {
				$fraud_define_unsafe_countries_list = implode( ',', $fraud_define_unsafe_countries_list );
			} else {
				$fraud_define_unsafe_countries_list = '';
			}
			$suspecius_email                              = get_option( 'wc_af_suspecius_email' );
			$settings_anti_fraud_suspecious_email_weight  = get_option( 'wc_settings_anti_fraud_suspecious_email_weight' );
			$settings_anti_fraud_suspecious_email_domains = get_option( 'wc_settings_anti_fraud_suspecious_email_domains' );
			$check_email_domain_api_key                   = get_option( 'check_email_domain_api_key' );
			$order_avg_amount_check                       = get_option( 'wc_af_order_avg_amount_check' );
			$fraud_order_avg_amount_weight                = get_option( 'wc_settings_anti_fraud_order_avg_amount_weight' );
			$fraud_avg_amount_multiplier                  = get_option( 'wc_settings_anti_fraud_avg_amount_multiplier' );
			$order_amount_check                           = get_option( 'wc_af_order_amount_check' );
			$fraud_order_amount_weight                    = get_option( 'wc_settings_anti_fraud_order_amount_weight' );
			$fraud_amount_limit                           = get_option( 'wc_settings_anti_fraud_amount_limit' );
			$attempt_count_check                          = get_option( 'wc_af_attempt_count_check' );
			$fraud_order_attempt_weight                   = get_option( 'wc_settings_anti_fraud_order_attempt_weight' );
			$fraud_attempt_time_span                      = get_option( 'wc_settings_anti_fraud_attempt_time_span' );
			$fraud_max_order_attempt_time_span            = get_option( 'wc_settings_anti_fraud_max_order_attempt_time_span' );
			$limit_order_count                            = get_option( 'wc_af_limit_order_count' );
			$limit_time_start                             = get_option( 'wc_af_limit_time_start' );
			$allowed_order_limit                          = get_option( 'wc_af_allowed_order_limit' );
			$limit_time_end                               = get_option( 'wc_af_limit_time_end' );

			/* Email Blacklisting */
			$enable_automatic_email_blacklist = get_option( 'wc_settings_anti_fraudenable_automatic_email_blacklist' );
			$enable_automatic_blacklist       = get_option( 'wc_settings_anti_fraudenable_automatic_blacklist' );
			$blacklist_emails                 = get_option( 'wc_settings_anti_fraudblacklist_emails' );
			$is_enable_ip_blacklist           = get_option( 'wc_settings_anti_fraudenable_automatic_ip_blacklist' );
			$blacklist_ip                     = get_option( 'wc_settings_anti_fraudblacklist_ipaddress' );
			$email_notification               = get_option( 'wc_af_email_notification' );
			$settings_anti_fraud_email_score  = get_option( 'wc_settings_anti_fraud_email_score' );

			/* Paypal Settings */
			$paypal_verification             = get_option( 'wc_af_paypal_verification' );
			$paypal_prevent_downloads        = get_option( 'wc_af_paypal_prevent_downloads' );
			$fraud_time_paypal_attempts      = get_option( 'wc_settings_anti_fraud_time_paypal_attempts' );
			$fraud_day_deleting_paypal_order = get_option( 'wc_settings_anti_fraud_day_deleting_paypal_order' );
			$fraud_paypal_verified_address   = get_option( 'wc_settings_anti_fraud_paypal_verified_address' );

			/* MaxMind minFraud Settings */
			$enable_maxmind_minfraud     = get_option( 'wc_af_maxmind_type' );
			$device_trackin_settings     = get_option( 'wc_af_maxmind_device_tracking' );
			$maxmind_user                = get_option( 'wc_af_maxmind_user' );
			$maxmind_license_key         = get_option( 'wc_af_maxmind_license_key' );
			$fraud_minfraud_risk_score   = get_option( 'wc_settings_anti_fraud_minfraud_risk_score' );
			$fraud_minfraud_order_weight = get_option( 'wc_settings_anti_fraud_minfraud_order_weight' );

			/* MaxMind minFraud insights Settings */
			$maxmind_insights_setting             = get_option( 'wc_af_maxmind_insights' );
			$fraud_minfraud_insights_risk_score   = get_option( 'wc_settings_anti_fraud_minfraud_insights_risk_score' );
			$fraud_minfraud_insights_order_weight = get_option( 'wc_settings_anti_fraud_minfraud_insights_order_weight' );

			/* MaxMind minFraud factors Settings */

			$wc_af_maxmind_factors_setting       = get_option( 'wc_af_maxmind_factors' );
			$fraud_minfraud_factors_risk_score   = get_option( 'wc_settings_anti_fraud_minfraud_factors_risk_score' );
			$fraud_minfraud_factors_order_weight = get_option( 'wc_settings_anti_fraud_minfraud_factors_order_weight' );

			/* Google Re-Captcha Settings */
			$enable_recaptcha_checkout = get_option( 'wc_settings_anti_fraudenable_enable_recaptcha' );
			$v2_recaptcha_site_key     = get_option( 'wc_af_recaptcha_site_key' );
			$v2_recaptcha_secret_key   = get_option( 'wc_af_recaptcha_secret_key' );

			$order            = wc_get_order( $order_id );
			$orderno          = $order->get_id();
			$order_date_time  = $order->get_date_created();
			$order_status     = $order->get_status();
			$customer_name    = $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();
			$email            = $order->get_billing_email();
			$phone            = $order->get_billing_phone();
			$billing_address  = $order->get_billing_address_1() . ' ' . $order->get_billing_address_2() . ', ' . $order->get_billing_city() . ', ' . $order->get_billing_state() . ', ' . $order->get_billing_postcode() . ', ' . $order->get_billing_country();
			$shipping_address = $order->get_shipping_address_1() . ' ' . $order->get_shipping_address_2() . ', ' . $order->get_shipping_city() . ', ' . $order->get_shipping_state() . ', ' . $order->get_shipping_postcode() . ', ' . $order->get_shipping_country();
			if ( empty( $shipping_address ) ) {
				$shipping_address = $billing_address;
			}
			$payment_method = $order->get_payment_method_title();
			$numer_of_items = $order->get_item_count();
			$subtotal       = $order->get_subtotal();
			$shipping       = $order->get_shipping_total();
			$discount       = $order->get_discount_total();
			$tax_amount     = $order->get_total_tax();
			$total_amount   = $order->get_total();

			$csv_content = $this->headercontent();
			$upload_dir  = wp_get_upload_dir()['basedir'];
			$file_path   = $upload_dir . '/antifraud';
			$files       = glob( "$file_path/*.csv" );

			$rows = array(
				array(
					$orderno,
					$order_date_time,
					$order_status,
					$customer_name,
					$email,
					$phone,
					$billing_address,
					$shipping_address,
					$payment_method,
					$numer_of_items,
					$subtotal,
					$shipping,
					$discount,
					$tax_amount,
					$total_amount,
					$settings_anti_fraud_low_risk_threshold,
					$settings_anti_fraud_higher_risk_threshold,
					$fraud_check_before_payment,
					$fraud_update_state,
					$settings_anti_fraud_cancel_score,
					$settings_anti_fraud_hold_score,
					$enable_whitelist_payment_method,
					$whitelist_payment_method,
					$is_enable_whitelist_user_roles,
					$wc_af_whitelist_user_roles,
					$email_whitelist,
					$start_auto_fraud_check,
					$debuglog,
					$first_order,
					$fraud_first_order_weight,
					$wc_af_first_order_custom,
					$fraud_first_order_custom_weight,
					$ip_geolocation_order,
					$settings_anti_fraud_ip_geolocation_order_weight,
					$bca_order,
					$fraud_bca_order_weight,
					$geolocation_order,
					$fraud_geolocation_order_weight,
					$billing_phone_number_order,
					$fraud_billing_phone_number_order_weight,
					$proxy_order,
					$fraud_proxy_order_weight,
					$ip_multiple_check,
					$settings_anti_fraud_ip_multiple_weight,
					$fraud_ip_multiple_time_span,
					$international_order,
					$settings_anti_fraud_international_order_weight,
					$unsafe_countries,
					$settings_anti_fraud_unsafe_countries_weight,
					$fraud_define_unsafe_countries_list,
					$suspecius_email,
					$settings_anti_fraud_suspecious_email_weight,
					$settings_anti_fraud_suspecious_email_domains,
					$check_email_domain_api_key,
					$order_avg_amount_check,
					$fraud_order_avg_amount_weight,
					$fraud_avg_amount_multiplier,
					$order_amount_check,
					$fraud_order_amount_weight,
					$fraud_amount_limit,
					$attempt_count_check,
					$fraud_order_attempt_weight,
					$fraud_attempt_time_span,
					$fraud_max_order_attempt_time_span,
					$limit_order_count,
					$limit_time_start,
					$limit_time_end,
					$allowed_order_limit,
					$enable_automatic_email_blacklist,
					$enable_automatic_blacklist,
					$blacklist_emails,
					$is_enable_ip_blacklist,
					$blacklist_ip,
					$email_notification,
					$settings_anti_fraud_email_score,
					$paypal_verification,
					$paypal_prevent_downloads,
					$fraud_time_paypal_attempts,
					$fraud_day_deleting_paypal_order,
					$fraud_paypal_verified_address,
					$enable_maxmind_minfraud,
					$device_trackin_settings,
					$maxmind_user,
					$maxmind_license_key,
					$fraud_minfraud_risk_score,
					$fraud_minfraud_order_weight,
					$maxmind_insights_setting,
					$fraud_minfraud_insights_risk_score,
					$fraud_minfraud_insights_order_weight,
					$wc_af_maxmind_factors_setting,
					$fraud_minfraud_factors_risk_score,
					$fraud_minfraud_factors_order_weight,
					$enable_recaptcha_checkout,
					$v2_recaptcha_site_key,
					$v2_recaptcha_secret_key,
				),
			);

			$today = gmdate( 'Y-m-d' );
			if ( ! empty( $files ) ) {
				foreach ( $files as $value ) {
					$val                 = $value;
					$file_name           = basename( $val );
					$created_file        = str_split( $file_name, 14 );
					$created_file_date[] = explode( '.', $created_file[1] );
				}
				foreach ( $created_file_date as $value ) {
					$new[] = $value[0];
				}

				if ( in_array( $today, $new ) ) {

					$upload_dir = wp_get_upload_dir()['basedir'];

					$file_path = $upload_dir . '/antifraud/antifraud-log-' . $today . '.csv';

					$fp = fopen( $file_path, 'a' ); // open in write only mode (with pointer at the end of the file)

					foreach ( $rows as $row ) {
						fputcsv( $fp, $row );
					}
					fclose( $fp );
				} else {

					$upload_dir       = wp_get_upload_dir()['basedir'];
					$file_path        = $upload_dir . '/antifraud/antifraud-log-' . gmdate( 'Y-m-d' ) . '.csv';
					$csv_content_file = '';
					file_put_contents( $file_path, $csv_content_file );
					$fp = fopen( $file_path, 'a' ); // open in write only mode (with pointer at the end of the file)
					foreach ( $csv_content as $row ) {
						fputcsv( $fp, $row );
					}
					fclose( $fp );

					$download_url = get_site_url() . '/wp-content/uploads/antifraud/antifraud-log-' . $today . '.csv';

					$this->insert_debuglog_download_data( $download_url );

					$fp = fopen( $file_path, 'a' ); // open in write only mode (with pointer at the end of the file)
					foreach ( $rows as $row ) {
						fputcsv( $fp, $row );
					}
					fclose( $fp );
				}
			} else {

				$upload_dir       = wp_get_upload_dir()['basedir'];
				$file_path        = $upload_dir . '/antifraud/antifraud-log-' . gmdate( 'Y-m-d' ) . '.csv';
				$csv_content_file = '';
				file_put_contents( $file_path, $csv_content_file );
				$fp = fopen( $file_path, 'a' ); // open in write only mode (with pointer at the end of the file)
				foreach ( $csv_content as $row ) {
					fputcsv( $fp, $row );
				}
				fclose( $fp );
				$download_url = get_site_url() . '/wp-content/uploads/antifraud/antifraud-log-' . $today . '.csv';

				$this->insert_debuglog_download_data( $download_url );
				$fp = fopen( $file_path, 'a' ); // open in write only mode (with pointer at the end of the file)
				foreach ( $rows as $row ) {
					fputcsv( $fp, $row );
				}
				fclose( $fp );
			}
		}
	}

	public function headercontent( $header_content = '' ) {
		$header_content = array(
			array(
				'orderno',
				'order-date-time',
				'order-status',
				'customer-name',
				'email',
				'phone',
				'billing-address',
				'shipping-address',
				'payment-method',
				'numer-of-items',
				'subtotal',
				'shipping',
				'discount',
				'tax-amount',
				'total-amount',
				'medium-risk-threshold',
				'high-risk-threshold',
				'pre-pay-check',
				'update-status-based-fraudscore',
				'weight-cancel-order',
				'weight-order-onhold',
				'whitelist-pay-method',
				'select-whitelist-pay-methods',
				'whitelist-of-user-role',
				'select-user-role-whitelist',
				'email-whitelist',
				'autofraud-check',
				'debuglog',
				'first-purchase-check',
				'first-purchase-value',
				're-check-first-orders-in-process-state-check',
				're-check-first-orders-in-process-state-value',
				'ip-address-match-location-check',
				'ip-address-match-location-value',
				'billing-shipping-address-same-check',
				'billing-shipping-address-same-value',
				'geo-location-match-check',
				'geo-location-match-value',
				'phone-number-billing-country-check',
				'phone-number-billing-country-value',
				'customer-behind-proxy-vpn-check',
				'customer-behind-proxy-vpn-value',
				'purchased-from-same-ip-but-different-customer-address-check',
				'purchased-from-same-ip-but-different-customer-address-value',
				'past-number-of-days',
				'it-international-order-check',
				'it-international-order-value',
				'order-high-risk-country-check',
				'order-high-risk-country-value',
				'mark-unsafe-countries',
				'high-risk-email-domain-check',
				'high-risk-email-domain-value',
				'high-risk-domains',
				'key-for-quickemailverification',
				'order-amount-above-average-check',
				'order-amount-above-average-value',
				'average-multiplier',
				'order-exceeds-max-amount-limit-check',
				'order-exceeds-max-amount-limit-value',
				'amount-limit, many-order-attempts-check',
				'many-order-attempts-value',
				'time-span-check-hours',
				'max-allowed-number-of-orders-time-span',
				'limit-number-orders-between-time-check',
				'start-time, end-time',
				'limit-number-orders-between-time',
				'email-blacklist',
				'automatic-blacklisting',
				'blocked-email-addresses',
				'ip-blacklist',
				'blocked-ip-addresses',
				'activate-email-alerts-for-admin',
				'additional-address-notify',
				'email-notification-score',
				'enable-disable-paypal',
				'block-downloads',
				'verification-retry',
				'auto-cancellation-days',
				'paypal-verified-address',
				'email-type',
				'enable-disable-minfraud',
				'device-tracking',
				'maxmind-account-id',
				'maxmind-license-key',
				'threshold-minfraud-score',
				'minfraud-rule-weight',
				'enable-disable-minfraud-insights',
				'threshold-minfraud-insights-score',
				'minfraud-insights-rule-weight',
				'enable-disable-minfraud-factors',
				'threshold-minFraud-factors-score',
				'minfraud-factors-rule-weight',
				'enable-re-captcha',
				'enable-v2-re-captcha',
				'v2-site-key',
				'v2-secret-key',
				'enable-v3-re-captcha',
				'v3-site-key',
				'v3-secret-key',
			),
		);

		return $header_content;
	}

	/* Debug log end*/

	public function my_admin_notice() {

		$wc_af_enable_recaptcha_checkout = get_option( 'wc_settings_anti_fraudenable_enable_recaptcha' );
		if ( 'yes' != $wc_af_enable_recaptcha_checkout ) {

			?>
            <div class="notice error is-dismissible">

                <p>
					<?php
					/* translators: 1. start of link, 2. end of link. */
					printf( esc_html__( 'Please consider enabling reCaptcha in the Anti Fraud plugin %1$ssettings%2$s to help prevent Velocity attacks.', 'woocommerce-anti-fraud' ), '<a href="' . esc_url( admin_url( 'admin.php?page=wc-settings&tab=wc_af&section=minfraud_recaptcha_settings' ) ) . '">', '</a>' );
					?>
                </p>
            </div>
            <script type="text/javascript">
                jQuery(document).ready(function () {
                    jQuery(document).on('click', '.notice-dismiss', function () {
                        //alert('It will again appear after 24 hours.');
                        jQuery.ajax({
                            url: ajaxurl,
                            data: {
                                action: 'my_dismiss_notice'
                            }
                        });
                    });
                });
            </script>
			<?php
		}
	}

	public function my_dismiss_notice() {
		$now = gmdate( 'Y-m-d H:i:s' );
		update_option( 'my_notice_dismisseds', 1 );
		// update_option( 'my_notice_dismisseds_time', $now );
	}

	public function my_action_geo_country() {

		$bigdatacloud_key = get_option( 'bigdatacloud_api_key', true );

		if ( ! empty( $_POST['latitude'] ) && ! empty( $_POST['longitude'] ) && ! empty( $bigdatacloud_key ) ) {

			if ( isset( $_REQUEST['_wpnonce'] ) ) {
				if ( ! wp_verify_nonce( $_REQUEST['_wpnonce'], 'my-nonce' ) ) {
					echo 'Nonce verification failed!';
					die();
				}
			}

			$lat      = sanitize_text_field( $_POST['latitude'] );
			$lng      = sanitize_text_field( $_POST['longitude'] );
			$response = wp_remote_get( 'https://api-bdc.net/data/reverse-geocode?latitude=' . $lat . '&longitude=' . $lng . '&localityLanguage=en&key=' . $bigdatacloud_key );

			//Test_api_key: bdc_ec1d9f652ec041888c19833cca0d0999;
			if ( is_wp_error( $response ) ) {
				echo 'error';
				die();
			}
			if ( isset( $response ) ) {

				$output = json_decode( $response['body'], true );
				if ( ! empty( $output ) ) {

					if ( ! empty( $output['city'] ) ) {
						$g_city = strtolower( $output['city'] );
						update_option( 'html_geo_loc_city', $g_city );
					} else {
						if ( ! empty( $output['countryCode'] ) ) {
							$g_countryCode = strtolower( $output['countryCode'] );
							update_option( 'html_geo_loc_cntry', $g_countryCode );
						}
					}
					if ( ! empty( $output['principalSubdivision'] ) ) {
						$g_state = strtolower( $output['principalSubdivision'] );
						update_option( 'html_geo_loc_state', $g_state );
					}
					echo 'success';
					die();
				}
			}
		} else {
			delete_option( 'html_geo_loc_state' );
			delete_option( 'html_geo_loc_city' );
			delete_option( 'html_geo_loc_cntry' );
		}
		die();
	}

	public function add_scripts_to_pages() {
		$maxmind_settings               = get_option( 'wc_af_maxmind_type' ); // Get MaxMind enable/disable
		$wc_af_maxmind_insights_setting = get_option( 'wc_af_maxmind_insights' ); // Get MaxMind insights enable/disable
		$wc_af_maxmind_factors_setting  = get_option( 'wc_af_maxmind_factors' ); // Get MaxMind factors enable/disable
		$bigdatacloud_key               = get_option( 'bigdatacloud_api_key' ); // Get bigdatacloud API key
		if ( 'yes' != $maxmind_settings && 'yes' != $wc_af_maxmind_insights_setting && 'yes' != $wc_af_maxmind_factors_setting ) {

			wp_enqueue_script( 'ajax_operation_script', plugins_url( 'assets/js/geoloc.js', __FILE__ ), array(), '1.0' );
			wp_localize_script( 'ajax_operation_script', 'bigdatacloud_key', $bigdatacloud_key );
			wp_localize_script( 'ajax_operation_script', 'myAjax', array( 'ajaxurl' => admin_url( 'admin-ajax.php', 'relataive' ) ) );
			wp_enqueue_script( 'ajax_operation_script' );

		}
	}

	public function plugin_load_td() {
	}

	public function check_for_card_error( $order_id ) {

		if ( ! defined( 'WC_VERSION' ) ) {
			return;
		}

		$order               = wc_get_order( $order_id );
		$ip_address          = $order->get_customer_ip_address();
		$orderemail          = version_compare( WC_VERSION, '3.0', '<' ) ? $order->billing_email : $order->get_billing_email();
		$current_user_id     = $order->get_user_id();
		$order_date          = $order->get_date_created();
		$order_date          = gmdate( 'Y-m-d', strtotime( $order_date ) );
		$currentDate         = gmdate( 'Y-m-d' );
		$userDetails         = $order->get_user();
		$userRole            = $userDetails->roles[0];
		$blacklist_available = false;

		$args = array(
			'post_type'      => 'shop_order',
			'post_status'    => 'any',
			'posts_per_page' => 1,
			'meta_query'     => array(
				array(
					'key'   => '_customer_user',
					'value' => $current_user_id,
				),
			),
			'orderby'        => 'ID',
			'order'          => 'DESC',
		);

		$loop     = new WP_Query( $args );
		$orderids = array();
		while ( $loop->have_posts() ) {
			$loop->the_post();
			$orderids[] = get_the_ID();
		}
		wp_reset_postdata();

		$_card_decline_times = 0;
		$cardDeclinedMsgs    = array( 'authentication failed', 'declined' );
		if ( ! empty( $orderids ) ) {
			global $wpdb;
			$table_perfixed = $wpdb->prefix . 'comments';
			$orderids       = implode( ',', $orderids );
			$sql            = "SELECT * FROM $table_perfixed WHERE  `comment_post_ID` IN ($orderids) AND  `comment_type` LIKE  'order_note'";
			$results        = $wpdb->get_results( $wpdb->prepare( '%s', $sql ) );
			$ic             = 1;
			foreach ( $results as $note ) {
				if ( ( strpos( $note->comment_content, 'declined' ) !== false ) || ( strpos( $note->comment_content, 'authentication failed' ) !== false ) ) {
					Af_Logger::debug( 'Note ' . $ic . ' ' . $note->comment_content );
					$_card_decline_times = opmc_hpos_get_post_meta( $order_id, '_card_decline_times', true );
					if ( isset( $_card_decline_times ) && ! empty( $_card_decline_times ) ) {
						++ $_card_decline_times;
						opmc_hpos_update_post_meta( $order_id, '_card_decline_times', $_card_decline_times );
					} else {
						opmc_hpos_update_post_meta( $order_id, '_card_decline_times', 1 );
					}
					break;
				}
				$ic ++;
			}
		}
		$_card_decline_times = opmc_hpos_get_post_meta( $order_id, '_card_decline_times', true );
		Af_Logger::debug( 'Card declined ' . $_card_decline_times . ' times' );

		if ( ( $_card_decline_times >= 5 ) && ( $order_date == $currentDate ) ) {

			$is_enable_ip_blacklist = get_option( 'wc_settings_anti_fraudenable_automatic_ip_blacklist' );
			// Blacklist ip if enabled
			if ( 'yes' == $is_enable_ip_blacklist ) {
				Af_Logger::debug( 'IP Blacklist ' . $ip_address );
				$existing_blacklist_ip = get_option( 'wc_settings_anti_fraudblacklist_ipaddress', false );
				if ( '' != $existing_blacklist_ip ) {
					$auto_blacklist_ip = explode( ',', $existing_blacklist_ip );

					if ( ! in_array( $ip_address, $auto_blacklist_ip ) ) {
						$existing_blacklist_ip .= ',' . $ip_address;
						update_option( 'wc_settings_anti_fraudblacklist_ipaddress', $existing_blacklist_ip );
					}
				} else {
					update_option( 'wc_settings_anti_fraudblacklist_ipaddress', $ip_address );
				}
			}

			// Auto blacklist email with high risk
			$enable_auto_blacklist = get_option( 'wc_settings_anti_fraudenable_automatic_blacklist' );

			if ( 'yes' == $enable_auto_blacklist ) {
				$existing_blacklist_emails = get_option( 'wc_settings_anti_fraudblacklist_emails', false );
				$auto_blacklist_emails     = explode( ',', $existing_blacklist_emails );

				if ( ! in_array( $orderemail, $auto_blacklist_emails ) ) {
					$existing_blacklist_emails .= ',' . $orderemail;
					update_option( 'wc_settings_anti_fraudblacklist_emails', $existing_blacklist_emails );
				}
			}
		}
	}

	public function switch_onoff( $hookget ) {

		if ( 'toplevel_page_antifraud-dashboard' == get_current_screen()->id ) {
			wp_enqueue_script( 'antifraud-chart-js', plugins_url( 'assets/js/chart.js', __FILE__ ), array(), WOOCOMMERCE_ANTI_FRAUD_VERSION );
		}

		if ( 'woocommerce_page_wc-settings' != $hookget ) {
			return;
		}

		if ( ! isset( $_REQUEST['section'] ) || 'minfraud_settings' !== $_REQUEST['section'] ) {
			return;
		}

		wp_enqueue_style( 'on-off-switch', plugins_url( 'assets/css/on-off-switch.css', __FILE__ ), array(), WOOCOMMERCE_ANTI_FRAUD_VERSION );
		wp_enqueue_script( 'on-off-jqueryadd', plugins_url( 'assets/js/jquery-1.11.2.min.js', __FILE__ ), array(), WOOCOMMERCE_ANTI_FRAUD_VERSION );
		wp_enqueue_script( 'on-off-switch', plugins_url( 'assets/js/on-off-switch.js', __FILE__ ), array(), WOOCOMMERCE_ANTI_FRAUD_VERSION );
		wp_enqueue_script( 'on-off-switch-onload', plugins_url( 'assets/js/on-off-switch-onload.js', __FILE__ ), array(), WOOCOMMERCE_ANTI_FRAUD_VERSION );
	}

	public function deactivate_events_on_active_plugin( $hook ) {

		$crons = _get_cron_array();
		if ( empty( $crons ) ) {
			return;
		}

		foreach ( $crons as $timestamp => $cron ) {

			if ( ! empty( $cron['my_hourly_event'] ) ) {
				unset( $crons[ $timestamp ]['my_hourly_event'] );
			}
		}
		_set_cron_array( $crons );

		// Delete option for Geolocation notice if plugin disabled
		delete_option( 'woo_af_geoloc_notice_dismissed' );
	}

	public function deactivate_events( $hook ) {

		$crons = _get_cron_array();
		if ( empty( $crons ) ) {
			return;
		}

		foreach ( $crons as $timestamp => $cron ) {

			if ( ! empty( $cron['wc-af-check'] ) ) {
				unset( $crons[ $timestamp ]['wc-af-check'] );
			}
			if ( ! empty( $cron['wp_af_paypal_verification'] ) ) {
				unset( $crons[ $timestamp ]['wp_af_paypal_verification'] );
			}
			if ( ! empty( $cron['wp_af_my_hourly_event'] ) ) {
				unset( $crons[ $timestamp ]['wp_af_my_hourly_event'] );
			}
		}
		_set_cron_array( $crons );


		$maxmind_alert_users = get_users( array( 'meta_key' => 'opmc-antifraud-maxmind-alert' ) );
		foreach ( $maxmind_alert_users as $maxmind_user ) {
			delete_user_meta( $maxmind_user->ID, 'opmc-antifraud-maxmind-alert' );
		}

		$trustswiftly_alert_users = get_users( array( 'meta_key' => 'opmc-antifraud-trustswiftly-alert' ) );
		foreach ( $trustswiftly_alert_users as $trustswiftly_user ) {
			delete_user_meta( $trustswiftly_user->ID, 'opmc-antifraud-trustswiftly-alert' );
		}
	}

	/**
	 * Check if Device tracking is active
	 *
	 * @since  1.0.0
	 *
	 * Call on header
	 */

	public function get_device_tracking_script() {

		$device_trackin_settings = get_option( 'wc_af_maxmind_device_tracking' );
		// Get Device Tracking enable/disable
		if ( 'yes' === $device_trackin_settings ) {
			$maxmind_user = get_option( 'wc_af_maxmind_user' );

			if ( ! empty( $maxmind_user ) ) {
				?>
                <script type="text/javascript">
                    maxmind_user_id = "<?php esc_html_e( $maxmind_user ); ?>";
                    (function () {
                        var loadDeviceJs = function () {
                            var element = document.createElement('script');
                            element.src = 'https://device.maxmind.com/js/device.js';
                            document.body.appendChild(element);
                        };
                        if (window.addEventListener) {
                            window.addEventListener('load', loadDeviceJs, false);
                        } else if (window.attachEvent) {
                            window.attachEvent('onload', loadDeviceJs);
                        }
                    })();
                </script>
				<?php
			}
		}
	}

	public function check_blacklist_whitelist() {
		$blocked_email = get_option( 'wc_settings_anti_fraudblacklist_emails' );
		$array_mail    = explode( ',', $blocked_email );

		if ( isset( $_REQUEST['_wpnonce'] ) ) {
			if ( ! wp_verify_nonce( $_REQUEST['_wpnonce'], 'my-nonce' ) ) {
				echo 'Nonce verification failed!';
				die();
			}
		}

		$whitelistarray = isset( $_POST['whitelist'] ) ? sanitize_text_field( $_POST['whitelist'] ) : '';
		$expwhitearray  = explode( "\n", $whitelistarray );
		$result         = array_diff( $array_mail, $expwhitearray );
		$finalblocklist = implode( ',', $result );

		update_option( 'wc_settings_anti_fraudblacklist_emails', $finalblocklist );

		echo esc_html__( $finalblocklist );
		wp_die();
	}

	public function whitelist_email() {

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( __( 'You do not have sufficient permissions to perform this action.', 'woocommerce-anti-fraud' ) );
		}

		if ( ! isset( $_REQUEST['_wpnonce'] ) || ! wp_verify_nonce( $_REQUEST['_wpnonce'], 'whitelist_email_nonce' ) ) {
			wp_send_json_error( __( 'Security check failed.', 'woocommerce-anti-fraud' ) );
		}

		$email = isset( $_REQUEST['email'] ) ? sanitize_text_field( $_REQUEST['email'] ) : '';
		if ( ! is_email( $email ) || empty( $email ) ) {
			wp_send_json_error( __( 'Invalid or empty email address.', 'woocommerce-anti-fraud' ) );
		}

		$email_blacklist = get_option( 'wc_settings_anti_fraudblacklist_emails' );
		if ( '' != $email_blacklist ) {
			$blacklist = explode( ',', $email_blacklist );
			if ( is_array( $blacklist ) && count( $blacklist ) > 0 && in_array( $email, $blacklist ) ) {
				foreach ( $blacklist as $key => $val ) {
					if ( $val == $email ) {
						unset( $blacklist[ $key ] );
					}
				}
				$blacklist = implode( ',', $blacklist );
				echo esc_html__( $blacklist );
				update_option( 'wc_settings_anti_fraudblacklist_emails', $blacklist );
			}
		}
		$email_whitelist = get_option( 'wc_settings_anti_fraud_whitelist' );
		$email_whitelist .= "\n" . sanitize_email( $email ) . " \n ";
		update_option( 'wc_settings_anti_fraud_whitelist', $email_whitelist );

		wp_send_json_success( __( 'Successfully whitelisted the email address. Refreshing the data.', 'woocommerce-anti-fraud' ) );
	}

	// display the extra data in the order admin panel
	public function kia_display_order_data_in_admin( $order ) {
		$blocked_email = get_option( 'wc_settings_anti_fraudblacklist_emails' );
		$array_mail    = explode( ',', $blocked_email );
		$orderemail    = $order->get_billing_email();
		foreach ( $array_mail as $single ) {
			if ( $orderemail == $single ) {
				?>
                <p class="form-field form-field-wide">
					<?php echo '<h3 style="color:red;"><strong>' . esc_html__( 'This email id is blocked', 'woocommerce-anti-fraud' ) . '</strong></h3>'; ?>
                </p>
                <p class="anti-fraud-error-msg" style="color: red;"></p>
                <p class="form-field form-field-wide">
                    <button type="button" class="button unblock-email" data-wpnonce="<?php echo wp_create_nonce( "whitelist_email_nonce" ); ?>" data-email="<?php echo esc_html__( $orderemail ); ?>"><?php echo esc_html__( 'Unblock', 'woocommerce-anti-fraud' ); ?></button>
                </p>
				<?php
			}
		}

		if ( $order instanceof WC_Order && $order->get_created_via() === 'rest-api' ) {
			echo '<p class="form-field form-field-wide" style="margin-top: 20px;"><span style="color: #ff5722; font-size: 16px;">' . esc_html__( 'This order is from REST API', 'woocommerce-anti-fraud' ) . '</span></p>';
		}
	}

	/**
	 * Check if WooCommerce is active
	 *
	 * @return bool
	 * @since  1.0.0
	 *
	 */
	private function is_wc_active() {

		$is_active = WC_Dependencies::woocommerce_active_check();

		// Do the WC active check
		if ( false === $is_active ) {
			add_action( 'admin_notices', array( $this, 'notice_activate_wc' ) );
		}

		return $is_active;
	}

	/**
	 * Display the notice
	 *
	 * @since  1.0.0
	 */
	public function notice_activate_wc() {
		?>
        <div class="error">
            <p>
				<?php
				/* translators: 1. start of link, 2. end of link. */
				printf( esc_html__( 'Please install and activate %1$sWooCommerce%2$s in order for the WooCommerce Anti Fraud extension to work!', 'woocommerce-anti-fraud' ), '<a href="' . esc_url( admin_url( 'plugin-install.php?tab=search&s=WooCommerce&plugin-search-input=Search+Plugins' ) ) . '">', '</a>' );
				?>
            </p>
        </div>
		<?php
	}

	/**
	 * Init the plugin
	 *
	 * @since  1.0.0
	 */
	private function init() {
		require_once dirname( __FILE__ ) . '/includes/class-wc-af-logger.php';

		// Load plugin textdomain
		// load_plugin_textdomain( 'woocommerce-anti-fraud', false, plugin_dir_path( self::get_plugin_file() ) . 'languages/' );

		// Setup the autoloader
		self::setup_autoloader();

		// Setup the required WooCommerce hooks
		WC_AF_Hook_Manager::setup();

		// Add base rules
		$maxmind_settings               = get_option( 'wc_af_maxmind_type' ); // Get MaxMind enable/disable
		$wc_af_maxmind_insights_setting = get_option( 'wc_af_maxmind_insights' ); // Get MaxMind insights enable/disable
		$wc_af_maxmind_factors_setting  = get_option( 'wc_af_maxmind_factors' ); // Get MaxMind factors enable/disable
		$maxmind_user                   = get_option( 'wc_af_maxmind_user' );
		$maxmind_license_key            = get_option( 'wc_af_maxmind_license_key' );
		// if ( $maxmind_settings == 'yes' ) {
		// WC_AF_Rules::get()->add_rule( new WC_AF_Rule_MinFraud() );
		// }
		// if ( $wc_af_maxmind_insights_setting == 'yes' ) {
		// WC_AF_Rules::get()->add_rule( new WC_AF_Rule_MinFraud_Insights() );
		// }
		if ( 'yes' == $wc_af_maxmind_factors_setting ) {
			WC_AF_Rules::get()->add_rule( new WC_AF_Rule_MinFraud_Factors() );
			if ( ! empty( $maxmind_user ) && ! empty( $maxmind_license_key ) ) {
				WC_AF_Rules::get()->add_rule( new WC_AF_Rule_Ip_Location() );
			}
		} elseif ( 'yes' == $wc_af_maxmind_insights_setting ) {
			WC_AF_Rules::get()->add_rule( new WC_AF_Rule_MinFraud_Insights() );
			if ( ! empty( $maxmind_user ) && ! empty( $maxmind_license_key ) ) {
				WC_AF_Rules::get()->add_rule( new WC_AF_Rule_Ip_Location() );
			}
		} elseif ( 'yes' == $maxmind_settings ) {
			WC_AF_Rules::get()->add_rule( new WC_AF_Rule_MinFraud() );
			if ( ! empty( $maxmind_user ) && ! empty( $maxmind_license_key ) ) {
				WC_AF_Rules::get()->add_rule( new WC_AF_Rule_Ip_Location() );
			}
		}
		if ( 'yes' != $maxmind_settings && 'yes' != $wc_af_maxmind_insights_setting && 'yes' != $wc_af_maxmind_factors_setting ) {

			WC_AF_Rules::get()->add_rule( new WC_AF_Rule_Geo_Location() );
		}

		WC_AF_Rules::get()->add_rule( new WC_AF_Rule_Country() );
		WC_AF_Rules::get()->add_rule( new WC_AF_Rule_Billing_Matches_Shipping() );
		WC_AF_Rules::get()->add_rule( new WC_AF_Rule_Detect_Proxy() );
		WC_AF_Rules::get()->add_rule( new WC_AF_Rule_Temporary_Email() );
		WC_AF_Rules::get()->add_rule( new WC_AF_Rule_Free_Email() );
		WC_AF_Rules::get()->add_rule( new WC_AF_Rule_International_Order() );
		WC_AF_Rules::get()->add_rule( new WC_AF_Rule_High_Value() );
		WC_AF_Rules::get()->add_rule( new WC_AF_Rule_High_Amount() );
		// if ( !empty( $maxmind_user ) && !empty( $maxmind_license_key ) ) {
		// WC_AF_Rules::get()->add_rule( new WC_AF_Rule_Ip_Location() );
		// }
		WC_AF_Rules::get()->add_rule( new WC_AF_Rule_First_Order() );
		WC_AF_Rules::get()->add_rule( new WC_AF_Rule_First_Order_Processing() );
		WC_AF_Rules::get()->add_rule( new WC_AF_Rule_Ip_Multiple_Order_Details() );
		WC_AF_Rules::get()->add_rule( new WC_AF_Rule_Velocities() );
		WC_AF_Rules::get()->add_rule( new WC_AF_Rule_Billing_Phone_Matches_Billing_Country() );

		// Check if admin
		if ( is_admin() ) {
			require_once dirname( __FILE__ ) . '/anti-fraud-core/class-wc-af-settings.php';
		}

		// reCaptcha on checkout page
		$wc_af_enable_recaptcha_checkout = get_option( 'wc_settings_anti_fraudenable_enable_recaptcha' );
		$wc_af_recaptcha_site_key        = get_option( 'wc_af_recaptcha_site_key' );
		$wc_af_recaptcha_secret_key      = get_option( 'wc_af_recaptcha_secret_key' );

		if ( 'yes' == $wc_af_enable_recaptcha_checkout && ! empty( $wc_af_recaptcha_site_key ) && ! empty( $wc_af_recaptcha_secret_key ) ) {
			add_action( 'woocommerce_review_order_before_payment', array( $this, 'wc_af_captcha_checkout_field' ) );
			add_action( 'woocommerce_after_checkout_validation', array( $this, 'wc_af_validate_captcha' ), 10, 2 );
		}
	}

	// Update order on paypal verification
	public function paypal_verification() {
		if ( isset( $_REQUEST['order_id'] ) && isset( $_REQUEST['paypal_verification'] ) ) {
			$order_id = base64_decode( sanitize_text_field( $_REQUEST['order_id'] ) );
			opmc_hpos_update_post_meta( $order_id, 'wc_af_paypal_verification', true );
			$order = new WC_Order( $order_id );
			echo "<script type='text/javascript'>
			alert('Your Paypal Email verified Successfully')</script>";
			if ( 'completed' === $order->get_status() || 'processing' === $order->get_status() || 'cancelled' === $order->get_status() ) {
				return;
			} else {
				$order->add_order_note( __( 'PayPal Verification Done.', 'woocommerce-anti-fraud' ) );
				// this should be set by paypal plugin. We should not override this.
				// $status = $order->update_status('processing');
			}
		}
	}

	// TO Do Test
	public function my_action() {
		$help_class = new WC_AF_Score_Helper();

		if ( isset( $_REQUEST['_wpnonce'] ) ) {
			if ( ! wp_verify_nonce( $_REQUEST['_wpnonce'], 'my-nonce' ) ) {
				echo 'Nonce verification failed!';
				die();
			}
		}

		if ( isset( $_POST['order_id'] ) ) {
			$help_class->do_check( sanitize_text_field( $_POST['order_id'] ) );
		}
		wp_die();
	}

	// TO DO
	public function admin_scripts() {

		$hposSettingsEnabled = get_option( 'woocommerce_custom_orders_table_enabled', true );

		if ( 'yes' === $hposSettingsEnabled ) {

			wp_enqueue_style( 'wc_af_edit_shop_order_css', plugins_url( 'assets/css/edit-shop-order.css', __FILE__ ), array(), WOOCOMMERCE_ANTI_FRAUD_VERSION );
			wp_enqueue_style(
				'wc_af_post_shop_order_css',
				plugins_url( '/assets/css/post-shop-order.css', __FILE__ ),
				array(),
				WOOCOMMERCE_ANTI_FRAUD_VERSION
			);
			wp_enqueue_script( 'knob' );
			wp_enqueue_script( 'edit' );
		}

		wp_enqueue_style( 'opmc_af_admin_css', plugins_url( 'assets/css/app.css', __FILE__ ), array(), WOOCOMMERCE_ANTI_FRAUD_VERSION );
		wp_enqueue_style( 'cal', plugins_url( 'assets/css/tags-input.css', __FILE__ ), array(), WOOCOMMERCE_ANTI_FRAUD_VERSION );

		wp_enqueue_script( 'cal', plugins_url( 'assets/js/cal.js', __FILE__ ), array(), WOOCOMMERCE_ANTI_FRAUD_VERSION );
		wp_enqueue_script( 'tags_input', plugins_url( 'assets/js/tags-input.js', __FILE__ ), array(), WOOCOMMERCE_ANTI_FRAUD_VERSION );
		wp_register_script( 'knob', plugins_url( '/assets/js/jquery.knob.min.js', self::get_plugin_file() ), array( 'jquery' ), WOOCOMMERCE_ANTI_FRAUD_VERSION );
		wp_register_script( 'edit', plugins_url( '/assets/js/edit-shop-order.js', __FILE__ ), array(), WOOCOMMERCE_ANTI_FRAUD_VERSION );
		wp_enqueue_script( 'opmc_af_admin_js', plugins_url( '/assets/js/app.js', __FILE__ ), array(), WOOCOMMERCE_ANTI_FRAUD_VERSION );
		wp_set_script_translations( 'opmc_af_admin_js', 'woocommerce-anti-fraud', WOOCOMMERCE_ANTI_FRAUD_PLUGIN_DIR . 'languages' );

		// Code related to displaying maxmind and trustswiftly related notifications to admin users
		/* Disabling maxmind and trustswiftly dash notifications.
		if (is_admin()) {
			add_action('admin_notices', array( $this, 'display_maxmind_dismissible_message' ));
			add_action('admin_notices', array( $this, 'display_trustswiftly_dismissible_message'));
		}
		*/
	}

	/**
	 * Displayes Maxmind dismissable notification to admin users
	 *
	 * @return void
	 */
	public function display_maxmind_dismissible_message() {

		$current_user_id = get_current_user_id();

		$alert_value = get_user_meta( $current_user_id, 'opmc-antifraud-maxmind-alert', true );

		if ( 'yes' === $alert_value ) {
			return;
		} else {

			$message = '<div class="notice notice-info is-dismissible opmc-antifraud-maxmind-alert">';
			$message .= '<p>We recommend you use <a href="https://maxmind.pxf.io/EK15XW" target="_blank">MaxMind</a>, to obtain the maximum fraud prevention benefit from the Anti Fraud plugin.  <a href="https://maxmind.pxf.io/EK15XW" target="_blank">MaxMind</a> can be configured in the <a href="/wp-admin/admin.php?page=wc-settings&tab=wc_af&section=minfraud_settings">plugin settings</a>.  Please refer to the Anti Fraud <a href="https://woo.com/products/woocommerce-anti-fraud/" target="_blank">Product page</a> and <a href="https://woo.com/document/woocommerce-anti-fraud/" target="_blank">Documentation page</a> for further information and configuration steps.</p>';
			$message .= '<p><strong>Steps to create a MaxMind Account:</strong></p>';
			$message .= '<ol>';
			$message .= '<li>Visit the <a href="https://maxmind.pxf.io/EK15XW" target="_blank">MaxMind Home page</a></li>';
			$message .= '<li>Click "Sign In" (top right).</li>';
			$message .= '<li>Select the option at the bottom to create a MaxMind account.</li>';
			$message .= '<li>Follow their remaining instructions.</li>';
			$message .= '</ol>';

			$message .= '</div>';

			echo wp_kses_post( $message );
		}
	} // display_maxmind_dismissible_message()

	/**
	 * Displayes Trust Swiftly dismissable notification to admin users
	 *
	 * @return void
	 */
	public function display_trustswiftly_dismissible_message() {

		$current_user_id = get_current_user_id();

		$trustswiftly_meta_value = get_user_meta( $current_user_id, 'opmc-antifraud-trustswiftly-alert', true );

		if ( 'yes' === $trustswiftly_meta_value ) {
			return;
		} else {

			$message = '<div class="notice notice-info is-dismissible opmc-antifraud-trustswiftly-alert">';
			$message .= '<p>We recommend you use <a href="https://thrive.zohopublic.com/aref/G4734hGpxD/mBWuIqNh8" target="_blank">Trust Swiftly</a> to further enhance fraud prevention using their Customer Identity Verification service with the Anti Fraud plugin.  <a href="https://thrive.zohopublic.com/aref/G4734hGpxD/mBWuIqNh8" target="_blank">Trust Swiftly</a> can be configured in the <a href="/wp-admin/admin.php?page=wc-settings&tab=wc_af&section=trust_swiftly_settings">plugin settings</a>.  Please refer to the Anti Fraud <a href="https://woo.com/products/woocommerce-anti-fraud/" target="_blank">Product page</a> and <a href="https://woo.com/document/woocommerce-anti-fraud/" target="_blank">Documentation page</a> for further information and configuration steps.</p>';
			$message .= '<p><strong>Steps to create a Trust Swiftly Account:</strong></p>';
			$message .= '<ol>';
			$message .= '<li>Visit the <a href="https://thrive.zohopublic.com/aref/G4734hGpxD/mBWuIqNh8 " target="_blank">Trust Swiftly Sign Up page</a>.</li>';
			$message .= '<li>Complete and Submit their Sign Up form.</li>';
			$message .= '<li>Follow their remaining instructions.</li>';
			$message .= '</ol>';

			$message .= '</div>';

			echo wp_kses_post( $message );
		}
	} // display_trustswiftly_dismissible_message()

	/**
	 * Save the default settings.
	 *
	 * This function is responsible for saving the default settings of the application.
	 * Default settings are typically used as a fallback when no user-specific settings exist.
	 * The saved default settings will be used as a reference for all users until they
	 * customize their preferences.
	 *
	 * @return bool True if the default settings were successfully saved, false otherwise.
	 */
	public function save_default_settings() {
		// check if settings were already saved before.
		if ( get_option( 'wc_af_is_settings_saved' ) == true ) {

			/* This validation will be removed after some time because it only works for existing customers once, if reCaptcha settings are enabled. */
			$enableCaptchaCheckout = get_option( 'wc_af_enable_recaptcha_checkout' );

			if ( ! empty( $enableCaptchaCheckout ) && 'yes' == $enableCaptchaCheckout ) {
				update_option( 'wc_settings_anti_fraudenable_enable_recaptcha', 'yes' );
				delete_option( 'wc_af_enable_recaptcha_checkout' );
			}
		} else {

			update_option( 'user_verified_from_ts', 'no' );
			// For Minfraud.
			update_option( 'wc_settings_anti_fraud_auto_check_days', 7 );
			update_option( 'wc_af_fraud_check_before_payment', 'no' );
			update_option( 'wc_af_fraud_update_state', 'yes' );

			update_option( 'wc_af_enable_whitelist_payment_method', 'no' );
			update_option( 'wc_settings_anti_fraud_minfraud_order_weight', 30 );
			update_option( 'wc_settings_anti_fraud_minfraud_risk_score', 30 );

			update_option( 'wc_af_email_notification', 'no' );
			update_option( 'wc_settings_anti_fraud_cancel_score', 90 );
			update_option( 'wc_settings_anti_fraud_hold_score', 70 );
			update_option( 'wc_settings_anti_fraud_email_score', 50 );
			update_option( 'wc_settings_anti_fraud_email_score1', 51 );
			update_option( 'wc_settings_anti_fraud_low_risk_threshold', 25 );
			update_option( 'wc_settings_anti_fraud_higher_risk_threshold', 75 );
			update_option( 'wc_af_first_order', 'yes' );
			update_option( 'wc_settings_anti_fraud_first_order_weight', 5 );
			update_option( 'wc_af_international_order', 'yes' );
			update_option( 'wc_settings_anti_fraud_international_order_weight', 10 );
			update_option( 'wc_af_ip_geolocation_order', 'yes' );
			update_option( 'wc_af_billing_phone_number_order', 'no' );
			update_option( 'wc_settings_anti_fraud_billing_phone_number_order_weight', 15 );
			update_option( 'wc_settings_anti_fraud_ip_geolocation_order_weight', 50 );
			update_option( 'wc_af_bca_order', 'yes' );
			update_option( 'wc_settings_anti_fraud_bca_order_weight', 20 );
			update_option( 'wc_af_proxy_order', 'yes' );
			update_option( 'wc_settings_anti_fraud_proxy_order_weight', 50 );
			update_option( 'wc_af_suspecius_email', 'yes' );
			update_option( 'wc_settings_anti_fraud_suspecious_email_weight', 5 );
			update_option( 'wc_settings_anti_fraud_suspecious_email_domains', $this->suspicious_domains() );
			update_option( 'wc_af_unsafe_countries', 'yes' );
			update_option( 'wc_settings_anti_fraud_unsafe_countries_weight', 25 );
			update_option( 'wc_af_order_avg_amount_check', 'yes' );
			update_option( 'wc_settings_anti_fraud_order_avg_amount_weight', 15 );
			update_option( 'wc_settings_anti_fraud_avg_amount_multiplier', 2 );
			update_option( 'wc_af_order_amount_check', 'yes' );
			update_option( 'wc_settings_anti_fraud_order_amount_weight', 5 );
			update_option( 'wc_settings_anti_fraud_amount_limit', 10000 );
			update_option( 'wc_af_attempt_count_check', 'yes' );
			update_option( 'wc_settings_anti_fraud_order_attempt_weight', 25 );
			update_option( 'wc_settings_anti_fraud_attempt_time_span', 24 );
			update_option( 'wc_settings_anti_fraud_max_order_attempt_time_span', 5 );

			update_option( 'wc_af_limit_order_count', 'no' );
			delete_option( 'wc_af_limit_time_start', 24 );
			delete_option( 'wc_af_limit_time_end', 24 );
			update_option( 'wc_af_allowed_order_limit', 2 );
			update_option( 'wc_settings_anti_fraud_max_order_payment_attempt', 2 );
			update_option( 'wc_af_ip_multiple_check', 'yes' );

			update_option( 'wc_settings_anti_fraud_ip_multiple_weight', 25 );
			update_option( 'wc_settings_anti_fraud_ip_multiple_time_span', 30 );
			update_option( 'wc_settings_anti_fraudenable_automatic_email_blacklist', 'yes' );
			update_option( 'wc_settings_anti_fraudenable_automatic_blacklist', 'yes' );
			update_option( 'wc_af_paypal_verification', 'yes' );
			update_option( 'wc_af_paypal_prevent_downloads', 'yes' );
			update_option( 'wc_settings_anti_fraud_time_paypal_attempts', 2 );
			update_option( 'wc_settings_anti_fraud_paypal_email_format', 'html' );
			update_option( 'wc_settings_anti_fraud_paypal_email_subject', $this->paypal_email_subject() );
			update_option( 'wc_settings_anti_fraud_email_body', $this->paypal_email_body() );
		}
	}

	public function suspicious_domains() {
		$email_domains = array(
			'hotmail',
			'live',
			'gmail',
			'yahoo',
			'mail',
			'123vn',
			'abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijk',
			'aaemail.com',
			'webmail.aol',
			'postmaster.info.aol',
			'personal',
			'atgratis',
			'aventuremail',
			'byke',
			'lycos',
			'computermail',
			'dodgeit',
			'thedoghousemail',
			'doramail',
			'e-mailanywhere',
			'eo.yifan',
			'earthlink',
			'emailaccount',
			'zzn',
			'everymail',
			'excite',
			'expatmail',
			'fastmail',
			'flashmail',
			'fuzzmail',
			'galacmail',
			'godmail',
			'gurlmail',
			'howlermonkey',
			'hushmail',
			'icqmail',
			'indiatimes',
			'juno',
			'katchup',
			'kukamail',
			'mail',
			'mail2web',
			'mail2world',
			'mailandnews',
			'mailinator',
			'mauimail',
			'meowmail',
			'merawalaemail',
			'muchomail',
			'MyPersonalEmail',
			'myrealbox',
			'nameplanet',
			'netaddress',
			'nz11',
			'orgoo',
			'phat.co',
			'probemail',
			'prontomail',
			'rediff',
			'returnreceipt',
			'synacor',
			'walkerware',
			'walla',
			'wongfaye',
			'xasamail',
			'zapak',
			'zappo',
		);

		return implode( ',', $email_domains );
	}

	public function paypal_email_body() {
		/* translators: 1. start of link, 2. end of link. */
		return sprintf( esc_html__( 'Hi! We have received your order on %1$s, but to complete it, we have to verify your PayPal email address. If you haven`t made or authorized any purchase, please, contact PayPal support immediately, and email us at %2$s .', 'woocommerce-anti-fraud' ), get_site_url(), get_option( 'admin_email' ) );
	}

	public function paypal_email_subject() {
		/* translators: 1. start of link. */
		return sprintf( esc_html__( '%1$s Confirm your PayPal email address.', 'woocommerce-anti-fraud' ), get_bloginfo( 'name' ) );
	}

	public function wc_af_captcha_checkout_field() {

		wp_enqueue_script( 'jquery' );

		$wc_af_recaptcha_site_key           = get_option( 'wc_af_recaptcha_site_key' );
		$wc_af_enable_checkout_waiting_time = get_option( 'wc_af_enable_checkout_waiting_time', 'no' );
		$wc_af_recaptcha_wait_time          = get_option( 'wc_af_recaptcha_wait_time', 10 );

		?>

        <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
            <label for="reg_captcha"><?php echo esc_html__( 'Captcha', 'woocommerce-anti-fraud' ); ?>&nbsp;<span class="required">*</span></label>
        <div id="wc-af-recaptcha-checkout" class="g-recaptcha" data-sitekey="<?php echo esc_attr( $wc_af_recaptcha_site_key ); ?>" data-callback="onCheckoutCaptchaSuccess"></div>
        <input type="hidden" name="checkout_captcha_response" id="checkout_captcha_response" value="">
        </p>

        <div id="wc-af-timer" style="display: none; text-align: left; margin-bottom: 10px;"></div>

        <script>
            let wcAfCaptchaCallback,
                wcAfCaptcha = null;

            (function ($) {
                // Define the callback function in global scope
                window.onCheckoutCaptchaSuccess = function (token) {

                    if (!token) {
                        return;
                    }

                    // Store the response in hidden input
                    $('#checkout_captcha_response').val(token);

                    let enable_checkout_waiting_time = '<?php echo esc_js( $wc_af_enable_checkout_waiting_time ); ?>';
                    if (enable_checkout_waiting_time !== 'yes') {
                        return;
                    }

                    let $timer = $("#wc-af-timer"),
                        $placeOrder = $("#place_order"),
                        baseWaitTime = <?php echo esc_js( $wc_af_recaptcha_wait_time ); ?>,
                        attemptCount = parseInt($timer.data('attempts') || 0) + 1;

                    $timer.data('attempts', attemptCount);

                    let remainingTime = Math.min(baseWaitTime * attemptCount, 1200);

                    $timer.show();
                    $placeOrder.prop("disabled", true);

                    wcafUpdateTimer(remainingTime);

                    let captchaTimer = setInterval(function () {
                        remainingTime--;
                        if (remainingTime <= 0) {
                            clearInterval(captchaTimer);
                            $timer.hide();
                            $placeOrder.prop("disabled", false);
                        } else {
                            wcafUpdateTimer(remainingTime);
                        }
                    }, 1000);

                    // Store timer reference for cleanup
                    $timer.data('timer', captchaTimer);
                };

                function wcafUpdateTimer(remainingTime) {
                    $("#wc-af-timer").html("<b>Anti-fraud prevention measures will delay the transaction time for the next <span style='color: red;'>" + remainingTime + "</span> seconds.</b>");
                }

                function initializeAFCaptcha() {
                    if (typeof grecaptcha !== 'undefined' && wcAfCaptcha === null) {
                        try {
                            wcAfCaptcha = grecaptcha.render('wc-af-recaptcha-checkout', {
                                'sitekey': '<?php echo esc_attr( $wc_af_recaptcha_site_key ); ?>',
                                'callback': onCheckoutCaptchaSuccess
                            });
                        } catch (e) {
                            console.log('reCAPTCHA has already been rendered in this element');
                        }
                    }
                }

                // Reset captcha and timer on checkout error
                $(document.body).on('checkout_error', function () {
                    let $timer = $("#wc-af-timer"),
                        captchaTimer = $timer.data('timer');

                    if (captchaTimer) {
                        clearInterval(captchaTimer);
                    }

                    if (typeof grecaptcha !== 'undefined' && wcAfCaptcha !== null) {
                        grecaptcha.reset(wcAfCaptcha);
                    }

                    $timer.hide();
                    $("#place_order").prop("disabled", false);
                });

                // Initialize reCAPTCHA when checkout form updates
                $(document).on('updated_checkout', function () {
                    wcAfCaptcha = null;
                    initializeAFCaptcha();
                });
            })(jQuery);
        </script>
        <script src="https://www.google.com/recaptcha/api.js?render=explicit" async defer></script>
		<?php
	}

	public function wc_af_validate_captcha( $fields, $validation_errors ) {

		$captcha_response = isset( $_POST['checkout_captcha_response'] ) ? sanitize_text_field( $_POST['checkout_captcha_response'] ) : '';
		$secret_key       = get_option( 'wc_af_recaptcha_secret_key', '' );
		$verify_url       = 'https://www.google.com/recaptcha/api/siteverify';

		if ( empty( $secret_key ) ) {
			$validation_errors->add( 'captcha_error', __( 'Your reCAPTCHA is not configured properly.', 'woocommerce-anti-fraud' ) );

			return $validation_errors;
		}

		if ( empty( $captcha_response ) ) {
			$validation_errors->add( 'captcha_error', __( 'Please complete the reCAPTCHA verification.', 'woocommerce-anti-fraud' ) );

			return $validation_errors;
		}

		$verify_response = wp_remote_post( $verify_url, array(
			'body' => array(
				'secret'   => $secret_key,
				'response' => $captcha_response
			)
		) );

		if ( is_wp_error( $verify_response ) ) {
			$validation_errors->add( 'captcha_error', __( 'Failed to verify reCAPTCHA. Please try again.', 'woocommerce-anti-fraud' ) );

			error_log( 'captcha_error: ' . $verify_response->get_error_message() );

			return $validation_errors;
		}

		$response_data = json_decode( wp_remote_retrieve_body( $verify_response ) );

		if ( ! $response_data || ! $response_data->success ) {
			$validation_errors->add( 'captcha_error', __( 'reCAPTCHA verification failed. Please try again.', 'woocommerce-anti-fraud' ) );

			return $validation_errors;
		}

		return $validation_errors;
	}

	public function update_blacklist_ips_option() {

		$whitelist_ipaddress = get_option( 'wc_settings_anti_fraud_ips_whitelist' );
		$blocked_ipaddress   = get_option( 'wc_settings_anti_fraudblacklist_ipaddress' );

		if ( ! empty( $blocked_ipaddress ) && ! empty( $whitelist_ipaddress ) ) {

			$array_ipaddress           = explode( ',', $blocked_ipaddress );
			$array_whitelist_ipaddress = explode( ',', $whitelist_ipaddress );

			// Remove duplicate IP addresses from the blacklist
			if ( ! empty( $array_ipaddress ) ) {
				$unique_blocked_ipaddress = array_unique( $array_ipaddress );
			} else {
				$unique_blocked_ipaddress = $array_ipaddress;
			}

			// Check for common IP addresses and remove them from both whitelist and blacklist
			$common_ip_addresses = array_intersect( $unique_blocked_ipaddress, $array_whitelist_ipaddress );

			if ( ! empty( $common_ip_addresses ) ) {
				// Remove common IP addresses from the blacklist
				$unique_blocked_ipaddress = array_diff( $unique_blocked_ipaddress, $common_ip_addresses );
			}

			// Ensure we only update if $unique_blocked_ipaddress is not empty
			if ( ! empty( $unique_blocked_ipaddress ) ) {
				$blocked_ipaddress = implode( ',', $unique_blocked_ipaddress );
				update_option( 'wc_settings_anti_fraudblacklist_ipaddress', $blocked_ipaddress );
			}
		}
	}

	public function order_level_froud_check() {
		$orderid = isset( $_REQUEST['orderid'] ) ? sanitize_text_field( $_REQUEST['orderid'] ) : '';

		$score_helper = new WC_AF_Score_Helper();
		$score_helper->schedule_fraud_check( $orderid, true );

		$score_points = opmc_hpos_get_post_meta( $orderid, 'wc_af_score' );
		echo 'success';
		wp_die();
	}

	/* Antifraud bulk check froud action */

	public function bulk_fraud_check_action_hook( $bulk_actions ) {

		$bulk_actions['bulk_fraud_check'] = 'Fraud Check';

		return $bulk_actions;
	}


	public function bulk_fraud_check_action_not_hpos( $redirect_to, $do_action, $post_ids ) {
		if ( 'bulk_fraud_check' === $do_action ) {
			foreach ( $post_ids as $value ) {
				$score_helper = new WC_AF_Score_Helper();
				$score_helper->schedule_fraud_check( $value, true );
			}
		}

		return $redirect_to;
	}

	public function bulk_fraud_check_action_hpos( $redirect_to, $do_action, $order ) {
		global $post;
		if ( 'bulk_fraud_check' === $do_action ) {
			foreach ( $post->ID as $value ) {
				$score_helper = new WC_AF_Score_Helper();
				$score_helper->schedule_fraud_check( $value, true );
			}
		}

		return $redirect_to;
	}

	public function add_order_level_froud_check_column( $columns ) {
		$columns['fraud_action'] = __( 'Fraud Action', 'woocommerce-anti-fraud' );

		return $columns;
	}

	// The column content by row
	public function add_order_level_froud_check_column_not_hpos_contents( $column, $post_id ) {
		if ( 'fraud_action' === $column ) {

			$order        = wc_get_order( $post_id ); // Get the WC_Order
			$slug         = 'fraud_action';
			$url          = $post_id; // The order Id is required in the URL
			$score_points = opmc_hpos_get_post_meta( $post_id, 'wc_af_score', true );
			if ( empty( $score_points ) && '0' !== $score_points ) {
				echo '<button type="button" id="fraud_action" class="button wc-action-button wc-action-button fraud_action" aria-label="' . esc_attr( $url ) . '">' . esc_html__( 'Fraud Check', 'woocommerce-anti-fraud' ) . '</button>';
			}
		}
	}

	public function add_order_level_froud_check_column_hpos_contents( $column, $order ) {
		global $post;
		if ( 'fraud_action' === $column ) {

			$order        = wc_get_order( $order->get_id() ); // Get the WC_Order
			$slug         = 'fraud_action';
			$url          = $order->get_id(); // The order Id is required in the URL
			$score_points = opmc_hpos_get_post_meta( $order->get_id(), 'wc_af_score', true );
			if ( empty( $score_points ) ) {
				/* echo '<button type="button" id="'.$slug.'" class="button wc-action-button wc-action-button'.$slug.' '.$slug.'" aria-label="'.$url.'">Done</button>';
			} else { */
				echo '<button type="button" id="fraud_action" class="button wc-action-button wc-action-button fraud_action" aria-label="' . esc_attr( $url ) . '">' . esc_html__( 'Fraud Check', 'woocommerce-anti-fraud' ) . '</button>';
			}
		}
	}
}

// echo get_option('wc_af_paypal_verification');die;
new WooCommerce_Anti_Fraud();
