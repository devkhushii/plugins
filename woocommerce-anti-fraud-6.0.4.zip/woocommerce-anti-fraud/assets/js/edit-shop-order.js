(function ($) {
	$( window ).on( "load",function () {
		$('.knob').knob();
		var data = $('.knob').attr('rel');

		$({value: 0}).animate({value: data}, {
			duration: 3000,
			easing  : 'swing',
			step    : function () {
				$('.knob').val(Math.ceil(this.value)).trigger('change');
			}
		});

		$('.woocommerce-af-risk-failure-list ul').hide();

		$('.woocommerce-af-risk-failure-list-toggle').click(function(){
			$('.woocommerce-af-risk-failure-list ul').slideToggle();
			var text = $(this).text();
			$(this).text( $(this).data('toggle') );
			$(this).data('toggle', text);
		});

		$('.woocommerce-af-risk-maxmind-list ul').hide();

		$('.woocommerce-af-risk-maxmind-list-toggle').click(function(){
			$('.woocommerce-af-risk-maxmind-list ul').slideToggle();
			var text = $(this).text();
			$(this).text( $(this).data('toggle') );
			$(this).data('toggle', text);
		});
		
		$('.unblock-email').click(function(){
			let email = $(this).data('email'),
				wpnonce = $(this).data('wpnonce'),
				el_error_msg = $(this).parent().parent().find('.anti-fraud-error-msg');

			$.ajax({
				method : 'POST',
				url : ajaxurl,
				data : { action : 'whitelist_email', email : email, _wpnonce: wpnonce },
				success : function(result) {
					if( result.success ) {
						el_error_msg.css('color', '#009688').html(result.data);
						$(this).parent().remove();
						setTimeout(function() {
							window.location.reload();
						}, 1500 );
					}else {
						el_error_msg.html(result.data);
					}
				}				
			})
		});
		
	});
	
	
	
})(jQuery);