import metadata from './block.json';
import {__} from '@wordpress/i18n';
import {useEffect, useState} from '@wordpress/element';
import {ValidatedTextInput} from '@woocommerce/blocks-checkout'; // Import the ValidatedTextInput

const {registerCheckoutBlock} = wc.blocksCheckout;
const Block = ({checkoutExtensionData}) => {
    const [captchaCheck, setCaptchaCheck] = useState('');
    const {setExtensionData} = checkoutExtensionData;
    const [recaptchaRendered, setRecaptchaRendered] = useState(false);

    // Add function to enable iframes
    const enableIframes = () => {
        console.log('Enabling iframes...');
        const checkoutForm = document.querySelector('.wc-block-checkout__form');
        if (checkoutForm) {
            const iframes = checkoutForm.getElementsByTagName('iframe');
            console.log(`Found ${iframes.length} iframes to enable`);
            Array.from(iframes).forEach(iframe => {
                iframe.style.pointerEvents = 'auto';
                iframe.style.opacity = '1';
                console.log('Enabled iframe:', iframe.src || 'no src');
            });
        } else {
            console.warn('Checkout form not found');
        }
    };

    // Add function to disable iframes
    const disableIframes = () => {
        console.log('Disabling iframes...');
        const checkoutForm = document.querySelector('.wc-block-checkout__form');
        if (checkoutForm) {
            const iframes = checkoutForm.getElementsByTagName('iframe');
            console.log(`Found ${iframes.length} iframes to disable`);
            Array.from(iframes).forEach(iframe => {
                iframe.style.pointerEvents = 'none';
                iframe.style.opacity = '0.5';
                console.log('Disabled iframe:', iframe.src || 'no src');
            });
        } else {
            console.warn('Checkout form not found');
        }
    };

    useEffect(() => {
        console.log('Initializing reCAPTCHA component...');
        const captchaKey = captcha_ajax.captcha_key;
        const captchaEnable = captcha_ajax.captcha_enable;

        if (!captchaKey || captchaEnable !== 'yes') {
            console.warn('reCAPTCHA is disabled or site key is missing.');
            return;
        }

        // Function to reset reCAPTCHA
        const resetRecaptcha = () => {
            console.log('Resetting reCAPTCHA...');
            if (window.grecaptcha) {
                window.grecaptcha.reset();
                setCaptchaCheck('');
                disableIframes();
            }
        };

        // Add observer for checkout field changes
        const checkoutFieldsObserver = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                // Check if the mutation is a value change in an input field
                if (mutation.target.tagName === 'INPUT' ||
                    mutation.target.tagName === 'SELECT' ||
                    mutation.target.tagName === 'TEXTAREA') {
                    console.log('Checkout field changed:', mutation.target.name || 'unnamed field');
                    resetRecaptcha();
                }
            });
        });

        // Start observing checkout fields
        const checkoutForm = document.querySelector('.wc-block-checkout__form');
        if (checkoutForm) {
            // Observe all form fields
            const formFields = checkoutForm.querySelectorAll('input, select, textarea');
            formFields.forEach(field => {
                checkoutFieldsObserver.observe(field, {
                    attributes: true,
                    characterData: true,
                    childList: true,
                    subtree: true,
                    attributeFilter: ['value']
                });
            });
            console.log('Started observing checkout fields for changes');
        }

        // Define global callback functions
        window.onCheckoutCaptchaSuccess = (response) => {
            console.log('reCAPTCHA verification successful');
            enableIframes();
            setCaptchaCheck(response);
        };

        window.onCheckoutCaptchaExpired = () => {
            console.log('reCAPTCHA verification expired');
            disableIframes();
            setCaptchaCheck('');
        };

        // Add mutation observer to watch for new iframes
        const observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                mutation.addedNodes.forEach((node) => {
                    console.log('New node detected:', node.nodeName);
                    // Check if the added node is an iframe or contains iframes
                    if (node.nodeName === 'IFRAME') {
                        console.log('Direct iframe detected');
                        if (!captchaCheck) {
                            node.style.pointerEvents = 'none';
                            node.style.opacity = '0.5';
                            console.log('Disabled new iframe:', node.src || 'no src');
                        }
                    } else if (node.getElementsByTagName) {
                        const iframes = node.getElementsByTagName('iframe');
                        if (iframes.length > 0) {
                            console.log(`Found ${iframes.length} iframes in new container`);
                            if (!captchaCheck) {
                                Array.from(iframes).forEach(iframe => {
                                    iframe.style.pointerEvents = 'none';
                                    iframe.style.opacity = '0.5';
                                    console.log('Disabled nested iframe:', iframe.src || 'no src');
                                });
                            }
                        }
                    }
                });
            });
        });

        // Start observing the checkout form
        //  checkoutForm = document.querySelector('.wc-block-checkout__form');
        if (checkoutForm) {
            console.log('Starting mutation observer on checkout form');
            observer.observe(checkoutForm, {
                childList: true,
                subtree: true
            });
        } else {
            console.warn('Checkout form not found for observer');
        }

        const renderRecaptcha = () => {
            if (!recaptchaRendered && window.grecaptcha && window.grecaptcha.render) {
                console.log('Rendering reCAPTCHA...');
                try {
                    window.grecaptcha.render('recaptcha-container', {
                        sitekey: captcha_ajax.captcha_key,
                        callback: 'onCheckoutCaptchaSuccess',
                        'expired-callback': 'onCheckoutCaptchaExpired',
                    });
                    setRecaptchaRendered(true);
                    console.log('reCAPTCHA rendered successfully');
                } catch (error) {
                    console.error('Error rendering reCAPTCHA:', error);
                }
            }
        };

        const loadRecaptcha = () => {
            console.log('Loading reCAPTCHA script...');
            if (typeof window.grecaptcha === 'undefined') {
                window.onRecaptchaLoad = () => {
                    console.log('reCAPTCHA script loaded');
                    renderRecaptcha();
                };

                const script = document.createElement('script');
                script.src = 'https://www.google.com/recaptcha/api.js?onload=onRecaptchaLoad&render=explicit';
                script.async = true;
                document.head.appendChild(script);
            } else {
                console.log('reCAPTCHA already loaded');
                renderRecaptcha();
            }
        };

        loadRecaptcha();

        // Initially disable all iframes
        console.log('Initially disabling all iframes');
        disableIframes();

        // Cleanup function
        return () => {
            console.log('Cleaning up reCAPTCHA component...');
            observer.disconnect();
            checkoutFieldsObserver.disconnect();
            delete window.onCheckoutCaptchaSuccess;
            delete window.onCheckoutCaptchaExpired;
        };
    }, [recaptchaRendered]);

    // Add some CSS to the component
    useEffect(() => {
        // Add CSS to handle iframe styles
        const style = document.createElement('style');
        style.textContent = `
            .wc-block-checkout__form iframe {
                transition: opacity 0.3s ease;
            }
        `;
        document.head.appendChild(style);

        return () => {
            document.head.removeChild(style);
        };
    }, []);

    useEffect(() => {
        setExtensionData('checkout-captcha-block', 'checkout_captcha', captchaCheck);
    }, [captchaCheck]);

    const handleInputChange = (value) => {
        setCaptchaCheck(value);
    };

    return (
        <div>
            <div id="recaptcha-container" className="g-recaptcha" style={{marginBottom: '-15px', marginTop: '15px'}}></div>
            <ValidatedTextInput
                id="captcha_check"
                type="text"
                required={true}
                value={captchaCheck ? '1' : ''} // Set value based on CAPTCHA status
                onChange={handleInputChange}
                className="hidden-captcha-input" // Optional class for styling
                disabled={false} // Can be adjusted based on your requirements
                style={{display: 'none'}} // Hide the input visually
                errorMessage={__('Please complete the reCAPTCHA.', 'captcha-block')}
            />
        </div>
    );
};

const options = {
    metadata,
    component: Block
};

registerCheckoutBlock(options);
