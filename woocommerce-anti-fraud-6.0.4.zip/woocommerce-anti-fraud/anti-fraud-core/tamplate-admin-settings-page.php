<?php
$settings_fileds = array();
foreach ( $settings as $value ) {
	// pr($value);
	if ( 'sectionend' != $value['type'] ) {
		$settings_fileds[ $value['id'] ] = $value;
	}
}
// pr($settings_fileds['wc_settings_anti_fraud_cancel_score']);

if ( '' === $current_section ) : ?>

    <section>

        <h2><?php echo esc_html__( 'General Settings', 'woocommerce-anti-fraud' ); ?></h2>
        <div id="<?php echo esc_attr( $this->id . '_general_settings-description' ); ?>">
			<?php echo wp_kses_post( $settings_fileds[ $this->id . '_general_settings' ]['desc'] ); ?>
        </div>

		<?php $this->opmc_add_admin_field_section( $settings_fileds[ $this->id . '_thresholds_settings' ] ); ?>

        <table class="form-table opmc_wc_af_table">
            <tbody>
            <tr valign="top">
                <th scope="row" class="titledesc">
                    <label for="wc_settings_anti_fraud_low_risk_threshold">
						<?php
						echo wp_kses_post( $settings_fileds['wc_settings_anti_fraud_low_risk_threshold']['name'] );
						$description = WC_Admin_Settings::get_field_description( $settings_fileds['wc_settings_anti_fraud_low_risk_threshold'] );
						echo wp_kses_post( $description['tooltip_html'] );
						?>
                    </label>
                </th>
                <td class="forminp forminp-number">
                    <input name="wc_settings_anti_fraud_low_risk_threshold" id="wc_settings_anti_fraud_low_risk_threshold" type="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_low_risk_threshold']['type'] ); ?>" style="display: block; width: 5em;" value="<?php echo esc_attr( get_option( 'wc_settings_anti_fraud_low_risk_threshold' ) ); ?>" min="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_low_risk_threshold']['custom_attributes']['min'] ); ?>" step="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_low_risk_threshold']['custom_attributes']['step'] ); ?>" max="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_low_risk_threshold']['custom_attributes']['max'] ); ?>">
                </td>
                <td class="forminp forminp-slider" rowspan="2">
					<?php $this->opmc_score_slider( 0, false, true ); ?>
                </td>
            </tr>
            <tr valign="top">
                <th scope="row" class="titledesc">
                    <label for="wc_settings_anti_fraud_higher_risk_threshold">
						<?php
						echo wp_kses_post( $settings_fileds['wc_settings_anti_fraud_higher_risk_threshold']['name'] );
						$description = WC_Admin_Settings::get_field_description( $settings_fileds['wc_settings_anti_fraud_higher_risk_threshold'] );
						echo wp_kses_post( $description['tooltip_html'] );
						?>
                    </label>
                </th>
                <td class="forminp forminp-number">
                    <input name="wc_settings_anti_fraud_higher_risk_threshold" id="wc_settings_anti_fraud_higher_risk_threshold" type="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_higher_risk_threshold']['type'] ); ?>" style="display: block; width: 5em;" value="<?php echo esc_attr( get_option( 'wc_settings_anti_fraud_higher_risk_threshold' ) ); ?>" min="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_higher_risk_threshold']['custom_attributes']['min'] ); ?>" step="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_higher_risk_threshold']['custom_attributes']['step'] ); ?>" max="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_higher_risk_threshold']['custom_attributes']['max'] ); ?>">
                </td>
            </tr>
            </tbody>
        </table>

		<?php $this->opmc_add_admin_field_section( $settings_fileds[ $this->id . '_pre_purchase_settings' ] ); ?>

        <table class="form-table opmc_wc_af_table">
            <tbody>
            <tr valign="top" class="">
                <th scope="row" class="titledesc">
                    <label for="wc_af_fraud_check_before_payment">
						<?php echo wp_kses_post( $settings_fileds['wc_af_fraud_check_before_payment']['title'] ); ?>
                        <span class="woocommerce-help-tip" data-tip="<?php echo esc_attr( $settings_fileds['wc_af_fraud_check_before_payment']['desc_tip'] ); ?>"></span>
                    </label>
                </th>
                <td class="forminp forminp-checkbox">
                    <fieldset>
                        <legend class="screen-reader-text"><span><?php echo esc_attr( $settings_fileds['wc_af_fraud_check_before_payment']['title'] ); ?></span></legend>
                        <label for="wc_af_fraud_check_before_payment" class="opmc-toggle-control">
                            <input name="wc_af_fraud_check_before_payment" id="wc_af_fraud_check_before_payment" type="checkbox" value="1" <?php checked( get_option( 'wc_af_fraud_check_before_payment' ), 'yes' ); ?> >
                            <span class="opmc-control"></span>
                        </label>
                    </fieldset>
                </td>
            </tr>
            <tr valign="top">
                <th scope="row" class="titledesc">
                    <label for="wc_af_pre_payment_message">
						<?php
						echo wp_kses_post( $settings_fileds['wc_af_pre_payment_message']['title'] );
						$description = WC_Admin_Settings::get_field_description( $settings_fileds['wc_af_pre_payment_message'] );
						echo wp_kses_post( $description['tooltip_html'] );
						?>
                    </label>
                </th>
                <td class="forminp forminp-textarea">
                    <textarea name="wc_af_pre_payment_message" id="wc_af_pre_payment_message" style="width:100%; height: 100px;"><?php echo esc_html( get_option( 'wc_af_pre_payment_message' ) ); ?></textarea>
                </td>
            </tr>
            </tbody>
        </table>

		<?php $this->opmc_add_admin_field_section( $settings_fileds[ $this->id . '_order_status_settings' ] ); ?>

        <table class="form-table opmc_wc_af_table">
            <tbody>
            <tr valign="top" class="">
                <th scope="row" class="titledesc">
                    <label for="wc_af_fraud_update_state">
						<?php echo wp_kses_post( $settings_fileds['wc_af_fraud_update_state']['title'] ); ?>
                        <span class="woocommerce-help-tip" data-tip="<?php echo esc_html( $settings_fileds['wc_af_fraud_update_state']['desc_tip'] ); ?>"></span>
                    </label>
                </th>
                <td class="forminp forminp-checkbox">
                    <fieldset>
                        <legend class="screen-reader-text"><span><?php echo wp_kses_post( $settings_fileds['wc_af_fraud_update_state']['title'] ); ?></span></legend>
                        <label for="wc_af_fraud_update_state" class="opmc-toggle-control">
                            <input name="wc_af_fraud_update_state" id="wc_af_fraud_update_state" type="checkbox" value="1" <?php checked( get_option( 'wc_af_fraud_update_state' ), 'yes' ); ?> >
                            <span class="opmc-control"></span>
                        </label>
                    </fieldset>
                </td>
            </tr>
            <tr valign="top">
                <th scope="row" class="titledesc">
                    <label for="wc_settings_anti_fraud_cancel_score">
						<?php
						echo wp_kses_post( $settings_fileds['wc_settings_anti_fraud_cancel_score']['name'] );
						$description = WC_Admin_Settings::get_field_description( $settings_fileds['wc_settings_anti_fraud_cancel_score'] );
						echo wp_kses_post( $description['tooltip_html'] );
						?>
                    </label>
                </th>
                <td class="forminp forminp-select">
                    <select name="wc_settings_anti_fraud_cancel_score" id="wc_settings_anti_fraud_cancel_score" style="display: block; width: 5em;" class="">
						<?php foreach ( $settings_fileds['wc_settings_anti_fraud_cancel_score']['options'] as $option_key_inner => $option_value_inner ) : ?>
                            <option value="<?php echo esc_attr( $option_key_inner ); ?>" <?php selected( (string) $option_key_inner, esc_attr( get_option( 'wc_settings_anti_fraud_cancel_score' ) ) ); ?>><?php echo esc_html( $option_value_inner ); ?></option>
						<?php endforeach ?>
                    </select>
                </td>
                <td class="forminp forminp-slider">
					<?php $this->opmc_score_slider( get_option( 'wc_settings_anti_fraud_cancel_score' ), true ); ?>
                </td>
            </tr>
            <tr valign="top">
                <th scope="row" class="titledesc">
                    <label for="wc_settings_anti_fraud_hold_score">
						<?php
						echo wp_kses_post( $settings_fileds['wc_settings_anti_fraud_hold_score']['title'] );
						$description = WC_Admin_Settings::get_field_description( $settings_fileds['wc_settings_anti_fraud_hold_score'] );
						echo wp_kses_post( $description['tooltip_html'] );
						?>
                    </label>
                </th>
                <td class="forminp forminp-select">
                    <select name="wc_settings_anti_fraud_hold_score" id="wc_settings_anti_fraud_hold_score" style="display: block; width: 5em;" class="">
						<?php foreach ( $settings_fileds['wc_settings_anti_fraud_hold_score']['options'] as $option_key_inner => $option_value_inner ) : ?>
                            <option value="<?php echo esc_attr( $option_key_inner ); ?>" <?php selected( (string) $option_key_inner, esc_attr( get_option( 'wc_settings_anti_fraud_hold_score' ) ) ); ?>><?php echo esc_html( $option_value_inner ); ?></option>
						<?php endforeach ?>
                    </select>
                </td>
                <td class="forminp forminp-slider">
					<?php $this->opmc_score_slider( get_option( 'wc_settings_anti_fraud_hold_score' ), true ); ?>
                </td>
            </tr>
            </tbody>
        </table>

		<?php $this->opmc_add_admin_field_section( $settings_fileds[ $this->id . '_whitelist_payment_settings' ] ); ?>

        <table class="form-table opmc_wc_af_table">
            <tbody>
            <tr valign="top" class="">
                <th scope="row" class="titledesc">
                    <label for="wc_af_enable_whitelist_payment_method">
						<?php echo wp_kses_post( $settings_fileds['wc_af_enable_whitelist_payment_method']['title'] ); ?>
                        <span class="woocommerce-help-tip" data-tip="<?php echo wp_kses_post( $settings_fileds['wc_af_enable_whitelist_payment_method']['desc_tip'] ); ?>"></span>
                    </label>
                </th>
                <td class="forminp forminp-checkbox">
                    <fieldset>
                        <legend class="screen-reader-text"><span><?php echo wp_kses_post( $settings_fileds['wc_af_enable_whitelist_payment_method']['title'] ); ?></span></legend>
                        <label for="wc_af_enable_whitelist_payment_method" class="opmc-toggle-control">
                            <input name="wc_af_enable_whitelist_payment_method" id="wc_af_enable_whitelist_payment_method" type="checkbox" value="1" <?php checked( get_option( 'wc_af_enable_whitelist_payment_method' ), 'yes' ); ?> >
                            <span class="opmc-control"></span>
                        </label>
                    </fieldset>
                </td>
            </tr>
            <tr valign="top">
                <th scope="row" class="titledesc">
                    <label for="wc_settings_anti_fraud_whitelist_payment_method">
						<?php
						echo wp_kses_post( $settings_fileds['wc_settings_anti_fraud_whitelist_payment_method']['title'] );
						$description = WC_Admin_Settings::get_field_description( $settings_fileds['wc_settings_anti_fraud_whitelist_payment_method'] );
						echo wp_kses_post( $description['tooltip_html'] );
						?>
                    </label>
                </th>
                <td class="forminp forminp-multiselect">
                    <select name="wc_settings_anti_fraud_whitelist_payment_method[]" id="wc_settings_anti_fraud_whitelist_payment_method" style="" class="" multiple="multiple">
						<?php foreach ( $settings_fileds['wc_settings_anti_fraud_whitelist_payment_method']['options'] as $option_key_inner => $option_value_inner ) : ?>
                            <option value="<?php echo esc_attr( $option_key_inner ); ?>" <?php selected( in_array( (string) $option_key_inner, $settings_fileds['wc_settings_anti_fraud_whitelist_payment_method']['default'] ) ); ?>><?php echo esc_html( $option_value_inner ); ?></option>
						<?php endforeach; ?>
                    </select>
                </td>
            </tr>
            </tbody>
        </table>

		<?php $this->opmc_add_admin_field_section( $settings_fileds[ $this->id . '_user_role_settings' ] ); ?>

        <table class="form-table opmc_wc_af_table">
            <tbody>
            <tr valign="top" class="">
                <th scope="row" class="titledesc">
                    <label for="wc_af_enable_whitelist_user_roles">
						<?php echo wp_kses_post( $settings_fileds['wc_af_enable_whitelist_user_roles']['title'] ); ?>
                        <span class="woocommerce-help-tip" data-tip="<?php echo esc_attr( $settings_fileds['wc_af_enable_whitelist_user_roles']['desc_tip'] ); ?>"></span>
                    </label>
                </th>
                <td class="forminp forminp-checkbox">
                    <fieldset>
                        <legend class="screen-reader-text"><span><?php echo wp_kses_post( $settings_fileds['wc_af_enable_whitelist_user_roles']['title'] ); ?></span></legend>
                        <label for="wc_af_enable_whitelist_user_roles" class="opmc-toggle-control">
                            <input name="wc_af_enable_whitelist_user_roles" id="wc_af_enable_whitelist_user_roles" type="checkbox" value="1" <?php checked( get_option( 'wc_af_enable_whitelist_user_roles' ), 'yes' ); ?> >
                            <span class="opmc-control"></span>
                        </label>
                    </fieldset>
                </td>
            </tr>
            <tr valign="top">
                <th scope="row" class="titledesc">
                    <label for="wc_af_whitelist_user_roles">
						<?php
						echo wp_kses_post( $settings_fileds['wc_af_whitelist_user_roles']['title'] );
						$description = WC_Admin_Settings::get_field_description( $settings_fileds['wc_af_whitelist_user_roles'] );
						echo wp_kses_post( $description['tooltip_html'] );
						?>
                    </label>
                </th>
                <td class="forminp forminp-multiselect">
                    <select name="wc_af_whitelist_user_roles[]" id="wc_af_whitelist_user_roles" style="" class="" multiple="multiple">
						<?php foreach ( $settings_fileds['wc_af_whitelist_user_roles']['options'] as $option_key_inner => $option_value_inner ) : ?>
                            <option value="<?php echo esc_attr( $option_key_inner ); ?>" <?php selected( in_array( (string) $option_key_inner, $settings_fileds['wc_af_whitelist_user_roles']['default'] ) ); ?>><?php echo esc_html( $option_value_inner ); ?></option>
						<?php endforeach ?>
                    </select>
                </td>
            </tr>
            </tbody>
        </table>

		<?php $this->opmc_add_admin_field_section( $settings_fileds[ $this->id . '_email_whitelist_settings' ] ); ?>
        <table class="form-table opmc_wc_af_table">
            <tbody>
            <tr valign="top" class="">
                <th scope="row" class="titledesc">
                    <label for="wc_settings_anti_fraud_whitelist">
						<?php echo wp_kses_post( $settings_fileds['wc_settings_anti_fraud_whitelist']['name'] ); ?>
                        <span class="woocommerce-help-tip" data-tip="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_whitelist']['desc_tip'] ); ?>"></span>
                    </label>
                </th>
                <td class="forminp forminp-textarea" colspan="3">
					<?php
					$email_whitelist = str_replace( "\n", ',', get_option( 'wc_settings_anti_fraud_whitelist' ) );
					?>
                    <textarea name="wc_settings_anti_fraud_whitelist" id="wc_settings_anti_fraud_whitelist" style="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_whitelist']['css'] ); ?>" class="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_whitelist']['class'] ); ?>"><?php echo esc_html( $email_whitelist ); ?></textarea>
                </td>
            </tr>
            </tbody>
        </table>

        <!-- Ip Whitelist  -->
		<?php $this->opmc_add_admin_field_section( $settings_fileds[ $this->id . '_ips_whitelist_settings' ] ); ?>
        <table class="form-table opmc_wc_af_table">
            <tbody>
            <tr valign="top" class="">
                <th scope="row" class="titledesc">
                    <label for="wc_settings_anti_fraud_ips_whitelist">
						<?php echo wp_kses_post( $settings_fileds['wc_settings_anti_fraud_ips_whitelist']['name'] ); ?>
                        <span class="woocommerce-help-tip" data-tip="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_ips_whitelist']['desc_tip'] ); ?>"></span>
                    </label>
                </th>
                <td class="forminp forminp-textarea" colspan="3">
					<?php
					$email_whitelist = str_replace( "\n", ',', get_option( 'wc_settings_anti_fraud_ips_whitelist' ) );
					?>
                    <textarea name="wc_settings_anti_fraud_ips_whitelist" id="wc_settings_anti_fraud_ips_whitelist" style="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_ips_whitelist']['css'] ); ?>" class="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_ips_whitelist']['class'] ); ?>"><?php echo esc_html( $email_whitelist ); ?></textarea>
                </td>
            </tr>
            </tbody>
        </table>
        <!-- /* End */ -->

        <!-- Auto order fraud check settings -->
		<?php $this->opmc_add_admin_field_section( $settings_fileds[ $this->id . '_enable_start_auto_fraud_check' ] ); ?>

        <table class="form-table opmc_wc_af_table">
            <tbody>
            <tr valign="top" class="">
                <th scope="row" class="titledesc">
                    <label for="wc_af_enable_start_auto_fraud_check">
						<?php echo wp_kses_post( $settings_fileds['wc_af_start_auto_fraud_check']['title'] ); ?>
                        <span class="woocommerce-help-tip" data-tip="<?php echo esc_attr( $settings_fileds['wc_af_start_auto_fraud_check']['desc_tip'] ); ?>"></span>
                    </label>
                </th>
                <td class="forminp forminp-checkbox">
                    <fieldset>
                        <legend class="screen-reader-text"><span><?php echo wp_kses_post( $settings_fileds['wc_af_start_auto_fraud_check']['title'] ); ?></span></legend>
                        <label for="wc_af_start_auto_fraud_check" class="opmc-toggle-control">
                            <input name="wc_af_start_auto_fraud_check" id="wc_af_start_auto_fraud_check" type="checkbox" value="1" <?php checked( get_option( 'wc_af_start_auto_fraud_check' ), 'yes' ); ?> >
                            <span class="opmc-control"></span>
                        </label>
                    </fieldset>
                </td>
            </tr>

            <tr valign="top">
                <th scope="row" class="titledesc">
                    <label for="wc_settings_anti_fraud_auto_check_days">
						<?php
						echo wp_kses_post( $settings_fileds['wc_settings_anti_fraud_auto_check_days']['name'] );
						$description = WC_Admin_Settings::get_field_description( $settings_fileds['wc_settings_anti_fraud_auto_check_days'] );
						echo wp_kses_post( $description['tooltip_html'] );
						?>
                    </label>
                </th>
                <td class="forminp forminp-number">
                    <input name="wc_settings_anti_fraud_auto_check_days" id="wc_settings_anti_fraud_auto_check_days" type="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_auto_check_days']['type'] ); ?>" style="display: block; width: 5em;" value="<?php echo esc_attr( get_option( 'wc_settings_anti_fraud_auto_check_days' ) ); ?>" min="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_auto_check_days']['custom_attributes']['min'] ); ?>" step="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_auto_check_days']['custom_attributes']['step'] ); ?>" max="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_auto_check_days']['custom_attributes']['max'] ); ?>">
                </td>
            </tr>
            </tbody>
        </table>

        <!-- Fraud check for API orders  -->
		<?php $this->opmc_add_admin_field_section( $settings_fileds[ $this->id . '_enable_api_fraud_check' ] ); ?>

        <table class="form-table opmc_wc_af_table">
            <tbody>
            <tr valign="top" class="">
                <th scope="row" class="titledesc">
                    <label for="wc_af_enable_start_auto_fraud_check">
						<?php echo wp_kses_post( $settings_fileds['wc_af_api_fraud_check']['title'] ); ?>
                        <span class="woocommerce-help-tip" data-tip="<?php echo esc_attr( $settings_fileds['wc_af_api_fraud_check']['desc_tip'] ); ?>"></span>
                    </label>
                </th>
                <td class="forminp forminp-checkbox">
                    <fieldset>
                        <legend class="screen-reader-text"><span><?php echo wp_kses_post( $settings_fileds['wc_af_api_fraud_check']['title'] ); ?></span></legend>
                        <label for="wc_af_api_fraud_check" class="opmc-toggle-control">
                            <input name="wc_af_api_fraud_check" id="wc_af_api_fraud_check" type="checkbox" value="1" <?php checked( get_option( 'wc_af_api_fraud_check', $settings_fileds['wc_af_api_fraud_check']['default'] ), 'yes' ); ?> >
                            <span class="opmc-control"></span>
                        </label>
                    </fieldset>
                </td>
            </tr>

            <tr valign="top" class="">
                <th scope="row" class="titledesc">
                    <label for="wc_af_enable_start_auto_fraud_check">
						<?php echo wp_kses_post( $settings_fileds['wc_af_throttle_api_based_orders_check']['title'] ); ?>
                        <span class="woocommerce-help-tip" data-tip="<?php echo esc_attr( $settings_fileds['wc_af_throttle_api_based_orders_check']['desc_tip'] ); ?>"></span>
                    </label>
                </th>
                <td class="forminp forminp-checkbox">
                    <fieldset>
                        <legend class="screen-reader-text"><span><?php echo wp_kses_post( $settings_fileds['wc_af_throttle_api_based_orders_check']['title'] ); ?></span></legend>
                        <label for="wc_af_throttle_api_based_orders_check" class="opmc-toggle-control">
                            <input name="wc_af_throttle_api_based_orders_check" id="wc_af_throttle_api_based_orders_check" type="checkbox" value="1" <?php checked( get_option( 'wc_af_throttle_api_based_orders_check' ), 'yes' ); ?> >
                            <span class="opmc-control"></span>
                        </label>
                    </fieldset>
                </td>
            </tr>

            <tr valign="top" style="display: <?php echo esc_attr( get_option( 'wc_af_throttle_api_based_orders_check' ) === 'yes' ? 'revert' : 'none' ); ?>">
                <th scope="row" class="titledesc">
                    <label for="wc_af_max_orders_through_api_per_hour">
						<?php
						echo wp_kses_post( $settings_fileds['wc_af_max_orders_through_api_per_hour']['name'] );
						$description = WC_Admin_Settings::get_field_description( $settings_fileds['wc_af_max_orders_through_api_per_hour'] );
						echo wp_kses_post( $description['tooltip_html'] );
						?>
                    </label>
                </th>
                <td class="forminp forminp-number">
                    <input name="wc_af_max_orders_through_api_per_hour" id="wc_af_max_orders_through_api_per_hour" type="<?php echo esc_attr( $settings_fileds['wc_af_max_orders_through_api_per_hour']['type'] ); ?>" style="display: block; width: 5em;" value="<?php echo esc_attr( get_option( 'wc_af_max_orders_through_api_per_hour' ) ); ?>" min="<?php echo esc_attr( $settings_fileds['wc_af_max_orders_through_api_per_hour']['custom_attributes']['min'] ); ?>" step="<?php echo esc_attr( $settings_fileds['wc_af_max_orders_through_api_per_hour']['custom_attributes']['step'] ); ?>" max="<?php echo esc_attr( $settings_fileds['wc_af_max_orders_through_api_per_hour']['custom_attributes']['max'] ); ?>">
                    <p class="description"><?php echo esc_html( $settings_fileds['wc_af_max_orders_through_api_per_hour']['desc'] ); ?></p>
                </td>
            </tr>


            </tbody>
        </table>

        <!-- Debug log check settings -->
		<?php $this->opmc_add_admin_field_section( $settings_fileds[ $this->id . '_enable_debug_log_check' ] ); ?>

        <table class="form-table opmc_wc_af_table">
            <tbody>
            <tr valign="top" class="">
                <th scope="row" class="titledesc">
                    <label for="wc_af_enable_debug_log_check">
						<?php echo wp_kses_post( $settings_fileds['wc_af_enable_log_check']['title'] ); ?>
                        <span class="woocommerce-help-tip" data-tip="<?php echo esc_attr( $settings_fileds['wc_af_enable_log_check']['desc_tip'] ); ?>"></span>
                    </label>
                </th>
                <td class="forminp forminp-checkbox">
                    <fieldset>
                        <legend class="screen-reader-text"><span><?php echo wp_kses_post( $settings_fileds['wc_af_enable_log_check']['title'] ); ?></span></legend>
                        <label for="wc_af_enable_log_check" class="opmc-toggle-control">
                            <input name="wc_af_enable_log_check" id="wc_af_enable_log_check" type="checkbox" value="1" <?php checked( get_option( 'wc_af_enable_log_check' ), 'yes' ); ?> >
                            <span class="opmc-control"></span>
                        </label>
                    </fieldset>
                </td>
            </tr>
            </tbody>
        </table>
        <div class="main-debug-log-tbl" id="debug_log_tbl" style="width:90%;overflow:auto; max-height:100px;    margin-left: 5%; position: inherit;">
            <table id="debug_t" style="width:100%;">
                <thead style="font-size: 14px;">
                <tr id="debug_tr">
                    <th id="debug_th" width="10%"><?php echo esc_html__( 'Sr No', 'woocommerce-anti-fraud' ); ?></th>
                    <th id="debug_th" width="30%"><?php echo esc_html__( 'Name', 'woocommerce-anti-fraud' ); ?></th>
                    <th id="debug_th" width="30%"><?php echo esc_html__( 'Date', 'woocommerce-anti-fraud' ); ?></th>
                    <th id="debug_th" width="30%"><?php echo esc_html__( 'Action', 'woocommerce-anti-fraud' ); ?></th>
                </tr>
                </thead>
                <tbody style="line-height: 2.4em; font-size: 14px;">
				<?php
				global $wpdb;
				$dailyCapLimit = 500;
				$table_name    = $wpdb->prefix . 'af_download_url';
				$api_limits    = 0;
				$created_at    = '';

				// Check if API limits exceeded
				if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table_name ) ) == $table_name ) {
					$results = $wpdb->get_results( 'SELECT * FROM ' . $wpdb->prefix . 'af_download_url' );
					// $results = $wpdb->get_results($wpdb->prepare('SELECT download_url, created_at FROM ' . $wpdb->prefix . 'af_download_url WHERE created_at = %s', gmdate('Y-m-d')));
				}
				$resultss = (array) $results;
				if ( is_array( $resultss ) ) {
					foreach ( $resultss as $result ) {

						?>
                        <tr id="debug_tr">
                            <td id="debug_td" width="10%"><?php echo esc_html( $result->id ); ?></td>
                            <td id="debug_td" width="30%">antifraud-log-<?php echo esc_html( $result->created_at ); ?>.csv</td>
                            <td id="debug_td" width="30%"><?php echo esc_html( $result->created_at ); ?></td>
                            <td id="debug_td" width="30%">
                                <a href="<?php echo esc_url( $result->download_url ); ?>" type="button" name="Download" class="download-button"><?php echo esc_html__( 'Download', 'woocommerce-anti-fraud' ); ?> </a>
                            </td>
                        </tr>
						<?php
					}
				}
				?>
                </tbody>
            </table>
        </div>
        <!-- Debug log End -->
    </section>
<?php elseif ( 'card_attacks' === $current_section ) : ?>
    <section>
        <h2><?php echo esc_html__( 'Card Velocity Attack Settings', 'woocommerce-anti-fraud' ); ?></h2>
        <div id="<?php echo esc_attr( $this->id . '_card_attacks_settings-description' ); ?>">
			<?php echo wp_kses_post( $settings_fileds[ $this->id . '_card_attacks_settings' ]['desc'] ); ?>
        </div>

		<?php $this->opmc_add_admin_field_section_for_cardAttack( $settings_fileds[ $this->id . '_thresholds_settings' ] ); ?>
        <table class="form-table opmc_wc_af_table">
            <tbody>
            <tr>

                <th style="padding: 0px !important;">
                    <h4>Make it difficult for fraudsters to attempt card attacks at the checkout.</h4>
                    <P style="font-weight: 400;">1. Create your <a href="https://www.google.com/recaptcha/">reCaptcha site key and secret key. </a></P>
                    <P style="font-weight: 400;">2. Enter your site and secret keys into our <a href="<?php echo admin_url( 'admin.php?page=wc-settings&tab=wc_af&section=minfraud_recaptcha_settings' ); ?>">reCaptcha settings tab</a></P>
                    <P style="font-weight: 400;">3. You'll be protected once the Enable Checkout Protection bar displays as "Active”</P>
                </th>

            </tr>

            </tbody>

			<?php $this->opmc_add_admin_field_section_2_cardAttack( $settings_fileds[ $this->id . '_order_attempts_rules_settings' ] ); ?>
            <tbody>
            <tr valign="top" class="">
                <th scope="row" class="titledesc">
                    <label for="wc_af_attempt_count_check">
						<?php echo wp_kses_post( $settings_fileds['wc_af_attempt_count_check']['title'] ); ?>
                        <span class="woocommerce-help-tip" data-tip="<?php echo wp_kses_post( $settings_fileds['wc_af_attempt_count_check']['desc_tip'] ); ?>"></span>
                    </label>
                </th>
                <td class="forminp forminp-checkbox">
                    <fieldset>
                        <legend class="screen-reader-text"><span><?php echo wp_kses_post( $settings_fileds['wc_af_attempt_count_check']['title'] ); ?></span></legend>
                        <label for="wc_af_attempt_count_check" class="opmc-toggle-control">
                            <input name="wc_af_attempt_count_check" id="wc_af_attempt_count_check" type="checkbox" value="1" <?php checked( get_option( 'wc_af_attempt_count_check' ), 'yes' ); ?> >
                            <span class="opmc-control"></span>
                        </label>
                    </fieldset>
                </td>
            </tr>
            <tr valign="top" class="">
                <th scope="row" class="titledesc">
                    <label for="wc_settings_anti_fraud_attempt_time_span">
						<?php
						echo wp_kses_post( $settings_fileds['wc_settings_anti_fraud_attempt_time_span']['name'] );
						$description = WC_Admin_Settings::get_field_description( $settings_fileds['wc_settings_anti_fraud_attempt_time_span'] );
						echo wp_kses_post( $description['tooltip_html'] );
						?>
                    </label>
                </th>
                <td class="forminp forminp-number">
                    <input name="wc_settings_anti_fraud_attempt_time_span" id="wc_settings_anti_fraud_attempt_time_span" type="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_attempt_time_span']['type'] ); ?>" style="display: block; width: 5em;" value="<?php echo esc_attr( get_option( 'wc_settings_anti_fraud_attempt_time_span' ) ); ?>" min="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_attempt_time_span']['custom_attributes']['min'] ); ?>" step="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_attempt_time_span']['custom_attributes']['step'] ); ?>">
                </td>
            </tr>
            <tr valign="top" class="">
                <th scope="row" class="titledesc">
                    <label for="wc_settings_anti_fraud_max_order_attempt_time_span">
						<?php
						echo wp_kses_post( $settings_fileds['wc_settings_anti_fraud_max_order_attempt_time_span']['name'] );
						$description = WC_Admin_Settings::get_field_description( $settings_fileds['wc_settings_anti_fraud_max_order_attempt_time_span'] );
						echo wp_kses_post( $description['tooltip_html'] );
						?>
                    </label>
                </th>
                <td class="forminp forminp-number">
                    <input name="wc_settings_anti_fraud_max_order_attempt_time_span" id="wc_settings_anti_fraud_max_order_attempt_time_span" type="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_max_order_attempt_time_span']['type'] ); ?>" style="display: block; width: 5em;" value="<?php echo esc_attr( get_option( 'wc_settings_anti_fraud_max_order_attempt_time_span' ) ); ?>" min="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_max_order_attempt_time_span']['custom_attributes']['min'] ); ?>" step="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_max_order_attempt_time_span']['custom_attributes']['step'] ); ?>">
                </td>
            </tr>
            <tr valign="top">
                <td colspan="2">
                    <hr/>
                </td>
            </tr>
            <tr valign="top" class="">
                <th scope="row" class="titledesc">
                    <label for="wc_af_enable_checkout_waiting_time">
						<?php echo wp_kses_post( $settings_fileds['wc_af_enable_checkout_waiting_time']['title'] ); ?>
                        <span class="woocommerce-help-tip" data-tip="<?php echo wp_kses_post( $settings_fileds['wc_af_enable_checkout_waiting_time']['desc_tip'] ); ?>"></span>
                    </label>
                </th>
                <td class="forminps forminp-checkbox">
                    <fieldset>
                        <legend class="screen-reader-text"><span><?php echo wp_kses_post( $settings_fileds['wc_af_enable_checkout_waiting_time']['title'] ); ?></span></legend>
                        <label for="wc_af_enable_checkout_waiting_time" class="opmc-toggle-control">
                            <input name="wc_af_enable_checkout_waiting_time" id="wc_af_enable_checkout_waiting_time" type="checkbox" value="1" <?php checked( get_option( 'wc_af_enable_checkout_waiting_time' ), 'yes' ); ?> >
                            <span class="opmc-control"></span>
                        </label>
                    </fieldset>
                    <p class="description"><?php echo wp_kses_post( $settings_fileds['wc_af_enable_checkout_waiting_time']['desc'] ); ?></p>
                </td>
            </tr>
            <tr valign="top">
                <td colspan="2">
                    <hr/>
                </td>
            </tr>
            <tr valign="top" class="">
                <th scope="row" class="titledesc">
                    <label for="wc_af_order_payment_attempt_check">
						<?php echo wp_kses_post( $settings_fileds['wc_af_order_payment_attempt_check']['title'] ); ?>
                        <span class="woocommerce-help-tip" data-tip="<?php echo wp_kses_post( $settings_fileds['wc_af_order_payment_attempt_check']['desc_tip'] ); ?>"></span>
                    </label>
                </th>
                <td class="forminp forminp-checkbox">
                    <fieldset>
                        <legend class="screen-reader-text"><span><?php echo wp_kses_post( $settings_fileds['wc_af_order_payment_attempt_check']['title'] ); ?></span></legend>
                        <label for="wc_af_order_payment_attempt_check" class="opmc-toggle-control">
                            <input name="wc_af_order_payment_attempt_check" id="wc_af_order_payment_attempt_check" type="checkbox" value="1" <?php checked( get_option( 'wc_af_order_payment_attempt_check' ), 'yes' ); ?> >
                            <span class="opmc-control"></span>
                        </label>
                    </fieldset>
                </td>
            </tr>
            <tr valign="top" class="">
                <th scope="row" class="titledesc">
                    <label for="wc_settings_anti_fraud_max_order_payment_attempt">
						<?php
						echo wp_kses_post( $settings_fileds['wc_settings_anti_fraud_max_order_payment_attempt']['name'] );
						$description = WC_Admin_Settings::get_field_description( $settings_fileds['wc_settings_anti_fraud_max_order_payment_attempt'] );
						echo wp_kses_post( $description['tooltip_html'] );
						?>
                    </label>
                </th>
                <td class="forminp forminp-number">
                    <input name="wc_settings_anti_fraud_max_order_payment_attempt" id="wc_settings_anti_fraud_max_order_payment_attempt" type="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_max_order_payment_attempt']['type'] ); ?>" style="display: block; width: 5em;" value="<?php echo esc_attr( get_option( 'wc_settings_anti_fraud_max_order_payment_attempt' ) ); ?>" min="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_max_order_payment_attempt']['custom_attributes']['min'] ); ?>" step="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_max_order_payment_attempt']['custom_attributes']['step'] ); ?>">
                </td>
            </tr>
            <tr valign="top">
                <td colspan="2">
                    <hr/>
                </td>
            </tr>

            <tr valign="top" class="">
                <th scope="row" class="titledesc">
                    <label for="wc_af_limit_order_count">
						<?php echo wp_kses_post( $settings_fileds['wc_af_limit_order_count']['title'] ); ?>
                        <span class="woocommerce-help-tip" data-tip="<?php echo esc_attr( $settings_fileds['wc_af_limit_order_count']['desc_tip'] ); ?>"></span>
                    </label>
                </th>
                <td class="forminp forminp-checkbox">
                    <fieldset>
                        <legend class="screen-reader-text"><span><?php echo wp_kses_post( $settings_fileds['wc_af_limit_order_count']['title'] ); ?></span></legend>
                        <label for="wc_af_limit_order_count" class="opmc-toggle-control">
                            <input name="wc_af_limit_order_count" id="wc_af_limit_order_count" type="checkbox" value="1" <?php checked( get_option( 'wc_af_limit_order_count' ), 'yes' ); ?> >
                            <span class="opmc-control"></span>
                        </label>
                    </fieldset>
                </td>
            </tr>
            <tr valign="top" class="">
                <th scope="row" class="titledesc">
                    <label for="wc_af_limit_time_start">
						<?php
						echo wp_kses_post( $settings_fileds['wc_af_limit_time_start']['name'] );
						$description = WC_Admin_Settings::get_field_description( $settings_fileds['wc_af_limit_time_start'] );
						echo wp_kses_post( $description['tooltip_html'] );
						?>
                    </label>
                </th>
                <td class="forminp forminp-time">
                    <input name="wc_af_limit_time_start" id="wc_af_limit_time_start" type="<?php echo esc_attr( $settings_fileds['wc_af_limit_time_start']['type'] ); ?>" style="<?php echo esc_attr( $settings_fileds['wc_af_limit_time_start']['css'] ); ?>" value="<?php echo esc_attr( get_option( 'wc_af_limit_time_start' ) ); ?>">
                </td>
            </tr>

            <tr valign="top" class="">
                <th scope="row" class="titledesc">
                    <label for="wc_af_limit_time_end">
						<?php
						echo wp_kses_post( $settings_fileds['wc_af_limit_time_end']['name'] );
						$description = WC_Admin_Settings::get_field_description( $settings_fileds['wc_af_limit_time_end'] );
						echo wp_kses_post( $description['tooltip_html'] );
						?>
                    </label>
                </th>
                <td class="forminp forminp-number">
                    <input name="wc_af_limit_time_end" id="wc_af_limit_time_end" type="<?php echo esc_attr( $settings_fileds['wc_af_limit_time_end']['type'] ); ?>" style="<?php echo esc_attr( $settings_fileds['wc_af_limit_time_start']['css'] ); ?>" value="<?php echo esc_attr( get_option( 'wc_af_limit_time_end' ) ); ?>">
                </td>
            </tr>
            <tr valign="top" class="">
                <th scope="row" class="titledesc">
                    <label for="wc_af_allowed_order_limit">
						<?php
						echo wp_kses_post( $settings_fileds['wc_af_allowed_order_limit']['name'] );
						$description = WC_Admin_Settings::get_field_description( $settings_fileds['wc_af_allowed_order_limit'] );
						echo wp_kses_post( $description['tooltip_html'] );
						?>
                    </label>
                </th>
                <td class="forminp forminp-number">
                    <input name="wc_af_allowed_order_limit" id="wc_af_allowed_order_limit" type="<?php echo esc_attr( $settings_fileds['wc_af_allowed_order_limit']['type'] ); ?>" style="display: block; width: 5em;" value="<?php echo esc_attr( get_option( 'wc_af_allowed_order_limit' ) ); ?>" min="<?php echo esc_attr( $settings_fileds['wc_af_allowed_order_limit']['custom_attributes']['min'] ); ?>" step="<?php echo esc_attr( $settings_fileds['wc_af_allowed_order_limit']['custom_attributes']['step'] ); ?>">
                </td>
            </tr>
            </tbody>

			<?php $this->opmc_add_admin_field_section_3_cardAttack( $settings_fileds[ $this->id . '_order_payment_attempts_settings' ] ); ?>
            <tbody>
            <tr valign="top" class="">
                <th scope="row" class="titledesc">
                    <label for="wc_af_order_payment_attempt_check">
						<?php echo wp_kses_post( $settings_fileds['wc_af_order_payment_attempt_check']['title'] ); ?>
                        <span class="woocommerce-help-tip" data-tip="<?php echo wp_kses_post( $settings_fileds['wc_af_order_payment_attempt_check']['desc_tip'] ); ?>"></span>
                    </label>
                </th>
                <td class="forminp forminp-checkbox">
                    <fieldset>
                        <legend class="screen-reader-text"><span><?php echo wp_kses_post( $settings_fileds['wc_af_order_payment_attempt_check']['title'] ); ?></span></legend>
                        <label for="wc_af_order_payment_attempt_check" class="opmc-toggle-control">
                            <input name="wc_af_order_payment_attempt_check" id="wc_af_order_payment_attempt_check" type="checkbox" value="1" <?php checked( get_option( 'wc_af_order_payment_attempt_check' ), 'yes' ); ?> >
                            <span class="opmc-control"></span>
                        </label>
                    </fieldset>
                </td>
            </tr>
            <tr valign="top" class="">
                <th scope="row" class="titledesc">
                    <label for="wc_settings_anti_fraud_max_order_payment_attempt">
						<?php
						echo wp_kses_post( $settings_fileds['wc_settings_anti_fraud_max_order_payment_attempt']['name'] );
						$description = WC_Admin_Settings::get_field_description( $settings_fileds['wc_settings_anti_fraud_max_order_payment_attempt'] );
						echo wp_kses_post( $description['tooltip_html'] );
						?>
                    </label>
                </th>
                <td class="forminp forminp-number">
                    <input name="wc_settings_anti_fraud_max_order_payment_attempt" id="wc_settings_anti_fraud_max_order_payment_attempt" type="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_max_order_payment_attempt']['type'] ); ?>" style="display: block; width: 5em;" value="<?php echo esc_attr( get_option( 'wc_settings_anti_fraud_max_order_payment_attempt' ) ); ?>" min="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_max_order_payment_attempt']['custom_attributes']['min'] ); ?>" step="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_max_order_payment_attempt']['custom_attributes']['step'] ); ?>">
                </td>
            </tr>
            </tbody>

			<?php $this->opmc_add_admin_field_section_4_cardAttack( $settings_fileds[ $this->id . '_order_between_times_settings' ] ); ?>
            <tbody>
            <tr valign="top" class="">
                <th scope="row" class="titledesc">
                    <label for="wc_af_limit_order_count">
						<?php echo wp_kses_post( $settings_fileds['wc_af_limit_order_count']['title'] ); ?>
                        <span class="woocommerce-help-tip" data-tip="<?php echo esc_attr( $settings_fileds['wc_af_limit_order_count']['desc_tip'] ); ?>"></span>
                    </label>
                </th>
                <td class="forminp forminp-checkbox">
                    <fieldset>
                        <legend class="screen-reader-text"><span><?php echo wp_kses_post( $settings_fileds['wc_af_limit_order_count']['title'] ); ?></span></legend>
                        <label for="wc_af_limit_order_count" class="opmc-toggle-control">
                            <input name="wc_af_limit_order_count" id="wc_af_limit_order_count" type="checkbox" value="1" <?php checked( get_option( 'wc_af_limit_order_count' ), 'yes' ); ?> >
                            <span class="opmc-control"></span>
                        </label>
                    </fieldset>
                </td>
            </tr>
            <tr valign="top" class="">
                <th scope="row" class="titledesc">
                    <label for="wc_af_limit_time_start">
						<?php
						echo wp_kses_post( $settings_fileds['wc_af_limit_time_start']['name'] );
						$description = WC_Admin_Settings::get_field_description( $settings_fileds['wc_af_limit_time_start'] );
						echo wp_kses_post( $description['tooltip_html'] );
						?>
                    </label>
                </th>
                <td class="forminp forminp-time">
                    <input name="wc_af_limit_time_start" id="wc_af_limit_time_start" type="<?php echo esc_attr( $settings_fileds['wc_af_limit_time_start']['type'] ); ?>" style="<?php echo esc_attr( $settings_fileds['wc_af_limit_time_start']['css'] ); ?>" value="<?php echo esc_attr( get_option( 'wc_af_limit_time_start' ) ); ?>">
                </td>
            </tr>
            <tr valign="top" class="">
                <th scope="row" class="titledesc">
                    <label for="wc_af_limit_time_end">
						<?php
						echo wp_kses_post( $settings_fileds['wc_af_limit_time_end']['name'] );
						$description = WC_Admin_Settings::get_field_description( $settings_fileds['wc_af_limit_time_end'] );
						echo wp_kses_post( $description['tooltip_html'] );
						?>
                    </label>
                </th>
                <td class="forminp forminp-number">
                    <input name="wc_af_limit_time_end" id="wc_af_limit_time_end" type="<?php echo esc_attr( $settings_fileds['wc_af_limit_time_end']['type'] ); ?>" style="<?php echo esc_attr( $settings_fileds['wc_af_limit_time_start']['css'] ); ?>" value="<?php echo esc_attr( get_option( 'wc_af_limit_time_end' ) ); ?>">
                </td>
            </tr>
            <tr valign="top" class="">
                <th scope="row" class="titledesc">
                    <label for="wc_af_allowed_order_limit">
						<?php
						echo wp_kses_post( $settings_fileds['wc_af_allowed_order_limit']['name'] );
						$description = WC_Admin_Settings::get_field_description( $settings_fileds['wc_af_allowed_order_limit'] );
						echo wp_kses_post( $description['tooltip_html'] );
						?>
                    </label>
                </th>
                <td class="forminp forminp-number">
                    <input name="wc_af_allowed_order_limit" id="wc_af_allowed_order_limit" type="<?php echo esc_attr( $settings_fileds['wc_af_allowed_order_limit']['type'] ); ?>" style="display: block; width: 5em;" value="<?php echo esc_attr( get_option( 'wc_af_allowed_order_limit' ) ); ?>" min="<?php echo esc_attr( $settings_fileds['wc_af_allowed_order_limit']['custom_attributes']['min'] ); ?>" step="<?php echo esc_attr( $settings_fileds['wc_af_allowed_order_limit']['custom_attributes']['step'] ); ?>">
                </td>
            </tr>
            </tbody>

        </table>

    </section>

<?php elseif ( 'rules' == $current_section ) : ?>

    <section>
        <h2><?php echo esc_html__( 'General Rules', 'woocommerce-anti-fraud' ); ?></h2>
        <div id="<?php echo esc_attr( $this->id . '_rule_settings-description' ); ?>">
			<?php echo wp_kses_post( $settings_fileds[ $this->id . '_rule_settings' ]['desc'] ); ?>
        </div>

		<?php $this->opmc_add_admin_field_section( $settings_fileds[ $this->id . '_first_time_purchase_settings' ] ); ?>
        <tbody>
        <tr valign="top" class="">
            <th scope="row" class="titledesc">
                <label for="wc_af_first_order_custom">
					<?php echo wp_kses_post( $settings_fileds['wc_af_first_order']['title'] ); ?>
                    <span class="woocommerce-help-tip" data-tip="<?php echo esc_attr( $settings_fileds['wc_af_first_order']['desc_tip'] ); ?>"></span>
                </label>
            </th>
            <td class="forminp forminp-checkbox">
                <fieldset>
                    <legend class="screen-reader-text"><span><?php echo wp_kses_post( $settings_fileds['wc_af_first_order']['title'] ); ?></span></legend>
                    <label for="wc_af_first_order" class="opmc-toggle-control">
                        <input name="wc_af_first_order" id="wc_af_first_order" type="checkbox" value="1" <?php checked( get_option( 'wc_af_first_order' ), 'yes' ); ?> >
                        <span class="opmc-control"></span>
                    </label>
                </fieldset>
            </td>
            <td class="forminp forminp-number">
                <input name="wc_settings_anti_fraud_first_order_weight" id="wc_settings_anti_fraud_first_order_weight" type="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_first_order_weight']['type'] ); ?>" style="display: block; width: 5em;" value="<?php echo esc_attr( get_option( 'wc_settings_anti_fraud_first_order_weight' ) ); ?>" min="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_first_order_weight']['custom_attributes']['min'] ); ?>" step="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_first_order_weight']['custom_attributes']['step'] ); ?>" max="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_first_order_weight']['custom_attributes']['max'] ); ?>">
            </td>
            <td class="forminp forminp-slider">
				<?php $this->opmc_score_slider( get_option( 'wc_settings_anti_fraud_first_order_weight' ) ); ?>
            </td>
        </tr>
        <tr valign="top" class="">
            <th scope="row" class="titledesc">
                <label for="wc_af_first_order_custom">
					<?php echo wp_kses_post( $settings_fileds['wc_af_first_order_custom']['title'] ); ?>
                    <span class="woocommerce-help-tip" data-tip="<?php echo esc_attr( $settings_fileds['wc_af_first_order_custom']['desc_tip'] ); ?>"></span>
                </label>
            </th>
            <td class="forminp forminp-checkbox">
                <fieldset>
                    <legend class="screen-reader-text"><span><?php echo wp_kses_post( $settings_fileds['wc_af_first_order_custom']['title'] ); ?></span></legend>
                    <label for="wc_af_first_order_custom" class="opmc-toggle-control">
                        <input name="wc_af_first_order_custom" id="wc_af_first_order_custom" type="checkbox" value="1" <?php checked( get_option( 'wc_af_first_order_custom' ), 'yes' ); ?> >
                        <span class="opmc-control"></span>
                    </label>
                </fieldset>
            </td>
            <td class="forminp forminp-number">
                <input name="wc_settings_anti_fraud_first_order_custom_weight" id="wc_settings_anti_fraud_first_order_custom_weight" type="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_first_order_custom_weight']['type'] ); ?>" style="display: block; width: 5em;" value="<?php echo esc_attr( get_option( 'wc_settings_anti_fraud_first_order_custom_weight' ) ); ?>" min="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_first_order_custom_weight']['custom_attributes']['min'] ); ?>" step="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_first_order_custom_weight']['custom_attributes']['step'] ); ?>" max="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_first_order_custom_weight']['custom_attributes']['max'] ); ?>">
            </td>
            <td class="forminp forminp-slider">
				<?php $this->opmc_score_slider( get_option( 'wc_settings_anti_fraud_first_order_custom_weight' ) ); ?>
            </td>
        </tr>
        <tr valign="top">
            <td colspan="2">
                <hr/>
            </td>
        </tr>
        </tbody>

		<?php $this->opmc_add_admin_field_section( $settings_fileds[ $this->id . '_address_based_rules_settings' ] ); ?>

        <tbody>
        <tr valign="top" class="">
            <th scope="row" class="titledesc">
                <label for="wc_af_bca_order">
					<?php echo wp_kses_post( $settings_fileds['wc_af_bca_order']['title'] ); ?>
                    <span class="woocommerce-help-tip" data-tip="<?php echo wp_kses_post( $settings_fileds['wc_af_bca_order']['desc_tip'] ); ?>"></span>
                </label>
            </th>
            <td class="forminp forminp-checkbox">
                <fieldset>
                    <legend class="screen-reader-text"><span><?php echo wp_kses_post( $settings_fileds['wc_af_bca_order']['title'] ); ?></span></legend>
                    <label for="wc_af_bca_order" class="opmc-toggle-control">
                        <input name="wc_af_bca_order" id="wc_af_bca_order" type="checkbox" value="1" <?php checked( get_option( 'wc_af_bca_order' ), 'yes' ); ?> >
                        <span class="opmc-control"></span>
                    </label>
                </fieldset>
            </td>
            <td class="forminp forminp-number">
                <input name="wc_settings_anti_fraud_bca_order_weight" id="wc_settings_anti_fraud_bca_order_weight" type="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_bca_order_weight']['type'] ); ?>" style="display: block; width: 5em;" value="<?php echo esc_attr( get_option( 'wc_settings_anti_fraud_bca_order_weight' ) ); ?>" min="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_bca_order_weight']['custom_attributes']['min'] ); ?>" step="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_bca_order_weight']['custom_attributes']['step'] ); ?>" max="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_bca_order_weight']['custom_attributes']['max'] ); ?>">
            </td>
            <td class="forminp forminp-slider">
				<?php $this->opmc_score_slider( get_option( 'wc_settings_anti_fraud_bca_order_weight' ) ); ?>
            </td>
        </tr>
        <!-- /* Geo Localion */ -->
        <tr valign="top" class="">
            <th scope="row" class="titledesc">
                <label for="wc_af_geolocation_order">
					<?php echo wp_kses_post( $settings_fileds['wc_af_geolocation_order']['title'] ); ?>
                    <span class="woocommerce-help-tip" data-tip="<?php echo wp_kses_post( $settings_fileds['wc_af_geolocation_order']['desc_tip'] ); ?>"></span>
                </label>
            </th>
            <td class="forminp forminp-checkbox">
                <fieldset>
                    <legend class="screen-reader-text"><span><?php echo wp_kses_post( $settings_fileds['wc_af_geolocation_order']['title'] ); ?></span></legend>
                    <label for="wc_af_geolocation_order" class="opmc-toggle-control">
                        <input name="wc_af_geolocation_order" id="wc_af_geolocation_order" type="checkbox" value="1" <?php checked( get_option( 'wc_af_geolocation_order' ), 'yes' ); ?> >
                        <span class="opmc-control"></span>
                    </label>
                </fieldset>
            </td>
            <td class="forminp forminp-number">
                <input name="wc_settings_anti_fraud_geolocation_order_weight" id="wc_settings_anti_fraud_geolocation_order_weight" type="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_geolocation_order_weight']['type'] ); ?>" style="display: block; width: 5em;" value="<?php echo esc_attr( get_option( 'wc_settings_anti_fraud_geolocation_order_weight' ) ); ?>" min="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_geolocation_order_weight']['custom_attributes']['min'] ); ?>" step="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_geolocation_order_weight']['custom_attributes']['step'] ); ?>" max="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_geolocation_order_weight']['custom_attributes']['max'] ); ?>">
            </td>
            <td class="forminp forminp-slider">
				<?php $this->opmc_score_slider( get_option( 'wc_settings_anti_fraud_geolocation_order_weight' ) ); ?>
            </td>
        </tr>

        <tr valign="top">
            <th scope="row" class="titledesc">
                <label for="bigdatacloud_api_key">
					<?php
					echo wp_kses_post( $settings_fileds['bigdatacloud_api_key']['title'] );
					$description = WC_Admin_Settings::get_field_description( $settings_fileds['bigdatacloud_api_key'] );
					echo wp_kses_post( $description['tooltip_html'] );
					?>
                </label>
            </th>
            <td class="forminp forminp-text" colspan="3">
                <input name="bigdatacloud_api_key" id="bigdatacloud_api_key" type="<?php echo esc_attr( $settings_fileds['bigdatacloud_api_key']['type'] ); ?>" value="<?php echo esc_attr( get_option( 'bigdatacloud_api_key' ) ); ?>">
				<?php echo wp_kses_post( $description['description'] ); ?>
            </td>
        </tr>
        <!-- /* Geo Localion End */ -->

        <tr valign="top" class="">
            <th scope="row" class="titledesc">
                <label for="wc_af_billing_phone_number_order">
					<?php echo wp_kses_post( $settings_fileds['wc_af_billing_phone_number_order']['title'] ); ?>
                    <span class="woocommerce-help-tip" data-tip="<?php echo wp_kses_post( $settings_fileds['wc_af_billing_phone_number_order']['desc_tip'] ); ?>"></span>
                </label>
            </th>
            <td class="forminp forminp-checkbox">
                <fieldset>
                    <legend class="screen-reader-text"><span><?php echo wp_kses_post( $settings_fileds['wc_af_billing_phone_number_order']['title'] ); ?></span></legend>
                    <label for="wc_af_billing_phone_number_order" class="opmc-toggle-control">
                        <input name="wc_af_billing_phone_number_order" id="wc_af_billing_phone_number_order" type="checkbox" value="1" <?php checked( get_option( 'wc_af_billing_phone_number_order' ), 'yes' ); ?> >
                        <span class="opmc-control"></span>
                    </label>
                </fieldset>
            </td>
            <td class="forminp forminp-number">
                <input name="wc_settings_anti_fraud_billing_phone_number_order_weight" id="wc_settings_anti_fraud_billing_phone_number_order_weight" type="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_billing_phone_number_order_weight']['type'] ); ?>" style="display: block; width: 5em;" value="<?php echo esc_attr( get_option( 'wc_settings_anti_fraud_billing_phone_number_order_weight' ) ); ?>" min="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_billing_phone_number_order_weight']['custom_attributes']['min'] ); ?>" step="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_billing_phone_number_order_weight']['custom_attributes']['step'] ); ?>" max="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_billing_phone_number_order_weight']['custom_attributes']['max'] ); ?>">
            </td>
            <td class="forminp forminp-slider">
				<?php $this->opmc_score_slider( get_option( 'wc_settings_anti_fraud_billing_phone_number_order_weight' ) ); ?>
            </td>
        </tr>
        <tr valign="top" class="">
            <th scope="row" class="titledesc">
                <label for="wc_af_proxy_order">
					<?php echo wp_kses_post( $settings_fileds['wc_af_proxy_order']['title'] ); ?>
                    <span class="woocommerce-help-tip" data-tip="<?php echo wp_kses_post( $settings_fileds['wc_af_proxy_order']['desc_tip'] ); ?>"></span>
                </label>
            </th>
            <td class="forminp forminp-checkbox">
                <fieldset>
                    <legend class="screen-reader-text"><span><?php echo wp_kses_post( $settings_fileds['wc_af_proxy_order']['title'] ); ?></span></legend>
                    <label for="wc_af_proxy_order" class="opmc-toggle-control">
                        <input name="wc_af_proxy_order" id="wc_af_proxy_order" type="checkbox" value="1" <?php checked( get_option( 'wc_af_proxy_order' ), 'yes' ); ?> >
                        <span class="opmc-control"></span>
                    </label>
                </fieldset>
            </td>
            <td class="forminp forminp-number">
                <input name="wc_settings_anti_fraud_proxy_order_weight" id="wc_settings_anti_fraud_proxy_order_weight" type="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_proxy_order_weight']['type'] ); ?>" style="display: block; width: 5em;" value="<?php echo esc_attr( get_option( 'wc_settings_anti_fraud_proxy_order_weight' ) ); ?>" min="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_proxy_order_weight']['custom_attributes']['min'] ); ?>" step="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_proxy_order_weight']['custom_attributes']['step'] ); ?>" max="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_proxy_order_weight']['custom_attributes']['max'] ); ?>">
            </td>
            <td class="forminp forminp-slider">
				<?php $this->opmc_score_slider( get_option( 'wc_settings_anti_fraud_proxy_order_weight' ) ); ?>
            </td>
        </tr>
        <tr valign="top">
            <td colspan="2">
                <hr/>
            </td>
        </tr>
        </tbody>

		<?php $this->opmc_add_admin_field_section( $settings_fileds[ $this->id . '_multi_order_attempts_rules_settings' ] ); ?>

        <tbody>
        <tr valign="top" class="">
            <th scope="row" class="titledesc">
                <label for="wc_af_ip_multiple_check">
					<?php echo wp_kses_post( $settings_fileds['wc_af_ip_multiple_check']['title'] ); ?>
                    <span class="woocommerce-help-tip" data-tip="<?php echo wp_kses_post( $settings_fileds['wc_af_ip_multiple_check']['desc_tip'] ); ?>"></span>
                </label>
            </th>
            <td class="forminp forminp-checkbox">
                <fieldset>
                    <legend class="screen-reader-text"><span><?php echo wp_kses_post( $settings_fileds['wc_af_ip_multiple_check']['title'] ); ?></span></legend>
                    <label for="wc_af_ip_multiple_check" class="opmc-toggle-control">
                        <input name="wc_af_ip_multiple_check" id="wc_af_ip_multiple_check" type="checkbox" value="1" <?php checked( get_option( 'wc_af_ip_multiple_check' ), 'yes' ); ?> >
                        <span class="opmc-control"></span>
                    </label>
                </fieldset>
            </td>
            <td class="forminp forminp-number">
                <input name="wc_settings_anti_fraud_ip_multiple_weight" id="wc_settings_anti_fraud_ip_multiple_weight" type="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_ip_multiple_weight']['type'] ); ?>" style="display: block; width: 5em;" value="<?php echo esc_attr( get_option( 'wc_settings_anti_fraud_ip_multiple_weight' ) ); ?>" min="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_ip_multiple_weight']['custom_attributes']['min'] ); ?>" step="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_ip_multiple_weight']['custom_attributes']['step'] ); ?>" max="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_ip_multiple_weight']['custom_attributes']['max'] ); ?>">
            </td>
            <td class="forminp forminp-slider">
				<?php $this->opmc_score_slider( get_option( 'wc_settings_anti_fraud_ip_multiple_weight' ) ); ?>
            </td>
        </tr>

        <tr valign="top" class="">
            <th scope="row" class="titledesc">
                <label for="wc_settings_anti_fraud_ip_multiple_time_span">
					<?php
					echo wp_kses_post( $settings_fileds['wc_settings_anti_fraud_ip_multiple_time_span']['name'] );
					$description = WC_Admin_Settings::get_field_description( $settings_fileds['wc_settings_anti_fraud_ip_multiple_time_span'] );
					echo wp_kses_post( $description['tooltip_html'] );
					?>
                </label>
            </th>
            <td class="forminp forminp-number">
                <input name="wc_settings_anti_fraud_ip_multiple_time_span" id="wc_settings_anti_fraud_ip_multiple_time_span" type="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_ip_multiple_time_span']['type'] ); ?>" style="display: block; width: 5em;" value="<?php echo esc_attr( get_option( 'wc_settings_anti_fraud_ip_multiple_time_span' ) ); ?>" min="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_ip_multiple_time_span']['custom_attributes']['min'] ); ?>" step="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_ip_multiple_time_span']['custom_attributes']['step'] ); ?>">
            </td>
        </tr>
        <tr valign="top">
            <td colspan="2">
                <hr/>
            </td>
        </tr>

        </tbody>

		<?php $this->opmc_add_admin_field_section( $settings_fileds[ $this->id . '_origin_countries_rules_settings' ] ); ?>

        <tbody>
        <tr valign="top" class="">
            <th scope="row" class="titledesc">
                <label for="wc_af_international_order">
					<?php echo wp_kses_post( $settings_fileds['wc_af_international_order']['title'] ); ?>
                    <span class="woocommerce-help-tip" data-tip="<?php echo wp_kses_post( $settings_fileds['wc_af_international_order']['desc_tip'] ); ?>"></span>
                </label>
            </th>
            <td class="forminp forminp-checkbox">
                <fieldset>
                    <legend class="screen-reader-text"><span><?php echo wp_kses_post( $settings_fileds['wc_af_international_order']['title'] ); ?></span></legend>
                    <label for="wc_af_international_order" class="opmc-toggle-control">
                        <input name="wc_af_international_order" id="wc_af_international_order" type="checkbox" value="1" <?php checked( get_option( 'wc_af_international_order' ), 'yes' ); ?> >
                        <span class="opmc-control"></span>
                    </label>
                </fieldset>
            </td>
            <td class="forminp forminp-number">
                <input name="wc_settings_anti_fraud_international_order_weight" id="wc_settings_anti_fraud_international_order_weight" type="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_international_order_weight']['type'] ); ?>" style="display: block; width: 5em;" value="<?php echo esc_attr( get_option( 'wc_settings_anti_fraud_international_order_weight' ) ); ?>" min="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_international_order_weight']['custom_attributes']['min'] ); ?>" step="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_international_order_weight']['custom_attributes']['step'] ); ?>" max="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_international_order_weight']['custom_attributes']['max'] ); ?>">
            </td>
            <td class="forminp forminp-slider">
				<?php $this->opmc_score_slider( get_option( 'wc_settings_anti_fraud_international_order_weight' ) ); ?>
            </td>
        </tr>
        <tr valign="top" class="">
            <th scope="row" class="titledesc">
                <label for="wc_af_unsafe_countries">
					<?php echo wp_kses_post( $settings_fileds['wc_af_unsafe_countries']['title'] ); ?>
                    <span class="woocommerce-help-tip" data-tip="<?php echo wp_kses_post( $settings_fileds['wc_af_unsafe_countries']['desc_tip'] ); ?>"></span>
                </label>
            </th>
            <td class="forminp forminp-checkbox">
                <fieldset>
                    <legend class="screen-reader-text"><span><?php echo wp_kses_post( $settings_fileds['wc_af_unsafe_countries']['title'] ); ?></span></legend>
                    <label for="wc_af_unsafe_countries" class="opmc-toggle-control">
                        <input name="wc_af_unsafe_countries" id="wc_af_unsafe_countries" type="checkbox" value="1" <?php checked( get_option( 'wc_af_unsafe_countries' ), 'yes' ); ?> >
                        <span class="opmc-control"></span>
                    </label>
                </fieldset>
            </td>
            <td class="forminp forminp-number">
                <input name="wc_settings_anti_fraud_unsafe_countries_weight" id="wc_settings_anti_fraud_unsafe_countries_weight" type="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_unsafe_countries_weight']['type'] ); ?>" style="display: block; width: 5em;" value="<?php echo esc_attr( get_option( 'wc_settings_anti_fraud_unsafe_countries_weight' ) ); ?>" min="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_unsafe_countries_weight']['custom_attributes']['min'] ); ?>" step="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_unsafe_countries_weight']['custom_attributes']['step'] ); ?>" max="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_unsafe_countries_weight']['custom_attributes']['max'] ); ?>">
            </td>
            <td class="forminp forminp-slider">
				<?php $this->opmc_score_slider( get_option( 'wc_settings_anti_fraud_unsafe_countries_weight' ) ); ?>
            </td>
        </tr>
        <tr valign="top">
            <th scope="row" class="titledesc">
                <label for="wc_settings_anti_fraud_define_unsafe_countries_list">
					<?php
					echo wp_kses_post( $settings_fileds['wc_settings_anti_fraud_define_unsafe_countries_list']['name'] );
					$description = WC_Admin_Settings::get_field_description( $settings_fileds['wc_settings_anti_fraud_define_unsafe_countries_list'] );
					echo wp_kses_post( $description['tooltip_html'] );
					?>
                </label>
            </th>
            <td class="forminp forminp-multiselect" colspan="2">
                <select name="wc_settings_anti_fraud_define_unsafe_countries_list[]" id="wc_settings_anti_fraud_define_unsafe_countries_list" class="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_define_unsafe_countries_list']['class'] ); ?>" multiple>
					<?php foreach ( $settings_fileds['wc_settings_anti_fraud_define_unsafe_countries_list']['options'] as $option_key_inner => $option_value_inner ) : ?>
                        <option value="<?php echo esc_attr( $option_key_inner ); ?>" <?php selected( in_array( (string) $option_key_inner, $settings_fileds['wc_settings_anti_fraud_define_unsafe_countries_list']['default'] ) ); ?>><?php echo esc_html( $option_value_inner ); ?></option>
					<?php endforeach ?>
                </select>
            </td>
        </tr>
        <tr valign="top">
            <td colspan="2">
                <hr/>
            </td>
        </tr>
        </tbody>

		<?php $this->opmc_add_admin_field_section( $settings_fileds[ $this->id . '_high_risk_domain_rules_settings' ] ); ?>

        <tbody>
        <tr valign="top" class="">
            <th scope="row" class="titledesc">
                <label for="wc_af_suspecius_email">
					<?php echo wp_kses_post( $settings_fileds['wc_af_suspecius_email']['title'] ); ?>
                    <span class="woocommerce-help-tip" data-tip="<?php echo wp_kses_post( $settings_fileds['wc_af_suspecius_email']['desc_tip'] ); ?>"></span>
                </label>
            </th>
            <td class="forminp forminp-checkbox">
                <fieldset>
                    <legend class="screen-reader-text"><span><?php echo wp_kses_post( $settings_fileds['wc_af_suspecius_email']['title'] ); ?></span></legend>
                    <label for="wc_af_suspecius_email" class="opmc-toggle-control">
                        <input name="wc_af_suspecius_email" id="wc_af_suspecius_email" type="checkbox" value="1" <?php checked( get_option( 'wc_af_suspecius_email' ), 'yes' ); ?> >
                        <span class="opmc-control"></span>
                    </label>
                </fieldset>
            </td>
            <td class="forminp forminp-number">
                <input name="wc_settings_anti_fraud_suspecious_email_weight" id="wc_settings_anti_fraud_suspecious_email_weight" type="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_suspecious_email_weight']['type'] ); ?>" style="display: block; width: 5em;" value="<?php echo esc_attr( get_option( 'wc_settings_anti_fraud_suspecious_email_weight' ) ); ?>" min="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_suspecious_email_weight']['custom_attributes']['min'] ); ?>" step="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_suspecious_email_weight']['custom_attributes']['step'] ); ?>" max="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_suspecious_email_weight']['custom_attributes']['max'] ); ?>">
            </td>
            <td class="forminp forminp-slider">
				<?php $this->opmc_score_slider( get_option( 'wc_settings_anti_fraud_suspecious_email_weight' ) ); ?>
            </td>
        </tr>
        <tr valign="top">
            <th scope="row" class="titledesc">
                <label for="wc_settings_anti_fraud_suspecious_email_domains">
					<?php
					echo wp_kses_post( $settings_fileds['wc_settings_anti_fraud_suspecious_email_domains']['name'] );
					$description = WC_Admin_Settings::get_field_description( $settings_fileds['wc_settings_anti_fraud_suspecious_email_domains'] );
					echo wp_kses_post( $description['tooltip_html'] );
					?>
                </label>
            </th>
            <td class="forminp forminp-textarea" colspan="3">
                <textarea name="wc_settings_anti_fraud_suspecious_email_domains" id="wc_settings_anti_fraud_suspecious_email_domains" style="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_suspecious_email_domains']['css'] ); ?>" class="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_suspecious_email_domains']['class'] ); ?>"><?php echo esc_html( get_option( 'wc_settings_anti_fraud_suspecious_email_domains' ) ); ?></textarea>
            </td>
        </tr>
        <tr valign="top">
            <th scope="row" class="titledesc">
                <label for="check_email_domain_api_key">
					<?php
					echo wp_kses_post( $settings_fileds['check_email_domain_api_key']['title'] );
					$description = WC_Admin_Settings::get_field_description( $settings_fileds['check_email_domain_api_key'] );
					echo wp_kses_post( $description['tooltip_html'] );
					?>
                </label>
            </th>
            <td class="forminp forminp-text" colspan="3">
                <input name="check_email_domain_api_key" id="check_email_domain_api_key" type="<?php echo esc_attr( $settings_fileds['check_email_domain_api_key']['type'] ); ?>" value="<?php echo esc_attr( get_option( 'check_email_domain_api_key' ) ); ?>">
				<?php echo wp_kses_post( $description['description'] ); ?>
            </td>
        </tr>
        <tr valign="top">
            <td colspan="2">
                <hr/>
            </td>
        </tr>

        </tbody>

		<?php $this->opmc_add_admin_field_section( $settings_fileds[ $this->id . '_order_amount_attempts_rules_settings' ] ); ?>

        <tbody>
        <tr valign="top" class="">
            <th scope="row" class="titledesc">
                <label for="wc_af_order_avg_amount_check">
					<?php echo wp_kses_post( $settings_fileds['wc_af_order_avg_amount_check']['title'] ); ?>
                    <span class="woocommerce-help-tip" data-tip="<?php echo wp_kses_post( $settings_fileds['wc_af_order_avg_amount_check']['desc_tip'] ); ?>"></span>
                </label>
            </th>
            <td class="forminp forminp-checkbox">
                <fieldset>
                    <legend class="screen-reader-text"><span><?php echo wp_kses_post( $settings_fileds['wc_af_order_avg_amount_check']['title'] ); ?></span></legend>
                    <label for="wc_af_order_avg_amount_check" class="opmc-toggle-control">
                        <input name="wc_af_order_avg_amount_check" id="wc_af_order_avg_amount_check" type="checkbox" value="1" <?php checked( get_option( 'wc_af_order_avg_amount_check' ), 'yes' ); ?> >
                        <span class="opmc-control"></span>
                    </label>
                </fieldset>
            </td>
            <td class="forminp forminp-number">
                <input name="wc_settings_anti_fraud_order_avg_amount_weight" id="wc_settings_anti_fraud_order_avg_amount_weight" type="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_order_avg_amount_weight']['type'] ); ?>" style="display: block; width: 5em;" value="<?php echo esc_attr( get_option( 'wc_settings_anti_fraud_order_avg_amount_weight' ) ); ?>" min="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_order_avg_amount_weight']['custom_attributes']['min'] ); ?>" step="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_order_avg_amount_weight']['custom_attributes']['step'] ); ?>" max="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_order_avg_amount_weight']['custom_attributes']['max'] ); ?>">
            </td>
            <td class="forminp forminp-slider">
				<?php $this->opmc_score_slider( get_option( 'wc_settings_anti_fraud_order_avg_amount_weight' ) ); ?>
            </td>
        </tr>
        <tr valign="top" class="">
            <th scope="row" class="titledesc">
                <label for="wc_settings_anti_fraud_avg_amount_multiplier">
					<?php
					echo wp_kses_post( $settings_fileds['wc_settings_anti_fraud_avg_amount_multiplier']['name'] );
					$description = WC_Admin_Settings::get_field_description( $settings_fileds['wc_settings_anti_fraud_avg_amount_multiplier'] );
					echo wp_kses_post( $description['tooltip_html'] );
					?>
                </label>
            </th>
            <td class="forminp forminp-number">
                <input name="wc_settings_anti_fraud_avg_amount_multiplier" id="wc_settings_anti_fraud_avg_amount_multiplier" type="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_avg_amount_multiplier']['type'] ); ?>" style="display: block; width: 5em;" value="<?php echo esc_attr( get_option( 'wc_settings_anti_fraud_avg_amount_multiplier' ) ); ?>" min="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_avg_amount_multiplier']['custom_attributes']['min'] ); ?>" step="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_avg_amount_multiplier']['custom_attributes']['step'] ); ?>">
            </td>
        </tr>
        <tr valign="top">
            <td colspan="2">
                <hr/>
            </td>
        </tr>

        <tr valign="top" class="">
            <th scope="row" class="titledesc">
                <label for="wc_af_order_amount_check">
					<?php echo wp_kses_post( $settings_fileds['wc_af_order_amount_check']['title'] ); ?>
                    <span class="woocommerce-help-tip" data-tip="<?php echo esc_attr( $settings_fileds['wc_af_order_amount_check']['desc_tip'] ); ?>"></span>
                </label>
            </th>
            <td class="forminp forminp-checkbox">
                <fieldset>
                    <legend class="screen-reader-text"><span><?php echo wp_kses_post( $settings_fileds['wc_af_order_amount_check']['title'] ); ?></span></legend>
                    <label for="wc_af_order_amount_check" class="opmc-toggle-control">
                        <input name="wc_af_order_amount_check" id="wc_af_order_amount_check" type="checkbox" value="1" <?php checked( get_option( 'wc_af_order_amount_check' ), 'yes' ); ?> >
                        <span class="opmc-control"></span>
                    </label>
                </fieldset>
            </td>
            <td class="forminp forminp-number">
                <input name="wc_settings_anti_fraud_order_amount_weight" id="wc_settings_anti_fraud_order_amount_weight" type="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_order_amount_weight']['type'] ); ?>" style="display: block; width: 5em;" value="<?php echo esc_attr( get_option( 'wc_settings_anti_fraud_order_amount_weight' ) ); ?>" min="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_order_amount_weight']['custom_attributes']['min'] ); ?>" step="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_order_amount_weight']['custom_attributes']['step'] ); ?>" max="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_order_amount_weight']['custom_attributes']['max'] ); ?>">
            </td>
            <td class="forminp forminp-slider">
				<?php $this->opmc_score_slider( get_option( 'wc_settings_anti_fraud_order_amount_weight' ) ); ?>
            </td>
        </tr>
        <tr valign="top" class="">
            <th scope="row" class="titledesc">
                <label for="wc_settings_anti_fraud_amount_limit">
					<?php
					echo wp_kses_post( $settings_fileds['wc_settings_anti_fraud_amount_limit']['name'] );
					$description = WC_Admin_Settings::get_field_description( $settings_fileds['wc_settings_anti_fraud_amount_limit'] );
					echo wp_kses_post( $description['tooltip_html'] );
					?>
                </label>
            </th>
            <td class="forminp forminp-text">
                <input name="wc_settings_anti_fraud_amount_limit" id="wc_settings_anti_fraud_amount_limit" type="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_amount_limit']['type'] ); ?>" style="display: block; width: 5em;" value="<?php echo esc_attr( get_option( 'wc_settings_anti_fraud_amount_limit' ) ); ?>">
            </td>
        </tr>
        <tr valign="top">
            <td colspan="2">
                <hr/>
            </td>
        </tr>

        </tbody>
		<?php $this->opmc_add_admin_field_section( $settings_fileds[ $this->id . '_order_attempts_rules_settings' ] ); ?>

        <tbody>
        <tr valign="top" class="">
            <th scope="row" class="titledesc">
                <label for="wc_af_attempt_count_check">
					<?php echo wp_kses_post( $settings_fileds['wc_af_attempt_count_check']['title'] ); ?>
                    <span class="woocommerce-help-tip" data-tip="<?php echo wp_kses_post( $settings_fileds['wc_af_attempt_count_check']['desc_tip'] ); ?>"></span>
                </label>
            </th>
            <td class="forminp forminp-checkbox">
                <fieldset>
                    <legend class="screen-reader-text"><span><?php echo wp_kses_post( $settings_fileds['wc_af_attempt_count_check']['title'] ); ?></span></legend>
                    <label for="wc_af_attempt_count_check" class="opmc-toggle-control">
                        <input name="wc_af_attempt_count_check" id="wc_af_attempt_count_check" type="checkbox" value="1" <?php checked( get_option( 'wc_af_attempt_count_check' ), 'yes' ); ?> >
                        <span class="opmc-control"></span>
                    </label>
                </fieldset>
            </td>
        </tr>
        <tr valign="top" class="">
            <th scope="row" class="titledesc">
                <label for="wc_settings_anti_fraud_attempt_time_span">
					<?php
					echo wp_kses_post( $settings_fileds['wc_settings_anti_fraud_attempt_time_span']['name'] );
					$description = WC_Admin_Settings::get_field_description( $settings_fileds['wc_settings_anti_fraud_attempt_time_span'] );
					echo wp_kses_post( $description['tooltip_html'] );
					?>
                </label>
            </th>
            <td class="forminp forminp-number">
                <input name="wc_settings_anti_fraud_attempt_time_span" id="wc_settings_anti_fraud_attempt_time_span" type="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_attempt_time_span']['type'] ); ?>" style="display: block; width: 5em;" value="<?php echo esc_attr( get_option( 'wc_settings_anti_fraud_attempt_time_span' ) ); ?>" min="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_attempt_time_span']['custom_attributes']['min'] ); ?>" step="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_attempt_time_span']['custom_attributes']['step'] ); ?>">
            </td>
        </tr>
        <tr valign="top" class="">
            <th scope="row" class="titledesc">
                <label for="wc_settings_anti_fraud_max_order_attempt_time_span">
					<?php
					echo wp_kses_post( $settings_fileds['wc_settings_anti_fraud_max_order_attempt_time_span']['name'] );
					$description = WC_Admin_Settings::get_field_description( $settings_fileds['wc_settings_anti_fraud_max_order_attempt_time_span'] );
					echo wp_kses_post( $description['tooltip_html'] );
					?>
                </label>
            </th>
            <td class="forminp forminp-number">
                <input name="wc_settings_anti_fraud_max_order_attempt_time_span" id="wc_settings_anti_fraud_max_order_attempt_time_span" type="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_max_order_attempt_time_span']['type'] ); ?>" style="display: block; width: 5em;" value="<?php echo esc_attr( get_option( 'wc_settings_anti_fraud_max_order_attempt_time_span' ) ); ?>" min="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_max_order_attempt_time_span']['custom_attributes']['min'] ); ?>" step="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_max_order_attempt_time_span']['custom_attributes']['step'] ); ?>">
            </td>
        </tr>

        <tr valign="top">
            <td colspan="2">
                <hr/>
            </td>
        </tr>
        <tr valign="top" class="">
            <th scope="row" class="titledesc">
                <label for="wc_af_order_payment_attempt_check">
					<?php echo wp_kses_post( $settings_fileds['wc_af_order_payment_attempt_check']['title'] ); ?>
                    <span class="woocommerce-help-tip" data-tip="<?php echo wp_kses_post( $settings_fileds['wc_af_order_payment_attempt_check']['desc_tip'] ); ?>"></span>
                </label>
            </th>
            <td class="forminp forminp-checkbox">
                <fieldset>
                    <legend class="screen-reader-text"><span><?php echo wp_kses_post( $settings_fileds['wc_af_order_payment_attempt_check']['title'] ); ?></span></legend>
                    <label for="wc_af_order_payment_attempt_check" class="opmc-toggle-control">
                        <input name="wc_af_order_payment_attempt_check" id="wc_af_order_payment_attempt_check" type="checkbox" value="1" <?php checked( get_option( 'wc_af_order_payment_attempt_check' ), 'yes' ); ?> >
                        <span class="opmc-control"></span>
                    </label>
                </fieldset>
            </td>
        </tr>

        <tr valign="top" class="">
            <th scope="row" class="titledesc">
                <label for="wc_settings_anti_fraud_max_order_payment_attempt">
					<?php
					echo wp_kses_post( $settings_fileds['wc_settings_anti_fraud_max_order_payment_attempt']['name'] );
					$description = WC_Admin_Settings::get_field_description( $settings_fileds['wc_settings_anti_fraud_max_order_payment_attempt'] );
					echo wp_kses_post( $description['tooltip_html'] );
					?>
                </label>
            </th>
            <td class="forminp forminp-number">
                <input name="wc_settings_anti_fraud_max_order_payment_attempt" id="wc_settings_anti_fraud_max_order_payment_attempt" type="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_max_order_payment_attempt']['type'] ); ?>" style="display: block; width: 5em;" value="<?php echo esc_attr( get_option( 'wc_settings_anti_fraud_max_order_payment_attempt' ) ); ?>" min="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_max_order_payment_attempt']['custom_attributes']['min'] ); ?>" step="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_max_order_payment_attempt']['custom_attributes']['step'] ); ?>">
            </td>
        </tr>


        <tr valign="top">
            <td colspan="2">
                <hr/>
            </td>
        </tr>

        <tr valign="top" class="">
            <th scope="row" class="titledesc">
                <label for="wc_af_limit_order_count">
					<?php echo wp_kses_post( $settings_fileds['wc_af_limit_order_count']['title'] ); ?>
                    <span class="woocommerce-help-tip" data-tip="<?php echo esc_attr( $settings_fileds['wc_af_limit_order_count']['desc_tip'] ); ?>"></span>
                </label>
            </th>
            <td class="forminp forminp-checkbox">
                <fieldset>
                    <legend class="screen-reader-text"><span><?php echo wp_kses_post( $settings_fileds['wc_af_limit_order_count']['title'] ); ?></span></legend>
                    <label for="wc_af_limit_order_count" class="opmc-toggle-control">
                        <input name="wc_af_limit_order_count" id="wc_af_limit_order_count" type="checkbox" value="1" <?php checked( get_option( 'wc_af_limit_order_count' ), 'yes' ); ?> >
                        <span class="opmc-control"></span>
                    </label>
                </fieldset>
            </td>
        </tr>
        <tr valign="top" class="">
            <th scope="row" class="titledesc">
                <label for="wc_af_limit_time_start">
					<?php
					echo wp_kses_post( $settings_fileds['wc_af_limit_time_start']['name'] );
					$description = WC_Admin_Settings::get_field_description( $settings_fileds['wc_af_limit_time_start'] );
					echo wp_kses_post( $description['tooltip_html'] );
					?>
                </label>
            </th>
            <td class="forminp forminp-time">
                <input name="wc_af_limit_time_start" id="wc_af_limit_time_start" type="<?php echo esc_attr( $settings_fileds['wc_af_limit_time_start']['type'] ); ?>" style="<?php echo esc_attr( $settings_fileds['wc_af_limit_time_start']['css'] ); ?>" value="<?php echo esc_attr( get_option( 'wc_af_limit_time_start' ) ); ?>">
            </td>
        </tr>

        <tr valign="top" class="">
            <th scope="row" class="titledesc">
                <label for="wc_af_limit_time_end">
					<?php
					echo wp_kses_post( $settings_fileds['wc_af_limit_time_end']['name'] );
					$description = WC_Admin_Settings::get_field_description( $settings_fileds['wc_af_limit_time_end'] );
					echo wp_kses_post( $description['tooltip_html'] );
					?>
                </label>
            </th>
            <td class="forminp forminp-number">
                <input name="wc_af_limit_time_end" id="wc_af_limit_time_end" type="<?php echo esc_attr( $settings_fileds['wc_af_limit_time_end']['type'] ); ?>" style="<?php echo esc_attr( $settings_fileds['wc_af_limit_time_start']['css'] ); ?>" value="<?php echo esc_attr( get_option( 'wc_af_limit_time_end' ) ); ?>">
            </td>
        </tr>
        <tr valign="top" class="">
            <th scope="row" class="titledesc">
                <label for="wc_af_allowed_order_limit">
					<?php
					echo wp_kses_post( $settings_fileds['wc_af_allowed_order_limit']['name'] );
					$description = WC_Admin_Settings::get_field_description( $settings_fileds['wc_af_allowed_order_limit'] );
					echo wp_kses_post( $description['tooltip_html'] );
					?>
                </label>
            </th>
            <td class="forminp forminp-number">
                <input name="wc_af_allowed_order_limit" id="wc_af_allowed_order_limit" type="<?php echo esc_attr( $settings_fileds['wc_af_allowed_order_limit']['type'] ); ?>" style="display: block; width: 5em;" value="<?php echo esc_attr( get_option( 'wc_af_allowed_order_limit' ) ); ?>" min="<?php echo esc_attr( $settings_fileds['wc_af_allowed_order_limit']['custom_attributes']['min'] ); ?>" step="<?php echo esc_attr( $settings_fileds['wc_af_allowed_order_limit']['custom_attributes']['step'] ); ?>">
            </td>
        </tr>
        <tr valign="top">
            <td colspan="2">
                <hr/>
            </td>
        </tr>

        </tbody>

        </table>
    </section>

<?php elseif ( 'email_alert' == $current_section ) : ?>
    <section>

        <h2>Email Alerts</h2>
        <div id="<?php echo esc_attr( $this->id . '_email_alert_settings-description' ); ?>">
			<?php echo wp_kses_post( $settings_fileds[ $this->id . '_email_alert_settings' ]['desc'] ); ?>
        </div>


        <table class="form-table opmc_wc_af_table">
            <tbody>
            <tr valign="top" class="">
                <th scope="row" class="titledesc">
                    <label for="wc_af_email_notification">
						<?php echo wp_kses_post( $settings_fileds['wc_af_email_notification']['title'] ); ?>
                        <span class="woocommerce-help-tip" data-tip="<?php echo esc_attr( $settings_fileds['wc_af_email_notification']['desc_tip'] ); ?>"></span>
                    </label>
                </th>
                <td class="forminp forminp-checkbox">
                    <fieldset>
                        <legend class="screen-reader-text"><span><?php echo esc_attr( $settings_fileds['wc_af_email_notification']['title'] ); ?></span></legend>
                        <label for="wc_af_email_notification" class="opmc-toggle-control">
                            <input name="wc_af_email_notification" id="wc_af_email_notification" type="checkbox" value="1" <?php checked( get_option( 'wc_af_email_notification' ), 'yes' ); ?> >
                            <span class="opmc-control"></span>
                        </label>
                    </fieldset>
                </td>
            </tr>
            <tr valign="top">
                <th scope="row" class="titledesc">
                    <label for="wc_settings_anti_fraud_custom_email">
						<?php
						echo wp_kses_post( $settings_fileds['wc_settings_anti_fraud_custom_email']['name'] );
						$description = WC_Admin_Settings::get_field_description( $settings_fileds['wc_settings_anti_fraud_custom_email'] );
						echo wp_kses_post( $description['tooltip_html'] );
						?>
                    </label>
                </th>
                <td class="forminp forminp-textarea" colspan="3">
                    <textarea name="wc_settings_anti_fraud_custom_email" id="wc_settings_anti_fraud_custom_email" style="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_custom_email']['css'] ); ?>" class="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraud_custom_email']['class'] ); ?>"><?php echo esc_html( get_option( 'wc_settings_anti_fraud_custom_email' ) ); ?></textarea>
                </td>
            </tr>
            <tr valign="top">
                <th scope="row" class="titledesc">
                    <label for="wc_settings_anti_fraud_email_score">
						<?php
						echo wp_kses_post( $settings_fileds['wc_settings_anti_fraud_email_score']['name'] );
						$description = WC_Admin_Settings::get_field_description( $settings_fileds['wc_settings_anti_fraud_email_score'] );
						echo wp_kses_post( $description['tooltip_html'] );
						?>
                    </label>
                </th>
                <td class="forminp forminp-select">
                    <select name="wc_settings_anti_fraud_email_score" id="wc_settings_anti_fraud_email_score" style="display: block; width: 5em;" class="">
						<?php foreach ( $settings_fileds['wc_settings_anti_fraud_email_score']['options'] as $option_key_inner => $option_value_inner ) : ?>
                            <option value="<?php echo esc_attr( $option_key_inner ); ?>" <?php selected( (string) $option_key_inner, esc_attr( get_option( 'wc_settings_anti_fraud_email_score' ) ) ); ?>><?php echo esc_html( $option_value_inner ); ?></option>
						<?php endforeach ?>
                    </select>
                </td>
                <td class="forminp forminp-slider" colspan="2">
					<?php $this->opmc_score_slider( get_option( 'wc_settings_anti_fraud_email_score' ) ); ?>
                </td>
            </tr>

            </tbody>
        </table>
    </section>
<?php elseif ( 'black_list' == $current_section ) : ?>
    <section>
        <h2>Blacklist</h2>
        <div id="<?php echo esc_attr( $this->id . '_blacklist_settings-description' ); ?>">
			<?php echo wp_kses_post( $settings_fileds[ $this->id . '_blacklist_settings' ]['desc'] ); ?>
        </div>
        <hr/>
		<?php $this->opmc_add_admin_field_section( $settings_fileds[ $this->id . '_sub_blacklist_settings' ] ); ?>
        <table class="form-table opmc_wc_af_table">
            <tbody>
            <tr valign="top" class="">
                <th scope="row" class="titledesc">
                    <label for="wc_af_email_blacklist">
						<?php echo wp_kses_post( $settings_fileds['wc_settings_anti_fraudenable_automatic_email_blacklist']['title'] ); ?>
                        <span class="woocommerce-help-tip" data-tip="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraudenable_automatic_email_blacklist']['desc_tip'] ); ?>"></span>
                    </label>
                </th>
                <td class="forminp forminp-checkbox">
                    <fieldset>
                        <legend class="screen-reader-text"><span><?php echo esc_attr( $settings_fileds['wc_settings_anti_fraudenable_automatic_email_blacklist']['title'] ); ?></span></legend>
                        <label for="wc_settings_anti_fraudenable_automatic_email_blacklist" class="opmc-toggle-control">
                            <input name="wc_settings_anti_fraudenable_automatic_email_blacklist" id="wc_settings_anti_fraudenable_automatic_email_blacklist" type="checkbox" value="1" <?php checked( get_option( 'wc_settings_anti_fraudenable_automatic_email_blacklist' ), 'yes' ); ?> >
                            <span class="opmc-control"></span>
                        </label>
                    </fieldset>
                </td>
            </tr>

            <tr valign="top" class="">
                <th scope="row" class="titledesc">
                    <label for="wc_af_automatic_blacklist">
						<?php echo wp_kses_post( $settings_fileds['wc_settings_anti_fraudenable_automatic_blacklist']['title'] ); ?>
                        <span class="woocommerce-help-tip" data-tip="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraudenable_automatic_blacklist']['desc_tip'] ); ?>"></span>
                    </label>
                </th>
                <td class="forminp forminp-checkbox">
                    <fieldset>
                        <legend class="screen-reader-text"><span><?php echo esc_attr( $settings_fileds['wc_settings_anti_fraudenable_automatic_blacklist']['title'] ); ?></span></legend>
                        <label for="wc_settings_anti_fraudenable_automatic_blacklist" class="opmc-toggle-control">
                            <input name="wc_settings_anti_fraudenable_automatic_blacklist" id="wc_settings_anti_fraudenable_automatic_blacklist" type="checkbox" value="1" <?php checked( get_option( 'wc_settings_anti_fraudenable_automatic_blacklist' ), 'yes' ); ?> >
                            <span class="opmc-control"></span>
                        </label>
                    </fieldset>
                </td>
            </tr>
            <tr valign="top">
                <th scope="row" class="titledesc">
                    <label for="wc_settings_anti_fraudblacklist_emails">
						<?php
						echo wp_kses_post( $settings_fileds['wc_settings_anti_fraudblacklist_emails']['name'] );
						$description = WC_Admin_Settings::get_field_description( $settings_fileds['wc_settings_anti_fraudblacklist_emails'] );
						echo wp_kses_post( $description['tooltip_html'] );
						?>
                    </label>
                </th>
                <td class="forminp forminp-textarea" colspan="3">
                    <textarea name="wc_settings_anti_fraudblacklist_emails" id="wc_settings_anti_fraudblacklist_emails" style="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraudblacklist_emails']['css'] ); ?>" class="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraudblacklist_emails']['class'] ); ?>"><?php echo esc_html( get_option( 'wc_settings_anti_fraudblacklist_emails' ) ); ?></textarea>
                </td>
            </tr>


            </tbody>
        </table>

		<?php $this->opmc_add_admin_field_section( $settings_fileds[ $this->id . '_sub_ip_blacklist_settings' ] ); ?>
        <table class="form-table opmc_wc_af_table">
            <tbody>
            <tr valign="top" class="">
                <th scope="row" class="titledesc">
                    <label for="wc_af_ip_blacklist">
						<?php echo wp_kses_post( $settings_fileds['wc_settings_anti_fraudenable_automatic_ip_blacklist']['title'] ); ?>
                        <span class="woocommerce-help-tip" data-tip="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraudenable_automatic_ip_blacklist']['desc_tip'] ); ?>"></span>
                    </label>
                </th>
                <td class="forminp forminp-checkbox">
                    <fieldset>
                        <legend class="screen-reader-text"><span><?php echo esc_attr( $settings_fileds['wc_settings_anti_fraudenable_automatic_ip_blacklist']['title'] ); ?></span></legend>
                        <label for="wc_settings_anti_fraudenable_automatic_ip_blacklist" class="opmc-toggle-control">
                            <input name="wc_settings_anti_fraudenable_automatic_ip_blacklist" id="wc_settings_anti_fraudenable_automatic_ip_blacklist" type="checkbox" value="1" <?php checked( get_option( 'wc_settings_anti_fraudenable_automatic_ip_blacklist' ), 'yes' ); ?> >
                            <span class="opmc-control"></span>
                        </label>
                    </fieldset>
                </td>
            </tr>

            <tr valign="top">
                <th scope="row" class="titledesc">
                    <label for="wc_settings_anti_fraudblacklist_ipaddress">
						<?php
						echo wp_kses_post( $settings_fileds['wc_settings_anti_fraudblacklist_ipaddress']['name'] );
						$description = WC_Admin_Settings::get_field_description( $settings_fileds['wc_settings_anti_fraudblacklist_ipaddress'] );
						echo wp_kses_post( $description['tooltip_html'] );
						?>
                    </label>
                </th>
                <td class="forminp forminp-textarea" colspan="3">
                    <textarea name="wc_settings_anti_fraudblacklist_ipaddress" id="wc_settings_anti_fraud_blacklist_ipaddress" style="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraudblacklist_ipaddress']['css'] ); ?>" class="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraudblacklist_ipaddress']['class'] ); ?>"><?php echo esc_html( get_option( 'wc_settings_anti_fraudblacklist_ipaddress' ) ); ?></textarea>
                </td>
            </tr>
            </tbody>
        </table>
    </section>
<?php elseif ( 'minfraud_recaptcha_settings' == $current_section ) : ?>
    <section>
        <h2>Google reCAPTCHA Settings</h2>
        <div id="<?php echo esc_attr( $this->id . '_recaptch_settings-description' ); ?>">
			<?php echo wp_kses_post( $settings_fileds[ $this->id . '_recaptch_settings' ]['desc'] ); ?>
        </div>

		<?php //$this->opmc_add_admin_field_section( $settings_fileds[ $this->id . '_sub_blacklist_settings' ] ); ?>
		<?php $enable_recaptcha = get_option( 'wc_settings_anti_fraudenable_enable_recaptcha', 'no' ); ?>
        <table class="form-table opmc_wc_af_table">
            <tbody>
            <tr valign="top" class="">
                <th scope="row" class="titledesc">
                    <label for="wc_af_enable_recaptcha">
						<?php echo wp_kses_post( $settings_fileds['wc_settings_anti_fraudenable_enable_recaptcha']['title'] ); ?>
                        <span class="woocommerce-help-tip" data-tip="<?php echo esc_attr( $settings_fileds['wc_settings_anti_fraudenable_enable_recaptcha']['desc_tip'] ); ?>"></span>
                    </label>
                </th>
                <td class="forminp forminp-checkbox">
                    <fieldset>
                        <legend class="screen-reader-text"><span><?php echo esc_attr( $settings_fileds['wc_settings_anti_fraudenable_enable_recaptcha']['title'] ); ?></span></legend>
                        <label for="wc_settings_anti_fraudenable_enable_recaptcha" class="opmc-toggle-control">
                            <input name="wc_settings_anti_fraudenable_enable_recaptcha" id="wc_settings_anti_fraudenable_enable_recaptcha" type="checkbox" value="1" <?php checked( $enable_recaptcha, 'yes' ); ?> >
                            <span class="opmc-control"></span>
                        </label>
                    </fieldset>
                </td>
            </tr>

            <tr valign="top" class="<?php echo $enable_recaptcha !== 'yes' ? 'no-display' : ''; ?>">
                <th scope="row" class="titledesc">
                    <label for="wc_af_recaptcha_site_key">
						<?php
						echo wp_kses_post( $settings_fileds['wc_af_recaptcha_site_key']['title'] );
						$description = WC_Admin_Settings::get_field_description( $settings_fileds['wc_af_recaptcha_site_key'] );
						echo wp_kses_post( $description['tooltip_html'] );
						?>
                    </label>
                </th>
                <td class="forminp forminp-text" colspan="3">
                    <input name="wc_af_recaptcha_site_key" id="wc_af_recaptcha_site_key" type="<?php echo esc_attr( $settings_fileds['wc_af_recaptcha_site_key']['type'] ); ?>" value="<?php echo esc_attr( get_option( 'wc_af_recaptcha_site_key' ) ); ?>">
					<?php echo wp_kses_post( $description['description'] ); ?>
                </td>
            </tr>
            <tr valign="top" class="<?php echo $enable_recaptcha !== 'yes' ? 'no-display' : ''; ?>">
                <th scope="row" class="titledesc">
                    <label for="wc_af_recaptcha_secret_key">
						<?php
						echo wp_kses_post( $settings_fileds['wc_af_recaptcha_secret_key']['title'] );
						$description = WC_Admin_Settings::get_field_description( $settings_fileds['wc_af_recaptcha_secret_key'] );
						echo wp_kses_post( $description['tooltip_html'] );
						?>
                    </label>
                </th>
                <td class="forminp forminp-text" colspan="3">
                    <input name="wc_af_recaptcha_secret_key" id="wc_af_recaptcha_secret_key" type="<?php echo esc_attr( $settings_fileds['wc_af_recaptcha_secret_key']['type'] ); ?>" value="<?php echo esc_attr( get_option( 'wc_af_recaptcha_secret_key' ) ); ?>">
					<?php echo wp_kses_post( $description['description'] ); ?>
                </td>
            </tr>
            </tbody>
        </table>
    </section>
<?php else : ?>

	<?php WC_Admin_Settings::output_fields( $settings ); ?>

<?php endif; ?>
