<?php // BBQ Pro - License & Activation

if (!defined('ABSPATH')) exit;

if (!class_exists('EDD_SL_Plugin_Updater')) {
	
	include(BBQ_PRO_DIR .'updates/bbq-updater.php');
	
}



function bbq_plugin_updater() {
	
	if (!current_user_can('manage_options') && !wp_doing_cron()) return;
	
	$license_key = trim(get_option('bbq_license_key'));
	
	$license_key = (defined('BBQ_PRO_LICENSE') && BBQ_PRO_LICENSE) ? BBQ_PRO_LICENSE : $license_key;
	
	$edd_updater = new EDD_SL_Plugin_Updater(
		
		BBQ_PRO_HOME, 
		BBQ_PRO_FILE, 
		array(
			'license'   => $license_key,
			'item_name' => BBQ_PRO_NAME,
			'author'    => BBQ_PRO_AUTHOR,
			'version'   => BBQ_PRO_VERSION,
			'url'       => BBQ_PRO_HOME,
			'beta'		=> false
			
		)
		
	);
	
}
add_action('admin_init', 'bbq_plugin_updater', 0);



function bbq_display_license() {
	
	$license = trim(get_option('bbq_license_key'));
	
	$license_constant = (defined('BBQ_PRO_LICENSE') && BBQ_PRO_LICENSE) ? BBQ_PRO_LICENSE : null;
	
	$status = get_option('bbq_license_status');
	
	$status_constant = get_option('bbq_license_constant');
	
	?>
	
	<div class="wrap">
		
		<h1 class="bbq-title"><?php esc_html_e('BBQ Pro', 'bbq-pro'); ?> <span><?php echo BBQ_PRO_VERSION; ?></span></h1>
		
		<?php $heading = ($license_constant) ? __('License Status', 'bbq-pro') : __('Activate License', 'bbq-pro'); ?>
		
		<h2><?php echo esc_html($heading); ?></h2>
		
		<p>
			<?php
				echo '<a target="_blank" rel="noopener noreferrer" href="https://plugin-planet.com/activate-deactivate-plugin-license/">';
				echo esc_html__('Activate your license', 'bbq-pro') .'</a> ';
				echo esc_html__('to enable BBQ Pro, 1-click updates, and plugin support. Visit the Help tab for more infos.', 'bbq-pro');
			?>
		</p>
		
		<form method="post" action="options.php">
			
			<?php settings_fields('bbq_license_settings'); ?>
			
			<?php if ($license_constant) : ?>
				
				<?php $class = ($status_constant === 'active') ? 'bbq-license-status-activated' : 'bbq-license-status-deactivated'; ?>
				
				<p><?php esc_html_e('License key added via', 'bbq-pro'); ?> <code class="code-small">wp-config.php</code></p>
				<p><?php esc_html_e('Status:', 'bbq-pro'); ?> <span class="bbq-license-constant <?php echo $class; ?>"><?php echo esc_html($status_constant); ?></span></p>
				
			<?php else : ?>
				
				<?php if (bbq_check_license()) : ?>
					
					<p>
						<?php echo bbq_obfuscate_password($license); ?>
						<label class="bbq-license-label bbq-license-status-activated"><span class="emoji">✅</span> <?php esc_html_e('Your BBQ Pro License is active.', 'bbq-pro'); ?></label>
					</p>
					<p>
						<input type="submit" class="button button-primary" value="<?php esc_attr_e('Deactivate License', 'bbq-pro'); ?>">
						<input type="hidden" name="bbq_license_key" value="<?php echo esc_attr($license); ?>">
						<?php wp_nonce_field('bbq_license_deactivate', 'bbq_license_deactivate'); ?>
					</p>
					
				<?php else : ?>
					
					<?php if (empty($license)) : ?>
						
						<p>
							<input type="password" class="bbq-license-input regular-text" id="bbq_license_key" name="bbq_license_key" value="<?php echo esc_attr($license); ?>">
							<?php echo bbq_reveal_password(); ?>
							<label class="bbq-license-label" for="bbq_license_key"><?php esc_html_e('Enter your License Key', 'bbq-pro'); ?></label>
						</p>
						<p>
							<input type="submit" class="button button-primary" value="<?php esc_attr_e('Save License', 'bbq-pro'); ?>">
							<?php wp_nonce_field('bbq_license_save', 'bbq_license_save'); ?>
						</p>
						
					<?php else : ?>
						
						<p>
							<input type="password" class="bbq-license-input regular-text" id="bbq_license_key" name="bbq_license_key" value="<?php echo esc_attr($license); ?>"> 
							<?php echo bbq_clear_license_link(); ?>
							<label class="bbq-license-label bbq-license-status-deactivated" for="bbq_license_key"><?php esc_html_e('Your license is inactive. Click the button to activate.', 'bbq-pro'); ?></label>
						</p>
						<p>
							<input type="submit" class="button button-primary" value="<?php esc_attr_e('Activate License', 'bbq-pro'); ?>">
							<?php wp_nonce_field('bbq_license_activate', 'bbq_license_activate'); ?>
						</p>
						
					<?php endif; ?>
					
				<?php endif; ?>
				
			<?php endif; ?>
			
		</form>
		
	</div>
	
	<?php
	
}



function bbq_license_register_option() {
	
	register_setting('bbq_license_settings', 'bbq_license_key', 'bbq_sanitize_option');
}
add_action('admin_init', 'bbq_license_register_option');



function bbq_sanitize_option($new) {
	
	$old = trim(get_option('bbq_license_key'));
	
	if ($old && $old != $new) delete_option('bbq_license_status');
	
	return $new;
}



function bbq_obfuscate_password($string) {
	
	$output = '';
	
	$length = strlen($string);
	
	$password = str_repeat('*', $length);
	
	$output = '<code class="bbq-license-key">'. esc_html($password) .'</code>';
	
	return $output;
	
}



function bbq_reveal_password() {
	
	$title = esc_html__('Show License', 'bbq-pro');
	
	return '<a class="bbq-reveal-password" href="#bbq-reveal-password" data-type="password" title="'. $title .'"><span class="fa fa-eye"></span></a>';
	
}



function bbq_check_license() {
		
	$status = get_option('bbq_license_status');
	
	$status_constant = get_option('bbq_license_constant');
	
	if ($status === 'valid' || $status_constant === 'active') return true;
	
	return false;
	
}



function bbq_license_status() {
	return;
	
	$output = '';
	
	$local = apply_filters('bbq_license_status_local', false);
	
	if (!bbq_check_license() && !$local) {
		
		$output .= '<p class="bbq-license-status">❗ ';
		
		$output .= esc_html__('Your BBQ Pro license is not active.', 'bbq-pro');
		
		$output .= ' <a href="'. esc_url(admin_url('admin.php?page=bbq_license')) .'">'. esc_html__('Activate your license', 'bbq-pro') .'</a> ';
		
		$output .= esc_html__('to enable plugin updates and support.', 'bbq-pro');
		
		$output .= '</p>';
		
	}
	
	return $output;
	
}



function bbq_get_server_response($action, $license_key = '') {
	
	$license_key = $license_key ? $license_key : get_option('bbq_license_key');
	
	$params = array('edd_action' => $action, 'license' => trim($license_key), 'item_name' => urlencode(BBQ_PRO_NAME), 'url' => home_url());
	
	return wp_remote_get(BBQ_PRO_HOME, array('timeout' => 15, 'sslverify' => false, 'body' => $params));
	
}



function bbq_check_server_response($action, $license, $response) {
	
	if (empty($license)) return array(__('Home server not available.', 'bbq-pro'), 'server_not_available');
	
	$error   = property_exists($license, 'error')   ? $license->error   : null;
	$expires = property_exists($license, 'expires') ? $license->expires : 'now';
	$success = property_exists($license, 'success') ? $license->success : false;
	$status  = property_exists($license, 'license') ? $license->license : false;
	
	$message = __('Unknown error.', 'bbq-pro');
	
	if (wp_remote_retrieve_response_code($response) !== 200) {
		
		$message = __('Error making remote request. Please try again or contact Plugin Planet for help.', 'bbq-pro');
		
	} elseif (is_wp_error($response)) {
		
		$message = $response->get_error_message() .'.';
		
	} else {
		
		if ($error) {
			
			$message = bbq_license_error_message($error, $expires);
			
		} elseif ($success && $status) {
			
			if (
				($action === 'check_license'      && $status === 'valid') || 
				($action === 'activate_license'   && $status === 'valid') ||
				($action === 'deactivate_license' && $status === 'deactivated')
			) {
				
				$message = ''; // no error message
				
			} else {
				
				$message = bbq_license_status_message($status, $expires);
				
			}
			
		} else {
			
			$message = bbq_license_status_message($status, $expires);
			
		}
		
	}
	
	return array($message, $status);
	
}



function bbq_redirect_server_response($action, $message, $status, $updated) {
	
	if (
		($action === 'activate_license'   && $status === 'valid') ||
		($action === 'deactivate_license' && $status === 'deactivated')
	) {
		
		$result = $updated ? 'true' : 'false';
		
	} else {
		
		$result = 'false';
	}
	
	$params = array($action => $result, 'license-response' => urlencode($message), 'license-status' => $status);
	
	$path = admin_url('admin.php?page=bbq_license');
	
	$location = add_query_arg($params, $path);
	
	wp_redirect($location);
	
	exit;
	
}



function bbq_test_license() {
	
	if (get_transient('bbq_test_license') === false) {
		
		$action = 'check_license';
		
		$response = bbq_get_server_response($action);
		
		$license = json_decode(wp_remote_retrieve_body($response));
		
		list ($message, $status) = bbq_check_server_response($action, $license, $response);
		
		if (empty($message)) {
			
			$message = __('BBQ Pro license test result: ', 'bbq-pro') . $status;
			
		}
		
		update_option('bbq_license_status', $status);
		
		set_transient('bbq_test_license', $status, DAY_IN_SECONDS);
		
		// error_log($message); // testing
		
	}
	
}
add_action('admin_init', 'bbq_test_license');



function bbq_activate_license() {
	
	if (isset($_POST['bbq_license_activate']) && wp_verify_nonce($_POST['bbq_license_activate'], 'bbq_license_activate')) {
		
		if (!current_user_can('manage_options')) return;
		
		$updated = false;
		
		$action = 'activate_license';
		
		$response = bbq_get_server_response($action);
		
		$license = json_decode(wp_remote_retrieve_body($response));
		
		list ($message, $status) = bbq_check_server_response($action, $license, $response);
		
		if (empty($message) && $status === 'valid') {
			
			$message = __('License activated.', 'bbq-pro');
			
			$updated = update_option('bbq_license_status', $status);
			
		}
		
		bbq_redirect_server_response($action, $message, $status, $updated);
		
	}
	
}
add_action('admin_init', 'bbq_activate_license');



function bbq_deactivate_license() {
	
	if (isset($_POST['bbq_license_deactivate']) && wp_verify_nonce($_POST['bbq_license_deactivate'], 'bbq_license_deactivate')) {
		
		if (!current_user_can('manage_options')) return;
		
		$updated = false;
		
		$action = 'deactivate_license';
		
		$response = bbq_get_server_response($action);
		
		$license = json_decode(wp_remote_retrieve_body($response));
		
		list ($message, $status) = bbq_check_server_response($action, $license, $response);
		
		if (empty($message) && $status === 'deactivated') {
			
			$message = __('License deactivated.', 'bbq-pro');
			
			$updated = delete_option('bbq_license_status');
			
		}
		
		bbq_redirect_server_response($action, $message, $status, $updated);
		
	}
	
}
add_action('admin_init', 'bbq_deactivate_license');



function bbq_config_constant_activate() {
	
	if (bbq_get_current_screen_id() !== 'bbq-pro_page_bbq_license') return;
	
	if (isset($_POST['bbq_license_activate']) || isset($_POST['bbq_license_deactivate'])) return;
	
	if (isset($_GET['activate_license']) || isset($_GET['deactivate_license']) || isset($_GET['clear-license'])) return;
	
	if (!current_user_can('manage_options')) return;
	
	$license_key = (defined('BBQ_PRO_LICENSE') && BBQ_PRO_LICENSE) ? BBQ_PRO_LICENSE : null;
	
	if (empty($license_key)) {
		
		$updated = update_option('bbq_license_constant', 'inactive');
		
		$log = __('BBQ Pro license wp-config constant not defined', 'bbq-pro');
		
	} else {
		
		$action = $license_key ? 'activate_license' : 'deactivate_license';
		
		$response = bbq_get_server_response($action, $license_key);
		
		$license = json_decode(wp_remote_retrieve_body($response));
		
		list ($message, $status) = bbq_check_server_response($action, $license, $response);
		
		if ($message) { // error
			
			$updated = update_option('bbq_license_constant', 'inactive');
			
			$log = __('BBQ Pro', 'bbq-pro') .' '. $action .' '. __('failed due to error:', 'bbq-pro') .' '. $message;
			
		} else { // success
			
			if ($status === 'valid') {
				
				$updated = update_option('bbq_license_constant', 'active');
				
				$log = __('BBQ Pro license activated via wp-config constant', 'bbq-pro');
				
			} elseif ($status === 'deactivated') {
				
				$updated = update_option('bbq_license_constant', 'inactive');
				
				$log = __('BBQ Pro license deactivated via removed wp-config constant', 'bbq-pro');
				
			} else {
				
				$updated = update_option('bbq_license_constant', 'inactive');
				
				$log = __('BBQ Pro', 'bbq-pro') .' '. $action .' '. __('failed due to error', 'bbq-pro');
				
			}
			
		}
		
	}
	
	// if ($log) error_log($log); // testing
	
}
add_action('current_screen', 'bbq_config_constant_activate');



function bbq_clear_license_link() {
	
	$nonce = wp_create_nonce('bbq_license_clear');
	
	$href  = esc_url(add_query_arg(array('bbq_license_clear' => $nonce), admin_url('admin.php?page=bbq_license')));
	
	$title = esc_html__('Clear license field', 'bbq-pro');
	
	$label = '&#10005;';
	
	return '<a class="bbq-license-clear" href="'. $href .'" title="'. $title .'">'. $label .'</a>';
	
}



function bbq_clear_license() {
	
	if (isset($_GET['bbq_license_clear']) && wp_verify_nonce($_GET['bbq_license_clear'], 'bbq_license_clear')) {
		
		if (!current_user_can('manage_options')) return;
		
		$delete_key    = delete_option('bbq_license_key');
		
		$delete_status = delete_option('bbq_license_status');
		
		$result = ($delete_key) ? 'true' : 'false';
		
		$location = admin_url('admin.php?page=bbq_license&clear-license='. $result);
		
		wp_redirect($location);
		
		exit;
		
	}
	
}
add_action('admin_init', 'bbq_clear_license');



function bbq_license_admin_notice() {
	
	if (bbq_get_current_screen_id() === 'bbq-pro_page_bbq_license') {
		
		$response = isset($_GET['license-response']) ? urldecode($_GET['license-response']) : __('Undefined response.', 'bbq-pro');
		
		$response .= ' <a target="_blank" rel="noopener noreferrer" href="'. esc_url(BBQ_PRO_HOME .'/support/') .'">'. esc_html__('Get help&nbsp;&raquo;', 'bbq-pro') .'</a>';
		
		if (isset($_GET['activate_license'])) {
			
			if ($_GET['activate_license'] === 'true') : ?>
				
				<div class="notice notice-success is-dismissible"><p><strong><?php esc_html_e('License activated.', 'bbq-pro'); ?></strong></p></div>
				
			<?php else : ?>
				
				<div class="notice notice-warning is-dismissible"><p><strong><?php echo esc_html__('License not activated:', 'bbq-pro') .' '. $response; ?></strong></p></div>
				
			<?php endif;
			
		} elseif (isset($_GET['deactivate_license'])) {
			
			if ($_GET['deactivate_license'] === 'true') : ?>
				
				<div class="notice notice-success is-dismissible"><p><strong><?php esc_html_e('License deactivated.', 'bbq-pro'); ?></strong></p></div>
				
			<?php else : ?>
				
				<div class="notice notice-warning is-dismissible"><p><strong><?php echo esc_html__('License not deactivated:', 'bbq-pro') .' '. $response; ?></strong></p></div>
				
			<?php endif;
			
		} elseif (isset($_GET['clear-license'])) {
			
			if ($_GET['clear-license'] === 'true') : ?>
				
				<div class="notice notice-success is-dismissible"><p><strong><?php esc_html_e('Done.', 'bbq-pro'); ?></strong></p></div>
				
			<?php else : ?>
				
				<div class="notice notice-info is-dismissible"><p><strong><?php esc_html_e('No changes made.', 'bbq-pro'); ?></strong></p></div>
				
			<?php endif;
			
		}
		
	}
	
}
add_action('admin_notices', 'bbq_license_admin_notice');



function bbq_license_error_message($error, $expires) {
	
	switch($error) {
		
		case 'invalid' :
		case 'missing' :
			
			$message = __('Invalid license key. Please double-check and try again.', 'bbq-pro');
			
			break;
			
		case 'disabled' :
		case 'revoked'  :
			
			$message = __('License key disabled. Contact Plugin Planet for help.', 'bbq-pro');
			
			break;
			
		case 'expired' :
			
			$expires = date_i18n(get_option('date_format'), strtotime($expires, current_time('timestamp')));
			
			$message = __('Your license expired on', 'bbq-pro') .' '. $expires .'. '. __('Renew your license for plugin updates and support.', 'bbq-pro');
			
			break;
			
		case 'no_activations_left':
			
			$message = __('Your license key has reached its activation limit.', 'bbq-pro');
			
			break;
			
		case 'site_inactive' :
			
			$message = __('Your license key is not active for this domain.', 'bbq-pro');
			
			break;
			
		default :
			
			$message = __('An error occurred, please try again.', 'bbq-pro');
			
			break;
		
	}
	
	return $message;
	
}



function bbq_license_status_message($status, $expires) {
	
	switch($status) {
		
		case 'invalid' :
			
			$message = $message = __('Invalid license key. Please double-check and try again.', 'bbq-pro');
			
			break;
			
		case 'disabled' :
			
			$message = $message = __('License key disabled. Contact Plugin Planet for help.', 'bbq-pro');
			
			break;
			
		case 'expired' :
			
			$expires = date_i18n(get_option('date_format'), strtotime($expires, current_time('timestamp')));
			
			$message = __('Your license expired on', 'bbq-pro') .' '. $expires .'. '. __('Renew your license for plugin updates and support.', 'bbq-pro');
			
			break;
			
		case 'failed' :
			
			$message = __('License key action failed. Contact Plugin Planet for help.', 'bbq-pro');
			
			break;
			
		default :
			
			$message = __('License key not valid for this plugin. Please double-check and try again.', 'bbq-pro');
			
			break;
		
	}
	
	return $message;
	
}