<?php
/*
	Plugin Name: BBQ Pro
	Plugin URI: https://plugin-planet.com/bbq-pro/
	Description: The fastest firewall plugin for WordPress. Advanced protection against a wide range of threats.
	Tags: firewall, security, web application firewall, waf
	Author: Jeff Starr
	Contributors: specialk
	Author URI: https://plugin-planet.com/
	Donate link: https://monzillamedia.com/donate.html
	Requires at least: 4.6
	Tested up to: 6.7
	Stable tag: 3.8
	Version:    3.8
	Requires PHP: 5.6.20
	Text Domain: bbq-pro
	Domain Path: /languages
	
	License: The BBQ Pro license is comprised of two parts:
	
		* Part 1: Its PHP code is licensed under the GPL (v2 or later), like WordPress. More info @ https://www.gnu.org/licenses/
	
		* Part 2: Everything else (e.g., CSS, HTML, JavaScript, images, design) is licensed according to the purchased license. More info @ https://plugin-planet.com/bbq-pro/
	
	Without prior written consent from Monzilla Media, you must NOT directly or indirectly: license, sub-license, sell, resell, or provide for free any aspect or component of Part 2.
	
	Further license information is available in the plugin directory, /license/, and online @ https://plugin-planet.com/wp/files/bbq-pro/license.txt
	
	Upgrades: Your purchase of BBQ Pro includes free lifetime upgrades, which include new features, bug fixes, and other improvements. 
	
	Copyright 2024 Monzilla Media. All rights reserved.
*/

if (!defined('ABSPATH')) exit;

if (!class_exists('BBQ_Pro')) {
	
	final class BBQ_Pro {
		
		private static $instance;
		
		public static function instance() {
			
			if (!isset(self::$instance) && !(self::$instance instanceof BBQ_Pro)) {
				
				self::$instance = new BBQ_Pro;
				self::$instance->constants();
				self::$instance->includes();
				
				register_activation_hook(__FILE__, 'bbq_dismiss_notice_activate');
				
				add_action('admin_init',          array(self::$instance, 'check_bbq'));
				add_action('admin_init',          array(self::$instance, 'check_version'));
				add_action('init',                array(self::$instance, 'load_i18n'));
				add_filter('admin_footer_text',   array(self::$instance, 'footer_text'),  10, 1);
				add_filter('plugin_action_links', array(self::$instance, 'action_links'), 10, 2);
				add_filter('plugin_row_meta',     array(self::$instance, 'plugin_links'), 10, 2);
				
				add_action('admin_enqueue_scripts', 'bbq_pro_enqueue_resources_admin');
				add_action('admin_print_scripts', 'bbq_print_js_vars_admin');
				
				add_action('admin_init', 'bbq_dismiss_notice_save');
				add_action('admin_init', 'bbq_dismiss_notice_version');
				add_action('admin_init', 'bbq_update_patterns');
				add_action('admin_init', 'bbq_pro_register_settings');
				add_action('admin_init', 'bbq_reset_defaults');
				add_action('admin_menu', 'bbq_menu_pages');
				
			}
			
			return self::$instance;
			
		}
		
		public static function options() {
			
			$ip_server = isset($_SERVER['SERVER_ADDR']) ? sanitize_text_field($_SERVER['SERVER_ADDR']) : '';
			$ip_remote = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field($_SERVER['REMOTE_ADDR']) : '';
			
			$admin_mail = get_bloginfo('admin_email');
			
			$bbq_options = array(
				
				'basic_rules'     => true,
				'advanced_rules'  => false,
				'custom_rules'    => false,
				'logged_users'    => false,
				'limit_request'   => false,
				'strict_mode'     => false,
				'send_alerts'     => false,
				'send_address'    => $admin_mail,
				'send_exclude'    => '',
				'redirect_url'    => '',
				'custom_message'  => '403 Forbidden',
				'status_code'     => '403 Forbidden',
				'remove_disabled' => false,
				'whitelist_ips'   => self::default_ips()
				
			);
			
			return apply_filters('bbq_options', $bbq_options);
			
		}
		
		public static function default_ips() {
			
			$ip_server = isset($_SERVER['SERVER_ADDR']) ? sanitize_text_field($_SERVER['SERVER_ADDR']) : '';
			$ip_remote = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field($_SERVER['REMOTE_ADDR']) : '';
			
			$ips = $ip_server .', '. $ip_remote;
			
			return apply_filters('bbq_default_ips', $ips);
			
		}
		
		public static function patterns() {
			
			require_once plugin_dir_path(__FILE__) .'inc/bbq-patterns.php';
			
			return apply_filters('bbq_patterns', bbq_patterns());
			
		}
		
		private function constants() {
			
			if (!defined('BBQ_PRO_REQUIRE')) define('BBQ_PRO_REQUIRE', '4.6');
			if (!defined('BBQ_PRO_VERSION')) define('BBQ_PRO_VERSION', '3.8');
			if (!defined('BBQ_PRO_NAME'))    define('BBQ_PRO_NAME',    'BBQ Pro');
			if (!defined('BBQ_PRO_AUTHOR'))  define('BBQ_PRO_AUTHOR',  'Jeff Starr');
			if (!defined('BBQ_PRO_HOME'))    define('BBQ_PRO_HOME',    'https://plugin-planet.com');
			if (!defined('BBQ_PRO_URL'))     define('BBQ_PRO_URL',     plugin_dir_url(__FILE__));
			if (!defined('BBQ_PRO_DIR'))     define('BBQ_PRO_DIR',     plugin_dir_path(__FILE__));
			if (!defined('BBQ_PRO_FILE'))    define('BBQ_PRO_FILE',    plugin_basename(__FILE__));
			if (!defined('BBQ_PRO_SLUG'))    define('BBQ_PRO_SLUG',    basename(dirname(__FILE__)));
			
		}
		
		private function includes() {
			
			require_once BBQ_PRO_DIR .'inc/enqueue-resources.php';
			require_once BBQ_PRO_DIR .'inc/register-settings.php';
			require_once BBQ_PRO_DIR .'inc/display-settings.php';
			require_once BBQ_PRO_DIR .'inc/display-patterns.php';
			require_once BBQ_PRO_DIR .'inc/display-tools.php';
			require_once BBQ_PRO_DIR .'updates/bbq-updates.php';
			require_once BBQ_PRO_DIR .'inc/contextual-help.php';
			require_once BBQ_PRO_DIR .'inc/status-codes.php';
			
		}
		
		function action_links($links, $file) {
			
			if ($file == BBQ_PRO_FILE && current_user_can('manage_options')) {
				
				$bbq_links = '<a href="'. get_admin_url() .'admin.php?page=bbq_settings">'. esc_html__('Settings', 'bbq-pro') .'</a>';
				
				array_unshift($links, $bbq_links);
				
			}
			
			return $links;
			
		}
		
		public function plugin_links($links, $file) {
			
			if ($file == BBQ_PRO_FILE) {
				
				$rate_url   = esc_url('https://wordpress.org/support/plugin/block-bad-queries/reviews/?rate=5#new-post');
				$rate_title = esc_attr__('Click here to rate and review this plugin at WordPress.org', 'bbq-pro');
				$rate_text  = esc_html__('Rate this plugin&nbsp;&raquo;', 'bbq-pro');
				
				$links[] = '<a target="_blank" rel="noopener noreferrer" href="'. $rate_url .'" title="'. $rate_title .'">'. $rate_text .'</a>';
				
			}
			
			return $links;
			
		}
		
		public function check_bbq() {
			
			if (function_exists('bbq_core')) {
				
				if (is_plugin_active('bbq-pro/bbq-pro.php')) {
					
					deactivate_plugins(BBQ_PRO_FILE);
					
					$msg  = '<strong>'. esc_html__('Warning:', 'bbq-pro') .'</strong> '. esc_html__('Free and Pro versions of BBQ cannot be activated at the same time. ', 'bbq-pro');
					$msg .= esc_html__('Please return to the', 'bbq-pro') .' <a href="'. admin_url('plugins.php') .'">'. esc_html__('WordPress Admin Area', 'bbq-pro') .'</a> '. esc_html__('and try again.', 'bbq-pro');
					
					wp_die($msg);
					
				}
				
			}
			
		}
		
		function footer_text($text) {
			
			$screen_id = bbq_get_current_screen_id();
			
			$ids = array('toplevel_page_bbq_settings', 'bbq-pro_page_bbq_patterns', 'bbq-pro_page_bbq_tools', 'bbq-pro_page_bbq_license');
			
			if ($screen_id && apply_filters('bbq_admin_footer_text', in_array($screen_id, $ids))) {
				
				$text = __('Like BBQ? Give it a', 'bbq-pro');
				
				$text .= ' <a target="_blank" rel="noopener noreferrer" href="https://wordpress.org/support/plugin/block-bad-queries/reviews/?rate=5#new-post">';
				
				$text .= __('★★★★★ rating&nbsp;&raquo;', 'bbq-pro') .'</a>';
				
			}
			
			return $text;
			
		}
		
		public function check_version() {
			
			$wp_version = get_bloginfo('version');
			
			if (isset($_GET['activate']) && $_GET['activate'] == 'true') {
				
				if (version_compare($wp_version, BBQ_PRO_REQUIRE, '<')) {
					
					if (is_plugin_active(BBQ_PRO_FILE)) {
						
						deactivate_plugins(BBQ_PRO_FILE);
						
						$msg  = '<strong>'. BBQ_PRO_NAME .'</strong> '. esc_html__('requires WordPress ', 'bbq-pro') . BBQ_PRO_REQUIRE . esc_html__(' or higher, and has been deactivated. ', 'bbq-pro');
						$msg .= esc_html__('Please return to the', 'bbq-pro') .' <a href="'. admin_url('update-core.php') .'">'. esc_html__('WP Admin Area', 'bbq-pro') .'</a> '. esc_html__('to upgrade WordPress and try again.', 'bbq-pro');
						
						wp_die($msg);
						
					}
					
				}
				
			}
			
		}
		
		public function load_i18n() {
			
			$domain = 'bbq-pro';
			
			$locale = apply_filters('bbq_i18n_locale', get_locale(), $domain);
			
			$dir    = trailingslashit(WP_LANG_DIR);
			
			$file   = $domain .'-'. $locale .'.mo';
			
			$path_1 = $dir . $file;
			
			$path_2 = $dir . $domain .'/'. $file;
			
			$path_3 = $dir .'plugins/'. $file;
			
			$path_4 = $dir .'plugins/'. $domain .'/'. $file;
			
			$paths = array($path_1, $path_2, $path_3, $path_4);
			
			foreach ($paths as $path) {
				
				if ($loaded = load_textdomain($domain, $path)) {
					
					return $loaded;
					
				} else {
					
					return load_plugin_textdomain($domain, false, dirname(BBQ_PRO_FILE) .'/languages/');
					
				}
				
			}
			
		}
		
		public function __clone() {
			
			_doing_it_wrong(__FUNCTION__, esc_html__('Cheatin&rsquo; huh?', 'bbq-pro'), BBQ_PRO_VERSION);
			
		}
		
		public function __wakeup() {
			
			_doing_it_wrong(__FUNCTION__, esc_html__('Cheatin&rsquo; huh?', 'bbq-pro'), BBQ_PRO_VERSION);
			
		}
		
	}
}

if (class_exists('BBQ_Pro')) {
	
	$bbq_options  = get_option('bbq_options',  BBQ_Pro::options());
	$bbq_patterns = get_option('bbq_patterns', BBQ_Pro::patterns());
	
	$bbq_options  = apply_filters('bbq_get_options',  $bbq_options);
	$bbq_patterns = apply_filters('bbq_get_patterns', $bbq_patterns);
	
	if (!function_exists('bbq_pro')) {
		
		function bbq_pro() {
			
			if (is_admin()) return BBQ_Pro::instance();
		}
	}
	
	bbq_pro();
	
}

if (
	(isset($bbq_options['basic_rules'])    && $bbq_options['basic_rules']) || 
	(isset($bbq_options['advanced_rules']) && $bbq_options['advanced_rules']) || 
	(isset($bbq_options['custom_rules'])   && $bbq_options['custom_rules'])) {
	
	if (!is_admin() || (is_admin() && !$bbq_options['logged_users'])) {
		
		require_once plugin_dir_path(__FILE__) .'inc/bbq-helpers.php';
		require_once plugin_dir_path(__FILE__) .'inc/bbq-core.php';
		
	}
}

if (class_exists('BBQ_Core')) {
	
	if (!function_exists('bbq__core')) {
		
		function bbq__core() {
			
			return BBQ_Core::instance();
			
		}
	}
	
	bbq__core();
	
}


