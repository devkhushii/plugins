<?php // BBQ Pro - Display Settings

if (!defined('ABSPATH')) exit;

function bbq_menu_pages() {
	
	$icon = apply_filters('bbq_dash_icon', 'dashicons-shield-alt');
	
	// add_menu_page( $page_title, $menu_title, $capability, $menu_slug, $function, $icon_url, $position );
	add_menu_page(esc_html__('BBQ Pro', 'bbq-pro'), esc_html__('BBQ Pro', 'bbq-pro'), 'manage_options', 'bbq_settings', 'bbq_pro_display_settings', $icon); // avoid duplicate menu item: menu function = submenu function
	
	// add_submenu_page( $parent_slug, $page_title, $menu_title, $capability, $menu_slug, $function );
	add_submenu_page('bbq_settings', esc_html__('Settings', 'bbq-pro'), esc_html__('Settings', 'bbq-pro'), 'manage_options', 'bbq_settings', 'bbq_pro_display_settings'); // avoid duplicate menu item: parent slug = menu slug
	add_submenu_page('bbq_settings', esc_html__('Firewall', 'bbq-pro'), esc_html__('Firewall', 'bbq-pro'), 'manage_options', 'bbq_patterns', 'bbq_display_patterns');
	add_submenu_page('bbq_settings', esc_html__('Tools',    'bbq-pro'), esc_html__('Tools',    'bbq-pro'), 'manage_options', 'bbq_tools',    'bbq_display_tools');
	add_submenu_page('bbq_settings', esc_html__('License',  'bbq-pro'), esc_html__('License',  'bbq-pro'), 'manage_options', 'bbq_license',  'bbq_display_license');
}

function bbq_pro_display_settings() { 
	
	$status = get_option('bbq_license_status'); 
	
	?>
	
	<div class="wrap">
		<h1 class="bbq-title"><?php esc_html_e('BBQ Pro', 'bbq-pro'); ?> <span><?php echo BBQ_PRO_VERSION; ?></span></h1>
		<?php settings_errors(); ?>
		<?php echo bbq_license_status(); ?>
		<form method="post" action="options.php">
			
			<?php
				
				settings_fields('bbq_options');
				do_settings_sections('bbq_options');
				submit_button();
				
			?>
			
		</form>
	</div>
	
<?php }

//

function bbq_settings_admin_notice() {
	
	$screen_id = bbq_get_current_screen_id();
	
	if ($screen_id === 'toplevel_page_bbq_settings') {
		
		if (!bbq_check_date_expired() && !bbq_dismiss_notice_check()) {
			
			?>
			
			<div class="notice notice-success notice-margin">
				<p>
					<strong><?php esc_html_e('Fall Sale!', 'bbq-pro'); ?></strong> 
					<?php esc_html_e('Take 25% OFF any of our', 'bbq-pro'); ?> 
					<a target="_blank" rel="noopener noreferrer" href="https://plugin-planet.com/"><?php esc_html_e('Pro WordPress plugins', 'bbq-pro'); ?></a> 
					<?php esc_html_e('and', 'bbq-pro'); ?> 
					<a target="_blank" rel="noopener noreferrer" href="https://books.perishablepress.com/"><?php esc_html_e('books', 'bbq-pro'); ?></a>. 
					<?php esc_html_e('Apply code', 'bbq-pro'); ?> <code>FALL2024</code> <?php esc_html_e('at checkout. Sale ends 12/21/24.', 'bbq-pro'); ?> 
					<?php echo bbq_dismiss_notice_link(); ?>
				</p>
			</div>
			
			<?php
			
		}
		
	}
	
}
add_action('admin_notices', 'bbq_settings_admin_notice');

//

function bbq_dismiss_notice_activate() {
	
	delete_option('bbq-pro-dismiss-notice');
	
}

function bbq_dismiss_notice_version() {
	
	$version_current = BBQ_PRO_VERSION;
	
	$version_previous = get_option('bbq-pro-dismiss-notice');
	
	$version_previous = ($version_previous) ? $version_previous : $version_current;
	
	if (version_compare($version_current, $version_previous, '>')) {
		
		delete_option('bbq-pro-dismiss-notice');
		
	}
	
}

function bbq_dismiss_notice_check() {
	
	$check = get_option('bbq-pro-dismiss-notice');
	
	return ($check) ? true : false;
	
}

function bbq_dismiss_notice_save() {
	
	if (isset($_GET['dismiss-notice-verify']) && wp_verify_nonce($_GET['dismiss-notice-verify'], 'bbq_dismiss_notice')) {
		
		if (!current_user_can('manage_options')) exit;
		
		$result = update_option('bbq-pro-dismiss-notice', BBQ_PRO_VERSION, false);
		
		$result = $result ? 'true' : 'false';
		
		$location = admin_url('admin.php?page=bbq_settings&dismiss-notice='. $result);
		
		wp_redirect($location);
		
		exit;
		
	}
	
}

function bbq_dismiss_notice_link() {
	
	$nonce = wp_create_nonce('bbq_dismiss_notice');
	
	$href  = add_query_arg(array('dismiss-notice-verify' => $nonce), admin_url('admin.php?page=bbq_settings'));
	
	$label = esc_html__('Dismiss', 'bbq-pro');
	
	return '<a class="bbq-dismiss-notice" href="'. esc_url($href) .'">'. esc_html($label) .'</a>';
	
}

function bbq_check_date_expired() {
	
	$expires = apply_filters('bbq_check_date_expired', '2024-12-21');
	
	return (new DateTime() > new DateTime($expires)) ? true : false;
	
}
