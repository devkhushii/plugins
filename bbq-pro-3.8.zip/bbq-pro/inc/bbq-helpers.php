<?php // BBQ Pro - BBQ Helper funtionz

if (!defined('ABSPATH')) exit;

function bbq_send_exclude($pattern, $bbq_options) {
	
	$exclude = isset($bbq_options['send_exclude']) ? $bbq_options['send_exclude'] : '';
	$exclude = array_filter(array_map('trim', explode(',', $exclude)));
	
	if (!empty($exclude)) {
		
		foreach ($exclude as $ex) {
			
			if (stripos($pattern, $ex) !== false) {
				
				return true;
				
			}
			
		}
		
	}
	
	return false;
	
}

function bbq_send_alerts($match, $request_uri, $query_string, $user_agent, $referrer, $protocol, $ip_address, $the_request) {
	
	if (!$match) return false;
	
	global $bbq_options;
	
	$pattern = isset($match[0]) ? $match[0] : 'undefined';
	$count   = isset($match[1]) ? $match[1] : 1;
	
	if (bbq_send_exclude($pattern, $bbq_options)) return false;
	
	$send_alerts = isset($bbq_options['send_alerts']) ? $bbq_options['send_alerts'] : false;
	
	if (!$send_alerts) return;
	
	$send_address = isset($bbq_options['send_address']) ? $bbq_options['send_address'] : false;
	
	$send_address = $send_address ? $send_address : get_bloginfo('admin_email');
	
	$send_address = array_map('trim', explode(',', $send_address));
	
	$blog_name = apply_filters('bbq_send_alerts_site', get_bloginfo('name'));
	
	$blog_url = apply_filters('bbq_send_alerts_url', trailingslashit(get_site_url()));
	
	$subject = apply_filters('bbq_send_alerts_subject', __('BBQ Alert: Blocked Request at', 'bbq-pro') .' '. $blog_name);
	
	$log = bbq_send_alerts_data(array($pattern, $count, $request_uri, $query_string, $user_agent, $referrer, $protocol, $ip_address, $the_request));
	
	bbq_send_alerts_email($send_address, $blog_name, $blog_url, $subject, $log);
	
}

function bbq_send_alerts_email($send_address, $blog_name, $blog_url, $subject, $log) {
	
	$n  = "\n";
	$nn = "\n\n";
	
	$date = bbq_get_date();
	
	$date = apply_filters('bbq_alert_date', $date);
	
	$data  = __('Hello! This email alert is sent from your WordPress site,', 'bbq-pro') .' '. $blog_name .' @ '. $blog_url .'. ';
	
	$data .= __('There, you are using a plugin called BBQ Firewall. This email alert tells you that the plugin is working great, doing its job protecting your site against bad requests and other threats.', 'bbq-pro') .' ';
	
	$data .= __('Below you will find details about a recent blocked request. To disable these email alerts at any time, visit the plugin settings.', 'bbq-pro') . $nn;
	
	$data .= '*******'. $nn;
	
	$data .= __('Request blocked on', 'bbq-pro') .' '. $date .':'. $nn . $log;
	
	$data  = stripslashes(trim($data));
	
	if (isset($send_address[0]) && !empty($send_address[0])) {
		
		foreach ($send_address as $address) {
			
			$address = sanitize_email($address);
			
			$headers  = 'X-Mailer: BBQ Pro'. $n;
			$headers .= 'From: '. $blog_name .' <'. $address .'>'. $n;
			$headers .= 'Reply-To: '. $blog_name .' <'. $address .'>'. $n;
			$headers .= 'Content-Type: text/plain; charset="'. get_option('blog_charset', 'UTF-8') .'"'. $n;
			
			$headers = apply_filters('bbq_alert_headers', $headers, $address, $blog_name, $blog_url, $subject, $log, $date);
			
			wp_mail($address, $subject, $data, $headers);
			
		}
		
	}
	
}

function bbq_send_alerts_data($data) {
	
	list ($pattern, $count, $request_uri, $query_string, $user_agent, $referrer, $protocol, $ip_address, $the_request) = $data;
	
	$n  = "\n";
	$nn = "\n\n";
	
	$data  = 'Blocked Count: '. $count . $n;
	$data .= 'Pattern Match: '. $pattern . $n;
	$data .= 'Request URI: '  . $request_uri . $n;
	$data .= 'The Request: '  . $the_request . $n;
	$data .= 'Query String: ' . $query_string . $n;
	$data .= 'Referrer: '     . $referrer . $n;
	$data .= 'Protocol: '     . $protocol . $n;
	$data .= 'IP Address: '   . $ip_address . $n;
	$data .= 'User Agent: '   . $user_agent . $nn;
	
	$data .= __('IP Lookup:', 'bbq-pro') .' '. esc_url('https://ipinfo.io/'. $ip_address) . $n;
	$data .= __('IP Lookup:', 'bbq-pro') .' '. esc_url('https://whatismyipaddress.com/ip/'. $ip_address);
	
	return $data;
	
}

function bbq_get_date() {
	
	$date_format = get_option('date_format');
	
	$time_format = get_option('time_format');
	
	$default_format = 'Y/m/d @ h:i:s a';
	
	if (function_exists('current_datetime')) {
		
		$date = current_datetime()->format($default_format);
		
	} else {
		
		$date = date_i18n($date_format, current_time('timestamp')) .' @ '. date_i18n($time_format, current_time('timestamp'));
		
	}
	
	return apply_filters('bbq_date', $date, $date_format, $time_format, $default_format);
	
}