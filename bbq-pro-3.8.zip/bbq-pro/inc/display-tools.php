<?php // BBQ Pro - Display Tools

function bbq_display_tools() { 
	
	$status = get_option('bbq_license_status');
	
	?>
	
	<div class="wrap">
		
		<h1 class="bbq-title"><?php esc_html_e('BBQ Pro', 'bbq-pro'); ?> <span><?php echo BBQ_PRO_VERSION; ?></span></h1>
		
		<?php echo bbq_license_status(); ?>
		
		<h2><?php esc_html_e('BBQ Tools', 'bbq-pro'); ?></h2>
		
		<p><?php echo esc_html__('Visit the', 'bbq-pro') .' <strong>'. esc_html__('Help', 'bbq-pro') .'</strong> '. esc_html__('tab above for complete documentation.', 'bbq-pro'); ?></p>
		
		<div class="import-patterns">
			<h3><?php esc_html_e('Import', 'bbq-pro'); ?></h3>
			<p><?php echo esc_html__('Here you may upload custom patterns for BBQ Firewall. Visit the Help tab for details.', 'bbq-pro'); ?></p>
			<form method="post" enctype="multipart/form-data">
				<p><input type="file" name="file_select"></p>
				<p><input type="submit" class="button button-secondary" value="<?php esc_attr_e('Import', 'bbq-pro'); ?>"></p>
				<?php wp_nonce_field('bbq-import', 'bbq-import'); ?>
			</form>
		</div>
		
		<div class="export-patterns">
			<h3><?php esc_html_e('Export', 'bbq-pro'); ?></h3>
			<p><?php echo esc_html__('Here you may export all patterns as a plain .txt file. Visit the Help tab for details.', 'bbq-pro'); ?></p>
			<form method="post" enctype="multipart/form-data">
				<p><input type="submit" class="button button-secondary" value="<?php esc_attr_e('Export', 'bbq-pro'); ?>"></p>
				<?php wp_nonce_field('bbq-export', 'bbq-export'); ?>
			</form>
		</div>
		
		<h3><?php esc_html_e('Reset', 'bbq-pro'); ?></h3>
		<p><?php echo esc_html__('Here you may reset the plugin settings and patterns to factory defaults. Visit the Help tab for details.', 'bbq-pro'); ?></p>
		
		<form method="post" action="">
			
			<div class="bbq-tools-section">
				<h3><?php esc_html_e('Reset Settings', 'bbq-pro'); ?></h3>
				<p><?php esc_html_e('Resets the plugin settings back to default values.', 'bbq-pro'); ?></p>
				<ul>
					<li><label class="bbq-label inline-block"><input type="checkbox" value="1" name="bbq-reset-settings" /> <?php esc_html_e('Reset Plugin Settings', 'bbq-pro'); ?></label></li>
				</ul>
			</div>
			
			<div class="bbq-tools-section">
				<h3><?php esc_html_e('Reset Patterns', 'bbq-pro'); ?></h3>
				<p><?php esc_html_e('Resets patterns to current defaults. Also resets all counts to zero.', 'bbq-pro'); ?></p>
				<ul>
					<li><label class="bbq-label inline-block"><input type="checkbox" value="1" name="bbq-reset-basic" />    <?php esc_html_e('Reset Basic Patterns', 'bbq-pro'); ?></label></li>
					<li><label class="bbq-label inline-block"><input type="checkbox" value="1" name="bbq-reset-advanced" /> <?php esc_html_e('Reset Advanced Patterns', 'bbq-pro'); ?></label></li>
					<li><label class="bbq-label inline-block"><input type="checkbox" value="1" name="bbq-reset-custom" />   <?php esc_html_e('Reset Custom Patterns', 'bbq-pro'); ?></label></li>
				</ul>
			</div>
			
			<div class="bbq-tools-section">
				<h3><?php esc_html_e('Reset Counts', 'bbq-pro'); ?></h3>
				<p><?php esc_html_e('Resets all counts to zero. Does not change any patterns.', 'bbq-pro'); ?></p>
				<ul>
					<li><label class="bbq-label inline-block"><input type="checkbox" value="1" name="bbq-reset-count" /> <?php esc_html_e('Reset Pattern Counts', 'bbq-pro'); ?></label></li>
				</ul>
			</div>
			
			<?php wp_nonce_field('bbq-reset-defaults', 'bbq-reset-defaults', false); ?>
			
			<input class="button button-secondary bbq-reset-button" type="submit" value="<?php esc_attr_e('Reset', 'bbq-pro'); ?>" />
		</form>
		
	</div>
	
	<script type="text/javascript">
		jQuery('.bbq-reset-button').click(function() {
			if (confirm('<?php esc_html_e('Reset selected items?', 'bbq-pro'); ?>')) jQuery('form').submit();
		});
	</script>
	
<?php }

function bbq_reset_defaults() {
	global $bbq_options, $bbq_patterns;
	
	if (isset($_POST['bbq-reset-defaults']) && wp_verify_nonce($_POST['bbq-reset-defaults'], 'bbq-reset-defaults')) {
		
		if (!current_user_can('manage_options')) exit;
		
		$default_options  = BBQ_Pro::options();
		$default_patterns = BBQ_Pro::patterns();
		
		if (isset($_POST['bbq-reset-settings']))  $bbq_options = $default_options;
		
		if (isset($_POST['bbq-reset-basic']))    $bbq_patterns['basic']    = $default_patterns['basic']; 
		if (isset($_POST['bbq-reset-advanced'])) $bbq_patterns['advanced'] = $default_patterns['advanced'];
		if (isset($_POST['bbq-reset-custom']))   $bbq_patterns['custom']   = $default_patterns['custom'];
		
		if (isset($_POST['bbq-reset-count'])) {
			
			foreach ($bbq_patterns as $key => $value) {
				
				foreach ($value as $k => $v) {
					
					foreach ($v as $id => $array) {
						
						$bbq_patterns[$key][$k][$id]['count'] = 0;
						
					}
				}
			}
		}
		
		$options  = update_option('bbq_options',  $bbq_options, true);
		$patterns = update_option('bbq_patterns', $bbq_patterns, true);
		
	}
}



function bbq_tools_admin_notice() {
	
	$screen_id = bbq_get_current_screen_id();
	
	if ($screen_id === 'bbq-pro_page_bbq_tools') {
		
		if (isset($_POST['bbq-reset-defaults'])) {
			
			if (wp_verify_nonce($_POST['bbq-reset-defaults'], 'bbq-reset-defaults')) : ?>
				
				<div class="notice notice-success is-dismissible"><p><strong><?php esc_html_e('Reset successful.', 'bbq-pro'); ?></strong></p></div>
				
			<?php else : ?>
				
				<div class="notice notice-info is-dismissible"><p><strong><?php esc_html_e('No changes made.', 'bbq-pro'); ?></strong></p></div>
				
			<?php endif;
			
		} elseif (isset($_GET['bbq-import']) && isset($_GET['bbq-imported'])) {
			
			if ($_GET['bbq-import'] === 'success') : 
				
				$patterns = (intval($_GET['bbq-imported']) == 1) ? esc_html__('pattern', 'bbq-pro') : esc_html__('patterns', 'bbq-pro');
				
			?>
				
				<div class="notice notice-success is-dismissible"><p><strong><?php echo esc_html__('Success! Imported', 'bbq-pro') .' '. esc_html($_GET['bbq-imported']) .' '. $patterns; ?>.</strong></p></div>
				
			<?php else : ?>
				
				<div class="notice notice-info is-dismissible"><p><strong><?php esc_html_e('No changes made.', 'bbq-pro'); ?></strong></p></div>
				
			<?php endif;
			
		}
		
	}
	
}
add_action('admin_notices', 'bbq_tools_admin_notice');



function bbq_import_data() {
	
	global $bbq_patterns;
	
	if (!current_user_can('manage_options')) return;
	
	if (!isset($_POST['bbq-import']) || !wp_verify_nonce($_POST['bbq-import'], 'bbq-import')) return;
	
	//
	
	$file = null;
	
	if (isset($_FILES['file_select']['tmp_name'])) {
		
		$file = $_FILES['file_select']['tmp_name'];
		
		if (empty($file)) wp_die(esc_html__('Error: File is empty', 'bbq-pro'));
		
	}
	
	//
	
	$file_name = null;
	$extension = null;
	
	if (isset($_FILES['file_select']['name'])) {
		
		$file_name = explode('.', $_FILES['file_select']['name']);
		$part_name = reset($file_name);
		$extension = end($file_name);
		
		if ($extension !== 'txt') wp_die(esc_html__('Error: File must be plain-text format (.txt)', 'bbq-pro'));
		
	}
	
	//
	
	$lines = array();
	
	if (($handle = fopen($file, 'r')) !== false) {
		
		while (!feof($handle)) {
			
			$line = fgets($handle);
			
			$line = trim($line);
			
			if (!empty($line)) $lines[] = $line;
			
		}
		
		fclose($handle);
		
	}
	
	//
	
	$imported = 0;
	
	$count = count($lines);
	
	if ($count && isset($bbq_patterns['custom'][$part_name])) {
		
		foreach ($lines as $pattern) {
			
			$exists = array_search($pattern, array_column($bbq_patterns['custom'][$part_name], 'pattern'));
			
			if ($exists === false) {
				
				$bbq_patterns['custom'][$part_name][] = array('enable' => 1, 'pattern' => $pattern, 'count' => '1');
				
				$imported++;
				
				continue;
				
			}
			
		}
		
	}
	
	//
	
	$success = update_option('bbq_patterns', $bbq_patterns, true);
	
	$params = $success ? array('bbq-import' => 'success', 'bbq-imported' => $imported) : array('bbq-import' => 'failure', 'bbq-imported' => $imported);
	
	$redirect = add_query_arg($params, admin_url('admin.php?page=bbq_tools'));
	
	wp_safe_redirect(esc_url_raw($redirect));
	
	exit;
	
}
add_action('admin_init', 'bbq_import_data');



function bbq_export_data() {
	
	if (!current_user_can('manage_options')) return;
	
	if (!isset($_POST['bbq-export']) || !wp_verify_nonce($_POST['bbq-export'], 'bbq-export')) return;
	
	//
	
	global $bbq_patterns;
	
	ignore_user_abort(true);
	
	nocache_headers();
	
	header('Content-Description: File Transfer');
	header('Content-Type: text/plain; charset=utf-8');
	header('Content-Disposition: attachment; filename=bbq-pro-patterns-'. date('Ymd-His') .'.txt');
	header('Cache-Control: must-revalidate');
	header('Pragma: public');
	header('Expires: 0');
	
	$output = __('This file contains all firewall patterns for BBQ Pro.', 'bbq-pro') . "\n\n";
	
	$output .= __('Exported on', 'bbq-pro') .' '. date('Y/m/d \@ H:i:s');
	
	foreach ($bbq_patterns as $key => $value) {
		
		foreach ($value as $k => $v) {
			
			if ($k === 'request_uri') {
				
				$section = __('Request URI', 'bbq-pro');
				
			} elseif ($k === 'ip_address') {
				
				$section = __('IP Address', 'bbq-pro');
				
			} else {
				
				$section = ucwords(str_replace('_', ' ', $k));
				
			}
			
			$output .= "\n\n\n" . '# ' . ucwords($key) . ' > ' . $section . "\n\n";
			
			if (!empty($v)) {
				
				foreach ($v as $item) {
					
					if (isset($item['pattern']) && !empty($item['pattern'])) {
						
						$output .= $item['pattern'] . "\n";
						
					}
					
				}
				
			} else {
				
				$output .= __('[ no patterns ]', 'bbq-pro');
				
			}
			
		}
		
	}
	
	$output = $output . "\n\n\n";
	
	echo ltrim($output);
	
	exit;
	
}
add_action('admin_init', 'bbq_export_data');
