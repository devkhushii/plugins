<?php // BBQ Pro - Enqueue Resources

if (!defined('ABSPATH')) exit;

function bbq_pro_enqueue_resources_admin() {
	
	$screen_id = bbq_get_current_screen_id();
	
	$ids = array('toplevel_page_bbq_settings', 'bbq-pro_page_bbq_patterns', 'bbq-pro_page_bbq_tools', 'bbq-pro_page_bbq_license');
	
	if ($screen_id && in_array($screen_id, $ids)) {
		
		// wp_enqueue_style($handle, $src, $deps, $ver, $media)
		
		wp_enqueue_style('bbq_admin', BBQ_PRO_URL .'css/admin-styles.css', array(), BBQ_PRO_VERSION);
		
		// wp_enqueue_script($handle, $src, $deps, $ver, $in_footer)
		
		wp_enqueue_script('bbq_admin', BBQ_PRO_URL .'js/admin-scripts.js', array(), BBQ_PRO_VERSION);
		
	}
	
}

function bbq_print_js_vars_admin() {
	
	$screen_id = bbq_get_current_screen_id();
	
	$ids = array('toplevel_page_bbq_settings', 'bbq-pro_page_bbq_patterns', 'bbq-pro_page_bbq_tools', 'bbq-pro_page_bbq_license');
	
	if ($screen_id && in_array($screen_id, $ids)) :
		
		?>
		
		<script type="text/javascript">var bbq_home_url = <?php echo "'". esc_url(home_url('/')) ."'"; ?>;</script>
		
		<?php 
		
	endif;
	
}

function bbq_get_current_screen_id() {
	
	if (!function_exists('get_current_screen')) require_once ABSPATH .'/wp-admin/includes/screen.php';
	
	$screen = get_current_screen();
	
	if ($screen && property_exists($screen, 'id')) return $screen->id;
	
	return false;
	
}