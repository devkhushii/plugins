<?php // BBQ Pro - BBQ Core

if (!defined('ABSPATH')) exit;

if (!class_exists('BBQ_Core')) {
	
	final class BBQ_Core {
	
		private static $instance;
		
		public static function instance() {
			
			if (!isset(self::$instance) && !(self::$instance instanceof BBQ_Core)) {
				
				self::$instance = new BBQ_Core;
				
				add_action('plugins_loaded', array(self::$instance, 'scan'));
				add_action('bbq_scan', 'bbq_send_alerts', 10, 8);
			}
			
			return self::$instance;
		}
		
		public function scan() {
			
			global $bbq_options, $bbq_patterns;
			
			$disable_for_logged_in_users = isset($bbq_options['logged_users']) ? $bbq_options['logged_users'] : false;
			
			if ($disable_for_logged_in_users && is_user_logged_in()) return;
			
			list ($request_uri, $query_string, $user_agent, $referrer, $protocol, $ip_address, $the_request) = self::get_vars();
			
			if (self::whitelist_ip($ip_address)) return;
			
			$limit_request_length = isset($bbq_options['limit_request']) ? $bbq_options['limit_request'] : false;
			$block_empty_agent    = isset($bbq_options['block_empty'])   ? $bbq_options['block_empty']   : false;
			
			$match = array();
			
			if ($limit_request_length && self::check_length($the_request)) {
				
				$bbq = true;
				$match = array('request_length', 'request_length');
				
			} elseif ($block_empty_agent && self::check_agent($user_agent)) {
				
				$bbq = true;
				$match = array('empty_agent', 'empty_agent');
			
			} elseif ($match = self::loop($request_uri, $query_string, $user_agent, $referrer, $ip_address)) {
				
				$bbq = true;
			
			} else {
				
				$bbq = false;
				
			}
			
			do_action('bbq_scan', $match, $request_uri, $query_string, $user_agent, $referrer, $protocol, $ip_address, $the_request);
			
			if ($bbq) self::bbq($protocol, $match);
			
			return false;
		}
		
		public function loop($request_uri, $query_string, $user_agent, $referrer, $ip_address) {
			
			global $bbq_options, $bbq_patterns;
			
			foreach ((array) $bbq_patterns as $key => $value) {
				
				if (!$bbq_options['basic_rules']    && $key === 'basic')    continue;
				if (!$bbq_options['advanced_rules'] && $key === 'advanced') continue;
				if (!$bbq_options['custom_rules']   && $key === 'custom')   continue;
				
				foreach ($value as $k => $v) {
					
					foreach ($v as $id => $array) {
						
						if (!isset($array['enable']) || !$array['enable'] || !isset($array['pattern'])) continue;
						
						if (isset($array['pattern']) && empty($array['pattern'])) continue;
						
						if (isset($bbq_options['strict_mode']) && $bbq_options['strict_mode']) ${$k} = rawurldecode(${$k});
						
						if (stripos(${$k}, $array['pattern']) !== false) {
							
							$bbq_patterns[$key][$k][$id]['count'] = (int) $array['count'] + 1;
							
							$update = update_option('bbq_patterns', $bbq_patterns, true);
							
							return array($array['pattern'], $bbq_patterns[$key][$k][$id]['count']);
						}
					}
				}
			}
			
			return false;
		}
		
		public function whitelist_ip($ip_address) {
			
			global $bbq_options;
			
			$wildcard = apply_filters('bbq_wildcard', ''); // use $ to disable wildcard matching
			
			$whitelist_ips = isset($bbq_options['whitelist_ips']) ? $bbq_options['whitelist_ips'] : '';
			$whitelist_ips = array_filter(array_map('trim', explode(',', $whitelist_ips)));
			
			foreach ($whitelist_ips as $ip) {
				
				if (strpos($ip, '/') === false) {
					
					if (empty($wildcard)) {
						
						if (substr($ip_address, 0, strlen($ip)) === $ip) {
							
							return true;
							
						}
						
					} elseif ($wildcard === '$') {
						
						if ($ip_address === $ip) {
							
							return true;
							
						}
						
					}
					
				} else {
					
					if (self::ip_in_range($ip_address, $ip)) {
						
						return true;
						
					}
					
				}
				
			}
			
			return false;
			
		}
		
		public function ip_in_range($ip, $range) {
			
			list($range, $netmask) = explode('/', $range, 2);
			
			$range_decimal = ip2long($range);
			
			$ip_decimal = ip2long($ip);
			
			$wildcard_decimal = pow(2, (32 - $netmask)) - 1;
			
			$netmask_decimal = ~ $wildcard_decimal;
			
			return (($ip_decimal & $netmask_decimal) == ($range_decimal & $netmask_decimal));
			
		}
		
		public function check_length($request_uri) {
			
			$max_length = apply_filters('bbq_check_length', 2000);
			
			if (strlen($request_uri) > $max_length) return true;
			
			return false;
		}
		
		public function check_agent($user_agent) {
			
			return empty($user_agent) ? true : false;
			
		}
		
		public function bbq($protocol, $match) {
			
			global $bbq_options;
			
			$status = ' 403 Forbidden';
			
			if (isset($bbq_options['status_code']) && !empty($bbq_options['status_code'])) {
				
				$status = ' '. sanitize_text_field($bbq_options['status_code']);
			}
			
			$redirect = false;
			
			if (isset($bbq_options['redirect_url']) && filter_var($bbq_options['redirect_url'], FILTER_VALIDATE_URL)) {
				
				$redirect = esc_url_raw($bbq_options['redirect_url']);
			}
			
			$message = '';
			
			if (isset($bbq_options['custom_message']) && !empty($bbq_options['custom_message'])) {
				
				list ($pattern, $count) = $match;
				
				$message = $bbq_options['custom_message'];
				
				$message = preg_replace('/\%s/', $pattern, $message);
				
				$message = preg_replace('/\%c/', $count, $message);
				
			}
			
			if ($redirect) {
				
				header($protocol . $status);
				header('Location: '. $redirect);
				exit;
				
			} else {
				
				header($protocol . $status);
				header('Connection: Close');
				die($message);
				
			}
		}
		
		public function get_vars() {
			
			$the_request = isset($_SERVER['REQUEST_URI'])     && !empty($_SERVER['REQUEST_URI'])     ? $_SERVER['REQUEST_URI']     : false;
			$user_agent  = isset($_SERVER['HTTP_USER_AGENT']) && !empty($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : false;
			$referrer    = isset($_SERVER['HTTP_REFERER'])    && !empty($_SERVER['HTTP_REFERER'])    ? $_SERVER['HTTP_REFERER']    : false;
			$protocol    = isset($_SERVER['SERVER_PROTOCOL']) && !empty($_SERVER['SERVER_PROTOCOL']) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.1';
			
			list ($request_uri, $query_string) = self::get_strings($the_request);
			
			$ip_address = self::get_ip();
			
			return apply_filters('bbq_request_array', array($request_uri, $query_string, $user_agent, $referrer, $protocol, $ip_address, $the_request));
		}
		
		public function get_strings($the_request) {
			
			$strings = explode('?', $the_request, 2);
			
			$request_uri  = isset($strings[0]) ? $strings[0] : false;
			$query_string = isset($strings[1]) ? $strings[1] : false;
			
			return array($request_uri, $query_string);
		}
		
		public function get_ip() {
			
			$ip = self::evaluate_ip();
			
			if (preg_match('/(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})/', $ip, $ip_match)) {
				
				$ip = $ip_match[1];
				
			}
			
			return sanitize_text_field($ip);
			
		}
		
		public function evaluate_ip() {
			
			$ip_keys = array('REMOTE_ADDR', 'HTTP_CF_CONNECTING_IP', 'HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_X_REAL_IP', 'HTTP_X_COMING_FROM', 'HTTP_PROXY_CONNECTION', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'HTTP_COMING_FROM', 'HTTP_VIA');
			
			$ip_keys = apply_filters('bbq_ip_keys', $ip_keys); // Important: do NOT make changes to $ip_keys array unless you absolutely know what you're doing.
			
			foreach ($ip_keys as $key) {
				
				if (array_key_exists($key, $_SERVER) === true) {
					
					foreach (explode(',', $_SERVER[$key]) as $ip) {
						
						$ip = trim($ip);
						
						$ip = self::normalize_ip($ip);
						
						if (self::validate_ip($ip)) {
							
							return $ip;
							
						}
						
					}
					
				}
				
			}
			
			return esc_html__('Error: Invalid IP Address', 'bbq-pro');
			
		}
		
		public function normalize_ip($ip) {
			
			if (strpos($ip, ':') !== false && substr_count($ip, '.') == 3 && strpos($ip, '[') === false) {
				
				// IPv4 with port (e.g., 123.123.123:80)
				$ip = explode(':', $ip);
				$ip = $ip[0];
				
			} else {
				
				// IPv6 with port (e.g., [::1]:80)
				$ip = explode(']', $ip);
				$ip = ltrim($ip[0], '[');
				
			}
			
			return $ip;
			
		}
		
		public function validate_ip($ip) {
			
			$options  = FILTER_FLAG_IPV4 | FILTER_FLAG_IPV6 | FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE;
			
			$options  = apply_filters('bbq_ip_filter', $options);
			
			$filtered = filter_var($ip, FILTER_VALIDATE_IP, $options);
			
			if (!$filtered || empty($filtered)) {
				
				if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
					
					return $ip; // IPv4
					
				} elseif (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
					
					return $ip; // IPv6
					
				}
				
				// error_log(__('BBQ Pro: Invalid IP Address: ', 'bbq-pro') . $ip);
				
				return false;
				
			}
			
			return $filtered;
			
		}
		
	}
}
