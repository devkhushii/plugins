<?php // BBQ Pro - Firewall Patterns

function bbq_patterns() {
	
	return array(
				
		'basic' => array(
			
			'request_uri' => array(
				
				array('enable' => true, 'count' => 0, 'pattern' => '/127.0.0.1'),
				array('enable' => true, 'count' => 0, 'pattern' => '/localhost'),
				array('enable' => true, 'count' => 0, 'pattern' => '/loopback'),
				array('enable' => true, 'count' => 0, 'pattern' => 'base64('),
				array('enable' => true, 'count' => 0, 'pattern' => 'base64_'),
				array('enable' => true, 'count' => 0, 'pattern' => 'eval('),
				array('enable' => true, 'count' => 0, 'pattern' => '@eval'),
				array('enable' => true, 'count' => 0, 'pattern' => '(null)'),
				
				array('enable' => true, 'count' => 0, 'pattern' => '/http:'),
				array('enable' => true, 'count' => 0, 'pattern' => '/https:'),
				array('enable' => true, 'count' => 0, 'pattern' => '/ftp:'),
				array('enable' => true, 'count' => 0, 'pattern' => '/ftps:'),
				array('enable' => true, 'count' => 0, 'pattern' => '/php:'),
				array('enable' => true, 'count' => 0, 'pattern' => '/file:'),
				array('enable' => true, 'count' => 0, 'pattern' => '/http/'),
				array('enable' => true, 'count' => 0, 'pattern' => '/https/'),
				array('enable' => true, 'count' => 0, 'pattern' => '/httpdocs/'),
				array('enable' => true, 'count' => 0, 'pattern' => '/htdocs/'),
				array('enable' => true, 'count' => 0, 'pattern' => '/vhosts/'),
				
				array('enable' => true, 'count' => 0, 'pattern' => 'union+all+select'),
				array('enable' => true, 'count' => 0, 'pattern' => 'union+select'),
				array('enable' => true, 'count' => 0, 'pattern' => '**/select+/**'),
				array('enable' => true, 'count' => 0, 'pattern' => 'bin/bash'),
				array('enable' => true, 'count' => 0, 'pattern' => 'etc/passwd'),
				array('enable' => true, 'count' => 0, 'pattern' => 'self/environ'),
				array('enable' => true, 'count' => 0, 'pattern' => 'usr/bin/perl'),
				array('enable' => true, 'count' => 0, 'pattern' => 'var/lib/php'),
				
				array('enable' => true, 'count' => 0, 'pattern' => '/document_root'),
				array('enable' => true, 'count' => 0, 'pattern' => '/error_log'),
				array('enable' => true, 'count' => 0, 'pattern' => '/makefile'),
				array('enable' => true, 'count' => 0, 'pattern' => '/pingserver'),
				array('enable' => true, 'count' => 0, 'pattern' => '/remoteview'),
				array('enable' => true, 'count' => 0, 'pattern' => '/wwwroot'),
				array('enable' => true, 'count' => 0, 'pattern' => 'www.root.'),
				
				array('enable' => true, 'count' => 0, 'pattern' => '^'),
				array('enable' => true, 'count' => 0, 'pattern' => '`'),
				array('enable' => true, 'count' => 0, 'pattern' => '<'),
				array('enable' => true, 'count' => 0, 'pattern' => '>'),
				array('enable' => true, 'count' => 0, 'pattern' => '/='),
				array('enable' => true, 'count' => 0, 'pattern' => '/:/'),
				array('enable' => true, 'count' => 0, 'pattern' => '/::/'),
				array('enable' => true, 'count' => 0, 'pattern' => '/($)/'),
				array('enable' => true, 'count' => 0, 'pattern' => '/(*)/'),
				array('enable' => true, 'count' => 0, 'pattern' => '/**/'),
				array('enable' => true, 'count' => 0, 'pattern' => '/$&'),
				array('enable' => true, 'count' => 0, 'pattern' => '/&&'),
				array('enable' => true, 'count' => 0, 'pattern' => '@@'),
				array('enable' => true, 'count' => 0, 'pattern' => '{0}'),
				array('enable' => true, 'count' => 0, 'pattern' => '...'),
				array('enable' => true, 'count' => 0, 'pattern' => '+++'),
				array('enable' => true, 'count' => 0, 'pattern' => '///'),
				array('enable' => true, 'count' => 0, 'pattern' => '://'),
				array('enable' => true, 'count' => 0, 'pattern' => '\\'),
				array('enable' => true, 'count' => 0, 'pattern' => '??'),
				
				array('enable' => true, 'count' => 0, 'pattern' => '&pws=0'),
				array('enable' => true, 'count' => 0, 'pattern' => 'cast(0x'),
				array('enable' => true, 'count' => 0, 'pattern' => '0x00'),
				array('enable' => true, 'count' => 0, 'pattern' => ').html('),
				array('enable' => true, 'count' => 0, 'pattern' => '{x.html('),
				array('enable' => true, 'count' => 0, 'pattern' => '{$itemURL}'),
				
				array('enable' => true, 'count' => 0, 'pattern' => '/config.'),
				array('enable' => true, 'count' => 0, 'pattern' => '/crossdomain.'),
				array('enable' => true, 'count' => 0, 'pattern' => '/function.array-rand'),
				array('enable' => true, 'count' => 0, 'pattern' => '/function.parse-url'),
				array('enable' => true, 'count' => 0, 'pattern' => '/ref.outcontrol'),
				array('enable' => true, 'count' => 0, 'pattern' => '/wp-config.'),
				array('enable' => true, 'count' => 0, 'pattern' => '.php/index.php/index'),
				array('enable' => true, 'count' => 0, 'pattern' => '.well-known/host-meta'),
				
				array('enable' => true, 'count' => 0, 'pattern' => 'bitrix'),
				array('enable' => true, 'count' => 0, 'pattern' => 'fckeditor'),
				array('enable' => true, 'count' => 0, 'pattern' => 'timthumb'),
				array('enable' => true, 'count' => 0, 'pattern' => 'muieblack'),
				array('enable' => true, 'count' => 0, 'pattern' => 'revslider'),
				array('enable' => true, 'count' => 0, 'pattern' => 'indoxploi'),
				array('enable' => true, 'count' => 0, 'pattern' => 'xrumer'),
				
				// new 2024 10 30
				
				array('enable' => true, 'count' => 0, 'pattern' => '|'),
				array('enable' => true, 'count' => 0, 'pattern' => '%00'),
				array('enable' => true, 'count' => 0, 'pattern' => ',,,'),
				array('enable' => true, 'count' => 0, 'pattern' => '------'),
				array('enable' => true, 'count' => 0, 'pattern' => '"0"="0'),
				
				array('enable' => true, 'count' => 0, 'pattern' => 'echo('),
				array('enable' => true, 'count' => 0, 'pattern' => '/adminer.php'),
				array('enable' => true, 'count' => 0, 'pattern' => '/administrator.php'),
				array('enable' => true, 'count' => 0, 'pattern' => '.mysql-select-db'),
				
				array('enable' => true, 'count' => 0, 'pattern' => 'open_basedir'),
				array('enable' => true, 'count' => 0, 'pattern' => '/server/php'),
				array('enable' => true, 'count' => 0, 'pattern' => '/webroot.php'),
				array('enable' => true, 'count' => 0, 'pattern' => '/root.php'),
				array('enable' => true, 'count' => 0, 'pattern' => '/root/'),
				
				array('enable' => true, 'count' => 0, 'pattern' => 'header:'),
				array('enable' => true, 'count' => 0, 'pattern' => 'set-cookie:'),
				array('enable' => true, 'count' => 0, 'pattern' => 'ckfinder'),
				array('enable' => true, 'count' => 0, 'pattern' => 'ckeditor'),
				array('enable' => true, 'count' => 0, 'pattern' => 'posix_'),
				
				array('enable' => true, 'count' => 0, 'pattern' => '/vbull'),
				array('enable' => true, 'count' => 0, 'pattern' => '/vbforum'),
				
			),
			
			'query_string' => array(
				
				array('enable' => true, 'count' => 0, 'pattern' => '../'),
				array('enable' => true, 'count' => 0, 'pattern' => '127.0.0.1'),
				array('enable' => true, 'count' => 0, 'pattern' => 'localhost'),
				array('enable' => true, 'count' => 0, 'pattern' => 'loopback'),
				array('enable' => true, 'count' => 0, 'pattern' => 'javascript:'),
				
				array('enable' => true, 'count' => 0, 'pattern' => '@copy'),
				array('enable' => true, 'count' => 0, 'pattern' => '@eval'),
				array('enable' => true, 'count' => 0, 'pattern' => 'eval('),
				array('enable' => true, 'count' => 0, 'pattern' => 'base64('),
				array('enable' => true, 'count' => 0, 'pattern' => 'base64_'),
				
				array('enable' => true, 'count' => 0, 'pattern' => 'mod=.'),
				array('enable' => true, 'count' => 0, 'pattern' => 'path=.'),
				array('enable' => true, 'count' => 0, 'pattern' => '/config.'),
				array('enable' => true, 'count' => 0, 'pattern' => 'mosconfig'),
				array('enable' => true, 'count' => 0, 'pattern' => 'wp-config.php'),
				
				array('enable' => true, 'count' => 0, 'pattern' => 'benchmark('),
				array('enable' => true, 'count' => 0, 'pattern' => 'concat('),
				array('enable' => true, 'count' => 0, 'pattern' => 'phpinfo('),
				array('enable' => true, 'count' => 0, 'pattern' => ')select'),
				array('enable' => true, 'count' => 0, 'pattern' => 'select('),
				
				array('enable' => true, 'count' => 0, 'pattern' => 'shell_exec('),
				array('enable' => true, 'count' => 0, 'pattern' => 'sleep('),
				array('enable' => true, 'count' => 0, 'pattern' => 'union('),
				array('enable' => true, 'count' => 0, 'pattern' => 'etc/passwd'),
				array('enable' => true, 'count' => 0, 'pattern' => 'self/environ'),
				
				array('enable' => true, 'count' => 0, 'pattern' => 'etc/motd'),
				array('enable' => true, 'count' => 0, 'pattern' => 'etc/hosts'),
				array('enable' => true, 'count' => 0, 'pattern' => 'etc/shadow'),
				array('enable' => true, 'count' => 0, 'pattern' => 'windows/win'),
				
				array('enable' => true, 'count' => 0, 'pattern' => 'timthumb'),
				array('enable' => true, 'count' => 0, 'pattern' => 'fckeditor'),
				array('enable' => true, 'count' => 0, 'pattern' => 'revslider'),
				array('enable' => true, 'count' => 0, 'pattern' => 'indoxploi'),
				array('enable' => true, 'count' => 0, 'pattern' => 'xrumer'),
				
				array('enable' => true, 'count' => 0, 'pattern' => 'allow_url_include'),
				array('enable' => true, 'count' => 0, 'pattern' => 'auto_prepend_file'),
				array('enable' => true, 'count' => 0, 'pattern' => 'curl_exec'),
				array('enable' => true, 'count' => 0, 'pattern' => 'disable_function'),
				array('enable' => true, 'count' => 0, 'pattern' => 'document_root'),
				
				array('enable' => true, 'count' => 0, 'pattern' => 'execute'),
				array('enable' => true, 'count' => 0, 'pattern' => 'fgets'),
				array('enable' => true, 'count' => 0, 'pattern' => 'file_get_contents'),
				array('enable' => true, 'count' => 0, 'pattern' => 'file_put_contents'),
				array('enable' => true, 'count' => 0, 'pattern' => 'fputs'),
				
				array('enable' => true, 'count' => 0, 'pattern' => 'fsockopen'),
				array('enable' => true, 'count' => 0, 'pattern' => 'fwrite'),
				array('enable' => true, 'count' => 0, 'pattern' => 'gethostbyname'),
				array('enable' => true, 'count' => 0, 'pattern' => 'input_file'),
				array('enable' => true, 'count' => 0, 'pattern' => 'outfile'),
				
				array('enable' => true, 'count' => 0, 'pattern' => 'basedir'),
				array('enable' => true, 'count' => 0, 'pattern' => 'passthru'),
				array('enable' => true, 'count' => 0, 'pattern' => 'phpshell'),
				array('enable' => true, 'count' => 0, 'pattern' => 'proc_open'),
				array('enable' => true, 'count' => 0, 'pattern' => 'remoteview'),
				
				array('enable' => true, 'count' => 0, 'pattern' => 'root_path'),
				array('enable' => true, 'count' => 0, 'pattern' => 'safe_mode'),
				array('enable' => true, 'count' => 0, 'pattern' => 'user_func_array'),
				
				// new 2024 10 30
				
				array('enable' => true, 'count' => 0, 'pattern' => 'orderby('),
				array('enable' => true, 'count' => 0, 'pattern' => 'header:'),
				array('enable' => true, 'count' => 0, 'pattern' => 'set-cookie:'),
				
				array('enable' => true, 'count' => 0, 'pattern' => 'cmd='),
				array('enable' => true, 'count' => 0, 'pattern' => 'command='),
				array('enable' => true, 'count' => 0, 'pattern' => 'request='),
				array('enable' => true, 'count' => 0, 'pattern' => '/mod='),
				array('enable' => true, 'count' => 0, 'pattern' => '/path='),
				
				array('enable' => true, 'count' => 0, 'pattern' => 'absolute_dir'),
				array('enable' => true, 'count' => 0, 'pattern' => 'basepath'),
				array('enable' => true, 'count' => 0, 'pattern' => 'root_dir'),
				
				array('enable' => true, 'count' => 0, 'pattern' => 'char('),
				array('enable' => true, 'count' => 0, 'pattern' => 'exec('),
				array('enable' => true, 'count' => 0, 'pattern' => 'popen('),
				array('enable' => true, 'count' => 0, 'pattern' => 'fopen('),
				array('enable' => true, 'count' => 0, 'pattern' => 'fclose('),
				array('enable' => true, 'count' => 0, 'pattern' => 'function('),
				array('enable' => true, 'count' => 0, 'pattern' => 'html('),
				
				array('enable' => true, 'count' => 0, 'pattern' => 'webshell'),
				array('enable' => true, 'count' => 0, 'pattern' => 'executesql'),
				array('enable' => true, 'count' => 0, 'pattern' => 'load_file'),
				array('enable' => true, 'count' => 0, 'pattern' => 'unhex'),
				array('enable' => true, 'count' => 0, 'pattern' => 'wget'),
				
			),
			
			'user_agent' => array(
				
				array('enable' => true, 'count' => 0, 'pattern' => 'acapbot'),
				array('enable' => true, 'count' => 0, 'pattern' => 'alexibot'),
				array('enable' => true, 'count' => 0, 'pattern' => 'attack'),
				array('enable' => true, 'count' => 0, 'pattern' => 'backdo'),
				array('enable' => true, 'count' => 0, 'pattern' => 'binlar'),
				
				array('enable' => true, 'count' => 0, 'pattern' => 'blackwidow'),
				array('enable' => true, 'count' => 0, 'pattern' => 'blexbot'),
				array('enable' => true, 'count' => 0, 'pattern' => 'blowfish'),
				array('enable' => true, 'count' => 0, 'pattern' => 'bullseye'),
				array('enable' => true, 'count' => 0, 'pattern' => 'casper'),
				
				array('enable' => true, 'count' => 0, 'pattern' => 'cherrypick'),
				array('enable' => true, 'count' => 0, 'pattern' => 'cmswor'),
				array('enable' => true, 'count' => 0, 'pattern' => 'comodo'),
				array('enable' => true, 'count' => 0, 'pattern' => 'crescent'),
				array('enable' => true, 'count' => 0, 'pattern' => 'demon'),
				
				array('enable' => true, 'count' => 0, 'pattern' => 'diavol'),
				array('enable' => true, 'count' => 0, 'pattern' => 'discobot'),
				array('enable' => true, 'count' => 0, 'pattern' => 'dotbot'),
				array('enable' => true, 'count' => 0, 'pattern' => 'dumbot'),
				array('enable' => true, 'count' => 0, 'pattern' => 'email'),
				
				array('enable' => true, 'count' => 0, 'pattern' => 'exabot'),
				array('enable' => true, 'count' => 0, 'pattern' => 'finder'),
				array('enable' => true, 'count' => 0, 'pattern' => 'flicky'),
				array('enable' => true, 'count' => 0, 'pattern' => 'flaming'),
				array('enable' => true, 'count' => 0, 'pattern' => 'flashget'),
				
				array('enable' => true, 'count' => 0, 'pattern' => 'foobot'),
				array('enable' => true, 'count' => 0, 'pattern' => 'gigabot'),
				array('enable' => true, 'count' => 0, 'pattern' => 'gozilla'),
				array('enable' => true, 'count' => 0, 'pattern' => 'grafula'),
				array('enable' => true, 'count' => 0, 'pattern' => 'hacker'),
				
				array('enable' => true, 'count' => 0, 'pattern' => 'heritrix'),
				array('enable' => true, 'count' => 0, 'pattern' => 'jetbot'),
				array('enable' => true, 'count' => 0, 'pattern' => 'kmccrew'),
				array('enable' => true, 'count' => 0, 'pattern' => 'leacher'),
				array('enable' => true, 'count' => 0, 'pattern' => 'leech'),
				
				array('enable' => true, 'count' => 0, 'pattern' => 'libweb'),
				array('enable' => true, 'count' => 0, 'pattern' => 'linkwalker'),
				array('enable' => true, 'count' => 0, 'pattern' => 'majestic'),
				array('enable' => true, 'count' => 0, 'pattern' => 'morfeus'),
				array('enable' => true, 'count' => 0, 'pattern' => 'netspider'),
				
				array('enable' => true, 'count' => 0, 'pattern' => 'ninja'),
				array('enable' => true, 'count' => 0, 'pattern' => 'nutch'),
				array('enable' => true, 'count' => 0, 'pattern' => 'octopus'),
				array('enable' => true, 'count' => 0, 'pattern' => 'planet'),
				array('enable' => true, 'count' => 0, 'pattern' => 'postrank'),
				
				array('enable' => true, 'count' => 0, 'pattern' => 'proximic'),
				array('enable' => true, 'count' => 0, 'pattern' => 'purebot'),
				array('enable' => true, 'count' => 0, 'pattern' => 'reaper'),
				array('enable' => true, 'count' => 0, 'pattern' => 'scooter'),
				array('enable' => true, 'count' => 0, 'pattern' => 'semalt'),
				
				array('enable' => true, 'count' => 0, 'pattern' => 'shellshock'),
				array('enable' => true, 'count' => 0, 'pattern' => 'sistrix'),
				array('enable' => true, 'count' => 0, 'pattern' => 'skygrid'),
				array('enable' => true, 'count' => 0, 'pattern' => 'snoopy'),
				array('enable' => true, 'count' => 0, 'pattern' => 'sosospider'),
				
				array('enable' => true, 'count' => 0, 'pattern' => 'spankbot'),
				array('enable' => true, 'count' => 0, 'pattern' => 'stripper'),
				array('enable' => true, 'count' => 0, 'pattern' => 'sucker'),
				array('enable' => true, 'count' => 0, 'pattern' => 'suzukacz'),
				array('enable' => true, 'count' => 0, 'pattern' => 'teleport'),
				
				array('enable' => true, 'count' => 0, 'pattern' => 'turnit'),
				array('enable' => true, 'count' => 0, 'pattern' => 'vampire'),
				array('enable' => true, 'count' => 0, 'pattern' => 'vikspi'),
				array('enable' => true, 'count' => 0, 'pattern' => 'voideye'),
				array('enable' => true, 'count' => 0, 'pattern' => 'webvac'),
				
				array('enable' => true, 'count' => 0, 'pattern' => 'woxbot'),
				array('enable' => true, 'count' => 0, 'pattern' => 'xaldon'),
				array('enable' => true, 'count' => 0, 'pattern' => 'zeus'),
				array('enable' => true, 'count' => 0, 'pattern' => 'zmeu'),
				array('enable' => true, 'count' => 0, 'pattern' => 'zyborg'),
				
			),
		),
		
		'advanced' => array(
			
			'request_uri' => array(
				
				array('enable' => true, 'count' => 0, 'pattern' => 'benchmark('),
				array('enable' => true, 'count' => 0, 'pattern' => 'curl_exec('),
				array('enable' => true, 'count' => 0, 'pattern' => '(function('),
				array('enable' => true, 'count' => 0, 'pattern' => 'function()'),
				array('enable' => true, 'count' => 0, 'pattern' => 'fwrite('),
				array('enable' => true, 'count' => 0, 'pattern' => 'leak('),
				array('enable' => true, 'count' => 0, 'pattern' => 'passthru('),
				array('enable' => true, 'count' => 0, 'pattern' => 'phpinfo('),
				array('enable' => true, 'count' => 0, 'pattern' => 'shell_exec('),
				array('enable' => true, 'count' => 0, 'pattern' => 'sleep('),
				array('enable' => true, 'count' => 0, 'pattern' => 'system('),
				array('enable' => true, 'count' => 0, 'pattern' => 'terminate('),
				
				array('enable' => true, 'count' => 0, 'pattern' => '/bin/chmod/'),
				array('enable' => true, 'count' => 0, 'pattern' => '/bin/chsh/'),
				array('enable' => true, 'count' => 0, 'pattern' => '/bin/echo/'),
				array('enable' => true, 'count' => 0, 'pattern' => '/bin/kill/'),
				array('enable' => true, 'count' => 0, 'pattern' => '/bin/mail/'),
				array('enable' => true, 'count' => 0, 'pattern' => '/bin/python/'),
				array('enable' => true, 'count' => 0, 'pattern' => '/etc/hidden/'),
				array('enable' => true, 'count' => 0, 'pattern' => '/etc/secret/'),
				array('enable' => true, 'count' => 0, 'pattern' => '/etc/tmp/'),
				
				array('enable' => true, 'count' => 0, 'pattern' => '/admin-uploadify/'),
				array('enable' => true, 'count' => 0, 'pattern' => '/database/'),
				array('enable' => true, 'count' => 0, 'pattern' => '/dbscripts/'),
				array('enable' => true, 'count' => 0, 'pattern' => '/db-admin/'),
				array('enable' => true, 'count' => 0, 'pattern' => '/filemanager/'),
				array('enable' => true, 'count' => 0, 'pattern' => '/fileupload/'),
				array('enable' => true, 'count' => 0, 'pattern' => '/ima/'),
				array('enable' => true, 'count' => 0, 'pattern' => '/jquery-file-upload/'),
				array('enable' => true, 'count' => 0, 'pattern' => '/mailman/'),
				array('enable' => true, 'count' => 0, 'pattern' => '/mailto/'),
				array('enable' => true, 'count' => 0, 'pattern' => '/mysql-admin/'),
				array('enable' => true, 'count' => 0, 'pattern' => '/mysql/'),
				array('enable' => true, 'count' => 0, 'pattern' => '/tmp/'),
				array('enable' => true, 'count' => 0, 'pattern' => '/ucp/'),
				array('enable' => true, 'count' => 0, 'pattern' => '/undefined/'),
				array('enable' => true, 'count' => 0, 'pattern' => '/upload/'),
				array('enable' => true, 'count' => 0, 'pattern' => '/upload_file/'),
				array('enable' => true, 'count' => 0, 'pattern' => '/uploadify/'),
				array('enable' => true, 'count' => 0, 'pattern' => '/var/'),
				array('enable' => true, 'count' => 0, 'pattern' => '/webforms/'),
				
				array('enable' => true, 'count' => 0, 'pattern' => '/__hdhdhd.php'),
				array('enable' => true, 'count' => 0, 'pattern' => '/0day.php'),
				array('enable' => true, 'count' => 0, 'pattern' => '/3xp.php'),
				array('enable' => true, 'count' => 0, 'pattern' => '/70bex.php'),
				array('enable' => true, 'count' => 0, 'pattern' => '/70be.php'),
				array('enable' => true, 'count' => 0, 'pattern' => '/apikey.php'),
				array('enable' => true, 'count' => 0, 'pattern' => '/c99.php'),
				array('enable' => true, 'count' => 0, 'pattern' => '/configbak.php'),
				array('enable' => true, 'count' => 0, 'pattern' => '/curltest.php'),
				array('enable' => true, 'count' => 0, 'pattern' => '/db.php'),
				array('enable' => true, 'count' => 0, 'pattern' => '/dompdf.php'),
				array('enable' => true, 'count' => 0, 'pattern' => '/eval-stdin.php'),
				array('enable' => true, 'count' => 0, 'pattern' => '/fpw.php'),
				array('enable' => true, 'count' => 0, 'pattern' => '/install.php'),
				array('enable' => true, 'count' => 0, 'pattern' => '/iprober.php'),
				array('enable' => true, 'count' => 0, 'pattern' => '/mobiquo.php'),
				array('enable' => true, 'count' => 0, 'pattern' => '/mysql.php'),
				array('enable' => true, 'count' => 0, 'pattern' => '/php-info.php'),
				array('enable' => true, 'count' => 0, 'pattern' => '/phpinfo.php'),
				array('enable' => true, 'count' => 0, 'pattern' => '/phpspy.php'),
				array('enable' => true, 'count' => 0, 'pattern' => '/playing.php'),
				array('enable' => true, 'count' => 0, 'pattern' => '/register.php'),
				array('enable' => true, 'count' => 0, 'pattern' => '/router.php'),
				array('enable' => true, 'count' => 0, 'pattern' => '/setup-config.php'),
				array('enable' => true, 'count' => 0, 'pattern' => '/shell.php'),
				array('enable' => true, 'count' => 0, 'pattern' => '/sql.php'),
				array('enable' => true, 'count' => 0, 'pattern' => '/sqlpatch.php'),
				array('enable' => true, 'count' => 0, 'pattern' => '/up__uzegp.php'),
				array('enable' => true, 'count' => 0, 'pattern' => '/uploadbg.php'),
				array('enable' => true, 'count' => 0, 'pattern' => '/uploadify.php'),
				array('enable' => true, 'count' => 0, 'pattern' => '/vuln.php'),
				array('enable' => true, 'count' => 0, 'pattern' => '/webconfig.php'),
				array('enable' => true, 'count' => 0, 'pattern' => '/webshell.php'),
				
				array('enable' => true, 'count' => 0, 'pattern' => '.asp'),
				array('enable' => true, 'count' => 0, 'pattern' => '.bash'),
				array('enable' => true, 'count' => 0, 'pattern' => '.bak'),
				array('enable' => true, 'count' => 0, 'pattern' => '.bat'),
				array('enable' => true, 'count' => 0, 'pattern' => '.cfg'),
				array('enable' => true, 'count' => 0, 'pattern' => '.cgi'),
				array('enable' => true, 'count' => 0, 'pattern' => 'cgi.'),
				array('enable' => true, 'count' => 0, 'pattern' => '/cgi/'),
				array('enable' => true, 'count' => 0, 'pattern' => '/cgi-'),
				array('enable' => true, 'count' => 0, 'pattern' => '.cmd'),
				array('enable' => true, 'count' => 0, 'pattern' => '.dll'),
				array('enable' => true, 'count' => 0, 'pattern' => '.ds_'),
				array('enable' => true, 'count' => 0, 'pattern' => '/.env'),
				array('enable' => true, 'count' => 0, 'pattern' => '.exe'),
				array('enable' => true, 'count' => 0, 'pattern' => '.git'),
				array('enable' => true, 'count' => 0, 'pattern' => '.htacc'),
				array('enable' => true, 'count' => 0, 'pattern' => '.htpas'),
				array('enable' => true, 'count' => 0, 'pattern' => '.ini'),
				array('enable' => true, 'count' => 0, 'pattern' => '.jsp'),
				array('enable' => true, 'count' => 0, 'pattern' => '/_mm'),
				array('enable' => true, 'count' => 0, 'pattern' => '.mdb'),
				array('enable' => true, 'count' => 0, 'pattern' => '.msi'),
				array('enable' => true, 'count' => 0, 'pattern' => '.mysql'),
				array('enable' => true, 'count' => 0, 'pattern' => '.pass'),
				array('enable' => true, 'count' => 0, 'pattern' => '.pwd'),
				array('enable' => true, 'count' => 0, 'pattern' => '.py'),
				array('enable' => true, 'count' => 0, 'pattern' => '.rar'),
				array('enable' => true, 'count' => 0, 'pattern' => '.sql'),
				array('enable' => true, 'count' => 0, 'pattern' => '.svn'),
				array('enable' => true, 'count' => 0, 'pattern' => '.tar'),
				array('enable' => true, 'count' => 0, 'pattern' => '.tmp'),
				array('enable' => true, 'count' => 0, 'pattern' => '_vti_'),
				array('enable' => true, 'count' => 0, 'pattern' => '.zlib'),
				
				// new 2024 10 30
				
				array('enable' => true, 'count' => 0, 'pattern' => '/force-download.php'),
				array('enable' => true, 'count' => 0, 'pattern' => '/framework/main.php'),
				
			),
			
			'query_string' => array(
				
				array('enable' => true, 'count' => 0, 'pattern' => '^'),
				array('enable' => true, 'count' => 0, 'pattern' => '<'),
				array('enable' => true, 'count' => 0, 'pattern' => '>'),
				array('enable' => true, 'count' => 0, 'pattern' => '['),
				array('enable' => true, 'count' => 0, 'pattern' => ']'),
				
				array('enable' => true, 'count' => 0, 'pattern' => '{'),
				array('enable' => true, 'count' => 0, 'pattern' => '}'),
				array('enable' => true, 'count' => 0, 'pattern' => '?'),
				array('enable' => true, 'count' => 0, 'pattern' => '`'),
				array('enable' => true, 'count' => 0, 'pattern' => '\\'),
				
				array('enable' => true, 'count' => 0, 'pattern' => '@@'),
				array('enable' => true, 'count' => 0, 'pattern' => '/='),
				array('enable' => true, 'count' => 0, 'pattern' => '/$&'),
				array('enable' => true, 'count' => 0, 'pattern' => '/:/'),
				array('enable' => true, 'count' => 0, 'pattern' => '/**/'),
				
				array('enable' => true, 'count' => 0, 'pattern' => '(0x'),
				array('enable' => true, 'count' => 0, 'pattern' => '0x3c62723e'),
				array('enable' => true, 'count' => 0, 'pattern' => ';!--='),
				
				array('enable' => true, 'count' => 0, 'pattern' => 'GLOBALS='),
				array('enable' => true, 'count' => 0, 'pattern' => 'GLOBALS['),
				array('enable' => true, 'count' => 0, 'pattern' => 'GLOBALS%'),
				array('enable' => true, 'count' => 0, 'pattern' => 'REQUEST['),
				array('enable' => true, 'count' => 0, 'pattern' => 'REQUEST%'),
				
				array('enable' => true, 'count' => 0, 'pattern' => '+select+'),
				array('enable' => true, 'count' => 0, 'pattern' => '+delete+'),
				array('enable' => true, 'count' => 0, 'pattern' => '+concat+'),
				array('enable' => true, 'count' => 0, 'pattern' => '+union+'),
				
				array('enable' => true, 'count' => 0, 'pattern' => 'boot.ini'),
				array('enable' => true, 'count' => 0, 'pattern' => 'win.ini'),
				array('enable' => true, 'count' => 0, 'pattern' => '/makefile'),
				array('enable' => true, 'count' => 0, 'pattern' => '/wwwroot'),
				
				array('enable' => true, 'count' => 0, 'pattern' => '$_env'),
				array('enable' => true, 'count' => 0, 'pattern' => '$_files'),
				array('enable' => true, 'count' => 0, 'pattern' => '$_get'),
				array('enable' => true, 'count' => 0, 'pattern' => '$_post'),
				array('enable' => true, 'count' => 0, 'pattern' => '$_request'),
				array('enable' => true, 'count' => 0, 'pattern' => '$_server'),
				array('enable' => true, 'count' => 0, 'pattern' => '$_session'),
				
				array('enable' => true, 'count' => 0, 'pattern' => 'inurl:/'),
				array('enable' => true, 'count' => 0, 'pattern' => 'http://'),
				array('enable' => true, 'count' => 0, 'pattern' => 'https://'),
				array('enable' => true, 'count' => 0, 'pattern' => 'ftp://'),
				array('enable' => true, 'count' => 0, 'pattern' => 'sftp://'),
				array('enable' => true, 'count' => 0, 'pattern' => 'ftps://'),
				array('enable' => true, 'count' => 0, 'pattern' => 'php://'),
				array('enable' => true, 'count' => 0, 'pattern' => 'phps://'),
				
				// new 2024 10 30
				
				array('enable' => true, 'count' => 0, 'pattern' => '0x00'),
				array('enable' => true, 'count' => 0, 'pattern' => '%00'),
				array('enable' => true, 'count' => 0, 'pattern' => '%0d%0a'),
				array('enable' => true, 'count' => 0, 'pattern' => '+get+'),
				
				array('enable' => true, 'count' => 0, 'pattern' => '/_mm'),
				array('enable' => true, 'count' => 0, 'pattern' => '/cgi.'),
				array('enable' => true, 'count' => 0, 'pattern' => '/cgi-'),
				
			),
			
			'user_agent' => array(
				
				array('enable' => true, 'count' => 0, 'pattern' => '<'),
				array('enable' => true, 'count' => 0, 'pattern' => '>'),
				array('enable' => true, 'count' => 0, 'pattern' => '$x0E'),
				array('enable' => true, 'count' => 0, 'pattern' => '@$x'),
				array('enable' => true, 'count' => 0, 'pattern' => '&lt;?'),
				
				array('enable' => true, 'count' => 0, 'pattern' => '!susie'),
				array('enable' => true, 'count' => 0, 'pattern' => '_irc'),
				array('enable' => true, 'count' => 0, 'pattern' => '_works'),
				array('enable' => true, 'count' => 0, 'pattern' => '+select+'),
				array('enable' => true, 'count' => 0, 'pattern' => '+union+'),
				
				array('enable' => true, 'count' => 0, 'pattern' => '/bin/bash'),
				array('enable' => true, 'count' => 0, 'pattern' => '0x00'),
				array('enable' => true, 'count' => 0, 'pattern' => '1,1,1,'),
				array('enable' => true, 'count' => 0, 'pattern' => '3gse'),
				array('enable' => true, 'count' => 0, 'pattern' => '4all'),
				
				array('enable' => true, 'count' => 0, 'pattern' => 'archiver'),
				array('enable' => true, 'count' => 0, 'pattern' => 'base64_decode'),
				array('enable' => true, 'count' => 0, 'pattern' => 'checkpriv'),
				array('enable' => true, 'count' => 0, 'pattern' => 'clshttp'),
				array('enable' => true, 'count' => 0, 'pattern' => 'curious'),
				
				array('enable' => true, 'count' => 0, 'pattern' => 'disconnect'),
				array('enable' => true, 'count' => 0, 'pattern' => 'extract'),
				array('enable' => true, 'count' => 0, 'pattern' => 'g00g1e'),
				array('enable' => true, 'count' => 0, 'pattern' => 'grab'),
				array('enable' => true, 'count' => 0, 'pattern' => 'harvest'),
				
				array('enable' => true, 'count' => 0, 'pattern' => 'httrack'),
				array('enable' => true, 'count' => 0, 'pattern' => 'icarus6j'),
				array('enable' => true, 'count' => 0, 'pattern' => 'jakarta'),
				array('enable' => true, 'count' => 0, 'pattern' => 'libwww'),
				array('enable' => true, 'count' => 0, 'pattern' => 'loader'),
				
				array('enable' => true, 'count' => 0, 'pattern' => 'md5sum'),
				array('enable' => true, 'count' => 0, 'pattern' => 'miner'),
				array('enable' => true, 'count' => 0, 'pattern' => 'mj12'),
				array('enable' => true, 'count' => 0, 'pattern' => 'nikto'),
				array('enable' => true, 'count' => 0, 'pattern' => 'phpshell'),
				
				array('enable' => true, 'count' => 0, 'pattern' => 'python'),
				array('enable' => true, 'count' => 0, 'pattern' => 'queryseeker'),
				array('enable' => true, 'count' => 0, 'pattern' => 'remoteview'),
				array('enable' => true, 'count' => 0, 'pattern' => 'seekerspider'),
				array('enable' => true, 'count' => 0, 'pattern' => 'siclab'),
				
				array('enable' => true, 'count' => 0, 'pattern' => 'sux0r'),
				array('enable' => true, 'count' => 0, 'pattern' => 'unserialize'),
				array('enable' => true, 'count' => 0, 'pattern' => 'wget'),
				array('enable' => true, 'count' => 0, 'pattern' => 'winhttp'),
				array('enable' => true, 'count' => 0, 'pattern' => 'xv6875)'),
				
				array('enable' => true, 'count' => 0, 'pattern' => 'youda'),
				
				// new 2024 10 30
				
				array('enable' => true, 'count' => 0, 'pattern' => 'wwwoffle'),
				array('enable' => true, 'count' => 0, 'pattern' => 'xxxyy'),
				array('enable' => true, 'count' => 0, 'pattern' => 'zune'),
				array('enable' => true, 'count' => 0, 'pattern' => 'takeout'),
				array('enable' => true, 'count' => 0, 'pattern' => 'true_robots'),
				
				array('enable' => true, 'count' => 0, 'pattern' => 'telesoft'),
				array('enable' => true, 'count' => 0, 'pattern' => 'siteexplorer'),
				array('enable' => true, 'count' => 0, 'pattern' => 'smartdownload'),
				array('enable' => true, 'count' => 0, 'pattern' => 'sqlmap'),
				array('enable' => true, 'count' => 0, 'pattern' => 'sitesnagger'),
				
				array('enable' => true, 'count' => 0, 'pattern' => 'pagegrabber'),
				array('enable' => true, 'count' => 0, 'pattern' => 'petalbot'),
				array('enable' => true, 'count' => 0, 'pattern' => 'realdownload'),
				array('enable' => true, 'count' => 0, 'pattern' => 'mj12bot'),
				array('enable' => true, 'count' => 0, 'pattern' => 'moveoverbot'),
				
				array('enable' => true, 'count' => 0, 'pattern' => 'linkscan'),
				array('enable' => true, 'count' => 0, 'pattern' => 'masscan'),
				array('enable' => true, 'count' => 0, 'pattern' => 'grabnet'),
				array('enable' => true, 'count' => 0, 'pattern' => 'leechftp'),
				array('enable' => true, 'count' => 0, 'pattern' => 'getright'),
				
				array('enable' => true, 'count' => 0, 'pattern' => 'dotnet'),
				array('enable' => true, 'count' => 0, 'pattern' => 'eventures'),
				array('enable' => true, 'count' => 0, 'pattern' => 'cheesebot'),
				array('enable' => true, 'count' => 0, 'pattern' => 'chinaclaw'),
				array('enable' => true, 'count' => 0, 'pattern' => 'cmsworld'),
				
				array('enable' => true, 'count' => 0, 'pattern' => 'spyder'),
				array('enable' => true, 'count' => 0, 'pattern' => 'backdor'),
				array('enable' => true, 'count' => 0, 'pattern' => 'webshell'),
				
			),
			
		),
		
		'custom' => array(
			
			'request_uri'  => array(),
			'query_string' => array(),
			'user_agent'   => array(),
			'ip_address'   => array(),
			'referrer'     => array(),
			
		),
		
	);
	
}