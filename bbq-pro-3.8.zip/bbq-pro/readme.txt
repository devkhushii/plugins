=== BBQ Pro ===

Plugin Name: BBQ Pro
Plugin URI: https://plugin-planet.com/bbq-pro/
Description: The fastest firewall plugin for WordPress. Advanced protection against a wide range of threats.
Tags: firewall, security, web application firewall, waf
Author: Jeff Starr
Contributors: specialk
Author URI: https://plugin-planet.com/
Donate link: https://monzillamedia.com/donate.html
Requires at least: 4.6
Tested up to: 6.7
Stable tag: 3.8
Version:    3.8
Requires PHP: 5.6.20
Text Domain: bbq-pro
Domain Path: /languages
License: BBQ Pro is comprised of two parts (see "License" section below for details)

The lightest, fastest firewall plugin for WordPress. Advanced protection against a wide range of threats.



== Description ==

> Install, activate, and done!
> Powerful protection from WP's __fastest__ firewall plugin.

[BBQ Pro](https://plugin-planet.com/bbq-pro/) helps keep your WordPress site safe and secure by blocking attacks and bad requests. This helps to conserve precious server resources like memory and bandwidth. BBQ Pro is built to be extensible, flexible, and blazing fast. It checks all incoming traffic and quietly blocks any URI requests that contain nasty stuff like `eval(`, `base64(`, `exec(`, and other malicious patterns. BBQ Pro is fully customizable, giving you control over every pattern and rule. You can edit, remove, add, and/or test BBQ patterns via easy-to-use settings screens.

> Adds a strong firewall to ANY WordPress site
> Works with all WordPress plugins and themes


### Powerful Protection ###

BBQ Pro protects your site against many threats:

* SQL injection attacks
* Executable file uploads
* Directory traversal attacks
* Unsafe character requests
* Excessively long requests
* PHP remote/file execution
* XSS, XXE, and related attacks
* Protects against bad bots
* Protects against bad referrers
* Protects against [user-ID phishing](https://plugin-planet.com/bbq-pro-block-user-id-phishing/)
* Plus many other bad requests

> Works great with [Blackhole for Bad Bots](https://wordpress.org/plugins/blackhole-bad-bots/) and [Blackhole Pro](https://plugin-planet.com/blackhole-pro/)


### Awesome Features ###

* Rated [5 stars](https://wordpress.org/plugins/block-bad-queries/#reviews) at WordPress.org
* 100% plug-&amp;-play, zero configuration
* 100% focused on security and performance
* Blocks a wide range of malicious URL requests
* Fastest Web Application Firewall (WAF) for WordPress
* Based on the [6G](https://perishablepress.com/6g/)/[7G Firewall](https://perishablepress.com/7g-firewall/)
* Scans all incoming traffic and blocks bad requests
* Scans all types of requests: GET, POST, PUT, DELETE, etc.
* Protects against known bad bots and referrers
* Works silently behind the scenes to protect your site
* Hassle-free security plugin that's easy to use
* Thoroughly tested, error-free performance
* Extremely low rate of false positives
* Compatible with other security plugins
* Regularly updated and "future proof"
* Lightweight, fast and flexible

> BBQ = Block Bad Queries


### Pro Features ###

* Advanced protection against malicious requests
* Advanced configuration via easy-to-use settings screen
* Customize BBQ patterns to suit your security strategy
* Tracks the number of times each BBQ pattern blocks a request
* Includes tools to reset options, patterns, and statistics
* Option to display a custom message for all blocked requests
* Option to specify a redirect URL for blocked requests
* Option to disable firewall for logged-in users
* Option to whitelist IP addresses and User Agents
* Set your own Status Code for blocked requests
* Built-in "test" buttons to test each BBQ pattern
* Add your own custom patterns to protect against threats
* Scans the Request URI, Query String, User Agent, IP Address, and Referrer

BBQ Pro is the premium version of the free [BBQ Firewall](https://wordpress.org/plugins/block-bad-queries/).

[Learn more about BBQ Pro &raquo;](https://plugin-planet.com/bbq-pro/)


### Privacy ###

This plugin does not collect or store any user data. It does not set any cookies, and it does not connect to any third-party locations. Thus, this plugin does not affect user privacy in any way.



== Screenshots ==

[Screenshots available at Plugin Planet](https://plugin-planet.com/bbq-pro/#screenshots)



== Installation ==

### Installing BBQ Pro ###

1. Download a zipped copy of BBQ Pro from Plugin Planet
2. Unzip and upload the `/bbq-pro/` folder to `/wp-content/plugins/`
3. Visit the WordPress Plugins screen to activate BBQ Pro
4. Visit BBQ Pro License to activate the license
5. Visit BBQ Pro Settings to configure options

Step 5 is optional; by default BBQ Pro works just like the free version of BBQ, silently protecting your site with no configuration required. To customize the plugin, visit the BBQ Settings and BBQ Patterns.

__Note:__ BBQ includes complete inline documentation; click the "Help" tab in the upper-right corner of any BBQ settings screen for more information.

[Get started using BBQ Pro](https://plugin-planet.com/bbq-pro-quick-start/)

[More info on installing WP plugins](https://wordpress.org/support/article/managing-plugins/#installing-plugins)


### Upgrades ###

Your purchase of USP Pro includes free lifetime upgrades, which include new features, bug fixes, and other improvements. When an upgrade is available, WordPress will notify you in the Admin Area. When you see that there is an update available, just click "Update" and WordPress will perform the upgrade automatically. Note that you can [download the latest version of USP Pro at Plugin Planet](https://plugin-planet.com/download-purchased-plugin/) anytime at your convenience.


### New BBQ Patterns ###

When new patterns are available, they can be enabled via "Reset Patterns" under the Tools menu. 


### Uninstall/Reset ###

At any time you may visit the "Tools" screen to reset default settings, patterns, and statistics. Also, uninstalling the plugin from the WP Plugins screen results in the removal of all settings and data from the WP database.


### Developer ###

BBQ Pro is developed and maintained by [Jeff Starr](https://twitter.com/perishable), 15-year [WordPress developer](https://plugin-planet.com/) and [book author](https://books.perishablepress.com/).


### Like the plugin? ###

If you like BBQ Pro, please take a moment to [give a 5-star rating](https://wordpress.org/support/plugin/block-bad-queries/reviews/?rate=5#new-post). It helps to keep development and support going strong. Thank you!



== Upgrade Notice ==

This plugin has been tested and is 100% current with the latest version of WordPress.



== Usage ==

* Install, activate, and done -- no configuration required for basic BBQ protection
* To configure plugin settings, visit BBQ's "Settings" screen
* To customize the patterns used to block bad requests, visit BBQ's "Patterns" screen
* To reset settings, patterns, and statistics, visit BBQ's "Tools" screen
* To enter your license and enable the plugin, visit BBQ's "License" screen

__Note:__ BBQ includes complete inline documentation; click the "Help" tab in the upper-right corner of any BBQ settings screen for more information.



== Resources ==

Some useful resources for BBQ Pro:

= Getting started =

* [BBQ Pro Homepage](https://plugin-planet.com/bbq-pro/)
* [BBQ Pro Quick Start Guide](https://plugin-planet.com/bbq-pro-quick-start/)
* [BBQ Pro readme.txt](https://plugin-planet.com/wp/files/bbq-pro/readme.txt)
* [BBQ Pro Settings](https://plugin-planet.com/bbq-pro-settings/)
* [BBQ Pro FAQs](https://plugin-planet.com/bbq-pro-faqs/)

= License Information =

* [Guide: Install Plugin](https://plugin-planet.com/install-plugin/)
* [Guide: Get plugin license key](https://plugin-planet.com/get-license-key/)
* [Guide: Activate Plugin License](https://plugin-planet.com/activate-deactivate-plugin-license/)
* [More info on installing WP plugins](https://codex.wordpress.org/Managing_Plugins#Installing_Plugins)

= Further resources =

* [BBQ Pro Docs](https://plugin-planet.com/docs/bbq/)
* [BBQ Pro Forum](https://plugin-planet.com/forum/bbq/)
* [BBQ Pro Tutorials](https://plugin-planet.com/category/tuts+bbq-pro/)
* [BBQ Pro News](https://plugin-planet.com/category/news+bbq-pro/)

= Feedback and downloads =

* [Bug reports, help requests, and feedback](https://plugin-planet.com/support/#contact)
* [Log in to your account for current downloads](https://plugin-planet.com/wp/wp-login.php)

= Screenshots and more =

* [Learn more about BBQ Pro](https://plugin-planet.com/bbq-pro/)
* [Screenshots and more available](https://plugin-planet.com/bbq-pro/#screenshots)

Need help? Reach us anytime via our [contact form](https://plugin-planet.com/support/#contact).



== Frequently Asked Questions ==

Check out the [BBQ Pro FAQs](https://plugin-planet.com/bbq-pro-faqs/) at Plugin Planet.


### Questions? Feedback? Bugs? ###

There are two channels for getting help:

* [Ask a question in the BBQ Pro Forum](https://plugin-planet.com/forum/bbq/) ([login required](https://plugin-planet.com/wp/wp-login.php))
* [Send an email via the contact form](https://plugin-planet.com/support/#contact)

The contact form is best for direct support, bug reports, and feedback.



== License ==

The BBQ Pro license comprises two parts:

* __Part 1:__ Its PHP code is licensed under the GPL (v3 or later), like WordPress. [More info](https://www.gnu.org/licenses/).
* __Part 2:__ Everything else (e.g., CSS, HTML, JavaScript, images, design) is licensed according to the purchased license. [More info](https://plugin-planet.com/bbq-pro/).

Without prior written consent from Monzilla Media, you must NOT directly or indirectly: license, sub-license, sell, resell, or provide for free any aspect or component of Part 2.

Further license information is available in the plugin directory, `/license/`, and [online](https://plugin-planet.com/wp/files/bbq-pro/license.txt).

__Upgrades:__ Your purchase of BBQ Pro includes free lifetime upgrades, which include new features, bug fixes, and other improvements. 

Copyright 2024 Monzilla Media. All rights reserved.



== More from Jeff Starr ==

Premium WordPress plugins:

* [Banhammer Pro](https://plugin-planet.com/banhammer-pro/)    - Monitor traffic and ban bad users and bots
* [BBQ Pro](https://plugin-planet.com/bbq-pro/)                - Fastest firewall plugin for WordPress
* [Blackhole Pro](https://plugin-planet.com/blackhole-pro/)    - Block bad bots in a virtual black hole
* [GA Pro](https://plugin-planet.com/ga-google-analytics-pro/) - Connect WordPress to Google Analytics
* [SAC Pro](https://plugin-planet.com/simple-ajax-chat-pro/)   - Unlimited chat rooms for WordPress
* [USP Pro](https://plugin-planet.com/usp-pro/)                - Advanced front-end forms

Quality WordPress books:

* [The Tao of WordPress](https://wp-tao.com/)
* [Digging into WordPress](https://digwp.com/)
* [.htaccess made easy](https://htaccessbook.com/)
* [WordPress Themes In Depth](https://wp-tao.com/wordpress-themes-book/)
* [Wizard's SQL Recipes for WordPress](https://books.perishablepress.com/downloads/wizards-collection-sql-recipes-wordpress/)

More awesome stuff on the way :)



== Changelog ==

If you like BBQ Pro, please take a moment to [give a 5-star rating](https://wordpress.org/support/plugin/block-bad-queries/reviews/?rate=5#new-post). It helps to keep development and support going strong. Thank you!


= 3.8 (2024/10/30) =

* Adds new 8G patterns to firewall rules
* Adds "export patterns" to BBQ Tools
* Updates some existing patterns
* Updates license update script
* Updates plugin Help tab information
* Updates plugin settings page
* Updates default translation template
* Tests on WordPress 6.7 (beta)


Full changelog @ [https://plugin-planet.com/wp/changelog/bbq-pro.txt](https://plugin-planet.com/wp/changelog/bbq-pro.txt)
