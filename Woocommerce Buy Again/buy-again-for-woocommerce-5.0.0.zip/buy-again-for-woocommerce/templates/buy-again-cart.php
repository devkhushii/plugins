<?php
/**
 * This template displays Buy Again Products in cart
 *
 * This template can be overridden by copying it to yourtheme/buy-again-for-woocommerce/buy-again-cart.php
 *
 * To maintain compatibility, buy again will update the template files and you have to copy the updated files to your theme
 *
 * @package Buy Again for Woocommerce
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>

<?php
foreach ( $product_ids as $product_args ) :
	$product_id   = $product_args['product_id'];
	$variation_id = $product_args['variation_id'];
	$product_obj  = wc_get_product( $product_id );

	if ( $variation_id ) {
		$product_obj = wc_get_product( $variation_id );
	}

	if ( ! is_object( $product_obj ) ) {
		continue;
	}

	$product_price = ( 'excl' === get_option( 'woocommerce_tax_display_cart' ) ) ? wc_get_price_excluding_tax( $product_obj ) : wc_get_price_including_tax( $product_obj );
	$quantity_id   = ( $variation_id ) ? 'bya_qty_' . $variation_id : 'bya_qty_' . $product_id;
	$quantity_max  = $product_obj->backorders_allowed() ? '' : $product_obj->get_stock_quantity();
	?>
		<div class="bya-cart-product bya-owl-carousel-item wc-block-grid__product">
			<a href="<?php echo esc_url( $product_obj->get_permalink() ); ?>" class="bya-cart-product-link wc-block-grid__product-link">
			<?php
				$feature_image = wp_get_attachment_image_src( get_post_thumbnail_id( esc_attr( $product_id ) ), 'thumbnail' );
			if ( $product_obj->get_image_id() && bya_check_is_array( $feature_image ) ) {
				?>
						<img class="bya_product_img" src="<?php echo esc_url( $feature_image[0] ); ?>" data-id="<?php echo esc_attr( $product_id ); ?>">
					<?php
			} else {
				printf( '<img src="%s" alt="%s" class="bya_product_img" />', esc_url( wc_placeholder_img_src( 'woocommerce_single' ) ), esc_html__( 'Awaiting product image', 'woocommerce' ) );
			}
			?>
			</a>
			<div class="bya-cart-product-title wc-block-grid__product-title"><?php echo esc_attr( $product_obj->get_title() ); ?></div>
			<div class="bya-cart-product-price wc-block-grid__product-price price">
				<?php
				/**
				 * Woocommerce Price HTML.
				 *
				 * @since 1.0.0
				 * */
				echo wp_kses_post( apply_filters( 'woocommerce_get_price_html', wc_price( $product_price ), $product_obj ) );
				?>
			</div>
			<?php
			$args = array(
				'product_id'              => $product_id,
				'variation_id'            => $variation_id,
				'quantity_id'             => $quantity_id,
				'add_to_cart_class'       => 'bya_add_to_cart_' . $product_id,
				'add_to_cart_ajax_enable' => bya_add_to_cart_ajax_enable(),
				'cartlink'                => '?add-to-cart=' . $product_id,
				'qty_allow'               => false,
				'bya_order_id'            => $product_args['order_id'],
				'page'                    => get_option( 'woocommerce_myaccount_view_order_endpoint', 'view-order' ),
			);

			bya_get_template( 'display-input-fields.php', $args );
			?>
		</div>
		<?php
	endforeach;
?>
