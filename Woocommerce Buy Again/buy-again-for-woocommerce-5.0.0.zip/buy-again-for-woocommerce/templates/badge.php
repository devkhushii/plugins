<?php
/**
 * This template is used for displaying the batch.
 *
 * This template can be overridden by copying it to yourtheme/buy-again-for-woocommerce/loop/badge.php
 *
 * To maintain compatibility, Buy Again will update the template files and you have to copy the updated files to your theme
 *
 * @package Buy Again/Templates
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

global $product;
?>
<div class="bya-badge">
	<?php if ( '3' === get_option( 'bya_display_tag_image_options' ) ) { ?>
		<img src="<?php echo esc_url( bya_get_badge_image() ); ?>">
		<?php
	} else {
		?>
		<strong>
			<?php echo esc_html( get_option( 'bya_general_tag_label', 'Buy Again' ) ); ?>
		</strong>
		<?php
	}
	?>
</div>
