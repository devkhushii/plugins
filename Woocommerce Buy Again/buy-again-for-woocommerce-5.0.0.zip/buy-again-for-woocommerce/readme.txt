=== Buy Again for WooCommerce ===
Contributors: Flintop
Tags: woocommerce buy again, buy again plugin
Requires at least: 4.6
Tested up to: 6.7.1
WC Tested up to: 9.5.1
Requires PHP: 5.6
Stable tag: 5.0.0
