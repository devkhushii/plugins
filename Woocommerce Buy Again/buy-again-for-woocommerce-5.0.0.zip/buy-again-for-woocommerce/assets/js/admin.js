/* global bya_admin_params, ajaxurl */

jQuery(function ($) {
	'use strict';

	var BYA_Admin = {
		init: function () {
			this.trigger_on_page_load();
			//Advanced Settings
			$(document).on('change', '#bya_advanced_allow_products', this.toggle_allow_products);
			$(document).on('change', '#bya_advanced_allow_users', this.toggle_allow_users);
			$(document).on('change', '#bya_advanced_allow_filter_btn', this.toggle_show_filter_button);
			$(document).on('change', '#bya_advanced_buy_again_table_product_img_disp', this.toggle_image_disp_type);
			$(document).on('change', '.bya-tag-img-opt', this.changeTagImageOption);
			$(document).on('click', '.bya_general_upload_badge_image_url_button', this.uploadTagImage);
			//General Settings
			$(document).on('change', '#bya_general_show_buy_again_notice', this.toggle_buy_again_notice);
			$(document).on('change', '.bya-my-order-order-again-opt', this.toggle_order_again_fields);
		}, trigger_on_page_load: function () {
			this.allow_products('#bya_advanced_allow_products');
			this.allow_users('#bya_advanced_allow_users');
			this.buy_again_notice('#bya_general_show_buy_again_notice');
			this.order_again_fields('.bya-my-order-order-again-opt');
			this.image_disp_type('#bya_advanced_buy_again_table_product_img_disp');
			this.show_filter_button_opt('#bya_advanced_allow_filter_btn');

			$.each($('.bya-tag-img-opt'), function () {
				BYA_Admin.tagImageOptionChange(this);
			});
		},

		toggle_show_filter_button: function (event) {
			event.preventDefault();
			var $this = $(event.currentTarget);
			BYA_Admin.show_filter_button_opt($this);
		}, show_filter_button_opt: function ($this) {
			if (true === $($this).prop('checked')) {
				$('.bya_filter_option_fields').closest('tr').show();
			} else {
				$('.bya_filter_option_fields').closest('tr').hide();
			}
		},

		toggle_allow_products: function (event) {
			event.preventDefault();
			var $this = $(event.currentTarget);
			BYA_Admin.allow_products($this);
		}, allow_products: function ($this) {
			$('.bya_allow_product_option').closest('tr').hide();
			if ($($this).val() === '2') {
				$('#bya_advanced_include_product').closest('tr').show();
			} else if ($($this).val() === '3') {
				$('#bya_advanced_exclude_product').closest('tr').show();
			} else if ($($this).val() === '4') {
				$('#bya_advanced_include_category').closest('tr').show();
			} else if ($($this).val() === '5') {
				$('#bya_advanced_exclude_category').closest('tr').show();
			}
		},

		toggle_allow_users: function (event) {
			event.preventDefault();
			var $this = $(event.currentTarget);
			BYA_Admin.allow_users($this);
		}, allow_users: function ($this) {
			$('.bya_allow_user_option').closest('tr').hide();
			if ($($this).val() === '2') {
				$('#bya_advanced_include_user').closest('tr').show();
			} else if ($($this).val() === '3') {
				$('#bya_advanced_exclude_user').closest('tr').show();
			} else if ($($this).val() === '4') {
				$('#bya_include_user_role').closest('tr').show();
			} else if ($($this).val() === '5') {
				$('#bya_exclude_user_role').closest('tr').show();
			}
		},

		toggle_order_again_fields: function (event) {
			event.preventDefault();
			var $this = $(event.currentTarget);
			BYA_Admin.order_again_fields($this);
		}, order_again_fields: function ($this) {
			if (true === $($this).prop("checked")) {
				$('.bya-my-order-buy-again-fields').closest('tr').show();
			} else {
				$('.bya-my-order-buy-again-fields').closest('tr').hide();
			}
		},

		toggle_buy_again_notice: function (event) {
			event.preventDefault();
			var $this = $(event.currentTarget);
			BYA_Admin.buy_again_notice($this);
		}, buy_again_notice: function ($this) {
			if (true == $($this).prop("checked")) {
				$('#bya_general_buy_again_message').closest('tr').show();
				$('#bya_general_order_detail_link_caption').closest('tr').show();
			} else {
				$('#bya_general_buy_again_message').closest('tr').hide();
				$('#bya_general_order_detail_link_caption').closest('tr').hide();
			}
		},

		toggle_image_disp_type: function (event) {
			event.preventDefault();
			var $this = $(event.currentTarget);
			BYA_Admin.image_disp_type($this);
		}, image_disp_type: function ($this) {
			if ('1' == $($this).val()) {
				$('.bya_product_img_size').closest('tr').hide();
			} else {
				$('.bya_product_img_size').closest('tr').show();
			}
		},

		changeTagImageOption(e) {
			e.preventDefault();
			BYA_Admin.tagImageOptionChange(this);
		}, tagImageOptionChange($this) {
			if ('3' === $($this).val() && $($this).is(':checked')) {
				$('.bya_general_upload_badge_image_url').closest('tr').show();
				$('.bya-default-styles-field').closest('tr').hide();
			} else {
				$('.bya_general_upload_badge_image_url').closest('tr').hide();
				$('.bya-default-styles-field').closest('tr').show();

				if ('1' !== $($this).val() && $($this).is(':checked')) {
					$('#bya_general_tag_position').closest('tr').hide();
				} else {
					$('#bya_general_tag_position').closest('tr').show();
				}
			}
		},

		uploadTagImage(e) {
			e.preventDefault();
			// Upload Batch Image.
			var file_frame,
				$button = $(this),
				formfield = $(this).prev();

			// If the media frame already exists, reopen it.
			if (file_frame) {
				file_frame.open();
				return;
			}

			// Create the media frame.
			file_frame = wp.media.frames.file_frame = wp.media({
				frame: 'select',
				title: $button.data('title'), // Set the title of the modal.
				multiple: false,
				library: {
					type: 'image'
				},
				button: {
					text: $button.data('button')
				}
			});

			// When an image is selected, run a callback.
			file_frame.on('select', function () {
				let file_path = '',
					selection = file_frame.state().get('selection');

				selection.map(function (attachment) {
					attachment = attachment.toJSON();
					if (attachment.url) {
						file_path = attachment.url;
					}
				});
				formfield.val(file_path);

				let img = $('<img />');
				img.attr('src', file_path);
				// Replace previous image with new one if selected.
				$('#bya_general_upload_badge_image_url_preview').empty().append(img);
			});
			// Finally, open the modal.
			file_frame.open();
		},

		block: function (id) {
			$(id).block({
				message: null,
				overlayCSS: {
					background: '#fff',
					opacity: 0.7
				}
			});
		}, unblock: function (id) {
			$(id).unblock();
		},
	};
	BYA_Admin.init();
});
