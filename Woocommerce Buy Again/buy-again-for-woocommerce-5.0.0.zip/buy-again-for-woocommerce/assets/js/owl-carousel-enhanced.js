/* global bya_carousel_params */

jQuery(function ($) {
	'use strict';

	try {

		$(document.body).on('bya-enhanced-carousel', function () {

			var owl_carousels = $('.bya-owl-carousel-items');

			if (!owl_carousels.length) {
				return;
			}

			owl_carousels.each(function (e) {
				$(this).owlCarousel({
					margin: 10,
					responsiveClass: true,
					nav: true,
					navText: ['<', '>'],
					autoplay: false,
					dots: true,
					slideBy: bya_carousel_params.item_per_slide,
					responsive: {
						0: {
							items: 1,
						},
						600: {
							items: 2,
						},
						1000: {
							items: bya_carousel_params.per_page,
						}
					}
				});
			});
		});

		// Initialize carousel when cart updated.
		$(document.body).on('updated_wc_div', function () {
			$(document.body).trigger('bya-enhanced-carousel');
		});

		$(document.body).trigger('bya-enhanced-carousel');
	} catch (err) {
		window.console.log(err);
	}
});
