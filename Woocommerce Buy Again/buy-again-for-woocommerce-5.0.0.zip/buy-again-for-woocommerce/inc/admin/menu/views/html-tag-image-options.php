<?php
/**
 * Admin HTML Settings
 *
 * @package Custom Pricing/Admin/HTML
 * */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

$selected_tag = get_option( 'bya_display_tag_image_options', '1' );
?>
<tr>
	<th><?php esc_html_e( 'Tag Style', 'buy-again-for-woocommerce' ); ?></th>
	<td>
		<div class="bya-tag-img-wrapper">
			<p>
				<input id="bya_style1" name="bya_display_tag_image_options" type="radio" value="1" class="bya-tag-img-opt bya-tag-img-opt-1" <?php checked( $selected_tag, '1', true ); ?>>
				<label for="bya_style1"><?php esc_html_e( 'Style 1', 'buy-again-for-woocommerce' ); ?></label>
				<img src="<?php echo esc_url( BYA_PLUGIN_URL . '/assets/images/tag-1.png' ); ?>" class="bya-tag-image-preview"/>
			</p>
			<p>
				<input id="bya_style2" name="bya_display_tag_image_options" type="radio" value="2" class="bya-tag-img-opt bya-tag-img-opt-2" <?php checked( $selected_tag, '2', true ); ?>/>
				<label for="bya_style2"><?php esc_html_e( 'Style 2', 'buy-again-for-woocommerce' ); ?></label>
				<img src="<?php echo esc_url( BYA_PLUGIN_URL . '/assets/images/tag-2.png' ); ?>" class="bya-tag-image-preview">
			</p>

			<p>
				<input id="bya_style_custom" name="bya_display_tag_image_options" type="radio" value="3" class="bya-tag-img-opt bya-tag-img-opt-3 bya-tag-img-custom-opt" <?php checked( $selected_tag, '3', true ); ?>/>
				<label for="bya_style_custom"><?php esc_html_e( 'Custom Style', 'buy-again-for-woocommerce' ); ?></label>
			</p>
		</div>
	</td>
</tr>

<?php
