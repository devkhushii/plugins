<?php
/**
 * Action Scheduler for Multi Vendor
 *
 * @package Action Scheduler
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'BYA_Action_Scheduler' ) ) {
	/**
	 * Scheduler for user purchase history that uses the Action Scheduler
	 *
	 * @class BYA_Action_Scheduler
	 * @package Class
	 */
	class BYA_Action_Scheduler {

		/**
		 * An internal cache of action hooks and corresponding date types.
		 *
		 * @var array An array of $action_hook => $date_type values
		 */
		protected static $action_hooks = array();

		/**
		 * Init Function
		 *
		 * @since 4.9.0
		 */
		public static function init() {
			add_action( 'init', __CLASS__ . '::prepare_queue_events' );

			// Vendor Update.
			add_action( 'bya_customer_update_scheduler', __CLASS__ . '::customer_update_scheduler' );
		}

		/**
		 * Queue Setup
		 *
		 * @since 4.9.0
		 * */
		public static function prepare_queue_events() {
			if ( ! bya_is_plugin_active() ) {
				return;
			}

			self::update_customer_details();
		}

		/**
		 * Update Vendor Amount
		 *
		 * @since 4.9.0
		 * */
		public static function update_customer_details() {
			$next = WC()->queue()->get_next( 'bya_customer_update_scheduler' );

			if ( ! $next ) {
				WC()->queue()->cancel_all( 'bya_customer_update_scheduler' );
				WC()->queue()->schedule_recurring( time(), DAY_IN_SECONDS, 'bya_customer_update_scheduler', array(), 'BYA' );
			}
		}

		/**
		 * Update Customer Data.
		 *
		 * @since 4.9.0
		 * */
		public static function customer_update_scheduler() {
			var_dump('hello');
			$users                = get_users( array( 'fields' => array( 'ID' ) ) );
			$allowed_order_status = get_option( 'bya_general_order_status_to_show', array( 'processing', 'completed' ) );

			// Add the 'wc-' prefix to status if needed.
			if ( ! empty( $allowed_order_status ) ) {
				if ( is_array( $allowed_order_status ) ) {
					foreach ( $allowed_order_status as &$status ) {
						if ( wc_is_order_status( 'wc-' . $status ) ) {
							$status = 'wc-' . $status;
						}
					}
				}
			}

			foreach ( $users as $user ) {
				$customer_orders = get_posts(
					array(
						'numberposts' => -1,
						'meta_key'    => '_customer_user',
						'meta_value'  => $user->ID,
						'orderby'     => 'ID',
						'order'       => 'DESC',
						'post_type'   => wc_get_order_types(),
						'post_status' => $allowed_order_status,
						'fields'      => 'ids',
					)
				);

				foreach ( $customer_orders as $order_id ) {
					$order_obj = wc_get_order( $order_id );

					if ( ! is_a( $order_obj, 'WC_Order' ) ) {
						continue;
					}

					foreach ( $order_obj->get_items() as $item_id => $item ) {
						$product_obj = wc_get_product( $item->get_product_id() );

						if ( ! is_a( $product_obj, 'WC_Product' ) ) {
							continue;
						}

						$customer_logs = bya_get_customers(
							array(
								'user_id'      => $user->ID,
								'product_id'   => $item->get_product_id(),
								'variation_id' => $item->get_variation_id(),
							)
						);

						if ( ! $customer_logs->has_customer ) {
							$customer_obj = new BYA_Customer();
							$customer_obj->set_props(
								array(
									'product_id'    => $item->get_product_id(),
									'variation_id'  => $item->get_variation_id(),
									'user_id'       => $user->ID,
									'last_order_id' => $order_id,
									'qty'           => $item->get_quantity(),
									'email'         => $user->user_email,
								)
							);
							$customer_obj->save();
						}
					}
				}
			}

			update_option( 'bya_update_customer_data', current_time( 'timestamp' ) );
		}
	}

	BYA_Action_Scheduler::init();
}
