<?php
/**
 * Initialize the Plugin.
 *
 * @package Class
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'BYA_Install' ) ) {

	/**
	 * Class.
	 */
	class BYA_Install {

		/**
		 * Data Base Table.
		 *
		 * @var Array
		 * */
		public static $db_tables = array(
			'customer',
		);

		/**
		 *  Class initialization.
		 */
		public static function init() {
			add_action( 'init', array( __CLASS__, 'maybe_update_customer_data' ), 20 );
			add_action( 'admin_init', array( __CLASS__, 'check_db_tables' ) );
			add_action( 'woocommerce_init', array( __CLASS__, 'check_version' ) );
			add_filter( 'plugin_action_links_' . BYA_PLUGIN_SLUG, array( __CLASS__, 'settings_link' ) );
		}

		/**
		 * Check Database Tables are there.
		 *
		 * @since 4.9.0
		 * */
		public static function maybe_update_customer_data() {
			if ( false === get_option( 'bya_update_customer_data' ) ) {
				WC()->queue()->cancel_all( 'bya_customer_update_scheduler' );
				WC()->queue()->schedule_single( time(), 'bya_customer_update_scheduler' );
			}
		}

		/**
		 * Check Database Tables are there.
		 *
		 * @since 4.9.0
		 * */
		public static function check_db_tables() {
			global $wpdb;

			$wpdb_ref       = &$wpdb;
			$missing_tables = array();

			foreach ( self::$db_tables as $db_table ) {
				$db_table = "{$wpdb_ref->prefix}bya_" . $db_table;
				$result   = $wpdb_ref->get_var( $wpdb_ref->prepare( 'SHOW TABLES LIKE %s', $db_table ) );

				if ( $result !== $db_table ) {
					$missing_tables[] = $db_table;
				}
			}

			if ( bya_check_is_array( $missing_tables ) ) {
				/* translators: %s: Table Name */
				$message = sprintf( esc_html__( 'Buy Again plugin will not work properly some of Tables are missing in the database %s. Please verify the database.', 'buy-again-for-woocommerce' ), esc_html( implode( ', ', $missing_tables ) ) );

				BYA_Settings::add_error( $message );
			}
		}

		/**
		 * Check Version.
		 *
		 * @since 1.0
		 * */
		public static function check_version() {
			if ( version_compare( get_option( 'bya_version', 1.0 ), BYA_VERSION, '>=' ) ) {
				return;
			}

			// Set default values here.
			self::install();
		}

		/**
		 * Install
		 */
		public static function install() {
			BYA_Pages::create_pages(); // Create pages.
			self::set_default_values(); // Default values.
			self::update_version();
			self::create_tables(); // Create Tables.
			self::verify_base_tables(); // Verify base tables.
		}

		/**
		 * Creating Tables
		 *
		 * @since 4.9.0
		 */
		private static function create_tables() {
			global $wpdb;

			$wpdb->hide_errors();

			require_once ABSPATH . 'wp-admin/includes/upgrade.php';

			$db_delta_result = dbDelta( self::get_schema() );

			return $db_delta_result;
		}

		/**
		 * Table Schema
		 *
		 * @since 1.0.0
		 */
		private static function get_schema() {
			global $wpdb;

			$collate = '';

			if ( $wpdb->has_cap( 'collation' ) ) {
				$collate = $wpdb->get_charset_collate();
			}

			$tables = " CREATE TABLE `{$wpdb->prefix}bya_customer` (
						`ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
						`user_id` bigint(20) NOT NULL,
						`product_id` bigint(20) NOT NULL,
						`variation_id` bigint(20) NOT NULL,
						`last_order_id` bigint(20) NOT NULL,
						`qty` bigint(20) NOT NULL,
						`email` varchar(100) NULL default NULL,
						`date_created` datetime NOT NULL,
						`date_created_gmt` datetime NOT NULL,
						`created_via` varchar(20) NOT NULL,
						`date_modified` datetime NOT NULL,
						`date_modified_gmt` datetime NOT NULL,
						`version` varchar(20) NOT NULL,
						PRIMARY KEY  (`ID`),
						KEY `last_order_id` (`last_order_id`),
						KEY `product_id` (`product_id`),
						KEY `variation_id` (`variation_id`),
						KEY `user_id` (`user_id`)
						) $collate; 
						";

			return $tables;
		}

		/**
		 * Check if all the base tables are present.
		 *
		 * @since 1.0.0
		 * @param Boolean $execute       Whether to execute get_schema queries as well.
		 * @return Array List of queries.
		 */
		public static function verify_base_tables( $execute = false ) {
			if ( $execute ) {
				self::create_tables();
			}

			$missing_tables = self::get_missing_tables( self::get_schema() );

			if ( 0 < count( $missing_tables ) ) {
				$message  = esc_html__( 'Verifying database... One or more tables are still missing: ', 'buy-again-for-woocommerce' );
				$message .= implode( ', ', $missing_tables );

				BYA_Settings::add_error( $message );
			}

			return $missing_tables;
		}

		/**
		 * Get Missing Table
		 *
		 * @since 4.9.0
		 * @param String $creation_queries The output from the execution of dbDelta.
		 * @return Array.
		 */
		public static function get_missing_tables( $creation_queries ) {
			global $wpdb;

			$suppress_errors = $wpdb->suppress_errors( true );

			require_once ABSPATH . 'wp-admin/includes/upgrade.php';

			$output = dbDelta( $creation_queries, false );

			$wpdb->suppress_errors( $suppress_errors );

			$parsed_output = self::parse_dbdelta_output( $output );

			return $parsed_output['missing_tables'];
		}

		/**
		 * Parses the output given by dbdelta and returns information about it.
		 *
		 * @since 4.9.0
		 * @param Array $dbdelta_output The output from the execution of dbdelta.
		 * @return Array.
		 */
		public static function parse_dbdelta_output( array $dbdelta_output ) {
			$created_tables = array();

			foreach ( $dbdelta_output as $table_name => $result ) {
				if ( "Created table $table_name" !== $result ) {
					$created_tables[] = $table_name;
				}
			}

			return array( 'missing_tables' => array_filter( $created_tables ) );
		}

		/**
		 * Update current version.
		 */
		private static function update_version() {
			update_option( 'bya_version', BYA_VERSION );
		}

		/**
		 * Settings link.
		 *
		 * @since 1.0
		 * @param Array $links Settings Links.
		 * @return Array
		 */
		public static function settings_link( $links ) {
			$setting_page_link = '<a href="' . bya_get_settings_page_url() . '">' . esc_html__( 'Settings', 'buy-again-for-woocommerce' ) . '</a>';

			array_unshift( $links, $setting_page_link );

			return $links;
		}

		/**
		 *  Set settings default values
		 */
		public static function set_default_values() {
			if ( ! class_exists( 'BYA_Settings' ) ) {
				include_once BYA_PLUGIN_PATH . '/inc/admin/menu/class-bya-settings.php';
			}

			// Default for settings.
			$settings = BYA_Settings::get_settings_pages();

			foreach ( $settings as $setting ) {
				$sections = $setting->get_sections();

				if ( ! bya_check_is_array( $sections ) ) {
					continue;
				}

				foreach ( $sections as $section_key => $section ) {
					$settings_array = $setting->get_settings( $section_key );

					foreach ( $settings_array as $value ) {
						if ( isset( $value['default'] ) && isset( $value['id'] ) && get_option( $value['id'] ) === false ) {
							add_option( $value['id'], $value['default'] );
						}
					}
				}
			}
		}
	}

	BYA_Install::init();
}
