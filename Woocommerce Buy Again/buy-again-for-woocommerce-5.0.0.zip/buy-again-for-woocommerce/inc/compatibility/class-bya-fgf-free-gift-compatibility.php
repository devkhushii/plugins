<?php
/**
 * Free Gifts Compatibility.
 *
 * @package Buy Again/Free Gifts Compatibility.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'BYA_FGF_Free_Gift_Compatibility' ) ) {

	/**
	 * Class Declaration.
	 * */
	class BYA_FGF_Free_Gift_Compatibility extends BYA_Abstract_Compatibility {
		/**
		 * Class Constructor.
		 *
		 * @since 4.7.0
		 */
		public function __construct() {
			$this->id = 'fgf_free_gift';

			parent::__construct();
		}

		/**
		 * Is plugin enabled?.
		 *
		 * @since 1.0
		 * @return Boolean
		 * */
		public function is_plugin_enabled() {
			return class_exists( 'FP_Free_Gift' );
		}

		/**
		 * Hook in methods.
		 *
		 * @since 1.0
		 */
		public function actions() {
			add_filter( 'bya_allow_order_item', array( $this, 'validate_free_gift_item' ), 10, 4 );
		}

		/**
		 * Set Product Price
		 *
		 * @since 1.0
		 * @param Boolean       $bool Condition to set.
		 * @param Integer       $item_id Order Item identifier.
		 * @param WC_Order_Item $item Order Item.
		 * @param WC_Order      $order_obj Order object.
		 */
		public function validate_free_gift_item( $bool, $item_id, $item, $order_obj ) {
			if ( ! is_a( $item, 'WC_Order_Item_Product' ) ) {
				return $bool;
			}

			if ( ! bya_check_is_array( $item->get_meta_data() ) ) {
				return $bool;
			}

			foreach ( $item->get_meta_data() as $meta ) {
				if ( '_fgf_gift_product' === $meta->key ) {
					return false;
				}
			}

			return $bool;
		}
	}

}
