<?php
/**
 * WooCommerce Product Bundle Compatibility.
 *
 * @package Buy Again/WooCommerce Product Bundle Compatibility.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'BYA_Woo_Product_Bundle_Compatibility' ) ) {

	/**
	 * Class Declaration.
	 * */
	class BYA_Woo_Product_Bundle_Compatibility extends BYA_Abstract_Compatibility {
		/**
		 * Class Constructor.
		 *
		 * @since 4.7.0
		 */
		public function __construct() {
			$this->id = 'woo_product_bundle';

			parent::__construct();
		}

		/**
		 * Is plugin enabled?.
		 *
		 * @since 1.0
		 * @return Boolean
		 * */
		public function is_plugin_enabled() {
			return class_exists( 'WC_Bundles' );
		}

		/**
		 * Hook in methods.
		 *
		 * @since 1.0
		 */
		public function actions() {
			add_filter( 'bya_allow_order_item', array( $this, 'validate_bundled_product_item' ), 10, 4 );
		}

		/**
		 * Set Product Price
		 *
		 * @since 1.0
		 * @param Boolean       $bool Condition to set.
		 * @param Integer       $item_id Order Item identifier.
		 * @param WC_Order_Item $item Order Item.
		 * @param WC_Order      $order_obj Order object.
		 * @return Boolean
		 */
		public function validate_bundled_product_item( $bool, $item_id, $item, $order_obj ) {
			if ( ! is_a( $item, 'WC_Order_Item_Product' ) ) {
				return $bool;
			}

			if ( ! function_exists( 'wc_pb_get_bundled_order_item_container' ) ) {
				return $bool;
			}

			$bundle_container_order_item = wc_pb_get_bundled_order_item_container( $item, $order_obj );

			if ( $bundle_container_order_item ) {
				return false;
			}

			return $bool;
		}
	}

}
