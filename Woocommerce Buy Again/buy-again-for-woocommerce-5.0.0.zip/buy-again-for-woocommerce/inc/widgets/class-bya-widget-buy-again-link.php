<?php
/**
 * Buy Again Link Widget.
 *
 * Displays Buy Again Link widget.
 *
 * @package Buy_Again\Widgets
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'BYA_Widget_Buy_Again_Link' ) ) {
	/**
	 * Widget cart class.
	 */
	class BYA_Widget_Buy_Again_Link extends WC_Widget {

		/**
		 * Constructor.
		 */
		public function __construct() {
			$this->widget_cssclass    = 'bya-widget-buy-again-link';
			$this->widget_description = __( 'Display the customer buy again list link.', 'buy-again-for-woocommerce' );
			$this->widget_id          = 'bya_widget_buy_again_link';
			$this->widget_name        = __( 'Buy Again Products', 'buy-again-for-woocommerce' );
			$this->settings           = array(
				'title'         => array(
					'type'  => 'text',
					'std'   => __( 'Buy Again', 'buy-again-for-woocommerce' ),
					'label' => __( 'Title', 'buy-again-for-woocommerce' ),
				),
				'hide_if_empty' => array(
					'type'  => 'checkbox',
					'std'   => 0,
					'label' => __( 'Hide if buy again list is empty', 'buy-again-for-woocommerce' ),
				),
			);

			parent::__construct();
		}

		/**
		 * Output widget.
		 *
		 * @since 4.2.0
		 * @see WP_Widget
		 *
		 * @param array $args     Arguments.
		 * @param array $instance Widget instance.
		 */
		public function widget( $args, $instance ) {
			/**
			 * Buy Again Link Widget Hidden
			 *
			 * @since 4.2.0
			 */
			if ( apply_filters( 'bya_widget_buy_again_is_hidden', bya_is_buy_again_list() ) ) {
				return;
			}

			$hide_if_empty = empty( $instance['hide_if_empty'] ) ? 0 : 1;

			if ( ! isset( $instance['title'] ) ) {
				$instance['title'] = __( 'Buy Again', 'buy-again-for-woocommerce' );
			}

			$this->widget_start( $args, $instance );

			if ( $hide_if_empty ) {
				$class = bya_buy_again_is_empty( get_current_user_id() ) ? ' bya_hide' : '';

				echo '<div class="hide-buy-again-widget-if-empty' . esc_attr( $class ) . '">';
			}

			echo '<a href="' . esc_url( wc_get_endpoint_url( get_option( 'bya_advanced_my_account_menu_slug', 'buy-again' ), '', wc_get_page_permalink( 'myaccount' ) ) ) . '" class="bya-buy-again-list-url">' . esc_html__( 'Buy Again Products', 'buy-again-for-woocommerce' ) . '</a>';

			if ( $hide_if_empty ) {
				echo '</div>';
			}

			$this->widget_end( $args );
		}
	}
}
