<?php
/**
 * Buy Again Widget.
 *
 * Displays Buy Again widget.
 *
 * @package Buy_Again\Widgets
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'BYA_Widget_Buy_Again' ) ) {
	/**
	 * Widget cart class.
	 */
	class BYA_Widget_Buy_Again extends WC_Widget {

		/**
		 * Constructor.
		 */
		public function __construct() {
			$this->widget_cssclass    = 'bya-widget-buy-again';
			$this->widget_description = __( 'Display the customer buy again list.', 'buy-again-for-woocommerce' );
			$this->widget_id          = 'bya_widget_buy_again';
			$this->widget_name        = __( 'Buy Again', 'buy-again-for-woocommerce' );
			$this->settings           = array(
				'title'         => array(
					'type'  => 'text',
					'std'   => __( 'Buy Again', 'buy-again-for-woocommerce' ),
					'label' => __( 'Title', 'buy-again-for-woocommerce' ),
				),
				'hide_if_empty' => array(
					'type'  => 'checkbox',
					'std'   => 0,
					'label' => __( 'Hide if buy again list is empty', 'buy-again-for-woocommerce' ),
				),
			);

			parent::__construct();
		}

		/**
		 * Output widget.
		 *
		 * @since 4.2.0
		 * @see WP_Widget
		 *
		 * @param array $args     Arguments.
		 * @param array $instance Widget instance.
		 */
		public function widget( $args, $instance ) {
			/**
			 * Buy Again Widget Hidden
			 *
			 * @since 4.2.0
			 */
			if ( apply_filters( 'bya_widget_buy_again_is_hidden', bya_is_buy_again_list() ) ) {
				return;
			}

			$hide_if_empty = empty( $instance['hide_if_empty'] ) ? 0 : 1;

			if ( ! isset( $instance['title'] ) ) {
				$instance['title'] = __( 'Buy Again', 'buy-again-for-woocommerce' );
			}

			$this->widget_start( $args, $instance );

			if ( $hide_if_empty ) {
				$class = bya_buy_again_is_empty( get_current_user_id() ) ? ' bya_hide' : '';

				echo '<div class="hide-buy-again-widget-if-empty' . esc_attr( $class ) . '">';
			}

			// Insert cart widget placeholder - code in woocommerce.js will update this on page load.
			bya_widget_buy_again_list();

			if ( $hide_if_empty ) {
				echo '</div>';
			}

			$this->widget_end( $args );
		}
	}
}
