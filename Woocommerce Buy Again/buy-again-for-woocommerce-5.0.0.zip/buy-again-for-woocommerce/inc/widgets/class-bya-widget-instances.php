<?php
/**
 * Widget Instances Class.
 *
 * @package Buy_Again
 * */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'BYA_Widget_Instances' ) ) {

	/**
	 * Class BYA_Widget_Instances.
	 * */
	class BYA_Widget_Instances {

		/**
		 * Widgets.
		 *
		 * @var Array
		 * */
		private static $widgets = array();

		/**
		 * Get Widgets.
		 *
		 * @since 4.2.0
		 * */
		public static function get_widgets() {
			if ( ! self::$widgets ) {
				self::load_widgets();
			}

			return self::$widgets;
		}

		/**
		 * Load all Widgets.
		 *
		 * @since 4.2.0
		 * */
		public static function load_widgets() {
			$default_widget_classes = array(
				'bya-widget-buy-again'      => 'BYA_Widget_Buy_Again',
				'bya-widget-buy-again-link' => 'BYA_Widget_Buy_Again_Link',
			);

			foreach ( $default_widget_classes as $file_name => $widget_class ) {
				// Include widget file.
				include 'class-' . $file_name . '.php';

				// Add Widget.
				self::add_widget( $widget_class );
			}

			add_action( 'widgets_init', array( __CLASS__, 'register_widgets' ) );
		}

		/**
		 * Add a widget class.
		 *
		 * @since 4.2.0
		 * */
		public static function register_widgets() {
			$widget_classes = self::get_widget_classes();

			if ( ! bya_check_is_array( $widget_classes ) ) {
				return $widget_classes;
			}

			foreach ( $widget_classes as $widget_class ) {

				// Register a widget.
				register_widget( $widget_class );
			}
		}

		/**
		 * Add a widget.
		 *
		 * @since 4.2.0
		 * @param String $class Class.
		 * @return HTML
		 * */
		public static function add_widget( $class ) {
			self::$widgets[] = $class;

			return self::$widgets;
		}

		/**
		 * Get widget classes.
		 *
		 * @since 4.2.0
		 * */
		public static function get_widget_classes() {
			return self::$widgets;
		}
	}

}
