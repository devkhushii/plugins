<?php
/**
 * Compatibility.
 *
 * @package Custom Pricing/Compatibility
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'BYA_Abstract_Compatibility' ) ) {

	/**
	 * Abstract.
	 */
	abstract class BYA_Abstract_Compatibility {

		/**
		 * ID
		 *
		 * @var String.
		 * */
		protected $id;

		/**
		 * Plugin slug.
		 *
		 * @var String.
		 * */
		protected $plugin_slug = 'bya';

		/**
		 * Class Constructor.
		 * */
		public function __construct() {
			$this->process_actions();
		}

		/**
		 * Get id.
		 *
		 * @return String
		 * */
		public function get_id() {
			return $this->id;
		}

		/**
		 * Is enabled?.
		 *
		 *  @return Boolean
		 * */
		public function is_enabled() {
			return $this->is_plugin_enabled();
		}

		/**
		 * Is plugin enabled?.
		 *
		 *  @return Boolean
		 * */
		public function is_plugin_enabled() {
			return true;
		}

		/**
		 * Actions.
		 *
		 * @return void
		 * */
		public function process_actions() {
			if ( ! $this->is_enabled() ) {
				return;
			}

			$this->actions();

			if ( is_admin() ) {
				$this->admin_action();

				// Add action for external js files in backend.
				add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue_scripts' ) );
			}

			if ( ! is_admin() || defined( 'DOING_AJAX' ) ) {
				$this->frontend_action();

				// Add action for external js files in backend.
				add_action( 'wp_enqueue_scripts', array( $this, 'frontend_enqueue_scripts' ) );
			}
		}

		/**
		 * Admin Actions.
		 * */
		public function admin_action() {
		}

		/**
		 * Actions.
		 * */
		public function actions() {
		}

		/**
		 * Frontend Actions.
		 * */
		public function frontend_action() {
		}

		/**
		 * Enqueue admin scripts.
		 * */
		public function admin_enqueue_scripts() {
			$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

			$this->admin_external_js_files( $suffix );
			$this->admin_external_css_files( $suffix );
		}

		/**
		 * Enqueue Frontend scripts.
		 * */
		public function frontend_enqueue_scripts() {
			$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

			$this->frontend_external_js_files( $suffix );
			$this->frontend_external_css_files( $suffix );
		}

		/**
		 * Enqueue frontend JS files.
		 *
		 * @since 1.0
		 * @param String $suffix The suffix.
		 * */
		public function frontend_external_js_files( $suffix ) {
		}

		/**
		 * Enqueue frontend CSS files.
		 *
		 * @since 1.0
		 * @param String $suffix The suffix.
		 * */
		public function frontend_external_css_files( $suffix ) {
		}

		/**
		 * Enqueue admin JS files.
		 *
		 * @since 1.0
		 * @param String $suffix The suffix.
		 * */
		public function admin_external_js_files( $suffix ) {
		}

		/**
		 * Enqueue admin CSS files.
		 *
		 * @since 1.0
		 * @param String $suffix The suffix.
		 * */
		public function admin_external_css_files( $suffix ) {
		}
	}

}
