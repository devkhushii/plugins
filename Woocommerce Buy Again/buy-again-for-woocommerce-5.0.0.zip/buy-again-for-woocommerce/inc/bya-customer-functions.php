<?php
/**
 * Customer Functions.
 *
 * @package Multi-Vendor Functions.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! function_exists( 'bya_is_customer' ) ) {
	/**
	 * Check whether the given the value is Customer.
	 *
	 * @since 4.9.0
	 * @param  Mixed $customer Post object or post ID of the customer.
	 * @return Boolean True on success.
	 */
	function bya_is_customer( $customer ) {
		return $customer && is_a( $customer, 'BYA_Customer' );
	}
}

if ( ! function_exists( 'bya_get_customer' ) ) {
	/**
	 * Get customer.
	 *
	 * @since 4.9.0
	 * @param BYA_Customer $customer Customer.
	 * @param Boolean      $wp_error WordPress error.
	 * @return bool|\BYA_Customer
	 */
	function bya_get_customer( $customer, $wp_error = false ) {
		if ( ! $customer ) {
			return false;
		}

		try {
			$customer = new BYA_Customer( $customer );
		} catch ( Exception $e ) {
			return $wp_error ? new WP_Error( 'error', $e->getMessage() ) : false;
		}

		return $customer;
	}
}

if ( ! function_exists( 'bya_get_customers' ) ) {
	/**
	 * Return the array of customers based upon the args requested.
	 *
	 * @since 4.9.0
	 * @param Array $args Arguments.
	 * @return Object
	 */
	function bya_get_customers( $args = array() ) {
		global $wpdb;

		$wpdb_ref = &$wpdb;
		$args     = wp_parse_args(
			$args,
			array(
				'include_ids'   => array(),
				'exclude_ids'   => array(),
				's'             => '',
				'last_order_id' => '',
				'product_id'    => '',
				'variation_id'  => '',
				'user_id'       => '',
				'email'         => '',
				'page'          => 1,
				'limit'         => -1,
				'fields'        => 'objects',
				'orderby'       => 'ID',
				'order'         => 'DESC',
			)
		);

		// Search term.
		if ( ! empty( $args['s'] ) ) {
			$term          = str_replace( '#', '', wc_clean( wp_unslash( $args['s'] ) ) );
			$search_fields = array();
			$search_where  = " AND ( 
                (ID LIKE '%%" . $wpdb_ref->esc_like( $term ) . "%%') OR
                (product_id LIKE '%%" . $wpdb_ref->esc_like( $term ) . "%%') OR
				(variation_id LIKE '%%" . $wpdb_ref->esc_like( $term ) . "%%') OR
				(last_order_id LIKE '%%" . $wpdb_ref->esc_like( $term ) . "%%') OR
				(created_via LIKE '%%" . $wpdb_ref->esc_like( $term ) . "%%') OR 
				(user_id LIKE '%%" . $wpdb_ref->esc_like( $term ) . "%%') OR 
				(email LIKE '%%" . $wpdb_ref->esc_like( $term ) . "%%')
                ) ";
		} else {
			$search_where = '';
		}

		// Includes.
		if ( ! empty( $args['include_ids'] ) ) {
			$include_ids = " AND ID IN ('" . implode( "','", $args['include_ids'] ) . "') ";
		} else {
			$include_ids = '';
		}

		// Excludes.
		if ( ! empty( $args['exclude_ids'] ) ) {
			$exclude_ids = " AND ID NOT IN ('" . implode( "','", $args['exclude_ids'] ) . "') ";
		} else {
			$exclude_ids = '';
		}

		// Allowed Product.
		if ( ! empty( $args['product_id'] ) ) {
			if ( is_array( $args['product_id'] ) ) {
				$allowed_products = " AND product_id IN ('" . implode( "','", $args['product_id'] ) . "') ";
			} else {
				$allowed_products = " AND product_id = '" . esc_sql( $args['product_id'] ) . "' ";
			}
		} else {
			$allowed_products = '';
		}

		// Allowed Variation.
		if ( ! empty( $args['variation_id'] ) ) {
			if ( is_array( $args['variation_id'] ) ) {
				$allowed_variations = " AND variation_id IN ('" . implode( "','", $args['variation_id'] ) . "') ";
			} else {
				$allowed_variations = " AND variation_id = '" . esc_sql( $args['variation_id'] ) . "' ";
			}
		} else {
			$allowed_variations = '';
		}

		// User ID.
		if ( ! empty( $args['user_id'] ) ) {
			if ( is_array( $args['user_id'] ) ) {
				$allowed_users = " AND user_id IN ('" . implode( "','", $args['user_id'] ) . "') ";
			} else {
				$allowed_users = " AND user_id = '" . esc_sql( $args['user_id'] ) . "' ";
			}
		} else {
			$allowed_users = '';
		}

		// User Email.
		if ( ! empty( $args['email'] ) ) {
			if ( is_array( $args['email'] ) ) {
				$allowed_emails = " AND email IN ('" . implode( "','", $args['email'] ) . "') ";
			} else {
				$allowed_emails = " AND email = '" . esc_sql( $args['email'] ) . "' ";
			}
		} else {
			$allowed_emails = '';
		}

		// Order ID.
		if ( ! empty( $args['last_order_id'] ) ) {
			if ( is_array( $args['last_order_id'] ) ) {
				$allowed_last_order_ids = " AND last_order_id IN ('" . implode( "','", $args['last_order_id'] ) . "') ";
			} else {
				$allowed_last_order_ids = " AND last_order_id = '" . esc_sql( $args['last_order_id'] ) . "' ";
			}
		} else {
			$allowed_last_order_ids = '';
		}

		// Order by.
		switch ( ! empty( $args['orderby'] ) ? $args['orderby'] : 'ID' ) {
			case 'ID':
				$orderby = ' ORDER BY ' . esc_sql( $args['orderby'] ) . ' ';
				break;
			default:
				$orderby = ' ORDER BY ID ';
				break;
		}

		// Order.
		if ( ! empty( $args['order'] ) && 'desc' === strtolower( $args['order'] ) ) {
			$order = ' DESC ';
		} else {
			$order = ' ASC ';
		}

		// Paging.
		if ( $args['limit'] >= 0 ) {
			$page   = absint( $args['page'] );
			$page   = $page ? $page : 1;
			$offset = absint( ( $page - 1 ) * $args['limit'] );
			$limits = 'LIMIT ' . $offset . ', ' . $args['limit'];
		} else {
			$limits = '';
		}

		$all_customer_ids = $wpdb_ref->get_var(
			"SELECT COUNT(DISTINCT ID) FROM {$wpdb->prefix}bya_customer AS c
			WHERE 1=1 {$search_where} {$include_ids} {$exclude_ids} {$allowed_products} {$allowed_variations} {$allowed_users} {$allowed_emails} {$allowed_last_order_ids}"
		);

		$customer_ids = $wpdb_ref->get_col(
			"SELECT DISTINCT ID FROM {$wpdb->prefix}bya_customer AS c
			WHERE 1=1 {$search_where} {$include_ids} {$exclude_ids}  {$allowed_products} {$allowed_variations} {$allowed_users} {$allowed_emails} {$allowed_last_order_ids}
			{$orderby} {$order} {$limits}"
		);

		if ( 'objects' === $args['fields'] ) {
			$customers = array_filter( array_combine( $customer_ids, array_map( 'bya_get_customer', $customer_ids ) ) );
		} else {
			$customers = $customer_ids;
		}

		$customers_count = count( $customers );
		$query_object    = (object) array(
			'customers'       => $customers,
			'total_customers' => $all_customer_ids,
			'has_customer'    => $customers_count > 0,
			'max_num_pages'   => $args['limit'] > 0 ? ceil( $all_customer_ids / $args['limit'] ) : 1,
		);

		return $query_object;
	}
}

if ( ! function_exists( 'bya_get_purchased_products' ) ) {
	/**
	 * Return the array of Products and Order id based upon the args requested.
	 *
	 * @since 4.9.0
	 * @param Array $args Arguments.
	 * @return Object
	 */
	function bya_get_purchased_products( $args = array() ) {
		global $wpdb;

		$wpdb_ref = &$wpdb;
		$args     = wp_parse_args(
			$args,
			array(
				'include_ids' => array(),
				'exclude_ids' => array(),
				's'           => '',
				'user_id'     => '',
				'email'       => '',
				'page'        => 1,
				'limit'       => -1,
				'orderby'     => 'ID',
				'order'       => 'DESC',
			)
		);

		// Search term.
		if ( ! empty( $args['s'] ) ) {
			$term          = str_replace( '#', '', wc_clean( wp_unslash( $args['s'] ) ) );
			$search_fields = array();
			$search_where  = " AND ( 
                (ID LIKE '%%" . $wpdb_ref->esc_like( $term ) . "%%') OR
				(created_via LIKE '%%" . $wpdb_ref->esc_like( $term ) . "%%') OR 
				(user_id LIKE '%%" . $wpdb_ref->esc_like( $term ) . "%%') OR 
				(email LIKE '%%" . $wpdb_ref->esc_like( $term ) . "%%')
                ) ";
		} else {
			$search_where = '';
		}

		// Includes.
		if ( ! empty( $args['include_ids'] ) ) {
			$include_ids = " AND ID IN ('" . implode( "','", $args['include_ids'] ) . "') ";
		} else {
			$include_ids = '';
		}

		// Excludes.
		if ( ! empty( $args['exclude_ids'] ) ) {
			$exclude_ids = " AND ID NOT IN ('" . implode( "','", $args['exclude_ids'] ) . "') ";
		} else {
			$exclude_ids = '';
		}

		// User ID.
		if ( ! empty( $args['user_id'] ) ) {
			if ( is_array( $args['user_id'] ) ) {
				$allowed_users = " AND user_id IN ('" . implode( "','", $args['user_id'] ) . "') ";
			} else {
				$allowed_users = " AND user_id = '" . esc_sql( $args['user_id'] ) . "' ";
			}
		} else {
			$allowed_users = '';
		}

		// User Email.
		if ( ! empty( $args['email'] ) ) {
			if ( is_array( $args['email'] ) ) {
				$allowed_emails = " AND email IN ('" . implode( "','", $args['email'] ) . "') ";
			} else {
				$allowed_emails = " AND email = '" . esc_sql( $args['email'] ) . "' ";
			}
		} else {
			$allowed_emails = '';
		}

		// Order by.
		switch ( ! empty( $args['orderby'] ) ? $args['orderby'] : 'ID' ) {
			case 'ID':
				$orderby = ' ORDER BY ' . esc_sql( $args['orderby'] ) . ' ';
				break;
			default:
				$orderby = ' ORDER BY ID ';
				break;
		}

		// Order.
		if ( ! empty( $args['order'] ) && 'desc' === strtolower( $args['order'] ) ) {
			$order = ' DESC ';
		} else {
			$order = ' ASC ';
		}

		// Paging.
		if ( $args['limit'] >= 0 ) {
			$page   = absint( $args['page'] );
			$page   = $page ? $page : 1;
			$offset = absint( ( $page - 1 ) * $args['limit'] );
			$limits = 'LIMIT ' . $offset . ', ' . $args['limit'];
		} else {
			$limits = '';
		}

		$all_product_ids = $wpdb_ref->get_var(
			"SELECT COUNT(DISTINCT product_id) FROM {$wpdb->prefix}bya_customer AS c
			WHERE 1=1 {$search_where} {$include_ids} {$exclude_ids} {$allowed_users} {$allowed_emails}"
		);

		$product_ids = $wpdb_ref->get_col(
			"SELECT DISTINCT product_id, last_order_id FROM {$wpdb->prefix}bya_customer AS c
			WHERE 1=1 {$search_where} {$include_ids} {$exclude_ids} {$allowed_users} {$allowed_emails}
			{$orderby} {$order} {$limits}"
		);

		$products = $product_ids;

		$products_count = count( $products );
		$query_object   = (object) array(
			'product_ids'    => $products,
			'total_products' => $all_product_ids,
			'has_product'    => $products_count > 0,
			'max_num_pages'  => $args['limit'] > 0 ? ceil( $all_product_ids / $args['limit'] ) : 1,
		);

		return $query_object;
	}
}
