<?php
/**
 * Customer Data.
 *
 * @package Multi-Vendor for WooCommerce
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'BYA_Customer' ) ) {
	/**
	 * Order
	 *
	 * @class BYA_Customer
	 * @package Class
	 */
	class BYA_Customer extends WC_Data {

		/**
		 * Order Data array.
		 *
		 * @var Array
		 */
		protected $data = array(
			'product_id'    => '',
			'variation_id'  => '',
			'user_id'       => '',
			'last_order_id' => '',
			'qty'           => '',
			'email'         => '',
			'date_created'  => null,
			'date_modified' => null,
			'created_via'   => '',
			'version'       => '',
		);

		/**
		 * Which data store to load.
		 *
		 * @var String
		 */
		protected $data_store_name = 'bya_customer';

		/**
		 * Get the customer if ID is passed, otherwise the customer is new and empty.
		 *
		 * @since 4.9.0
		 * @param  int|object|BYA_customer $customer Customer to read.
		 */
		public function __construct( $customer = 0 ) {
			parent::__construct( $customer );

			if ( is_numeric( $customer ) && $customer > 0 ) {
				$this->set_id( $customer );
			} elseif ( $customer instanceof self ) {
				$this->set_id( $customer->get_id() );
			} elseif ( ! empty( $customer->ID ) ) {
				$this->set_id( $customer->ID );
			} else {
				$this->set_object_read( true );
			}

			$this->data_store = WC_Data_Store::load( $this->data_store_name );

			if ( $this->get_id() > 0 ) {
				$this->data_store->read( $this );
			}
		}

		/**
		 * Log an error about this customer is exception is encountered.
		 *
		 * @since 4.9.0
		 * @param Exception $e Exception object.
		 * @param String    $message Message regarding exception thrown.
		 */
		protected function handle_exception( $e, $message = 'Error' ) {
			wc_get_logger()->error(
				$message,
				array(
					'customer' => $this,
					'error'    => $e,
				)
			);
		}

		/*
		|--------------------------------------------------------------------------
		| URLs and Endpoints
		|--------------------------------------------------------------------------
		 */

		/**
		 * Get's Product Obj.
		 *
		 * @since 4.9.0
		 * @return WC_Product
		 */
		public function get_product() {
			$product = wc_get_product( $this->get_product_id() );

			if ( ! is_a( $product, 'WC_Product' ) ) {
				return false;
			}

			return $product;
		}

		/**
		 * Get's User Obj.
		 *
		 * @since 4.9.0
		 * @return WP_User
		 */
		public function get_user() {
			$user_obj = get_user_by( 'id', $this->get_user_id() );

			if ( ! $user_obj instanceof WP_User ) {
				return false;
			}

			return $user_obj;
		}

		/**
		 * Get's Customer Orders Obj.
		 *
		 * @since 4.9.0
		 * @return WC_Order
		 */
		public function get_last_order() {
			$order = wc_get_order( $this->get_last_order_id() );

			if ( ! is_a( $order, 'WC_Order' ) ) {
				return false;
			}

			return $order;
		}

		/*
		|--------------------------------------------------------------------------
		| Getters
		|--------------------------------------------------------------------------
		 */

		/**
		 * Get version.
		 *
		 * @since 4.9.0
		 * @param  String $context View or edit context.
		 * @return String
		 */
		public function get_version( $context = 'view' ) {
			return $this->get_prop( 'version', $context );
		}

		/**
		 * Get date created.
		 *
		 * @since 4.9.0
		 * @param  String $context View or edit context.
		 * @return WC_DateTime|NULL object if the date is set or null if there is no date.
		 */
		public function get_date_created( $context = 'view' ) {
			return $this->get_prop( 'date_created', $context );
		}

		/**
		 * Get date modified.
		 *
		 * @since 4.9.0
		 * @param String $context View or edit context.
		 * @return WC_DateTime|NULL object if the date is set or null if there is no date.
		 */
		public function get_date_modified( $context = 'view' ) {
			return $this->get_prop( 'date_modified', $context );
		}

		/**
		 * Get user ID.
		 *
		 * @since 4.9.0
		 * @param String $context View or edit context.
		 * @return String|NULL String if the user id is set or null if there is no user id.
		 */
		public function get_user_id( $context = 'view' ) {
			return (int) $this->get_prop( 'user_id', $context );
		}

		/**
		 * Get Product ID.
		 *
		 * @since 4.9.0
		 * @param String $context View or edit context.
		 * @return String|NULL String if the product id is set or null if there is no product id.
		 */
		public function get_product_id( $context = 'view' ) {
			return (int) $this->get_prop( 'product_id', $context );
		}

		/**
		 * Get Variation ID.
		 *
		 * @since 4.9.0
		 * @param String $context View or edit context.
		 * @return String|NULL String if the variation id is set or null if there is no variation id.
		 */
		public function get_variation_id( $context = 'view' ) {
			return (int) $this->get_prop( 'variation_id', $context );
		}

		/**
		 * Get last order id.
		 *
		 * @since 4.9.0
		 * @param String $context View or edit context.
		 * @return String|NULL String if the last order id is set or null if there is no last order id.
		 */
		public function get_last_order_id( $context = 'view' ) {
			return $this->get_prop( 'last_order_id', $context );
		}

		/**
		 * Get quantity.
		 *
		 * @since 4.9.0
		 * @param String $context View or edit context.
		 * @return String|NULL String if the qty is set or null if there is no qty.
		 */
		public function get_qty( $context = 'view' ) {
			return $this->get_prop( 'qty', $context );
		}

		/**
		 * Get email.
		 *
		 * @since 4.9.0
		 * @param String $context View or edit context.
		 * @return String|NULL String if the email is set or null if there is no email.
		 */
		public function get_email( $context = 'view' ) {
			return $this->get_prop( 'email', $context );
		}

		/**
		 * Get created_via.
		 *
		 * @since 1.0.0
		 * @param String $context View or edit context.
		 * @return String|NULL String if the created_via is set or null if there is no created_via.
		 */
		public function get_created_via( $context = 'view' ) {
			return $this->get_prop( 'created_via', $context );
		}

		/*
		|--------------------------------------------------------------------------
		| Setters
		|--------------------------------------------------------------------------
		|
		| Functions for setting vendor data. These should not update anything in the
		| database itself and should only change what is stored in the class
		| object.
		 */

		/**
		 * Set version.
		 *
		 * @since 4.9.0
		 * @param String $value Value to set.
		 * @throws WC_Data_Exception Exception may be thrown if value is invalid.
		 */
		public function set_version( $value ) {
			$this->set_prop( 'version', $value );
		}

		/**
		 * Set date created.
		 *
		 * @since 4.9.0
		 * @param String|Integer|Null $date UTC timestamp, or ISO 8601 DateTime. If the DateTime string has no timezone or offset, WordPress site timezone will be assumed. Null if there is no date.
		 * @throws WC_Data_Exception Exception may be thrown if value is invalid.
		 */
		public function set_date_created( $date = null ) {
			$this->set_date_prop( 'date_created', $date );
		}

		/**
		 * Set date modified.
		 *
		 * @since 4.9.0
		 * @param String|Integer|Null $date UTC timestamp, or ISO 8601 DateTime. If the DateTime string has no timezone or offset, WordPress site timezone will be assumed. Null if there is no date.
		 * @throws WC_Data_Exception Exception may be thrown if value is invalid.
		 */
		public function set_date_modified( $date = null ) {
			$this->set_date_prop( 'date_modified', $date );
		}

		/**
		 * Set user id.
		 *
		 * @since 4.9.0
		 * @param String $value user id.
		 * @throws WC_Data_Exception Exception may be thrown if value is invalid.
		 */
		public function set_user_id( $value = null ) {
			$this->set_prop( 'user_id', (int) $value );
		}

		/**
		 * Set product id.
		 *
		 * @since 4.9.0
		 * @param String $value Product id.
		 * @throws WC_Data_Exception Exception may be thrown if value is invalid.
		 */
		public function set_product_id( $value = null ) {
			$this->set_prop( 'product_id', (int) $value );
		}

		/**
		 * Set Variation id.
		 *
		 * @since 4.9.0
		 * @param String $value Variation id.
		 * @throws WC_Data_Exception Exception may be thrown if value is invalid.
		 */
		public function set_variation_id( $value = null ) {
			$this->set_prop( 'variation_id', (int) $value );
		}

		/**
		 * Set last order id.
		 *
		 * @since 1.0.0
		 * @param String $value last order id.
		 * @throws WC_Data_Exception Exception may be thrown if value is invalid.
		 */
		public function set_last_order_id( $value = null ) {
			$this->set_prop( 'last_order_id', $value );
		}

		/**
		 * Set qty.
		 *
		 * @since 4.9.0
		 * @param String $value qty.
		 * @throws WC_Data_Exception Exception may be thrown if value is invalid.
		 */
		public function set_qty( $value = null ) {
			$this->set_prop( 'qty', $value );
		}

		/**
		 * Set email.
		 *
		 * @since 4.9.0
		 * @param String $value email.
		 * @throws WC_Data_Exception Exception may be thrown if value is invalid.
		 */
		public function set_email( $value = null ) {
			$this->set_prop( 'email', $value );
		}

		/**
		 * Set created_via.
		 *
		 * @since 4.9.0
		 * @param String $value created_via.
		 * @throws WC_Data_Exception Exception may be thrown if value is invalid.
		 */
		public function set_created_via( $value = null ) {
			$this->set_prop( 'created_via', $value );
		}
	}
}
