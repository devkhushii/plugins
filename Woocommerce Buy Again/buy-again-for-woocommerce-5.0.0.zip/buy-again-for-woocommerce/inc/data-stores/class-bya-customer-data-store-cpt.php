<?php
/**
 * Customer Data Store
 *
 * @package Multi Vendor Marketplace
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'BYA_Customer_Data_Store_CPT' ) ) {

	/**
	 * Customer Data Store CPT
	 *
	 * @class BYA_Customer_Data_Store_CPT
	 * @package Class
	 */
	class BYA_Customer_Data_Store_CPT extends WC_Data_Store_WP implements WC_Object_Data_Store_Interface {

		/**
		 * Data stored props.
		 *
		 * @var Array
		 */
		protected $internal_props = array(
			'product_id',
			'variation_id',
			'user_id',
			'last_order_id',
			'qty',
			'email',
			'date_created',
			'date_modified',
			'created_via',
			'version',
		);

		/*
		|--------------------------------------------------------------------------
		| CRUD Methods
		|--------------------------------------------------------------------------
		 */

		/**
		 * Method to create a new ID in the database from the new changes.
		 *
		 * @since 4.9.0
		 * @param BYA_Customer $customer Customer object.
		 */
		public function create( &$customer ) {
			global $wpdb;

			$wpdb_ref = &$wpdb;

			$customer->set_version( BYA_VERSION );
			$customer->set_date_created( time() );

			$table  = "{$wpdb->prefix}bya_customer";
			$format = array(
				'product_id'        => '%d',
				'variation_id'      => '%d',
				'user_id'           => '%d',
				'last_order_id'     => '%d',
				'qty'               => '%d',
				'email'             => '%s',
				'date_created'      => '%s',
				'date_created_gmt'  => '%s',
				'date_modified'     => '%s',
				'date_modified_gmt' => '%s',
				'created_via'       => '%s',
				'version'           => '%s',
			);
			$data   = array(
				'product_id'        => $customer->get_product_id(),
				'variation_id'      => $customer->get_variation_id(),
				'user_id'           => $customer->get_user_id(),
				'last_order_id'     => $customer->get_last_order_id(),
				'qty'               => $customer->get_qty(),
				'email'             => $customer->get_email(),
				'date_created'      => current_time( 'mysql' ),
				'date_created_gmt'  => current_time( 'mysql', 1 ),
				'date_modified'     => current_time( 'mysql' ),
				'date_modified_gmt' => current_time( 'mysql', 1 ),
				'created_via'       => $customer->get_created_via(),
				'version'           => $customer->get_version(),
			);

			$id = bya_insert_row_query( $table, $data, $format );

			if ( $id && ! is_wp_error( $id ) ) {
				$customer->set_id( $id );
				$customer->apply_changes();

				/**
				 * New Customer Hook
				 *
				 * @since 4.9.0
				 */
				do_action( 'bya_new_customer', $customer->get_id(), $customer );
			}
		}

		/**
		 * Method to read data from the database.
		 *
		 * @since 4.9.0
		 * @param BYA_Customer $customer Customer object.
		 * @throws Exception Invalid Post.
		 */
		public function read( &$customer ) {
			$customer->set_defaults();

			if ( ! $customer->get_id() ) {
				throw new Exception( esc_html__( 'Invalid Customer.', 'buy-again-for-woocommerce' ) );
			}

			global $wpdb;

			$wpdb_ref = &$wpdb;
			$data     = $wpdb_ref->get_row(
				$wpdb_ref->prepare( "SELECT * from {$wpdb->prefix}bya_customer WHERE ID=%d", $customer->get_id() )
			);

			foreach ( $this->internal_props as $prop ) {
				$setter = "set_$prop";

				if ( is_callable( array( $customer, $setter ) ) && is_object( $data ) && property_exists( $data, $prop ) ) {
					$customer->{$setter}( $data->$prop );
				}
			}

			$customer->set_object_read( true );
		}

		/**
		 * Method to update changes in the database.
		 *
		 * @since 4.9.0
		 * @param BYA_Customer $customer Customer object.
		 */
		public function update( &$customer ) {
			global $wpdb;

			$wpdb_ref = &$wpdb;
			$customer->set_version( BYA_VERSION );

			if ( ! $customer->get_date_created( 'edit' ) ) {
				$customer->set_date_created( time() );
			}

			$format = array(
				'product_id'        => '%d',
				'variation_id'      => '%d',
				'user_id'           => '%d',
				'last_order_id'     => '%d',
				'qty'               => '%d',
				'email'             => '%s',
				'date_modified'     => '%s',
				'date_modified_gmt' => '%s',
				'created_via'       => '%s',
				'version'           => '%s',
			);
			$data   = array(
				'product_id'        => $customer->get_product_id(),
				'variation_id'      => $customer->get_variation_id(),
				'user_id'           => $customer->get_user_id(),
				'last_order_id'     => $customer->get_last_order_id(),
				'qty'               => $customer->get_qty(),
				'email'             => $customer->get_email(),
				'date_modified'     => current_time( 'mysql' ),
				'date_modified_gmt' => current_time( 'mysql', 1 ),
				'created_via'       => $customer->get_created_via(),
				'version'           => $customer->get_version(),
			);
			$table  = "{$wpdb_ref->prefix}bya_customer";
			$where  = '`ID` = ' . $customer->get_id();
			$id     = bya_update_row_query( $table, $format, $data, $where );

			if ( $id && ! is_wp_error( $id ) ) {
				$customer->apply_changes();

				/**
				 * Update Customer Hook
				 *
				 * @since 4.9.0
				 */
				do_action( 'bya_update_customer', $customer->get_id(), $customer );
			}
		}

		/**
		 * Delete an object, set the ID to 0.
		 *
		 * @since 4.9.0
		 * @param BYA_Customer $customer Customer object.
		 * @param Array        $args Array of args to pass to the delete method.
		 * @return Boolean
		 */
		public function delete( &$customer, $args = array() ) {
			$id = $customer->get_id();

			if ( ! $id ) {
				return false;
			}

			global $wpdb;

			$wpdb_ref = &$wpdb;
			$result   = $wpdb_ref->delete( "{$wpdb->prefix}bya_customer", array( 'ID' => $customer->get_id() ) );

			if ( ! $result ) {
				return false;
			}

			$customer->set_id( 0 );

			/**
			 * Delete Customer.
			 *
			 * @since 4.9.0
			 */
			do_action( 'bya_delete_customer', $id );

			return true;
		}
	}
}
