<?php
/**
 * Handles the Cart.
 *
 * @package Class
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'BYA_Cart_Handler' ) ) {

	/**
	 * Class BYA_Cart_Handler
	 **/
	class BYA_Cart_Handler {

		/**
		 * Class Initialization.
		 */
		public static function init() {
			// Add tickets data in the cart item.
			add_action( 'woocommerce_get_item_data', array( __CLASS__, 'maybe_add_custom_item_data' ), 10, 2 );
			// Add Cart item data.
			add_filter( 'woocommerce_add_cart_item_data', array( __CLASS__, 'add_cart_item_data' ), 10, 3 );
			// Change Cart ID.
			add_filter( 'woocommerce_cart_id', array( __CLASS__, 'find_cart_id_in_cart' ), 10, 4 );
			// Order Again function.
			add_action( 'wp_loaded', array( __CLASS__, 'set_order_again_products' ) );
			// Display Buy again products after the cart table.
			add_action( 'woocommerce_after_cart', array( __CLASS__, 'display_cart_bya_products' ) );
			add_action( 'render_block_woocommerce/cart', array( __CLASS__, 'display_cart_bya_products_blocks' ), 10, 2 );
		}

		/**
		 * Display the buy again product table in WC Blocks.
		 *
		 * @since 4.6.0
		 * @param HTML  $content Content.
		 * @param Array $parsed_block Parse block.
		 * @return HTML
		 * */
		public static function display_cart_bya_products_blocks( $content, $parsed_block ) {
			ob_start();
			self::display_cart_bya_products();
			$template = ob_get_clean();

			return $content . $template;
		}

		/**
		 * Display the buy again product table.
		 *
		 * @since 4.6.0
		 * @return HTML
		 * */
		public static function display_cart_bya_products() {
			if ( 'yes' !== get_option( 'bya_general_enable_buy_again_in_cart' ) ) {
				return;
			}

			$user_id          = get_current_user_id();
			$user_restriction = bya_user_restriction( $user_id );

			if ( ! $user_restriction ) {
				return;
			}
			?>
			<div class="bya-cart-product-list-wrapper">
				<h1 class="bya-title"><?php echo esc_html( get_option( 'bya_localization_buy_again_menu_label', 'Buy Again' ) ); ?></h1>
				<div class="bya-owl-carousel-items owl-carousel">
					<?php
					bya_get_template(
						'buy-again-cart.php',
						array(
							'user_id'     => $user_id,
							'product_ids' => bya_get_product_ids_from_user_orders( $user_id ),
						)
					);
					?>
				</div>
			</div>
			<?php
		}

		/**
		 * Add custom data in cart items.
		 *
		 * @since 1.0
		 * @param Integer $cart_id Cart Item Key.
		 * @param Integer $product_id Product ID.
		 * @param Integer $variation_id Variation ID.
		 * @param Array   $cart_item_data Cart Item Data.
		 * @return String
		 * */
		public static function find_cart_id_in_cart( $cart_id, $product_id, $variation_id, $cart_item_data ) {
			if ( '2' === get_option( 'bya_general_cart_same_entry', '1' ) ) {
				return $cart_id;
			}

			foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
				if ( $product_id !== $cart_item['product_id'] ) {
					continue;
				}

				if ( ! empty( $variation_id ) && $variation_id !== $cart_item['variation_id'] ) {
					continue;
				}

				if ( bya_check_is_array( $cart_item_data ) ) {
					foreach ( $cart_item_data as $cart_item_data_key => $cart_item_data_value ) {
						if ( ! isset( $cart_item[ $cart_item_data_key ] ) ) {
							continue 2;
						}

						if ( $cart_item[ $cart_item_data_key ] !== $cart_item_data_value ) {
							continue 2;
						}
					}
				}

				return $cart_item_key;
			}

			return $cart_id;
		}

		/**
		 * Add custom data in cart items.
		 *
		 * @param Array $item_data Cart Item Data.
		 * @param Array $cart_item Cart Item.
		 * @return Array
		 * */
		public static function maybe_add_custom_item_data( $item_data, $cart_item ) {
			if ( ! isset( $cart_item['product_id'] ) || empty( $cart_item['product_id'] ) ) {
				return $item_data;
			}

			$get_display_metas = bya_get_display_custom_metas();

			if ( ! bya_check_is_array( $get_display_metas ) ) {
				return $item_data;
			}

			foreach ( $get_display_metas as $meta_key ) {
				if ( ! isset( $cart_item[ $meta_key ] ) || ! bya_check_is_array( $cart_item[ $meta_key ] ) ) {
					continue;
				}

				foreach ( $cart_item[ $meta_key ] as $display_key => $display_value ) {
					$item_data[ $meta_key ] = array(
						'key'   => $display_key,
						'value' => $display_value,
					);
				}
			}

			return $item_data;
		}

		/**
		 * Display Product title based on Booster for WooCommerce custom cart info
		 *
		 * @since 1.0
		 * @param Array   $cart_item_data Cart item data.
		 * @param Integer $product_id Product ID.
		 * @param Integer $variation_id Product ID.
		 * @return Array
		 */
		public static function add_cart_item_data( $cart_item_data, $product_id, $variation_id ) {
			$order_id = isset( $_REQUEST['bya_order_id'] ) ? wc_clean( wp_unslash( $_REQUEST['bya_order_id'] ) ) : ''; // @codingStandardsIgnoreLine.

			if ( empty( $order_id ) ) {
				return $cart_item_data;
			}

			$cart_item_data = bya_prepare_cart_item_data( $order_id, $cart_item_data, $product_id, $variation_id );

			return $cart_item_data;
		}

		/**
		 * Add to cart from order again products.
		 *
		 * @since 4.4.0
		 */
		public static function set_order_again_products() {
			if ( ! isset( $_GET['bya_nonce'] ) || ! isset( $_GET['bya_order_again'] ) || ! is_user_logged_in() ) {
				return;
			}

			if ( ! wp_verify_nonce( sanitize_key( wp_unslash( $_GET['bya_nonce'] ) ), 'bya-order-again' ) ) {
				return;
			}

			$order_id = absint( $_GET['bya_order_again'] );

			if ( empty( $order_id ) ) {
				return;
			}

			$order_obj = wc_get_order( $order_id );

			if ( ! is_a( $order_obj, 'WC_Order' ) ) {
				return;
			}

			if ( ! $order_obj->has_status( get_option( 'bya_general_order_status_to_show', array( 'processing', 'completed' ) ) ) ) {
				return;
			}

			$cart              = array();
			$initial_cart_size = count( $cart );
			$order_items       = $order_obj->get_items();
			$allowed_items     = 0;

			foreach ( $order_items as $item ) {
				/**
				 * Buy Again Add to Cart Product ID.
				 *
				 * @since 4.4.0
				 */
				$product_id   = (int) apply_filters( 'bya_add_to_cart_product_id', $item->get_product_id() );

				/**
				 * Buy Again Add to Cart Quantity.
				 *
				 * @since 4.4.0
				 */
				$quantity     = (int) apply_filters( 'bya_add_to_cart_quantity', $item->get_quantity(), $item );
				$quantity     = '1' === get_option('bya_general_buy_again_order_qty', '1') ? $quantity : 1;
				$variation_id = (int) $item->get_variation_id();
				$variations   = array();

				/**
				 * Buy Again Add to Cart Item Data.
				 *
				 * @since 4.4.0
				 */
				$cart_item_data = apply_filters( 'bya_order_again_cart_item_data', array( 'buy_again_product' => 'bya_product' ), $item, $order_obj );
				$cart_item_attr = bya_prepare_cart_item_attr( $order_id, array(), $product_id, $variation_id );
				$product_obj    = $item->get_product();

				if ( ! $product_obj ) {
					continue;
				}

				// Prevent reordering variable products if no selected variation.
				if ( ! $variation_id && $product_obj->is_type( 'variable' ) ) {
					continue;
				}

				// Prevent reordering items specifically out of stock.
				if ( ! $product_obj->is_in_stock() ) {
					continue;
				}

				foreach ( $item->get_meta_data() as $meta ) {
					if ( taxonomy_is_product_attribute( $meta->key ) || meta_is_product_attribute( $meta->key, $meta->value, $product_id ) ) {
						$variations[ $meta->key ] = $meta->value;
					}
				}

				/**
				 * Buy Again Add to Cart Validation
				 *
				 * @since 4.7.0
				 */
				if ( ! apply_filters( 'bya_allow_order_item', true, $item->get_id(), $item, $order_obj ) ) {
					continue;
				}

				$allowed_items++;

				/**
				 * WooCommerce Add to Cart Validation
				 *
				 * @since 4.4.0
				 */
				if ( ! apply_filters( 'woocommerce_add_to_cart_validation', true, $product_id, $quantity, $variation_id, $variations, $cart_item_data ) ) {
					continue;
				}

				$cart_id      = WC()->cart->generate_cart_id( $product_id, $variation_id, $variations, $cart_item_data );
				$product_data = wc_get_product( $variation_id ? $variation_id : $product_id );

				/**
				 * Buy Again Order item data.
				 *
				 * @since 4.4.0
				 */
				$cart[ $cart_id ] = apply_filters(
					'bya_add_order_again_cart_item',
					array_merge(
						$cart_item_data,
						array(
							'key'          => $cart_id,
							'product_id'   => $product_id,
							'variation_id' => $variation_id,
							'variation'    => $variations,
							'quantity'     => $quantity,
							'data'         => $product_data,
							'data_hash'    => wc_get_cart_item_data_hash( $product_data ),
						)
					),
					$cart_id
				);

				WC()->cart->add_to_cart( $product_id, $quantity, $variation_id, $cart_item_attr, $cart_item_data );
			}

			do_action_ref_array( 'bya_ordered_again', array( $order_obj->get_id(), $order_items, &$cart ) );

			$num_items_in_cart           = count( $cart );
			$num_items_in_original_order = $allowed_items;
			$num_items_added             = $num_items_in_cart - $initial_cart_size;

			if ( $num_items_in_original_order > $num_items_added ) {
				wc_add_notice(
					sprintf(
					/* translators: %d item count */
						_n(
							'%d item from your previous order is currently unavailable and could not be added to your cart.',
							'%d items from your previous order are currently unavailable and could not be added to your cart.',
							$num_items_in_original_order - $num_items_added,
							'buy-again-for-woocommerce'
						),
						$num_items_in_original_order - $num_items_added
					),
					'error'
				);
			}

			if ( 0 < $num_items_added ) {
				wc_add_notice( __( 'The cart has been filled with the items from your previous order.', 'buy-again-for-woocommerce' ) );
			}

			wp_safe_redirect( wc_get_cart_url() );
			exit;
		}
	}

	BYA_Cart_Handler::init();
}
