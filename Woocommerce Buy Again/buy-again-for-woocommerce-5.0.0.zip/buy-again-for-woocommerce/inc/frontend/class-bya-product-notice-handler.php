<?php
/**
 * Handles the Product Notice.
 *
 * @package Buy Again/Product Notice Handler
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'BYA_Product_Notice_Handler' ) ) {
	/**
	 * Main Class
	 */
	class BYA_Product_Notice_Handler {

		/**
		 * Class Initialization.
		 */
		public static function init() {
			// Buy again enable check.
			if ( bya_allow_buy_again() ) {
				add_action( 'woocommerce_before_single_product', array( __CLASS__, 'get_product_notice' ) );
				add_filter( 'woocommerce_before_shop_loop_item', array( __CLASS__, 'render_shop_badge' ), 5 );
				add_action( 'woocommerce_product_thumbnails', array( __CLASS__, 'render_product_badge' ) );
			}
		}

		/**
		 * Product Notice
		 *
		 * @since 1.0.0
		 */
		public static function get_product_notice() {
			global $product;

			if ( ! is_a( $product, 'WC_Product' ) || ! is_product() || 'no' === get_option( 'bya_general_show_buy_again_notice', 'yes' ) ) {
				return;
			}

			$user_id = get_current_user_id();

			if ( ! bya_user_restriction( $user_id ) || ! bya_product_restriction( $product->get_id() ) ) {
				return;
			}

			$order = self::get_product_contain_order_id( $product->get_id(), $user_id );

			if ( ! bya_check_is_array( $order ) ) {
				return;
			}

			$link_caption = get_option( 'bya_general_order_detail_link_caption', esc_html__( 'Order_details', 'buy-again-for-woocommerce' ) );
			$message      = get_option( 'bya_general_buy_again_message', esc_html__( 'Previously you have puchased this product [order_details]', 'buy-again-for-woocommerce' ) );

			if ( str_contains( $message, '[order_details]' ) ) {
				$message = str_replace( '[order_details]', '', $message );
			}

			$message = sprintf( '<a href="%s" tabindex="1" class="button wc-forward">%s</a> %s', esc_url( $order['url'] ), esc_html( $link_caption ), esc_html( $message ) );

			wc_add_notice( $message, 'notice' );
		}

		/**
		 * Get product contain order id.
		 *
		 * @since 1.0.0
		 * @param Integer $product_id Product ID.
		 * @param Integer $customer_id Customer ID.
		 * @return Array|Boolean
		 */
		public static function get_product_contain_order_id( $product_id, $customer_id ) {
			$customer_objs = bya_get_customers(
				array(
					'user_id'    => $customer_id,
					'product_id' => $product_id,
				)
			);

			if ( ! $customer_objs->has_customer ) {
				return false;
			}

			$customer_obj = reset( $customer_objs->customers );

			return array(
				'order_id' => $customer_obj->get_last_order_id(),
				'url'      => $customer_obj->get_last_order()->get_view_order_url(),
			);
		}

		/**
		 * Render Badge for Custom Pricing product in shop page.
		 *
		 * @since 4.3.0
		 * */
		public static function render_shop_badge() {
			if ( 'yes' === get_option( 'bya_general_enable_tag_shop', 'no' ) && ! wc_current_theme_is_fse_theme() ) {
				self::render_badge();
			}
		}

		/**
		 * Render Badge for Custom Pricing product Page.
		 *
		 * @since 4.3.0
		 * */
		public static function render_product_badge() {
			if ( 'yes' === get_option( 'bya_general_enable_tag_product', 'no' ) ) {
				self::render_badge();
			}
		}

		/**
		 * Render Badge for Custom Pricing product in shop page.
		 *
		 * @since 4.3.0
		 * */
		public static function render_badge() {
			global $product;

			if ( ! is_a( $product, 'WC_Product' ) ) {
				return;
			}

			$user_id          = get_current_user_id();
			$user_restriction = bya_user_restriction( $user_id );

			if ( ! $user_restriction ) {
				return;
			}

			$product_restriction = bya_product_restriction( $product->get_id() );

			if ( ! $product_restriction ) {
				return;
			}

			$order = self::get_product_contain_order_id( $product->get_id(), $user_id );

			if ( ! bya_check_is_array( $order ) ) {
				return;
			}

			bya_get_template( 'badge.php' );
		}
	}

	BYA_Product_Notice_Handler::init();
}
