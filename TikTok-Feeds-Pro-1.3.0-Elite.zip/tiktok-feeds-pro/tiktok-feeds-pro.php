<?php

/**
 * Plugin Name: TikTok Feeds Pro Elite
 * Plugin URI: https://smashballoon.com/tiktok-feeds/
 * Description: Add TikTok feeds to your website.
 * Version: 1.3.0
 * Author: Smash Balloon
 * Author URI: https://smashballoon.com/
 * License: GPLv2 or later
 * Text Domain: feeds-for-tiktok
 * Domain Path: /languages
 * Requires at least: 5.2
 * Requires PHP: 7.4
 */

/*
Copyright 2024  Smash Balloon  (email: hey@smashballoon.com)
This program is paid software; you may not redistribute it under any
circumstances without the expressed written consent of the plugin author.
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
*/

if (! defined('ABSPATH')) {
	exit;
}

if (! defined('SBTT_PLUGIN_NAME')) {
	define('SBTT_PLUGIN_NAME', 'TikTok Feeds Pro Elite');
}

if (! defined('SBTTVER')) {
	define('SBTTVER', '1.3.0');
}

if (! defined('SBTT_PLUGIN_FILE')) {
	define('SBTT_PLUGIN_FILE', __FILE__);
}

if (! defined('SBTT_PLUGIN_DIR')) {
	define('SBTT_PLUGIN_DIR', plugin_dir_path(__FILE__));
}

if (! defined('SBTT_PRO')) {
	define('SBTT_PRO', true);
}

if (! defined('SBTT_PLUGIN_BASENAME')) {
	define('SBTT_PLUGIN_BASENAME', plugin_basename(__FILE__));
}

if (! defined('SBTT_STORE_URL')) {
	define('SBTT_STORE_URL', 'https://smashballoon.com/');
}

if (! defined('SBTT_MINIMUM_WALL_VERSION')) {
	define('SBTT_MINIMUM_WALL_VERSION', '2.2');
}

require_once trailingslashit(SBTT_PLUGIN_DIR) . 'bootstrap.php';

if (! class_exists('\TikTokFeeds\EDD_SL_Plugin_Updater')) {
	include dirname(__FILE__) . '/EDD_SL_Plugin_Updater.php';
}


/**
 * Initializes the TikTok Feeds plugin updater.
 *
 * This function sets up the plugin updater using the EDD_SL_Plugin_Updater class.
 * It retrieves the license key from the global settings and passes it to the updater.
 * The updater is responsible for checking for updates and handling the licensing of the plugin.
 *
 * @since 1.0.0
 */
function sb_tiktok_feeds_plugin_updater()
{
	$settings = get_option('sbtt_global_settings', array());

	$sbtt_license_key = ! empty($settings['license_key']) ? trim($settings['license_key']) : '';

	// setup the updater.
	$edd_updater = new TikTokFeeds\EDD_SL_Plugin_Updater(
		SBTT_STORE_URL,
		__FILE__,
		array(
			'version'   => SBTTVER,                   // current version number.
			'license'   => $sbtt_license_key,        // license key.
			'item_name' => SBTT_PLUGIN_NAME,         // name of this plugin.
			'author'    => 'Smash Balloon',          // author of this plugin.
		)
	);
}
add_action('admin_init', 'sb_tiktok_feeds_plugin_updater', 0);
