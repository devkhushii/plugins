=== TikTok Feeds Pro Elite ===
Author: Smash Balloon
Contributors: smashballoon
Support Website: https://smashballoon.com/tiktok-feeds/
Requires at least: 5.2
Tested up to: 6.6
Stable tag: 1.3.0
Requires PHP: 7.4
License: Non-distributable, Not for resale

TikTok Feeds Pro allows you to display completely customizable TikTok videos in a clean feed.

== Description ==
Display **completely customizable**, **responsive** and **search engine crawlable** versions of your TikTok feed on your website. Completely match the look and feel of your site with tons of customization options!

= Features =
* **Completely Customizable** - by default inherits your theme's styles
* TikTok feed content is **crawlable by search engines** adding SEO value to your site
* **Completely responsive and mobile optimized** - works on any screen size
* Display videos from TikTok

For simple step-by-step directions on how to set up the TikTok Feeds Pro plugin please refer to our [setup guide](https://smashballoon.com/doc/how-to-create-a-feed-using-the-tiktok-feeds-pro-wordpress-plugin/?tiktok 'TikTok Feeds Pro setup guide').


== Installation ==
1. Install the TikTok Feeds Pro plugin by uploading the files to your web server (in the /wp-content/plugins/ directory).
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Navigate to the 'TikTok Feed' settings page to connect your TikTok account and create a new feed.
4. Use the shortcode [sbtt-tiktok feed=1] in your page, post or widget to display your feed.


For simple step-by-step directions on how to set up the TikTok Feeds Pro plugin please refer to our [setup guide](https://smashballoon.com/doc/how-to-create-a-feed-using-the-tiktok-feeds-pro-wordpress-plugin/?tiktok 'TikTok Feeds Pro setup guide').


== Changelog ==
= 1.3.0 = 
* New: Added support for an inline video player. Great for use cases where you want to display a video in a feed without opening a lightbox.
* New: Added support for a "gallery" layout for "Plus" and "Elite" tiers. Showcase videos in an inline player at the top of your feed with thumbnails below to select others.
* New: Added support for a "list" layout for "Plus" and "Elite" tiers. Show your TikToks in a clean single column widget where videos play inline.
* New: Integration with [WPCode](https://wordpress.org/plugins/insert-headers-and-footers/) to make managing JavaScript and CSS customizations simple.
* Fix: Fixed responsiveness for narrow width list and grid layouts.
* Fix: Fixed an issue preventing multiple sources from showing up in a feed when multiple sources were used.

= 1.2.0 =
* New: Replaced the iframe video player with a .mp4 video player. Your visitors will now have a clean, distraction free experience when watching videos.
* Fix: Fixed an issue that would cause the load more button to disappear before all posts were loaded on the page.
* Translations: Added translations for German, Spanish, French, Italian, Dutch, Japanese, French, Russian, Polish, and Portuguese.
* Translations: Added wpml-config.xml for WPML compatibility.

= 1.1.3 =
* Fix: Fixed the 403 error that was occurring when trying to connect a new source for some users.

= 1.1.2 =
* Fix: Fixed an issue that would cause the source to not be updated after source connection.

= 1.1.1 =
* New: Added compatibility with Thrive Architect.

= 1.1 =
* New: Added compatibility with [Social Wall](https://smashballoon.com/pricing/all-access/), a plugin that allows you to show a feed from multiple social media sources.

= 1.0.2 =
* Fix: Fixed an issue that would cause an infinite loop of API requests when an error occurred.

= 1.0.1 =
* Fix: Fixed an issue that would cause the backup feed not to work in the event the access token had been invalidated and an API request was made.
* Fix: Fixed the layout of the lightbox and TikTok player for mobile devices to be wider and more user friendly.

= 1.0 =
* Launched the TikTok Feeds Pro plugin
