<?php

namespace SmashBalloon\TikTokFeeds\Pro;

use SmashBalloon\TikTokFeeds\Common\Container;
use SmashBalloon\TikTokFeeds\Pro\Services\LicenseManagerService;
use SmashBalloon\TikTokFeeds\Pro\Services\ShortcodeService;

class ServiceContainer extends \SmashBalloon\TikTokFeeds\Common\ServiceContainer
{
	/**
	 * Constructor.
	 *
	 * @return void
	 */
	public function __construct()
	{
		$this->services[] = LicenseManagerService::class;
		$this->services[] = ShortcodeService::class;

		// parent constructor
		parent::__construct();
	}

	public function register(): void
	{
		$container = Container::get_instance();

		foreach ($this->services as $service) {
			$serviceInstance = $container->get($service);

			if ($serviceInstance !== null) {
				$serviceInstance->register();
			}
		}
	}
}
