<?php

namespace SmashBalloon\TikTokFeeds\Pro\Services;

use SmashBalloon\TikTokFeeds\Common\Database\FeedsTable;
use SmashBalloon\TikTokFeeds\Common\FeedSettings;
use SmashBalloon\TikTokFeeds\Common\Feed;
use SmashBalloon\TikTokFeeds\Common\FeedCache;

class ShortcodeService extends \SmashBalloon\TikTokFeeds\Common\Services\ShortcodeService
{
	public function register()
	{
		add_shortcode('tiktok-feeds', array( $this, 'render' ));
		add_action('wp_ajax_sbtt_load_more_posts', array( $this, 'get_next_post_set_json' ));
		add_action('wp_ajax_nopriv_sbtt_load_more_posts', array( $this, 'get_next_post_set_json' ));
	}

	/**
	 * Get the next set of posts for the feed
	 *
	 * @since 1.0
	 */
	public function get_next_post_set_json()
	{
		check_ajax_referer('sbtt-frontend', 'nonce');

		if (! isset($_POST['feed_id'])) {
			wp_send_json_error();
		}

		$feed_id   = ! empty($_POST['feed_id']) ? absint($_POST['feed_id']) : 0;
		$next_page = ! empty($_POST['next_page']) ? absint($_POST['next_page']) : 2;

		$feed_data = new FeedSettings($feed_id);
		$feed_settings = $feed_data->get_feed_settings();

		if (! isset($feed_settings['sources']) || empty($feed_settings['sources'])) {
			wp_send_json_error();
		}

		$feed = new Feed($feed_settings, $feed_id, new FeedCache($feed_id, 2 * DAY_IN_SECONDS));
		$feed->init();
		$feed->get_set_cache();
		$posts = $feed->get_post_set_page($next_page);

		$data = array(
			'posts'     => $posts,
			'next_page' => $feed->has_next_page($next_page),
		);

		wp_send_json_success($data);

		wp_die();
	}
}
