<?php

namespace SmashBalloon\TikTokFeeds\Pro\Services;

use Smashballoon\Stubs\Services\ServiceProvider;
use SmashBalloon\TikTokFeeds\Common\Container;
use SmashBalloon\TikTokFeeds\Common\Relay\Relay;
use SmashBalloon\TikTokFeeds\Common\Services\SettingsManagerService;
use SmashBalloon\TikTokFeeds\Common\AuthorizationStatusCheck;
use Exception;

class LicenseManagerService extends ServiceProvider
{
	private $relay;
	private $global_settings;
	private $status;

	private $license_tiers = [
		"TikTok Feeds Pro Basic"                    => 'basic',
		"TikTok Feeds Pro Plus"                     => 'plus',
		"TikTok Feeds Pro Elite"                    => 'pro',
		"All Access Bundle - All Plugins Unlimited" => 'pro',
	];

	public function __construct()
	{
		$this->relay           = new Relay();
		$this->global_settings = Container::get_instance()->get(SettingsManagerService::class);
		$this->status          = new AuthorizationStatusCheck();
	}

	public function register()
	{
		add_action('wp_ajax_sbtt_activate_license', [ $this, 'ajax_activate_license' ]);
		add_action('wp_ajax_sbtt_deactivate_license', [ $this, 'ajax_deactivate_license' ]);
		add_action('wp_ajax_sbtt_test_connection', [ $this, 'ajax_test_connection' ]);
	}

	public function ajax_activate_license()
	{
		check_ajax_referer('sbtt-admin', 'nonce');

		if (! current_user_can('manage_options')) {
			wp_send_json_error();
		}

		if (! isset($_POST['license_key']) || empty($_POST['license_key'])) {
			wp_send_json_error(
				[
					'message' => 'license_key are required.',
				]
			);
		}

		$license_key = sanitize_text_field($_POST['license_key']);

		$data = [
			'license_key' => $license_key,
			'url'         => get_home_url(),
			'action'      => 'activate',
		];

		try {
			$response = $this->relay->call('auth/license', $data);
			$response = is_array($response) ? $response : [];

			if (isset($response['data']['license']) && $response['data']['license'] === 'valid') {
				$this->global_settings->update_global_settings(
					[
						'license_status' => isset($response['data']['license']) ? $response['data']['license'] : '',
						'license_info'   => isset($response['data']['api_data']) ? $response['data']['api_data'] : '',
						'license_key'    => $license_key,
					]
				);

				$item_name = isset($response['data']['api_data']['item_name']) ? $response['data']['api_data']['item_name'] : false;

				$this->status->update_statuses(
					[
						'last_cron_update' => time(),
						'license_info'     => isset($response['data']['api_data']) ? $response['data']['api_data'] : '',
						'license_tier'     => $item_name && $this->license_tiers[$item_name] ? $this->license_tiers[$item_name] : 'free',
					]
				);
			}

			$return = array_merge(
				$response,
				[
					'license_status' => isset($response['data']['license']) ? $response['data']['license'] : '',
					'license_info'   => isset($response['data']['api_data']) ? $response['data']['api_data'] : '',
					'license_key'    => $license_key,
					'pluginStatus'   => $this->status->get_statuses(),

				]
			);

			wp_send_json($return);
		} catch (Exception $exception) {
			wp_send_json_error(
				[
					'message' => $exception->getMessage(),
				],
				$exception->getCode()
			);
		}

		wp_die();
	}

	public function ajax_deactivate_license()
	{
		check_ajax_referer('sbtt-admin', 'nonce');

		if (! current_user_can('manage_options')) {
			wp_send_json_error();
		}

		if (! isset($_POST['license_key'])) {
			wp_send_json_error(
				[
					'message' => 'license_key, site_key are required.',
				],
				401
			);
		}

		$license_key = sanitize_text_field($_POST['license_key']);

		$data = [
			'license_key' => $license_key,
			'url'         => get_home_url(),
			'action'      => 'deactivate',
		];

		try {
			$response = $this->relay->call('auth/license', $data);

			$this->global_settings->update_global_settings(
				[
					'license_status' => '',
					'license_info'   => '',
					'license_key'    => '',
				]
			);

			$this->status->update_statuses(
				[
					'last_cron_update' => time(),
					'license_info'     => '',
					'license_tier'     => 'free',
				]
			);

			wp_send_json($response);
		} catch (Exception $exception) {
			wp_send_json_error(
				[
					'message' => $exception->getMessage(),
				],
				$exception->getCode()
			);
		}

		wp_die();
	}

	public function ajax_test_connection()
	{
		check_ajax_referer('sbtt-admin', 'nonce');

		if (! current_user_can('manage_options')) {
			wp_send_json_error();
		}

		if (! isset($_POST['license_key'])) {
			wp_send_json_error(
				[
					'message' => 'license_key, site_key are required.',
				],
				401
			);
		}

		$license_key = sanitize_text_field($_POST['license_key']);

		try {
			$args = [
				'license_key' => $license_key,
				'url'         => get_home_url(),
				'action'      => 'check_license',
				'headers'     => [
					'Content-Type' => 'application/json',
				],
			];

			$response = $this->relay->call('auth/license', $args);

			wp_send_json(
				[
					'success' => isset($response['data']['license']) && $response['data']['license'] === 'valid' ? true : false,
				]
			);
		} catch (Exception $exception) {
			wp_send_json(
				[
					'success' => false,
				]
			);
		}

		wp_die();
	}
}
