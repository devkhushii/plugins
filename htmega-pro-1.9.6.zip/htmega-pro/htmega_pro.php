<?php
/**
 * Plugin Name: HT Mega Pro
 * Description: The HTMega is a elementor addons package for Elementor page builder plugin for WordPress.
 * Plugin URI:  https://wphtmega.com/
 * Author:      HasThemes
 * Author URI:  https://hasthemes.com/plugins/ht-mega-pro/
 * Version:     1.9.6
 * License:     GPL2
 * License URI:  https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: htmega-pro
 * Domain Path: /languages
 * Elementor tested up to: 3.25.4
 * Elementor Pro tested up to: 3.25.2
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
update_option( 'HTMegaPro_lic_Key', 'activated' );
update_option( 'HTMegaPro_lic_email', 'noreply@gpmail.com' );
define( 'HTMEGA_VERSION_PRO', '1.9.6' );
define( 'HTMEGA_ADDONS_PL_ROOT_PRO', __FILE__ );
define( 'HTMEGA_ADDONS_PL_URL_PRO', plugins_url( '/', HTMEGA_ADDONS_PL_ROOT_PRO ) );
define( 'HTMEGA_ADDONS_PL_PATH_PRO', plugin_dir_path( HTMEGA_ADDONS_PL_ROOT_PRO ) );
define( 'HTMEGA_ADDONS_PLUGIN_BASE_PRO', plugin_basename( HTMEGA_ADDONS_PL_ROOT_PRO ) );

// Required File
require_once ( HTMEGA_ADDONS_PL_PATH_PRO .'includes/class.htmega-pro.php' );
if( is_admin() ){
    add_action( 'plugins_loaded', function() {
        include_once ( HTMEGA_ADDONS_PL_PATH_PRO .'includes/licence/HTMegaPro.php' );
    } );
}