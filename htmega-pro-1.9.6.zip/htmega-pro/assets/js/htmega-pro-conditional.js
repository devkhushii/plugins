;(function($){
        // To Run this code under Elementor.
        $(window).on('elementor/frontend/init', function () {

            //Time range condition cookie.
            let HTMegaLocalTimeZone = new Date().toString().match(/([A-Z]+[\+-][0-9]+.*)/)[1];

            let securedCheck = (document.location.protocol === 'https:') ? 'secure' : '';
            if (-1 != HTMegaLocalTimeZone.indexOf("(")) {
                HTMegaLocalTimeZone = HTMegaLocalTimeZone.split('(')[0];
            }

            document.cookie = "HTMegaLocalTimeZone=" + HTMegaLocalTimeZone + ";SameSite=Strict;" + securedCheck;

            //Recurring User condition cookie set.
            if (elementorFrontend.config.post.id) {
                document.cookie = "recurringVisitor" + elementorFrontend.config.post.id + "=true;SameSite=Strict;" + securedCheck;
            }
        });
        
    })(jQuery);