(function ($) {
    "use strict";
  
    var HTMegaFlipster = function ( $scope, $ ){
        var container_elem = $scope.find('.htmega-flipster').eq(0);
        if ( container_elem.length > 0 ) {
            var dataOpt = container_elem.data('settings');
            container_elem.flipster({
                start:dataOpt.start,
                fadeIn:dataOpt.fadein,
                loop:dataOpt.loop,
                style: dataOpt.style,
                spacing: dataOpt.spacing,
                autoplay: ( dataOpt.autoplay ) ? dataOpt.autoplay_speed : false,
                keyboard:dataOpt.keyboard,
                scrollwheel:dataOpt.scrollwheel,
                nav:dataOpt.dots_position,
                buttons:dataOpt.arrows,
                buttonPrev:dataOpt.prev_txt,
                buttonNext:dataOpt.next_txt,
            });
     
            // Increment the pagination index on each flipster flip
            var paginationIndex = container_elem.find('.flipster__nav__item').find('.flipster__nav__link');
			
			paginationIndex.each(function() {
				$(this).text(parseInt($(this).text()) + 1);
			});   
        }
    }
    // Run this code under Elementor.
    $(window).on('elementor/frontend/init', function () {
        elementorFrontend.hooks.addAction( 'frontend/element_ready/htmega-flip-carousel-addons.default', HTMegaFlipster);
    });      


})(jQuery);
