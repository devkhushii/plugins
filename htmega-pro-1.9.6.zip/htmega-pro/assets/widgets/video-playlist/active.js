(function ($) {
    "use strict";
    var HTMegaVideoPlaylist = function ( $scope, $ ){
        var container_elem = $scope.find('.htmega-video-playlist-wrapper').eq(0);
        if ( container_elem.length > 0 ) {
           // container_elem[0].style.display='block';
            var settings = container_elem.data('settings');

            var galleryHeight = settings['gallery_height'];
            $("#"+container_elem[0].id).unitegallery({
                gallery_theme: "video",
                gallery_height: galleryHeight || 500,
                gallery_width: "100%",
                theme_skin: settings['video_playlist_layout'],
                theme_autoplay: settings['video_autoplay'] || false,
                theme_next_video_onend: settings['video_autoplay_next'] || false,
                strip_control_avia: settings['mouse_hover_navigation'] || false,	
                strip_space_between_thumbs: parseInt(settings['video_item_gap']['size']) || 0, // thhumb item space
                strippanel_enable_buttons: settings['navigation_buttons'],
                strippanel_padding_top: parseInt(settings['video_list_panel_padding']['top']) || 0,
                strippanel_padding_bottom: parseInt(settings['video_list_panel_padding']['bottom']) || 0,
                strippanel_padding_left:  parseInt(settings['video_list_panel_padding']['left']) || 0,
                strippanel_padding_right: parseInt(settings['video_list_panel_padding']['right']) || 0,
            });
        }
 
    }
    // Run this code under Elementor.
    $(window).on('elementor/frontend/init', function () {
        elementorFrontend.hooks.addAction( 'frontend/element_ready/htmega-video-playlist-addons.default', HTMegaVideoPlaylist);
    });      


})(jQuery);
