
;(function($){
    "use strict";
        // Carousel Handler
        var WidgetHtmegaSourceCodeHandler = function () {
            const htMegaCodeTarget = document.querySelectorAll('.htmega-source-code-wrap')
            htMegaCodeTarget.forEach(el=> {
                const htmegaCodePre = el.querySelector('pre');
                const htmegaCodeBox = el.querySelector('code').getBoundingClientRect().height;
                const htmegaCodeBoxDec = htmegaCodeBox - 50;
                //const htmegaCodeBox = el.querySelector('code').offsetHeight
                const htmegaCodePreHeight = htmegaCodePre.dataset.htmega;
                htmegaCodePre.style.maxHeight = `${htmegaCodePreHeight}px`;
                if(htmegaCodeBoxDec >= Number(htmegaCodePreHeight) ){
                    el.classList.add('htmega-scroll');
                }
            });
            }

        // Run this code under Elementor.
        $(window).on('elementor/frontend/init', function () {
            elementorFrontend.hooks.addAction( 'frontend/element_ready/htmega-source-code-addons.default', WidgetHtmegaSourceCodeHandler);
        });

        
    })(jQuery);








