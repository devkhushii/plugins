;(function($){
"use strict";

    /*=========== Image Switcher =======*/
    var WidgetBackgroundSwitcherElement = function ($scope, $) {

		$('.htmega-bg-image-switcher-item').mouseenter(function () {
			const $this = $(this),
				$imgTarget = $this.data('img-target'),
				$bgImage = $this.siblings('.htmega-bg-image-switcher-background').find('img[data-img-id="'+$imgTarget+'"]');
			$this.addClass('active').siblings('.htmega-bg-image-switcher-item').removeClass('active');
			$bgImage.addClass('active').siblings('img').removeClass('active');
		})
        
    }

    // Run this code under Elementor.
    $(window).on('elementor/frontend/init', function () {
        elementorFrontend.hooks.addAction( 'frontend/element_ready/htmega-background-switcher.default', WidgetBackgroundSwitcherElement);
    });

})(jQuery);