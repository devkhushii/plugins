
;(function($){
    "use strict";
        // Carousel Handler
        var WidgetHtmegaThreesixty_RotationHandler = function ($scope, $) {

            var activeElement = $scope.find( '.htmega-threesixty-rotation-wrap' ).eq(0);

            var settings = activeElement.data('settings');

            var activeId = `htmega-360-rotation${settings.secid}`;

            var htmegaRotationTwoOptions = {
                scroll: true,
                vertical: false,
                speed: settings.play_speed,
                playSpeed: settings.play_speed,
            }
            var htmegaCrl = circlr(activeId , htmegaRotationTwoOptions);
            if( 'autoplay' == settings.play_option){
                var myTimeout = setTimeout(function () {
                    htmegaCrl.play();
                }, 100 );

            } else if( 'play_button' == settings.play_option){

                var playButton = `htmega-play-button-${settings.secid}`;
                var btnPlay2 = document.getElementById(playButton);

                btnPlay2.addEventListener('click', function (e) {
                    e.preventDefault();
                    htmegaCrl.play();
                    }, false);
            }

        }

        // Run this code under Elementor.
        $(window).on('elementor/frontend/init', function () {
            elementorFrontend.hooks.addAction( 'frontend/element_ready/htmega-threesixty-rotation-addons.default', WidgetHtmegaThreesixty_RotationHandler);
        });

        
    })(jQuery);








