<?php
namespace HTMega_Pro_Builder\Elementor;
use Elementor\Plugin as Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class HTMegaBuilder_Custom_Template_Layout{
    
    private static $_instance = null;
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    function __construct(){
        add_action('init', array( $this, 'init' ) );
    }

    /*
    * init Hooks init
    */
    public function init(){

        // Template
        add_filter( 'template_include', array( $this, 'change_template' ), 9999 );

        // Search Page Template
       add_action( 'htmegabuilder_search_content', array( $this, 'search_content_elementor' ), 999 );

       // 404 Error Page 
       add_action( 'htmegabuilder_error_content', array( $this, 'error_content_elementor' ), 999 );

       // Coming Soon Page 
       add_action( 'htmegabuilder_comingsoon_content', array( $this, 'comingsoon_content_elementor' ), 999 );

    }

    /*
    * Change template
    */
    public function change_template( $template ) {

        if ( is_embed() ) { return $template; }

        // Custom Search page template id
        $search_tm_id = $this->custom_template_id( 'search_page' );
        $error_tm_id = $this->custom_template_id( 'error_page' );
        $comingsoon_tm_id = $this->custom_template_id( 'coming_soon_page' );
        
        // Template Slug
        $searchtemplateid = get_page_template_slug( $search_tm_id );
        $errortemplateid = get_page_template_slug( $error_tm_id );
        $comingsoontemplateid = get_page_template_slug( $comingsoon_tm_id );

        // Search page
        if( is_search() && !empty( $search_tm_id ) ){
            if ( 'elementor_header_footer' === $searchtemplateid ) {
                $template = HTMEGA_ADDONS_PL_PATH_PRO . 'extensions/ht-builder/templates/search-fullwidth.php';
            } elseif ( 'elementor_canvas' === $searchtemplateid ) {
                $template = HTMEGA_ADDONS_PL_PATH_PRO . 'extensions/ht-builder/templates/search-canvas.php';
            }
        }

        // 404 page
        elseif( is_404() && !empty( $error_tm_id ) ){
            if ( 'elementor_header_footer' === $errortemplateid ) {
                $template = HTMEGA_ADDONS_PL_PATH_PRO . 'extensions/ht-builder/templates/error-fullwidth.php';
            } elseif ( 'elementor_canvas' === $errortemplateid ) {
                $template = HTMEGA_ADDONS_PL_PATH_PRO . 'extensions/ht-builder/templates/error-canvas.php';
            }
        }

        // Coming soon page
        elseif( !is_user_logged_in() && !empty( $comingsoon_tm_id ) ){
            if ( 'elementor_header_footer' === $comingsoontemplateid ) {
                $template = HTMEGA_ADDONS_PL_PATH_PRO . 'extensions/ht-builder/templates/comingsoon-fullwidth.php';
            } elseif ( 'elementor_canvas' === $comingsoontemplateid ) {
                $template = HTMEGA_ADDONS_PL_PATH_PRO . 'extensions/ht-builder/templates/comingsoon-canvas.php';
            }
        }

        return $template;

    }

    /*
    * Custom Template ID
    */
    public function custom_template_id( $option_key ){
        $custom_tm_id =  htmega_get_module_option( 'htmega_themebuilder_module_settings', 'themebuilder', $option_key ) ? htmega_get_module_option( 'htmega_themebuilder_module_settings', 'themebuilder', $option_key ) : htmega_get_option_pro( $option_key, 'htmegabuilder_templatebuilder_tabs', '0' );

        return $custom_tm_id;
    }

    /* 
    * Render Elementor search page content
    */
    public function search_content_elementor( $post ) {
        $templateid = $this->custom_template_id( 'search_page' );
        if( !empty( $templateid ) ){
            echo htmega_get_template_content_by_id( $templateid );  // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        }else{
            the_content();
        }
    }

    /* 
    * Render Elementor 404 error page content
    */
    public function error_content_elementor( $post ) {
        $templateid = $this->custom_template_id( 'error_page' );
        if( !empty( $templateid ) ){
            echo htmega_get_template_content_by_id( $templateid ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        }else{
            the_content();
        }
    }

    /* 
    * Render Elementor Coming soon page content
    */
    public function comingsoon_content_elementor( $post ) {
        $templateid = $this->custom_template_id( 'coming_soon_page' );
        if( !empty( $templateid ) ){
            echo htmega_get_template_content_by_id( $templateid ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        }else{
            the_content();
        }
    }


}

HTMegaBuilder_Custom_Template_Layout::instance();