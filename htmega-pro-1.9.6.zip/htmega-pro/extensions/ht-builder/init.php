<?php
require( HTMEGA_ADDONS_PL_PATH_PRO.'extensions/ht-builder/classes/class.template_builder.php' );
require( HTMEGA_ADDONS_PL_PATH_PRO.'extensions/ht-builder/classes/class.custom-metabox.php' );
require( HTMEGA_ADDONS_PL_PATH_PRO.'extensions/ht-builder/classes/class.widgets_control.php' );