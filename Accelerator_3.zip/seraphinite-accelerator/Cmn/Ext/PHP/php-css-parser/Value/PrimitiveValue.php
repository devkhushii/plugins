<?php

namespace seraph_accel\Sabberworm\CSS\Value;

abstract class PrimitiveValue extends Value {
    public function __construct($iPos = 0) {
        parent::__construct($iPos);
    }

}