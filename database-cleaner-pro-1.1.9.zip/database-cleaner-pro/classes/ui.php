<?php

class Meow_DBCLNR_UI {
	private $core = null;

	function __construct( $core ) {
	}
}
