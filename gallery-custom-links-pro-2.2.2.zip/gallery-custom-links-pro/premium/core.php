<?php

class MeowPro_MGCL_Core {
	private $item = 'Gallery Custom Links Pro';
	private $core = null;

	public function __construct( $core ) {
    $this->core = $core;

		// Additional functions for Pro
		add_action( 'init', array( $this, 'init' ) );
	}

	function init() {
		// Common behaviors, license, update system, etc.
		new MeowCommonPro_Licenser( MGCL_PREFIX, MGCL_ENTRY, MGCL_DOMAIN, $this->item, MGCL_VERSION );

    if ( is_admin() ) {
      new MeowPro_MGCL_Library( $this->core );
    }
	}



}
