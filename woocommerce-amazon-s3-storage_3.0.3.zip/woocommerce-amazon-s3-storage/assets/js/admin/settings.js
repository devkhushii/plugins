( function ( $ ) {

	$( document ).ready( function () {

		// toggles the access mode fields
		$( 'input[name="access_mode"]' ).on( 'change', function() {
			if ( 'constant' === $( 'input[name="access_mode"]:checked' ).val() ) {
				$( '#access_mode_constant' ).hide();
				$( '#access_mode_database' ).show();
				$( '#access_key_id' ).closest( 'tr' ).hide();
				$( '#secret_access_key' ).closest( 'tr' ).hide();
			} else {
				$( '#access_mode_constant' ).show();
				$( '#access_mode_database' ).hide();
				$( '#access_key_id' ).closest( 'tr' ).show();
				$( '#secret_access_key' ).closest( 'tr' ).show();
			}
		} ).change();

		// toggles the automatic offloading fields
		$( '#offload_downloadables' ).on( 'change', function() {
			if ( $( this ).is( ':checked' ) ) {
				$( '#default_bucket' ).trigger( 'change' ).closest( 'tr' ).show();
			} else {
				$( '#default_bucket' ).trigger( 'change' ).closest( 'tr' ).hide();
			}
		} ).trigger( 'change' );

		// copies the regions from the default bucket to the new bucket region and enables the enhanced select box
		$( '#default_region optgroup' ).clone().appendTo( '#new_bucket_region' );
		$( '#new_bucket_region' ).selectWoo();

		// toggles the new bucket fields when creating a new bucket
		$( '#default_bucket' ).on( 'change', function() {
			if ( '' === $( this ).val() && $( '#offload_downloadables' ).is( ':checked' ) ) {
				$( '#new_bucket' ).closest( 'tr' ).show();
				$( '#new_bucket_region' ).closest( 'tr' ).show();
			} else {
				$( '#new_bucket' ).closest( 'tr' ).hide();
				$( '#new_bucket_region' ).closest( 'tr' ).hide();
			}
		} ).trigger( 'change' );

		$( '#new_bucket' ).on( 'input', function() {
			let bucket_name = $( this ).val();

			if ( ! bucket_name || bucket_name.length === 0 || validate_bucket_name( bucket_name ) ) {
				$( this ).css( 'border-color', '' );
			} else {
				$( this ).css( 'border-color', 'red' );
			}
		} );

		/**
		 * Validates a bucket name.
		 *
		 * @param {string} bucket_name
		 * @return {boolean}
		 */
		function validate_bucket_name( bucket_name ) {

			// must be between 3 and 63 characters
			if ( bucket_name.length < 3 || bucket_name.length > 63 ) {
				return false;
			}

			// only lowercase letters, numbers, dots, and hyphens allowed
			if ( !/^[a-z0-9.-]+$/.test( bucket_name ) ) {
				return false;
			}

			// must begin and end with a letter or number
			if ( !/^[a-z0-9].*[a-z0-9]$/.test( bucket_name ) ) {
				return false;
			}

			// must not contain two adjacent periods
			if ( bucket_name.indexOf('..' ) !== -1 ) {
				return false;
			}

			// must not be formatted as an IP address
			let ipv4Regex = /^(\d{1,3}\.){3}\d{1,3}$/;
			if ( ipv4Regex.test( bucket_name ) ) {
				return false;
			}

			// disallowed prefixes
			if ( bucket_name.startsWith( 'xn--' ) || bucket_name.startsWith( 'sthree-' ) || bucket_name.startsWith( 'sthree-configurator' ) || bucket_name.startsWith( 'amzn-s3-demo-' ) ) {
				return false;
			}

			// disallowed suffixes
			if ( bucket_name.endsWith( '-s3alias' ) || bucket_name.endsWith( '--ol-s3' ) || bucket_name.endsWith( '.mrap' ) || bucket_name.endsWith( '--x-s3' ) ) {
				return false;
			}

			// valid bucket name
			return true;
		}
	} );

} )( jQuery );
