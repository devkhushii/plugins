/* global wcSetClipboard, wcClearClipboard, wcS3StorageMetaBoxesProduct */
( function( $, params ) {
	'use strict';

	const Shortcode = Backbone.Model.extend( {
		defaults() {
			return {
				object: '',
				bucket: '',
				region: '',
			};
		},

		// eslint-disable-next-line object-shorthand
		constructor: function() {
			// Set the model attributes from the shortcode string.
			if ( arguments.length && typeof arguments[ 0 ] === 'string' ) {
				arguments[ 0 ] = this.extractAttrs( arguments[ 0 ] );
			}

			Backbone.Model.apply( this, arguments );
		},

		reset() {
			return this.clear( { silent: true } ).set( this.defaults() );
		},

		extractAttrs( string ) {
			const pairs = string.matchAll( /(\w+)=([^\s\[\]]+)+/g );
			const attrs = {};

			for ( const pair of pairs ) {
				attrs[ pair[ 1 ] ] = pair[ 2 ].replace( /['"]+/g, '' );
			}

			return attrs;
		},

		getShortcode() {
			let string = '[amazon_s3';

			for ( const [ key, value ] of Object.entries( this.attributes ) ) {
				if ( value || 'object' === key ) {
					string += ` ${ key }="${ value }"`;
				}
			}

			string += ']';

			return string;
		},

		setShortcode( string ) {
			return this.reset().set( this.extractAttrs( string ), { silent: true } );
		},

		getFileName() {
			let filename = this.get( 'object' );

			// Extract basename.
			filename = filename.split( '/' ).pop();

			// Remove file extension.
			filename = filename.split( '.' )[ 0 ];

			// Split into words.
			filename = filename.replace( /[-_+]/g, ' ' );

			// Capitalize.
			filename = filename.charAt( 0 ).toUpperCase() + filename.slice( 1 );

			return filename;
		},
	} );

	const ShortcodeView = Backbone.View.extend( {
		initialize() {
			this.render();
			this.listenTo( this.model, 'change', this.render );
		},

		render() {
			this.$el.text( this.model.getShortcode() );
		},
	} );

	const ShortcodeModalView = $.WCBackboneModal.View.extend( {
		events() {
			return _.extend( {}, $.WCBackboneModal.View.prototype.events, {
				'click .add-file': 'addFile',
				'submit .shortcode-form': 'submitForm',
				'keyup .form-field input': 'updateModel',
				'change .form-field select': 'updateModel',
				'click .copy-shortcode': 'copyShortcode',
				'aftercopy .copy-shortcode': 'copyShortcodeTip',
			} );
		},

		initialize( data ) {
			// Action: Add or edit a file.
			this.action = data.action;

			// Callback function.
			this.onSubmit = data.onSubmit;

			$.WCBackboneModal.View.prototype.initialize.apply( this, [ {
				target: 'wc-amazon-s3-storage-shortcode-modal',
				string: {
					action: this.action,
					shortcode: this.model.toJSON(),
				},
			} ] );

			new ShortcodeView( {
				el: '.shortcode-text',
				model: this.model,
			} );

			// Set the S3 region in the selector field.
			this.$el.find( 'select#region' ).val( this.model.get( 'region' ) );

			// Init enhanced selects.
			$( document.body ).trigger( 'wc-enhanced-select-init' );
		},

		addFile( event ) {
			event.preventDefault();

			// Submit the form to trigger the fields' validation.
			this.$el.find( '.shortcode-form input[type="submit"]' ).trigger( 'click' );
		},

		submitForm( event ) {
			event.preventDefault();

			this.onSubmit( this.model );

			// Close the modal.
			this.closeButton( event );
		},

		updateModel( event ) {
			const field = $( event.target );
			const attr = field.prop( 'id' );

			if ( this.model.has( attr ) ) {
				this.model.set( attr, field.val() );
			}
		},

		copyShortcode( event ) {
			const $target = $( event.target );

			event.preventDefault();

			wcClearClipboard();
			wcSetClipboard( this.model.getShortcode(), $target );
		},

		copyShortcodeTip( event ) {
			$( event.target ).tipTip( {
				attribute: 'data-tip',
				activation: 'focus',
				fadeIn: 50,
				fadeOut: 50,
				delay: 0,
			} ).trigger( 'focus' );
		},
	} );

	$.S3StorageDownloadableFiles = function( element, options ) {
		const defaults = {
			addFileBtnText: 'Add S3 file',
		};

		this.options = $.extend( {}, defaults, options );
		this.filesTable = element.find( 'table' );
		this.rowContent = this.filesTable.find( 'tfoot a.insert' ).data( 'row' );

		this.init();
	};

	$.S3StorageDownloadableFiles.prototype = {
		init() {
			this.initFilesTable();
			this.bindEvents();
		},

		initFilesTable() {
			const that = this;

			// Add the S3 button.
			this.filesTable.find( 'tfoot a.insert' ).after( ` <a class="button add-s3-file" href="#">${ this.options.addFileBtnText }</a>` );

			// Set the files' type.
			this.filesTable.find( 'tbody td.file_url input[value^="[amazon_s3"]' )
				.closest( 'tr' )
				.each( function() {
					that.setFileType( $( this ), 's3' );
				} );
		},

		bindEvents() {
			const that = this;

			this.filesTable.on( 'click', '.add-s3-file', function( event ) {
				event.preventDefault();

				new ShortcodeModalView( {
					model: new Shortcode(),
					action: 'add',
					onSubmit( shortcode ) {
						that.addFile( shortcode );
					},
				} );
			} );

			this.filesTable.on( 'click', '.edit-s3-file', function( event ) {
				event.preventDefault();

				const row = $( this ).closest( 'tr' );

				new ShortcodeModalView( {
					model: new Shortcode( row.find( '.file_url input' ).val() ),
					action: 'edit',
					onSubmit( shortcode ) {
						that.updateFile( row, shortcode );
					},
				} );
			} );

			this.filesTable.on( 'change', '.file_url input[type="text"]', function() {
				const type = ( $( this ).val().startsWith( '[amazon_s3' ) ? 's3' : '' );

				that.setFileType( $( this ).closest( 'tr' ), type );
			} );
		},

		addFile( shortcode ) {
			const row = $( this.rowContent );

			this.updateFile( row, shortcode );

			this.filesTable.find( 'tbody' ).append( row );
		},

		updateFile( row, shortcode ) {
			// Convert the row in a S3 file row.
			this.setFileType( row, 's3' );

			// Fill the file fields.
			row.find( '.file_name input[type="text"]' ).val( shortcode.getFileName() );
			row.find( '.file_url input' ).val( shortcode.getShortcode() );
		},

		setFileType( row, type ) {
			const button = row.find( 'td.file_url_choose a.button' );

			if ( 's3' === type ) {
				button.removeClass( 'upload_file_button' ).addClass( 'edit-s3-file' );
			} else {
				button.removeClass( 'edit-s3-file' ).addClass( 'upload_file_button' );
			}
		},
	};

	$.fn.S3StorageDownloadableFiles = function( options ) {
		return this.each( function() {
			const element = $( this );
			let instance = element.data( 'S3StorageDownloadableFiles' );

			if ( ! instance ) {
				instance = ( new $.S3StorageDownloadableFiles( element, options ) );

				// Store the object in the element data to avoid creating it twice.
				element.data( 'S3StorageDownloadableFiles', instance );
			}

			return instance;
		} );
	};

	$( function() {
		function initDownloadableFiles() {
			$( '.downloadable_files' ).S3StorageDownloadableFiles( {
				addFileBtnText: params.addFileBtnText,
			} );
		}

		// Init for simple products.
		initDownloadableFiles();

		// Init for product variations.
		$( '#woocommerce-product-data' ).on( 'woocommerce_variations_loaded', initDownloadableFiles );
		$( '#variable_product_options' ).on( 'woocommerce_variations_added', initDownloadableFiles );
	} );
}( jQuery, wcS3StorageMetaBoxesProduct ) );
