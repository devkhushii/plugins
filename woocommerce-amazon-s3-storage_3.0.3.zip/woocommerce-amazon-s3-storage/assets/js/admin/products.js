jQuery( document ).ready( function( $ ) {

	/** @type {Object} admin */
	let admin = window.kestrel_woocommerce_amazon_s3_storage_admin_products;

	/**
	 * Updates the offload status of a row.
	 *
	 * @param {object} $row
	 * @param {boolean} is_variation
	 */
	function update_offload_status( $row, is_variation = false ) {

		// use the file hash as the identifier for matching
		let id    = $row.find( is_variation ? 'input[name^="_wc_variation_file_hashes"]' : 'input[name="_wc_file_hashes[]"]' ).val(),
			data  = admin.data || [],
			$cell = $row.find( 'td.s3_status' );

		let matched_data = data.find( function( item ){
			return item.id === id;
		} );

		if ( matched_data ) {

			$cell.html( matched_data.status );

		} else {

			let url = $row.find( 'input[name="_wc_file_urls[]"]' ).val();

			if ( url && url.startsWith('[amazon_s3 ') ) {
				$cell.html( admin.placeholders.shortcode );
			} else {
				$cell.html( admin.placeholders.unknown );
			}
		}
	}

	/**
	 * Processes a downloadable files table by adding the S3 Status column and handling rows.
	 *
	 * @param {object} $table
	 * @param {boolean} is_variation
	 */
	function process_downloadable_files_table( $table, is_variation= false ) {

		let $table_headers = $table.find( '> thead th' ),
			$table_footer = $table.find( '> tfoot th' );

		if ( $table_headers.filter( function() { return $( this ).text() === admin.i18n.s3_status; } ).length === 0 ) {
			// insert the S3 status column header and adjust colspan of the File URL column
			$table_headers.eq( -2 ).attr( 'colspan', 1 );
			$table_headers.eq( -2 ).after( '<th colspan="2">' + admin.i18n.s3_status + '</th>' );
			// increase the last footer cell colspan by 1 to match the width with the new column
			$table_footer.eq( -2 ).attr( 'colspan', 4 );
		}

		// apply handling to each row
		$table.find( 'tbody tr' ).each( function() {
			let $row = $( this );

			if ( $row.find( 'td.s3_status' ).length === 0 ) {

				$row.find( 'td.file_url' ).after( '<td class="s3_status"></td>' );

				update_offload_status( $row, is_variation );
			}
		} );

		// apply a default status whenever a new row is added
		$table.on( 'click', 'a.insert', function( e ) {

			setTimeout( function() {

				let $last_row = $table.find( 'tbody tr' ).last();

				// check if S3 status cell is already added to avoid duplicates
				if ( $last_row.find( 'td.s3_status' ).length === 0 ) {
					$last_row.find( 'td.file_url' ).after( '<td class="s3_status"></td>' );
					$last_row.find( 'td.s3_status' ).html( admin.placeholders.unhandled );
				}
			}, 0 );
		} );
	}

	let simple_products_table = $( '.downloadable_files > table' );

	// process the simple products table
	if ( simple_products_table.length ) {
		process_downloadable_files_table( simple_products_table, false );
	}

	/**
	 * Processes a downloadable files table for variations by adding the S3 Status column and handling rows.
	 */
	function process_variation_downloadable_files_tables() {
		$( '.woocommerce_variation .downloadable_files > table' ).each( function() {
			process_downloadable_files_table( $( this ), true );
		} );
	}

	// process the variation products tables (and below include all possible events concerning variations with downloadable files)
	process_variation_downloadable_files_tables();

	// variations loaded
	$( document.body ).on( 'woocommerce_variations_loaded', function() {
		process_variation_downloadable_files_tables();
	} );

	// multiple variations added
	$( document.body ).on( 'woocommerce_variations_added', function() {
		process_variation_downloadable_files_tables();
	} );

	// one variation added
	$( document.body ).on( 'click', '#variable_product_options .add_variation', function() {

		setTimeout( function() {
			process_variation_downloadable_files_tables();
		}, 500 );
	} );

} );
