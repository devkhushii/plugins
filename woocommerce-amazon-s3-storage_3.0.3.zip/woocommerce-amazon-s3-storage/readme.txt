=== Amazon S3 Storage for WooCommerce ===
Author: kestrelwp
Tags: woocommerce
Requires at least: 6.0
Tested up to: 6.7.1
Requires PHP: 7.4
