<?php

namespace Kestrel\AmazonS3\Scoped\Aws\Api\Parser;

use Kestrel\AmazonS3\Scoped\Aws\Api\Service;
use Kestrel\AmazonS3\Scoped\Aws\Api\StructureShape;
use Kestrel\AmazonS3\Scoped\Aws\CommandInterface;
use Kestrel\AmazonS3\Scoped\Aws\ResultInterface;
use Kestrel\AmazonS3\Scoped\Psr\Http\Message\ResponseInterface;
use Kestrel\AmazonS3\Scoped\Psr\Http\Message\StreamInterface;
/**
 * @internal
 */
abstract class AbstractParser
{
    /** @var \Kestrel\AmazonS3\Scoped\Aws\Api\Service Representation of the service API*/
    protected $api;
    /** @var callable */
    protected $parser;
    /**
     * @param Service $api Service description.
     */
    public function __construct(Service $api)
    {
        $this->api = $api;
    }
    /**
     * @param CommandInterface  $command  Command that was executed.
     * @param ResponseInterface $response Response that was received.
     *
     * @return ResultInterface
     */
    abstract public function __invoke(CommandInterface $command, ResponseInterface $response);
    abstract public function parseMemberFromStream(StreamInterface $stream, StructureShape $member, $response);
}
