<?php

namespace Kestrel\AmazonS3\Scoped\Aws\S3\Exception;

use Kestrel\AmazonS3\Scoped\Aws\Exception\AwsException;
/**
 * Represents an error interacting with the Amazon Simple Storage Service.
 */
class S3Exception extends AwsException
{
}
