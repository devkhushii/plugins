<?php

namespace Kestrel\AmazonS3\Scoped\Aws\S3\RegionalEndpoint\Exception;

use Kestrel\AmazonS3\Scoped\Aws\HasMonitoringEventsTrait;
use Kestrel\AmazonS3\Scoped\Aws\MonitoringEventsInterface;
/**
 * Represents an error interacting with configuration for sts regional endpoints
 */
class ConfigurationException extends \RuntimeException implements MonitoringEventsInterface
{
    use HasMonitoringEventsTrait;
}
