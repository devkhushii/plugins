<?php

namespace Kestrel\AmazonS3\Scoped\Aws\SSOOIDC\Exception;

use Kestrel\AmazonS3\Scoped\Aws\Exception\AwsException;
/**
 * Represents an error interacting with the **AWS SSO OIDC** service.
 */
class SSOOIDCException extends AwsException
{
}
