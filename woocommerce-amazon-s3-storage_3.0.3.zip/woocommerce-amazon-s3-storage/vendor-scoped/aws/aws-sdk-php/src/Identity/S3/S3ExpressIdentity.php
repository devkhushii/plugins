<?php

namespace Kestrel\AmazonS3\Scoped\Aws\Identity\S3;

use Kestrel\AmazonS3\Scoped\Aws\Credentials\Credentials;
class S3ExpressIdentity extends Credentials
{
}
