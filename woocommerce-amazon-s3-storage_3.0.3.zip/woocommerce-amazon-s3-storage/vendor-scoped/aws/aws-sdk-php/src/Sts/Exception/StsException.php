<?php

namespace Kestrel\AmazonS3\Scoped\Aws\Sts\Exception;

use Kestrel\AmazonS3\Scoped\Aws\Exception\AwsException;
/**
 * AWS Security Token Service exception.
 */
class StsException extends AwsException
{
}
