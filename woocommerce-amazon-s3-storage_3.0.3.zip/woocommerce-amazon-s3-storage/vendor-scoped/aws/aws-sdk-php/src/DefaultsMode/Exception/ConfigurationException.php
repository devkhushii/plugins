<?php

namespace Kestrel\AmazonS3\Scoped\Aws\DefaultsMode\Exception;

use Kestrel\AmazonS3\Scoped\Aws\HasMonitoringEventsTrait;
use Kestrel\AmazonS3\Scoped\Aws\MonitoringEventsInterface;
/**
 * Represents an error interacting with configuration mode
 */
class ConfigurationException extends \RuntimeException implements MonitoringEventsInterface
{
    use HasMonitoringEventsTrait;
}
