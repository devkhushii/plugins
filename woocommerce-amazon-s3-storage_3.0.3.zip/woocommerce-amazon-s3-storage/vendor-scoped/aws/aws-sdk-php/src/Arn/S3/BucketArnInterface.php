<?php

namespace Kestrel\AmazonS3\Scoped\Aws\Arn\S3;

use Kestrel\AmazonS3\Scoped\Aws\Arn\ArnInterface;
/**
 * @internal
 */
interface BucketArnInterface extends ArnInterface
{
    public function getBucketName();
}
