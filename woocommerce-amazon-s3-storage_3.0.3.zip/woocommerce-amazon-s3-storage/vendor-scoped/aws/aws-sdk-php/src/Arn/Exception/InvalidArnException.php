<?php

namespace Kestrel\AmazonS3\Scoped\Aws\Arn\Exception;

/**
 * Represents a failed attempt to construct an Arn
 */
class InvalidArnException extends \RuntimeException
{
}
