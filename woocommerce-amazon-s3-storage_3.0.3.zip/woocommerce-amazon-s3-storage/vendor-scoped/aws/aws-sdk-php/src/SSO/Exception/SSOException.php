<?php

namespace Kestrel\AmazonS3\Scoped\Aws\SSO\Exception;

use Kestrel\AmazonS3\Scoped\Aws\Exception\AwsException;
/**
 * Represents an error interacting with the **AWS Single Sign-On** service.
 */
class SSOException extends AwsException
{
}
