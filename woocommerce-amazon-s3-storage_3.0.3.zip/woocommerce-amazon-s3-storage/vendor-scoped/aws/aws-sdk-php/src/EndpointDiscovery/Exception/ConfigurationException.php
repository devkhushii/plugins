<?php

namespace Kestrel\AmazonS3\Scoped\Aws\EndpointDiscovery\Exception;

use Kestrel\AmazonS3\Scoped\Aws\HasMonitoringEventsTrait;
use Kestrel\AmazonS3\Scoped\Aws\MonitoringEventsInterface;
/**
 * Represents an error interacting with configuration for endpoint discovery
 */
class ConfigurationException extends \RuntimeException implements MonitoringEventsInterface
{
    use HasMonitoringEventsTrait;
}
