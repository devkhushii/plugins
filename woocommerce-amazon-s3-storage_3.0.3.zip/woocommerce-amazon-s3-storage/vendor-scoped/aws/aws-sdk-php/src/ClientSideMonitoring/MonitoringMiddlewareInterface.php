<?php

namespace Kestrel\AmazonS3\Scoped\Aws\ClientSideMonitoring;

use Kestrel\AmazonS3\Scoped\Aws\CommandInterface;
use Kestrel\AmazonS3\Scoped\Aws\Exception\AwsException;
use Kestrel\AmazonS3\Scoped\Aws\ResultInterface;
use Kestrel\AmazonS3\Scoped\GuzzleHttp\Psr7\Request;
use Kestrel\AmazonS3\Scoped\Psr\Http\Message\RequestInterface;
/**
 * @internal
 */
interface MonitoringMiddlewareInterface
{
    /**
     * Data for event properties to be sent to the monitoring agent.
     *
     * @param RequestInterface $request
     * @return array
     */
    public static function getRequestData(RequestInterface $request);
    /**
     * Data for event properties to be sent to the monitoring agent.
     *
     * @param ResultInterface|AwsException|\Exception $klass
     * @return array
     */
    public static function getResponseData($klass);
    public function __invoke(CommandInterface $cmd, RequestInterface $request);
}
