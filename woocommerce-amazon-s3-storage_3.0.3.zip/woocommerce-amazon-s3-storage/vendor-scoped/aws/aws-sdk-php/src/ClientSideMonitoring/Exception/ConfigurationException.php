<?php

namespace Kestrel\AmazonS3\Scoped\Aws\ClientSideMonitoring\Exception;

use Kestrel\AmazonS3\Scoped\Aws\HasMonitoringEventsTrait;
use Kestrel\AmazonS3\Scoped\Aws\MonitoringEventsInterface;
/**
 * Represents an error interacting with configuration for client-side monitoring.
 */
class ConfigurationException extends \RuntimeException implements MonitoringEventsInterface
{
    use HasMonitoringEventsTrait;
}
