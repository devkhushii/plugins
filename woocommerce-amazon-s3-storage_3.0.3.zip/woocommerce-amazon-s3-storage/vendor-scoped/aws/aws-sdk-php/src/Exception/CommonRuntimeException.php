<?php

namespace Kestrel\AmazonS3\Scoped\Aws\Exception;

class CommonRuntimeException extends \RuntimeException
{
}
