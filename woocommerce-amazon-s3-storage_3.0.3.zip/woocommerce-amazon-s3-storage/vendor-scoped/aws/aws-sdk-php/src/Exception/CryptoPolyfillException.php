<?php

namespace Kestrel\AmazonS3\Scoped\Aws\Exception;

/**
 * Class CryptoPolyfillException
 */
class CryptoPolyfillException extends \RuntimeException
{
}
