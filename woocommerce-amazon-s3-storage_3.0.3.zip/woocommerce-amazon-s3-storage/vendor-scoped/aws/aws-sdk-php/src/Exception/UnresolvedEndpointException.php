<?php

namespace Kestrel\AmazonS3\Scoped\Aws\Exception;

use Kestrel\AmazonS3\Scoped\Aws\HasMonitoringEventsTrait;
use Kestrel\AmazonS3\Scoped\Aws\MonitoringEventsInterface;
class UnresolvedEndpointException extends \RuntimeException implements MonitoringEventsInterface
{
    use HasMonitoringEventsTrait;
}
