<?php

namespace Kestrel\AmazonS3\Scoped\Aws\Signature;

use Kestrel\AmazonS3\Scoped\Aws\Credentials\CredentialsInterface;
use Kestrel\AmazonS3\Scoped\Psr\Http\Message\RequestInterface;
/**
 * Provides anonymous client access (does not sign requests).
 */
class AnonymousSignature implements SignatureInterface
{
    /**
     * /** {@inheritdoc}
     */
    public function signRequest(RequestInterface $request, CredentialsInterface $credentials)
    {
        return $request;
    }
    /**
     * /** {@inheritdoc}
     */
    public function presign(RequestInterface $request, CredentialsInterface $credentials, $expires, array $options = [])
    {
        return $request;
    }
}
