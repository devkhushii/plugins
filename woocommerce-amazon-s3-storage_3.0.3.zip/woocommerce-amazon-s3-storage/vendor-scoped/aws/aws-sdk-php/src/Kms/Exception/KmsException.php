<?php

namespace Kestrel\AmazonS3\Scoped\Aws\Kms\Exception;

use Kestrel\AmazonS3\Scoped\Aws\Exception\AwsException;
/**
 * Represents an error interacting with the AWS Key Management Service.
 */
class KmsException extends AwsException
{
}
