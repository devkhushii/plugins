<?php
/**
 * Amazon S3 Storage for WooCommerce
 *
 * This source file is subject to the GNU General Public License v3.0 that is bundled with this plugin in the file license.txt.
 *
 * Please do not modify this file if you want to upgrade this plugin to newer versions in the future.
 * If you want to customize this file for your needs, please review our developer documentation.
 * Join our developer program at https://kestrelwp.com/developers
 *
 * @author    Kestrel
 * @copyright Copyright (c) 2012-2024 Kestrel Commerce LLC [hey@kestrelwp.com]
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

namespace Kestrel\AmazonS3\Lifecycle;

defined( 'ABSPATH' ) or exit;

use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Plugin\Lifecycle\Contracts\Uninstaller as Uninstaller_Contract;

/**
 * Plugin uninstaller.
 *
 * @since 3.0.0
 */
class Uninstaller implements Uninstaller_Contract {

	/**
	 * Performs uninstallation routines.
	 *
	 * @since 3.0.0
	 *
	 * @return void
	 */
	public function uninstall() {
		global $wpdb;

		// @phpstan-ignore-next-line
		if ( ! $wpdb || ( ! defined( 'WC_REMOVE_ALL_DATA' ) && ! WC_REMOVE_ALL_DATA ) ) {
			return;
		}

		$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '%amazon_s3_storage%';" ); // phpcs:ignore
		$wpdb->query( "DELETE FROM {$wpdb->postmeta} WHERE meta_key LIKE '%amazon_s3_storage%';" ); // phpcs:ignore
	}

}
