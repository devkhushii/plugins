<?php
/**
 * Amazon S3 Storage for WooCommerce
 *
 * This source file is subject to the GNU General Public License v3.0 that is bundled with this plugin in the file license.txt.
 *
 * Please do not modify this file if you want to upgrade this plugin to newer versions in the future.
 * If you want to customize this file for your needs, please review our developer documentation.
 * Join our developer program at https://kestrelwp.com/developers
 *
 * @author    Kestrel
 * @copyright Copyright (c) 2012-2024 Kestrel Commerce LLC [hey@kestrelwp.com]
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

declare( strict_types = 1 );

namespace Kestrel\AmazonS3\Lifecycle\Migrations;

defined( 'ABSPATH' ) or exit;

use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Plugin\Lifecycle\Contracts\Migration;
use WC_Data_Exception;
use WC_Product_Download;

/**
 * Migration to version 2.0.0.
 *
 * @since 3.0.0
 */
class Update_To_Version_2_0_0 implements Migration {

	/**
	 * Upgrade the plugin to version 2.0.0.
	 *
	 * @since 3.0.0
	 *
	 * @return void
	 */
	public function upgrade() : void {

		$product_types   = array_keys( wc_get_product_types() );
		$product_types[] = 'variation';

		$product_ids = wc_get_products( [
			'type'     => $product_types,
			'limit'    => -1,
			'return'   => 'ids',
			'meta_key' => '_amazon_s3_bucket', // phpcs:ignore
		] );

		foreach ( $product_ids as $product_id ) {
			$product = wc_get_product( $product_id );

			if ( ! $product || 'yes' !== $product->get_meta( '_use_amazon_s3' ) ) {
				continue;
			}

			$bucket = $product->get_meta( '_amazon_s3_bucket' );
			$object = $product->get_meta( '_amazon_s3_object' );

			$shortcode = sprintf( '[amazon_s3 bucket=%1$s object=%2$s]', $bucket, $object );

			$download = new WC_Product_Download();
			$download->set_id( wp_generate_uuid4() );
			$download->set_name( wc_get_filename_from_url( $object ) );
			$download->set_file( $shortcode );

			$downloads   = $product->get_downloads();
			$downloads[] = $download;

			try {
				$product->set_downloads( $downloads );
			} catch ( WC_Data_Exception $e ) {
				continue;
			}

			$product->delete_meta_data( '_use_amazon_s3' );
			$product->delete_meta_data( '_amazon_s3_bucket' );
			$product->delete_meta_data( '_amazon_s3_object' );
			$product->save();
		}
	}

	/**
	 * Rollback the version changes.
	 *
	 * @since 3.0.0
	 *
	 * @return void
	 */
	public function rollback() : void {
		// no-op
	}

}
