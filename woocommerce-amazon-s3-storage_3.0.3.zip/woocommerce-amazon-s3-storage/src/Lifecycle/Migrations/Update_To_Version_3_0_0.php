<?php
/**
 * Amazon S3 Storage for WooCommerce
 *
 * This source file is subject to the GNU General Public License v3.0 that is bundled with this plugin in the file license.txt.
 *
 * Please do not modify this file if you want to upgrade this plugin to newer versions in the future.
 * If you want to customize this file for your needs, please review our developer documentation.
 * Join our developer program at https://kestrelwp.com/developers
 *
 * @author    Kestrel
 * @copyright Copyright (c) 2012-2024 Kestrel Commerce LLC [hey@kestrelwp.com]
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

declare( strict_types = 1 );

namespace Kestrel\AmazonS3\Lifecycle\Migrations;

defined( 'ABSPATH' ) or exit;

use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Plugin\Lifecycle\Contracts\Migration;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Plugin\Traits\Has_Plugin_Instance;
use Kestrel\AmazonS3\Settings\Credentials;
use Kestrel\AmazonS3\Settings\Default_Bucket;
use Kestrel\AmazonS3\Settings\Default_Region;
use Kestrel\AmazonS3\Settings\Download_Method;
use Kestrel\AmazonS3\Settings\Shortcode_Bucket;
use Kestrel\AmazonS3\Settings\URL_Validity_Period;

/**
 * Migration to version 3.0.0.
 *
 * @since 3.0.0
 */
final class Update_To_Version_3_0_0 implements Migration {
	use Has_Plugin_Instance;

	/**
	 * Upgrade the plugin to version 3.0.0.
	 *
	 * @since 3.0.0
	 *
	 * @return void
	 */
	public function upgrade() : void {

		$legacy_settings = wp_parse_args(
			get_option( 'woo_amazon_s3_storage', [] ),
			[
				'amazon_access_key'    => '',
				'amazon_access_secret' => '',
				'amazon_url_period'    => '',
				'force_redirect'       => 'no',
				'default_bucket'       => '',
				'default_region'       => '',
			]
		);

		update_option( self::plugin()->key( Credentials::SETTING_NAME ), [
			'access_mode'       => 'database',
			'access_key_id'     => $legacy_settings['amazon_access_key'] ?: '',
			'secret_access_key' => $legacy_settings['amazon_access_secret'] ?: '',
		] );

		if ( $region = $legacy_settings['default_region'] ?: '' ) {
			update_option( self::plugin()->key( Default_Region::SETTING_NAME ), $region );
		}

		if ( $bucket = $legacy_settings['default_bucket'] ?: '' ) {
			update_option( self::plugin()->key( Default_Bucket::SETTING_NAME ), $bucket );
			update_option( self::plugin()->key( Shortcode_Bucket::SETTING_NAME ), $bucket );
		}

		update_option( self::plugin()->key( URL_Validity_Period::SETTING_NAME ), max( 1, min( 7 * 60 * 24, intval( $legacy_settings['amazon_url_period'] ?: 1 ) ) ) );
		update_option( self::plugin()->key( Download_Method::SETTING_NAME ), wc_bool_to_string( $legacy_settings['force_redirect'] ?: false ) );

		delete_option( 'woo_amazon_s3_storage' );
		delete_option( 'wc_amazon_s3_storage_db_version' );
		delete_option( 'wc_amazon_s3_storage_version' );
		delete_option( 'woocommerce_amazon_s3_storage_active' );
	}

	/**
	 * Rollback the version changes.
	 *
	 * @since 3.0.0
	 *
	 * @return void
	 */
	public function rollback() : void {

		update_option( 'woo_amazon_s3_storage', [
			'amazon_access_key'    => Credentials::access_key_id(),
			'amazon_access_secret' => Credentials::access_key_id(),
			'amazon_url_period'    => URL_Validity_Period::minutes(),
			'force_redirect'       => wc_bool_to_string( Download_Method::force_redirect_only() ),
			'default_bucket'       => Shortcode_Bucket::name(),
			'default_region'       => Default_Region::name(),
		] );

		update_option( 'wc_amazon_s3_storage_db_version', self::plugin()->version() );
		update_option( 'wc_amazon_s3_storage_version', self::plugin()->version() );
		update_option( 'woocommerce_amazon_s3_storage_active', 'yes' );
	}

}
