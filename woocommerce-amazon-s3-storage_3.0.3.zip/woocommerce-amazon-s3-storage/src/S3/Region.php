<?php
/**
 * Amazon S3 Storage for WooCommerce
 *
 * This source file is subject to the GNU General Public License v3.0 that is bundled with this plugin in the file license.txt.
 *
 * Please do not modify this file if you want to upgrade this plugin to newer versions in the future.
 * If you want to customize this file for your needs, please review our developer documentation.
 * Join our developer program at https://kestrelwp.com/developers
 *
 * @author    Kestrel
 * @copyright Copyright (c) 2012-2024 Kestrel Commerce LLC [hey@kestrelwp.com]
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

declare( strict_types = 1 );

namespace Kestrel\AmazonS3\S3;

defined( 'ABSPATH' ) or exit;

use Exception;
use Kestrel\AmazonS3\S3;
use Kestrel\AmazonS3\Scoped\Aws\Result;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Cache;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Helpers\Strings;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Logger;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Traits\Has_Accessors;
use Kestrel\AmazonS3\Settings\Debug_Mode;

/**
 * Amazon S3 region.
 *
 * @since 3.0.0
 *
 * @method string get_name()
 * @method string get_label()
 * @method $this set_name( string $name )
 * @method $this set_label( string $label )
 */
final class Region {
	use Has_Accessors;

	/** @var string */
	protected string $name = '';

	/** @var string */
	protected string $label = '';

	/** @var array<string, Bucket[]>|null */
	private static ?array $buckets = null;

	/**
	 * Finds a region by name.
	 *
	 * @since 3.0.0
	 *
	 * @param string $region region name
	 * @return Region|null
	 */
	public static function find( string $region ) : ?Region {

		$regions = self::all();

		if ( ! isset( $regions[ $region ] ) ) {
			return null;
		}

		return ( new self() )
			->set_name( $region )
			->set_label( $regions[ $region ] );
	}

	/**
	 * Returns all the regions as an associative array.
	 *
	 * @since 3.0.0
	 *
	 * @return array<string, string>
	 */
	public static function all() : array {

		$regions = self::list();

		return array_reduce( $regions, 'array_merge', [] );
	}

	/**
	 * Returns all the regions by group as a multidimensional array.
	 *
	 * @since 3.0.0
	 *
	 * @return array<string, array<string, string>>
	 */
	public static function list() : array {

		return [
			'North America'     => [
				'us-east-1'    => 'US East (N. Virginia)',
				'us-east-2'    => 'US East (Ohio)',
				'us-west-1'    => 'US West (N. California)',
				'us-west-2'    => 'US West (Oregon)',
				'ca-central-1' => 'Canada (Central)',
			],
			'South America'     => [
				'sa-east-1' => 'South America (São Paulo)',
			],
			'Europe'            => [
				'eu-west-1'    => 'Europe (Ireland)',
				'eu-west-2'    => 'Europe (London)',
				'eu-west-3'    => 'Europe (Paris)',
				'eu-central-1' => 'Europe (Frankfurt)',
				'eu-north-1'   => 'Europe (Stockholm)',
				'eu-south-1'   => 'Europe (Milan)',
				'eu-south-2'   => 'Europe (Spain)',
				'eu-central-2' => 'Europe (Zurich)',
			],
			'Middle East'       => [
				'me-south-1'   => 'Middle East (Bahrain)',
				'me-central-1' => 'Middle East (UAE)',
			],
			'Africa'            => [
				'af-south-1' => 'Africa (Cape Town)',
			],
			'Asia Pacific'      => [
				'ap-south-1'     => 'Asia Pacific (Mumbai)',
				'ap-south-2'     => 'Asia Pacific (Hyderabad)',
				'ap-southeast-1' => 'Asia Pacific (Singapore)',
				'ap-southeast-2' => 'Asia Pacific (Sydney)',
				'ap-southeast-3' => 'Asia Pacific (Jakarta)',
				'ap-southeast-4' => 'Asia Pacific (Melbourne)',
				'ap-northeast-1' => 'Asia Pacific (Tokyo)',
				'ap-northeast-2' => 'Asia Pacific (Seoul)',
				'ap-northeast-3' => 'Asia Pacific (Osaka)',
				'ap-east-1'      => 'Asia Pacific (Hong Kong)',
			],
			'China'             => [
				'cn-north-1'     => 'China (Beijing)',
				'cn-northwest-1' => 'China (Ningxia)',
			],
			'AWS GovCloud (US)' => [
				'us-gov-west-1' => 'AWS GovCloud (US-West)',
				'us-gov-east-1' => 'AWS GovCloud (US-East)',
			],
		];
	}

	/**
	 * Returns the buckets for the region.
	 *
	 * @since 3.0.0
	 *
	 * @return array<string, Bucket>
	 */
	public function buckets() : array {

		$region = $this->get_name();

		if ( empty( $region ) ) {
			return [];
		}

		if ( self::$buckets && isset( self::$buckets[ $region ] ) ) {
			return self::$buckets[ $region ];
		} elseif ( ! is_array( self::$buckets ) ) {
			self::$buckets = [];
		}

		self::$buckets[ $region ] = [];

		$region_key  = Strings::string( $region )->snake_case()->to_string();
		$raw_buckets = Cache::key( $region_key . '_buckets' )->remember( fn() => $this->fetch_buckets( $region ), true, MONTH_IN_SECONDS ); // @phpstan-ignore-line WP constant

		foreach ( $raw_buckets as  $raw_bucket ) {

			if ( ! isset( $raw_bucket['Name'] ) ) {
				continue;
			}

			self::$buckets[ $region ][ $raw_bucket['Name'] ] = ( new Bucket() )
				->set_name( $raw_bucket['Name'] )
				->set_region( $this );
		}

		return self::$buckets[ $region ];
	}

	/**
	 * Queries the S3 service for the buckets in the region.
	 *
	 * @since 3.0.1
	 *
	 * @param string $region
	 * @return array<string, mixed>
	 */
	private function fetch_buckets( string $region ) : array {

		try {
			$client = S3::client( [ 'region' => $region ] );

			/** @var Result $result */
			$result = $client->listBuckets( [ 'region' => $region ] );
		} catch ( Exception $exception ) {
			if ( Debug_Mode::enabled() ) {
				Logger::warning( sprintf( 'Failed to list buckets in region "%s": %s', $region, $exception->getMessage() ) );
			}

			return [];
		}

		if ( ! $result->hasKey( 'Buckets' ) ) {
			return [];
		}

		return $result->get( 'Buckets' );
	}

	/**
	 * Purges the regions' buckets cache.
	 *
	 * @since 3.0.1
	 *
	 * @return void
	 */
	public static function purge() : void {

		self::$buckets = null;

		foreach ( self::all() as $region ) {

			$region_key = Strings::string( $region )->snake_case()->to_string();

			Cache::key( $region_key . '_buckets' )->forget();
		}
	}

}
