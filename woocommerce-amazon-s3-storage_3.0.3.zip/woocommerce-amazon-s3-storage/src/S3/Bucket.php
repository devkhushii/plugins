<?php
/**
 * Amazon S3 Storage for WooCommerce
 *
 * This source file is subject to the GNU General Public License v3.0 that is bundled with this plugin in the file license.txt.
 *
 * Please do not modify this file if you want to upgrade this plugin to newer versions in the future.
 * If you want to customize this file for your needs, please review our developer documentation.
 * Join our developer program at https://kestrelwp.com/developers
 *
 * @author    Kestrel
 * @copyright Copyright (c) 2012-2024 Kestrel Commerce LLC [hey@kestrelwp.com]
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

declare( strict_types = 1 );

namespace Kestrel\AmazonS3\S3;

defined( 'ABSPATH' ) or exit;

use Exception;
use Kestrel\AmazonS3\S3;
use Kestrel\AmazonS3\S3\Exceptions\Region_Exception;
use Kestrel\AmazonS3\Scoped\Aws\Result;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Cache;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Helpers\Arrays;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Logger;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Traits\Has_Accessors;
use Kestrel\AmazonS3\Settings\Debug_Mode;
use WP_Error;

/**
 * Amazon S3 bucket.
 *
 * @since 3.0.0
 *
 * @method string get_name()
 * @method $this set_name( string $name )
 * @method $this set_region( Region|null $region )
 */
final class Bucket {
	use Has_Accessors;

	/** @var string */
	protected string $name = '';

	/** @var Region|null */
	protected ?Region $region = null;

	/** @var array<string, Bucket>|null */
	private static ?array $buckets = null;

	/**
	 * Gets the region of the bucket.
	 *
	 * @since 3.0.0
	 *
	 * @return Region
	 * @throws Region_Exception
	 */
	public function get_region() : Region {

		if ( $this->region instanceof Region ) {
			return $this->region;
		}

		if ( empty( $this->name ) ) {
			throw new Region_Exception( 'Bucket name is required to get the region.' );
		}

		try {
			/** @var Result $result */
			$result = S3::client()->getBucketLocation( [ 'Bucket' => $this->name ] );
		} catch ( Exception $exception ) {
			if ( Debug_Mode::enabled() ) {
				Logger::warning( sprintf( 'Failed to get bucket location for bucket "%s": %s', $this->name, $exception->getMessage() ) );
			}

			throw new Region_Exception( sprintf( 'Failed to get bucket location for bucket "%s": %s', $this->name, $exception->getMessage() ), $exception ); // phpcs:ignore
		}

		$region = $result->hasKey( 'LocationConstraint' ) ? $result->get( 'LocationConstraint' ) : null;

		if ( $region && 'null' !== $region ) {
			$this->region = Region::find( $region );
		}

		if ( ! $this->region ) {
			throw new Region_Exception( sprintf( 'Failed to get region for bucket "%s".', $this->name ) ); // phpcs:ignore
		}

		return $this->region;
	}

	/**
	 * Finds a bucket by name.
	 *
	 * @since 3.0.0
	 *
	 * @param string $name bucket name
	 * @return Bucket|null
	 */
	public static function find( string $name ) : ?Bucket {

		$buckets = self::all();

		return $buckets[ $name ] ?? null;
	}

	/**
	 * Returns all the buckets.
	 *
	 * @since 3.0.0
	 *
	 * @return array<string, Bucket>
	 */
	public static function all() : array {

		if ( null !== self::$buckets ) {
			return self::$buckets;
		}

		// @phpstan-ignore-next-line WP constant
		$buckets = Cache::key( 'buckets' )->remember( fn() => self::fetch(), true, MONTH_IN_SECONDS );

		if ( ! is_array( $buckets ) ) {
			return [];
		}

		self::$buckets = [];

		foreach ( $buckets as $bucket ) {
			self::$buckets[ $bucket['Name'] ] = ( new self() )->set_name( $bucket['Name'] );
		}

		return self::$buckets;
	}

	/**
	 * Queries the S3 service for the buckets.
	 *
	 * @since 3.0.1
	 *
	 * @return array<string, mixed>
	 */
	private static function fetch() : array {

		try {
			/** @var Result $result */
			$result = S3::client()->listBuckets();
		} catch ( Exception $e ) {
			if ( Debug_Mode::enabled() ) {
				Logger::warning( sprintf( 'Failed to list buckets: %s', $e->getMessage() ) );
			}

			return [];
		}

		if ( ! $result->hasKey( 'Buckets' ) ) {
			return [];
		}

		return $result->get( 'Buckets' );
	}

	/**
	 * Validates a bucket name according to the S3 rules.
	 *
	 * @link https://docs.aws.amazon.com/AmazonS3/latest/userguide/bucketnamingrules.html
	 *
	 * @since 3.0.0
	 *
	 * @param string $bucket_name
	 * @return true|WP_Error
	 */
	public static function validate_name( string $bucket_name ) {

		$errors = [];

		if ( strlen( $bucket_name ) < 3 || strlen( $bucket_name ) > 63 ) {
			$errors[] = __( 'Bucket names must be between 3 and 63 characters long.', 'woocommerce-amazon-s3-storage' );
		}

		if ( ! preg_match( '/^[a-z0-9][a-z0-9.-]+[a-z0-9]$/', $bucket_name ) ) {
			$errors[] = __( 'Bucket names can consist only of lowercase letters, numbers, dots (.), and hyphens (-).', 'woocommerce-amazon-s3-storage' );
		}

		if ( preg_match( '/\.\./', $bucket_name ) ) {
			$errors[] = __( 'Bucket names must not contain two adjacent periods.', 'woocommerce-amazon-s3-storage' );
		}

		if ( preg_match( '/^\d+\.\d+\.\d+\.\d+$/', $bucket_name ) ) {
			$errors[] = __( 'Bucket names must not be formatted as an IP address.', 'woocommerce-amazon-s3-storage' );
		}

		$disallowed_prefixes = [
			'xn--',
			'sthree-',
			'sthree-configurator',
			'amzn-s3-demo-',
		];

		foreach ( $disallowed_prefixes as $disallowed_prefix ) {
			if ( strpos( $bucket_name, $disallowed_prefix ) === 0 ) {
				/* translators: Placeholder: %s - Disallowed prefix */
				$errors[] = sprintf( __( 'Bucket names must not end with a disallowed prefix (%s).', 'woocommerce-amazon-s3-storage' ), Arrays::array( $disallowed_prefixes )->to_human_readable_list( 'or' ) );
				break;
			}
		}

		$disallowed_suffixes = [
			'-s3alias',
			'--ol-s3',
			'.mrap',
			'--x-s3',
		];

		foreach ( $disallowed_suffixes as $disallowed_suffix ) {
			if ( substr( $bucket_name, -strlen( $disallowed_suffix ) ) === $disallowed_suffix ) {
				/* translators: Placeholder: %s - Disallowed suffixes */
				$errors[] = sprintf( __( 'Bucket names must not end with a disallowed suffix (%s).', 'woocommerce-amazon-s3-storage' ), Arrays::array( $disallowed_suffixes )->to_human_readable_list( 'or' ) );
				break;
			}
		}

		$result = true;

		if ( ! empty( $errors ) ) {
			$result         = ( new WP_Error( 'invalid_bucket_name', 'Invalid bucket name' ) );
			$result->errors = $errors;
		}

		return $result;
	}

	/**
	 * Purges the buckets cache.
	 *
	 * @since 3.0.0
	 *
	 * @return void
	 */
	public static function purge() : void {

		Cache::key( 'buckets' )->forget();

		self::$buckets = null;
	}

}
