<?php
/**
 * Amazon S3 Storage for WooCommerce
 *
 * This source file is subject to the GNU General Public License v3.0 that is bundled with this plugin in the file license.txt.
 *
 * Please do not modify this file if you want to upgrade this plugin to newer versions in the future.
 * If you want to customize this file for your needs, please review our developer documentation.
 * Join our developer program at https://kestrelwp.com/developers
 *
 * @author    Kestrel
 * @copyright Copyright (c) 2012-2024 Kestrel Commerce LLC [hey@kestrelwp.com]
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

declare( strict_types = 1 );

namespace Kestrel\AmazonS3;

defined( 'ABSPATH' ) or exit;

use Kestrel\AmazonS3\Files\File_Status;
use Kestrel\AmazonS3\Files\Local_File;
use Kestrel\AmazonS3\Files\Offload_Job;
use Kestrel\AmazonS3\Files\Uploader;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Plugin\Traits\Is_Handler;
use Kestrel\AmazonS3\Settings\Offload_Downloadables;
use WC_Product;
use WC_Product_Download;
use WP_Post;

/**
 * WooCommerce Product handler.
 *
 * @since 3.0.0
 */
final class Product {
	use Is_Handler;

	/**
	 * Constructor.
	 *
	 * @since 3.0.0
	 *
	 * @param Plugin $plugin plugin instance
	 */
	protected function __construct( Plugin $plugin ) {

		self::$plugin = $plugin;

		self::add_action( 'woocommerce_process_product_meta', [ $this, 'maybe_offload_downloadable_files' ], PHP_INT_MAX, 2 );
		self::add_action( 'woocommerce_save_product_variation', [ $this, 'maybe_offload_downloadable_files' ], PHP_INT_MAX, 2 );
	}

	/**
	 * Retrieves the downloadable files for a product.
	 *
	 * @since 3.0.0
	 *
	 * @param int|WC_Product|WP_Post $product
	 * @return Local_File[]
	 */
	public static function get_downloadable_files( $product ) : array {

		if ( is_numeric( $product ) || $product instanceof WP_Post ) {
			$product = wc_get_product( $product );
		}

		if ( ! $product instanceof WC_Product || ! $product->is_downloadable() ) {
			return [];
		}

		$downloadable_files = [];

		foreach ( $product->get_downloads() as $download ) {

			if ( ! $download instanceof WC_Product_Download ) {
				continue;
			}

			$downloadable_file = Local_File::from_product_downloadable( $download );

			if ( ! $downloadable_file ) {
				continue;
			}

			$downloadable_files[] = $downloadable_file;
		}

		return $downloadable_files;
	}

	/**
	 * Handles the downloadable files for a product.
	 *
	 * @since 3.0.0
	 *
	 * @param int|mixed $product_id
	 * @param mixed|WP_Post $product_post
	 * @return void
	 */
	protected function maybe_offload_downloadable_files( $product_id, $product_post = null ) : void {

		if ( ! Offload_Downloadables::enabled() ) {
			return;
		}

		$current_action = current_action();

		$local_files = $queue_files_for_upload = [];

		if ( 'woocommerce_process_product_meta' === $current_action ) {
			$local_files = $product_post instanceof WP_Post && in_array( $product_post->post_type, [ 'product', 'product_variation' ], true ) ? self::get_downloadable_files( $product_post ) : [];
		} elseif ( 'woocommerce_save_product_variation' === $current_action && is_numeric( $product_id ) ) {
			$product     = wc_get_product( $product_id );
			$local_files = $product ? self::get_downloadable_files( $product ) : [];
		}

		foreach ( $local_files as $local_file ) {

			// file already processed
			if ( ! $local_file->is_unhandled() ) {
				continue;
			}

			$queue_files_for_upload[] = $local_file->id();

			$local_file->set_offloaded_status( File_Status::QUEUED )->save();
		}

		if ( ! empty( $queue_files_for_upload ) ) {
			$this->offload_files( $queue_files_for_upload );
		}
	}

	/**
	 * Updates the background process to upload files to S3.
	 *
	 * @since 3.0.0
	 *
	 * @param int[] $file_ids
	 * @return void
	 */
	private function offload_files( array $file_ids ) : void {

		$uploader = Uploader::instance();

		foreach ( $file_ids as $file_id ) {

			$job = Offload_Job::create()->set_local_file_id( $file_id );

			$uploader->push_to_queue( $job );
		}

		$uploader->save()->dispatch();
	}

}
