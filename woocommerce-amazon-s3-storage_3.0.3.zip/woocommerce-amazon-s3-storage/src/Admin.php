<?php
/**
 * Amazon S3 Storage for WooCommerce
 *
 * This source file is subject to the GNU General Public License v3.0 that is bundled with this plugin in the file license.txt.
 *
 * Please do not modify this file if you want to upgrade this plugin to newer versions in the future.
 * If you want to customize this file for your needs, please review our developer documentation.
 * Join our developer program at https://kestrelwp.com/developers
 *
 * @author    Kestrel
 * @copyright Copyright (c) 2012-2024 Kestrel Commerce LLC [hey@kestrelwp.com]
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

declare( strict_types = 1 );

namespace Kestrel\AmazonS3;

defined( 'ABSPATH' ) or exit;

use Kestrel\AmazonS3\Admin\Products;
use Kestrel\AmazonS3\Admin\Settings_Page;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Plugin\Admin as Base_Admin;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Plugin\Admin\Notices\Notice;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\WooCommerce\Extension;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\WooCommerce\Settings\Settings_Section;
use Kestrel\AmazonS3\Settings\Credentials;
use Kestrel\AmazonS3\Settings\Debug_Mode;
use Kestrel\AmazonS3\Settings\Default_Bucket;
use Kestrel\AmazonS3\Settings\Default_Region;
use Kestrel\AmazonS3\Settings\Download_Method;
use Kestrel\AmazonS3\Settings\Offload_Downloadables;
use Kestrel\AmazonS3\Settings\Shortcode_Bucket;
use Kestrel\AmazonS3\Settings\URL_Validity_Period;
use WC_Settings_Page;

/**
 * Amazon S3 Storage for WooCommerce main admin handler.
 *
 * @since 3.0.0
 */
final class Admin extends Base_Admin {

	/** @var string settings page tab ID */
	public const SETTINGS_PAGE_TAB_ID = 'amazon_s3_storage';

	/**
	 * Admin handler constructor.
	 *
	 * @since 3.0.0
	 *
	 * @param Extension|null $plugin
	 */
	protected function __construct( ?Extension $plugin ) {

		parent::__construct( $plugin );

		Products::initialize( $plugin );

		self::add_action( 'admin_notices', [ $this, 'add_notices' ] );
		self::add_action( 'admin_menu', [ $this, 'add_menu_item' ], 100 );
		self::add_filter( 'parent_file', [ $this, 'set_current_menu_item' ], PHP_INT_MAX );
		self::add_filter( 'woocommerce_get_settings_pages', [ $this, 'add_settings_page' ] );
	}

	/**
	 * Checks the connection to the Amazon S3 client.
	 *
	 * @since 3.0.0
	 *
	 * @return void
	 */
	protected function add_notices() : void {
		global $current_screen;

		$message = sprintf(
			/* translators: Placeholders: %1$s - opening HTML link tag, %2$s - closing HTML link tag */
			__( 'A connection to Amazon S3 could not be initialized. %1$sPlease check your credentials%2$s and verify that you have the right permissions to manage S3.', 'woocommerce-amazon-s3-storage' ),
			'<a href="' . esc_url( self::plugin()->settings_url() ) . '">',
			'</a>'
		);

		Notice::error( $message )
			->set_dismissible( false )
			->set_display_condition( fn() => Credentials::configured() && ! S3::is_connected() )
			->dispatch();

		$message = sprintf(
			/* translators: Placeholders: %1$s - opening HTML link tag, %2$s - closing HTML link tag */
			__( 'Debug mode is enabled. Please remember to %1$sdisable this feature%2$s to prevent excessive amounts of logging data.', 'woocommerce-amazon-s3-storage' ),
			'<a href="' . esc_url( self::plugin()->settings_url() ) . '">',
			'</a>'
		);

		Notice::warning( $message )
			->set_dismissible( false )
			->set_display_condition( fn() => Debug_Mode::enabled() )
			->dispatch();

		// phpcs:ignore
		if ( $current_screen && $current_screen->id === 'woocommerce_page_wc-settings' && isset( $_GET['tab'], $_GET['section'] ) && $_GET['tab'] === 'products' && $_GET['section'] === 'download_urls' ) {

			Notice::warning( __( 'The approved download directories have been disabled while using this plugin.', 'woocommerce-amazon-s3-storage' ) )
				->set_display_condition( fn() => S3::is_connected() )
				->dispatch();

			if ( S3::is_connected() ) {
				wc_enqueue_js( '
					jQuery( document ).ready( function( $ ) {
						$( ".page-title-action" ).addClass( "button-disabled" );
						$( ".page-title-action" ).click( function( event ) {
							event.preventDefault();
						} );
					} );
				' );
			}
		}
	}

	/**
	 * Adds the menu item to the WooCommerce settings.
	 *
	 * @since 3.0.0
	 *
	 * @return void
	 */
	protected function add_menu_item() : void {

		add_submenu_page(
			'woocommerce',
			__( 'Amazon S3', 'woocommerce-amazon-s3-storage' ),
			__( 'Amazon S3', 'woocommerce-amazon-s3-storage' ),
			'manage_woocommerce',
			'admin.php?page=wc-settings&tab=' . self::SETTINGS_PAGE_TAB_ID,
			'',
			8.5
		);
	}

	/**
	 * Ensures that the "Amazon S3" submenu item is highlighted when viewing the "Amazon S3" tab inside WooCommerce Settings.
	 *
	 * Normally this would highlight the "WooCommerce > Settings" menu item otherwise.
	 *
	 * @isince 3.0.0
	 *
	 * @param mixed|string $parent_file
	 * @return mixed|string
	 */
	protected function set_current_menu_item( $parent_file ) {
		global $plugin_page, $submenu_file;

		$current_tab      = $_GET['tab'] ?? null; // phpcs:ignore
		$is_settings_page = 'woocommerce' === $parent_file && 'wc-settings' === $plugin_page && self::SETTINGS_PAGE_TAB_ID === $current_tab;

		if ( $is_settings_page ) {
			$submenu_file = 'admin.php?page=wc-settings&tab=' . self::SETTINGS_PAGE_TAB_ID; // phpcs:ignore
		}

		return $parent_file;
	}

	/**
	 * Adds the settings page.
	 *
	 * @since 3.0.0
	 *
	 * @param WC_Settings_Page[] $settings_pages
	 * @return WC_Settings_Page[]
	 */
	protected function add_settings_page( array $settings_pages ) : array {

		$settings_pages[] = new Settings_Page(
			__( 'Amazon S3', 'woocommerce-amazon-s3-storage' ),
			[
				'' => $this->get_settings(),
			]
		);

		return $settings_pages;
	}

	/**
	 * Returns the settings to be added to the settings page.
	 *
	 * @since 3.0.0
	 *
	 * @return array<int, Settings_Section>
	 */
	private function get_settings() : array {

		// connection settings
		$settings = [
			Settings_Section::create( [
				'title'       => __( 'Connection', 'woocommerce-amazon-s3-storage' ),
				'description' => __( 'Configure the connection to your Amazon S3 account.', 'woocommerce-amazon-s3-storage' ),
				'settings'    => array_values( Credentials::get_settings() ),
			] ),
		];

		// the following settings require a connection to make sense
		if ( S3::is_connected() ) {
			$settings = array_merge( $settings, [
				Settings_Section::create( [
					'title'       => __( 'Automatic offloading', 'woocommerce-amazon-s3-storage' ),
					'description' => __( 'Files offloaded to AWS S3 will be served to customers that have access to product downloads, within the limits and conditions defined in this WooCommerce installation. When S3 is disconnected or a file is not found in the bucket, the corresponding local file will be served instead.', 'woocommerce-amazon-s3-storage' ),
					'settings'    => [
						Offload_Downloadables::instance(),
						Default_Bucket::instance(),
						// the following are not settings, but they are used for let the merchant input their preferences when creating a new bucket
						[
							'type' => 'text',
							'id'   => 'new_bucket',
							'desc' => sprintf(
							/* translators: Placeholders: %1$s - opening HTML <a> tag, %2$s - closing HTML </a> tag */
								__( 'Enter the name of the new bucket to create. Bucket names must be unique across all AWS accounts and follow %1$sAmazon S3 bucket naming rules%2$s.', 'woocommerce-amazon-s3-storage' ),
								'<a href="https://docs.aws.amazon.com/AmazonS3/latest/userguide/bucketnamingrules.html" target="_blank">',
								'</a>'
							),
						],
						[
							'type'    => 'select',
							'id'      => 'new_bucket_region',
							'desc'    => __( 'Select the region for the new bucket.', 'woocommerce-amazon-s3-storage' ),
							'options' => [], // will be populated in JS
						],
					],
				] ),
				Settings_Section::create( [
					'title'       => __( 'Shortcode offloading', 'woocommerce-amazon-s3-storage' ),
					'description' => __( 'Use a shortcode to direct a product download to a file hosted in S3 maually.', 'woocommerce-amazon-s3-storage' ),
					'settings'    => [
						Default_Region::instance(),
						Shortcode_Bucket::instance(),
					],
				] ),
				Settings_Section::create( [
					'title'       => __( 'Product downloads', 'woocommerce-amazon-s3-storage' ),
					'description' => __( 'Configure how product downloads are handled with files offloaded to S3.', 'woocommerce-amazon-s3-storage' ),
					'settings'    => [
						Download_Method::instance(),
						URL_Validity_Period::instance(),
					],
				] ),
			] );
		}

		// always add debug settings
		return array_merge( $settings, [
			Settings_Section::create( [
				'title'    => __( 'Debug', 'woocommerce-amazon-s3-storage' ),
				'settings' => [ Debug_Mode::instance() ],
			] ),
		] );
	}

}
