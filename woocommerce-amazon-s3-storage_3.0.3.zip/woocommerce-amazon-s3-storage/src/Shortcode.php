<?php
/**
 * Amazon S3 Storage for WooCommerce
 *
 * This source file is subject to the GNU General Public License v3.0 that is bundled with this plugin in the file license.txt.
 *
 * Please do not modify this file if you want to upgrade this plugin to newer versions in the future.
 * If you want to customize this file for your needs, please review our developer documentation.
 * Join our developer program at https://kestrelwp.com/developers
 *
 * @author    Kestrel
 * @copyright Copyright (c) 2012-2024 Kestrel Commerce LLC [hey@kestrelwp.com]
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

declare( strict_types = 1 );

namespace Kestrel\AmazonS3;

defined( 'ABSPATH' ) or exit;

use Automattic\WooCommerce\Internal\ProductDownloads\ApprovedDirectories\Register;
use Exception;
use Kestrel\AmazonS3\S3\Exceptions\Client_Exception;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Helpers\Strings;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Logger;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Plugin\Traits\Is_Handler;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\WordPress\REST_API;
use Kestrel\AmazonS3\Settings\Debug_Mode;
use Kestrel\AmazonS3\Settings\Default_Region;
use Kestrel\AmazonS3\Settings\Shortcode_Bucket;
use Kestrel\AmazonS3\Settings\URL_Validity_Period;

/**
 * Legacy shortcode to handle a direct Amazon S3 URL.
 *
 * @since 3.0.0
 */
final class Shortcode {
	use Is_Handler;

	/** @var string shortcode name */
	public const NAME = 'amazon_s3';

	/**
	 * Constructor.
	 *
	 * @since 3.0.0
	 *
	 * @param Plugin $plugin
	 * @throws Exception
	 */
	protected function __construct( Plugin $plugin ) {

		self::$plugin = $plugin;

		self::add_filter( 'woocommerce_downloadable_product_name', [ $this, 'set_downloadable_file_name_from_shortcode' ] );
		self::add_filter( 'woocommerce_file_download_path', [ $this, 'set_downloadable_file_url_from_shortcode' ], 1 );
		self::add_filter( 'pre_option_wc_downloads_approved_directories_mode', [ $this, 'disable_approved_directories_rules' ], PHP_INT_MAX );

		add_shortcode( self::NAME, fn( $attributes ) => $this->process_shortcode( $attributes ) );
	}

	/**
	 * Parses the shortcode set as a downloadable file URL.
	 *
	 * @since 3.0.0
	 *
	 * @param mixed|string $file_url file URL
	 * @return mixed|string
	 */
	protected function set_downloadable_file_url_from_shortcode( $file_url ) {

		// not a shortcode to begin with
		if ( ! Strings::is_shortcode( $file_url, self::NAME ) ) {
			return $file_url;
		}

		if ( $this->is_download_request() ) {
			return do_shortcode( $this->parse_shortcode_quotes( $file_url ) );
		}

		return $file_url;
	}

	/**
	 * Determines if the request is a download request.
	 *
	 * @since 3.0.2
	 *
	 * @return bool
	 */
	private function is_download_request() : bool {

		$is_rest        = REST_API::is_rest_request();
		$request_method = ( isset( $_SERVER['REQUEST_METHOD'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) : '' );
		$context        = ( isset( $_GET['context'] ) ? wc_clean( wp_unslash( $_GET['context'] ) ) : '' ); // phpcs:ignore

		if ( ( ! $is_rest && ! is_admin() ) || ( $is_rest && 'GET' === strtoupper( $request_method ) && ( 'edit' !== $context ) ) ) {
			/** @see WC_Download_Handler::init() */
			$is_download_request = $is_rest || ( isset( $_GET['download_file'], $_GET['order'] ) && ( isset( $_GET['email'] ) || isset( $_GET['uid'] ) ) ); // phpcs:ignore
		} else {
			$is_download_request = false;
		}

		// @TODO move plugin-specific checks to integration classes later
		// https://wordpress.org/plugins/download-now-for-woocommerce/ Free Downloads compatibility
		// phpcs:ignore
		if ( ! $is_download_request && isset( $_POST['somdn_download_key'], $_POST['action'], $_POST['somdn_product'] ) ) {
			$is_download_request = true;
		}

		/**
		 * Filters if the request is a download request for S3 files handled via shortcode.
		 *
		 * @since 3.0.3
		 *
		 * @param bool $is_download_request
		 */
		return apply_filters( 'woocommerce_amazon_s3_is_shortcode_download_request', $is_download_request );
	}

	/**
	 * Filters the name so the amazon tag or any of its parts don't show - we just want the file name if possible.
	 *
	 * This may be shown to customers in as the downloadable name in the My Downloads section in the My Account area.
	 *
	 * @since 3.0.0
	 *
	 * @param mixed|string $name file name
	 * @return mixed|string
	 */
	protected function set_downloadable_file_name_from_shortcode( $name ) {

		// not a S3 shortcode
		if ( ! Strings::is_shortcode( $name, self::NAME ) ) {
			return $name;
		}

		// setting the return attribute to 'name' to just get the file name in `process_shortcode()` method below
		$name = str_replace( '[amazon_s3 ', '[amazon_s3 return="name" ', $name );

		return do_shortcode( $name );
	}

	/**
	 * Cleans the shortcode from HTML entities that may result when WooCommerce processes a file URL that contains special characters, spaces, plus signs, etc.
	 *
	 * @since 3.0.1
	 *
	 * @param string $shortcode
	 * @return string
	 */
	private function parse_shortcode_quotes( string $shortcode ) : string {

		// this ensures that some special characters are not encoded as HTML entities by accident when the file name contains + signs and other special characters in she shortcode field
		$shortcode = str_replace( '=&quot;', '="', $shortcode );
		$shortcode = str_replace( '&quot;]', '"]', $shortcode );

		return (string) preg_replace( '/&quot;(\s|\])/', '"$1', $shortcode );
	}

	/**
	 * Decodes HTML entities from attributes and normalize the values to match the object S3 keys
	 *
	 * @since 3.0.2
	 *
	 * @param array<string, string> $attributes
	 * @return array<string, string>
	 */
	private function parse_shortcode_special_characters( array $attributes ) : array {

		foreach ( $attributes as $key => $value ) {
			// replace URL encoded spaces with regular spaces
			$attributes[ $key ] = str_replace( [ '+', '%20' ], ' ', html_entity_decode( $value, ENT_QUOTES ) );
			// replace %2B with a plus sign if found
			$attributes[ $key ] = str_replace( '%2B', '+', $attributes[ $key ] );
		}

		return $attributes;
	}

	/**
	 * Parses the shortcode attributes.
	 *
	 * @sine 3.0.3
	 *
	 * @param array<string, mixed> $attributes
	 * @return array<string, mixed>
	 */
	private function parse_shortcode_attributes( array $attributes ) : array {

		$bucket      = Shortcode_Bucket::get();
		$bucket_name = $bucket ? $bucket->get_name() : '';

		try {
			$region      = $bucket ? $bucket->get_region() : null;
			$region_name = $region ? $region->get_name() : Default_Region::name();
		} catch ( Exception $exception ) {
			$region_name = '';
		}

		return shortcode_atts(
			[
				'bucket' => $bucket_name,
				'region' => $region_name,
				'object' => '',
				'return' => 'url',
			],
			$this->parse_shortcode_special_characters( $attributes ),
			self::NAME
		);
	}

	/**
	 * Processes the Amazon S3 shortcode.
	 *
	 * @since 3.0.0
	 *
	 * @param array<mixed|string>|mixed $shortcode_attributes shortcode attributes
	 * @return string
	 */
	private function process_shortcode( $shortcode_attributes ) : string {

		$parsed_attributes = $this->parse_shortcode_attributes( $shortcode_attributes );

		// just returns the product downloadable object name, this may be used in the My Downloads section in My Account for instance
		if ( 'name' === $parsed_attributes['return'] ) {
			return esc_attr( $parsed_attributes['object'] );
		}

		$debug_mode = Debug_Mode::enabled();

		if ( empty( $parsed_attributes['bucket'] ) || empty( $parsed_attributes['object'] ) ) {

			if ( $debug_mode ) {
				Logger::warning( 'The Amazon S3 shortcode is missing the bucket or object attributes.', null, $parsed_attributes );
			}

			return '';
		}

		if ( $debug_mode ) {
			Logger::info( 'Processing Amazon S3 shortcode...', null, $shortcode_attributes );
		}

		$region_name = ! empty( $parsed_attributes['region'] ) ? $parsed_attributes['region'] : Default_Region::name();

		/**
		 * Filters the arguments for the S3 client when generating a pre-signed URL for a shortcode.
		 *
		 * @see S3::client() for another filter applied to the S3 client for all requests
		 *
		 * @since 3.0.3
		 *
		 * @param array<string, mixed> $parsed_attributes shortcode attributes
		 * @param array<string, mixed> $arguments arguments passed to the S3 client
		 */
		$arguments = (array) apply_filters( 'woocommerce_amazon_s3_client_args_for_shortcode', [
			'region'                  => $region_name,
			'use_path_style_endpoint' => false,
		], $parsed_attributes );

		try {

			$client     = S3::client( $arguments );
			$get_object = $client->getCommand( 'GetObject', [
				'Bucket' => $parsed_attributes['bucket'],
				'Key'    => $parsed_attributes['object'],
			] );

			$request    = $client->createPresignedRequest( $get_object, sprintf( '+%d minutes', URL_Validity_Period::minutes() ) );
			$amazon_url = (string) $request->getUri();

			if ( empty( $amazon_url ) ) {
				throw new Client_Exception( 'The Amazon S3 URL is empty.' );
			}

			if ( $debug_mode ) {
				Logger::info( 'Signed Amazon S3 URL generated from shortcode successfully.' );
			}

			return esc_url_raw( $amazon_url );

		} catch ( Exception $exception ) {

			if ( ! is_admin() ) {
				wc_add_notice( __( 'A download failed due to a connection problem.', 'woocommerce-amazon-s3-storage' ), 'error' );
			}

			if ( $debug_mode ) {
				Logger::emergency( sprintf( 'Could not produce a valid Amazon S3 link from shortcode: %s', $exception->getMessage() ), null, $parsed_attributes ); // phpcs:ignore
			}

			return '';
		}
	}

	/**
	 * Disables pre-approved directories mode for WooCommerce downloadable products.
	 *
	 * The reason we need to do this is that WooCommerce will otherwise automatically parse the shortcode in __all__ products edit screens to check if the file path is valid.
	 * Other than being very resource intensive with the AWS SDK, the file paths won't necessarily match with the ones previously computed by the older plugin versions.
	 * WooCommerce does not seem to offer a public API either to modify these baths with the {@see Register} approved directories handler marked as internal.
	 * Besides, if a merchant is using S3 to store their files, the paths would be auto-added anyway, and they are safe being remotely hosted with pre-signed download URLs.
	 *
	 * We tried filtering {@see WC_Product_Download::approved_directory_checks()} but the resulting file paths didn't match the ones computed by the plugin from previous versions.
	 *
	 * @since 3.0.2
	 *
	 * @param mixed|string $approved_value
	 * @return mixed|string
	 */
	protected function disable_approved_directories_rules( $approved_value ) {

		return S3::is_connected() ? 'disabled' : $approved_value;
	}

}
