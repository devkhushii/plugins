<?php
/**
 * Amazon S3 Storage for WooCommerce
 *
 * This source file is subject to the GNU General Public License v3.0 that is bundled with this plugin in the file license.txt.
 *
 * Please do not modify this file if you want to upgrade this plugin to newer versions in the future.
 * If you want to customize this file for your needs, please review our developer documentation.
 * Join our developer program at https://kestrelwp.com/developers
 *
 * @author    Kestrel
 * @copyright Copyright (c) 2012-2024 Kestrel Commerce LLC [hey@kestrelwp.com]
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

declare( strict_types = 1 );

namespace Kestrel\AmazonS3\Files;

defined( 'ABSPATH' ) or exit;

use Exception;
use Kestrel\AmazonS3\Files\Exceptions\File_Exception;
use Kestrel\AmazonS3\Plugin;
use Kestrel\AmazonS3\S3;
use Kestrel\AmazonS3\Scoped\Aws\Result;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Logger;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Plugin\Traits\Is_Handler;
use Kestrel\AmazonS3\Scoped\WP_Background_Process;
use Kestrel\AmazonS3\Settings\Debug_Mode;
use Kestrel\AmazonS3\Settings\Default_Bucket;

/**
 * Background file uploader to S3.
 *
 * @since 3.0.0
 */
final class Uploader extends WP_Background_Process {
	use Is_Handler;

	/** @var string action name */
	protected $action = 'upload';

	/**
	 * Constructor.
	 *
	 * @since 3.0.0
	 *
	 * @param Plugin $plugin
	 */
	public function __construct( Plugin $plugin ) {

		self::$plugin = $plugin;

		$this->prefix = $plugin->key();

		parent::__construct();
	}

	/**
	 * Handles the task.
	 *
	 * @since 3.0.0
	 *
	 * @param mixed $item
	 * @return false|mixed
	 */
	protected function task( $item ) {

		return $this->process( $item ) ?: false;
	}

	/**
	 * Uploads a file to S3.
	 *
	 * @since 3.0.0
	 *
	 * @param mixed|Offload_Job $job
	 * @return mixed|null
	 */
	protected function process( $job ) {

		$debug_mode = Debug_Mode::enabled();

		if ( ! $job instanceof Offload_Job ) {

			if ( $debug_mode ) {
				Logger::warning( sprintf( 'Failed to upload file to S3: unexpected job instance "%s".', is_object( $job ) ? get_class( $job ) : gettype( $job ) ) );
			}

			return null;
		}

		if ( ! S3::is_connected() ) {
			return $job->retry( 'Failed to upload file to S3: S3 is not connected.' );
		}

		$file = $job->local_file();

		if ( ! $file ) {
			return $job->fail( sprintf( 'Failed to upload file to S3: local file to upload #%d not found.', $job->get_local_file_id() ) );
		}

		$bucket = Default_Bucket::get();

		if ( ! $bucket ) {
			return $job->fail( sprintf( 'Failed to upload file #%d to S3: bucket "%s" does not exist.', $file->id(), Default_Bucket::name() ) );
		}

		if ( $debug_mode ) {
			Logger::info( sprintf( 'Uploading file #%d to S3 bucket "%s" as "%s".', $file->id(), $bucket->get_name(), $file->name() ) );
		}

		try {

			$file_key    = $file->name();
			$file_path   = $file->path();
			$bucket_name = $bucket->get_name();
			$region_name = $bucket->get_region()->get_name();

			if ( ! is_readable( $file_path ) ) {
				throw new File_Exception( sprintf( 'File "%s" is not readable.', $file_path ) );
			}

			// @NOTE This seems to work well even with large files, but if we run into issues with some hosts or file sizes > 512M, we may need to use multipart uploads.

			/** @var Result $result */
			$result = S3::client( [ 'region' => $region_name ] )->putObject( [
				'Bucket'     => $bucket->get_name(),
				'Key'        => $file_key,
				'SourceFile' => $file->path(),
			] );

			if ( $debug_mode ) {
				Logger::info( sprintf( 'File #%d uploaded to S3 bucket "%s" as "%s".', $file->id(), $bucket_name, $file->name() ), null, $result->toArray() );
			}

			return $job->complete( $file_key, $bucket_name, $region_name, $result );

		} catch ( Exception $exception ) {

			return $job->fail( sprintf( 'Failed to upload file #%d to S3. %s', $file->id(), $exception->getMessage() ) );
		}
	}

}
