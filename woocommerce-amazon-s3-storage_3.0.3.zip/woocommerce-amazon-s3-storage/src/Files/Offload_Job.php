<?php
/**
 * Amazon S3 Storage for WooCommerce
 *
 * This source file is subject to the GNU General Public License v3.0 that is bundled with this plugin in the file license.txt.
 *
 * Please do not modify this file if you want to upgrade this plugin to newer versions in the future.
 * If you want to customize this file for your needs, please review our developer documentation.
 * Join our developer program at https://kestrelwp.com/developers
 *
 * @author    Kestrel
 * @copyright Copyright (c) 2012-2024 Kestrel Commerce LLC [hey@kestrelwp.com]
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

declare( strict_types = 1 );

namespace Kestrel\AmazonS3\Files;

defined( 'ABSPATH' ) or exit;

use Kestrel\AmazonS3\Scoped\Aws\Result;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Logger;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Traits\Creates_New_Instances;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Traits\Has_Accessors;
use Kestrel\AmazonS3\Settings\Debug_Mode;

/**
 * Background job for offloading files.
 *
 * @since 3.0.0
 *
 * @method int get_local_file_id()
 * @method $this set_local_file_id( int $local_file_id )
 */
final class Offload_Job {
	use Creates_New_Instances;

	use Has_Accessors;

	/** @var int */
	protected int $local_file_id = 0;

	/**
	 * Constructor.
	 *
	 * @since 3.0.0
	 *
	 * @param array<string, mixed> $properties
	 */
	protected function __construct( array $properties = [] ) {

		$this->set_properties( $properties );
	}

	/**
	 * Returns the local file object for this job.
	 *
	 * @since 3.0.0
	 *
	 * @return Local_File|null
	 */
	public function local_file() : ?Local_File {

		return $this->local_file_id > 0 ? Local_File::from_attachment( $this->local_file_id ) : null;
	}

	/**
	 * Fails the job.
	 *
	 * @since 3.0.0
	 *
	 * @param string $reason
	 * @return null
	 */
	public function fail( string $reason = '' ) {

		if ( $reason && Debug_Mode::enabled() ) {
			Logger::error( $reason );
		}

		if ( $local_file = $this->local_file() ) {
			$local_file->set_offloaded_status( File_Status::FAILED )->save();
		}

		return null;
	}

	/**
	 * Retries the job.
	 *
	 * @since 3.0.0
	 *
	 * @param string $reason
	 * @return self
	 */
	public function retry( string $reason = '' ) : self {

		if ( $reason && Debug_Mode::enabled() ) {
			Logger::warning( $reason );
		}

		if ( $local_file = $this->local_file() ) {
			// updates the last updated timestamp without changing status
			$local_file->save();
		}

		return $this;
	}

	/**
	 * Completes the job.
	 *
	 * @since 3.0.0
	 *
	 * @param string $key
	 * @param string $bucket
	 * @param string $region
	 * @param Result $result
	 * @return null
	 */
	public function complete( string $key, string $bucket, string $region, Result $result ) {

		if ( $local_file = $this->local_file() ) {
			$local_file->set_key( $key );
			$local_file->set_bucket( $bucket );
			$local_file->set_region( $region );
			$local_file->set_entity_tag( $result->hasKey( 'ETag' ) ? $result->get( 'ETag' ) : '' );
			$local_file->set_remote_uri( $result->hasKey( 'ObjectURL' ) ? $result->get( 'ObjectURL' ) : '' );
			$local_file->set_offloaded_status( File_Status::OFFLOADED );
			$local_file->save();
		}

		return null;
	}

}
