<?php
/**
 * Amazon S3 Storage for WooCommerce
 *
 * This source file is subject to the GNU General Public License v3.0 that is bundled with this plugin in the file license.txt.
 *
 * Please do not modify this file if you want to upgrade this plugin to newer versions in the future.
 * If you want to customize this file for your needs, please review our developer documentation.
 * Join our developer program at https://kestrelwp.com/developers
 *
 * @author    Kestrel
 * @copyright Copyright (c) 2012-2024 Kestrel Commerce LLC [hey@kestrelwp.com]
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

declare( strict_types = 1 );

namespace Kestrel\AmazonS3\Files;

defined( 'ABSPATH' ) or exit;

use Exception;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Helpers\Strings;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Logger;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Plugin;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Plugin\Traits\Is_Handler;
use Kestrel\AmazonS3\Settings\Debug_Mode;
use Kestrel\AmazonS3\Settings\Download_Method;
use Kestrel\AmazonS3\Settings\Offload_Downloadables;

/**
 * Downloads handler.
 *
 * @since 3.0.0
 */
final class Downloads {
	use Is_Handler;

	/**
	 * Constructor.
	 *
	 * @since 3.0.0
	 *
	 * @param Plugin $plugin
	 */
	protected function __construct( Plugin $plugin ) {

		self::$plugin = $plugin;

		self::add_filter( 'woocommerce_file_download_method', [ $this, 'set_downloadable_file_download_method' ], 10, 3 );
		self::add_filter( 'woocommerce_download_product_filepath', [ $this, 'set_downloadable_file_url' ], PHP_INT_MAX );
	}

	/**
	 * Determines if a file URL is an Amazon S3 URL.
	 *
	 * @since 3.0.0
	 *
	 * @param mixed $file_url
	 * @return bool
	 */
	private function is_amazon_file_url( $file_url ) : bool {

		return Strings::is_url( $file_url ) && strpos( $file_url, 'amazonaws.com' ) !== false;
	}

	/**
	 * Sets the downloadable file URL for a downloadable product.
	 *
	 * When the file has been offloaded to S3, the URL is changed to a temporary S3 URL, so we can serve a remote S3 file instead.
	 * This only happens after the user has requested to download the file via the `woocommerce_download_product_filepath` filter in {@see \WC_Download_Handler::download()}.
	 * This hook also passes $email_address, $order, $product, and $download in case we need them.
	 *
	 * @since 3.0.0
	 *
	 * @param mixed|string $file_url
	 * @return mixed|string
	 */
	protected function set_downloadable_file_url( $file_url ) {

		// skip if not a URL (e.g. a shortcode) or if URL already redirecting to AWS
		if ( $this->is_amazon_file_url( $file_url ) || ! Offload_Downloadables::enabled() ) {
			return $file_url;
		}

		$local_file = Local_File::from_url( $file_url );

		if ( ! $local_file || ! $local_file->is_offloaded() ) {
			return $file_url;
		}

		$debug_mode = Debug_Mode::enabled();

		try {
			$file_url = $local_file->get_remote()->download_url();
		} catch ( Exception $exception ) {
			if ( $debug_mode ) {
				Logger::error( sprintf( 'Could not get the remote S3 URL for the downloadable file #%d: %s', $local_file->id(), $exception->getMessage() ) );
			}
		}

		if ( $debug_mode ) {
			Logger::info( sprintf( 'Downloadable file #%d URL set to: %s', $local_file->id(), $file_url ) );
		}

		return esc_url_raw( $file_url );
	}

	/**
	 * Filters the download method for a downloadable product.
	 *
	 * @since 3.0.0
	 *
	 * @param mixed|string $download_method
	 * @param int|mixed $product_id
	 * @param mixed|string $file_url
	 * @return mixed|string
	 */
	protected function set_downloadable_file_download_method( $download_method, $product_id = 0, $file_url = '' ) {

		// only apply to Amazon S3 URLs if the force redirect download method is enabled
		if ( $this->is_amazon_file_url( $file_url ) && Download_Method::force_redirect_only() ) {
			$download_method = 'redirect';
		}

		return $download_method;
	}

}
