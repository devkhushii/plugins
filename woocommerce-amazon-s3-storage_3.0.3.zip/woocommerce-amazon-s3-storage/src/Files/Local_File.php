<?php
/**
 * Amazon S3 Storage for WooCommerce
 *
 * This source file is subject to the GNU General Public License v3.0 that is bundled with this plugin in the file license.txt.
 *
 * Please do not modify this file if you want to upgrade this plugin to newer versions in the future.
 * If you want to customize this file for your needs, please review our developer documentation.
 * Join our developer program at https://kestrelwp.com/developers
 *
 * @author    Kestrel
 * @copyright Copyright (c) 2012-2024 Kestrel Commerce LLC [hey@kestrelwp.com]
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

declare( strict_types = 1 );

namespace Kestrel\AmazonS3\Files;

defined( 'ABSPATH' ) or exit;

use Exception;
use Kestrel\AmazonS3\Files\Exceptions\File_Exception;
use Kestrel\AmazonS3\S3;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Helpers\Strings;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Logger;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Plugin\Traits\Has_Plugin_Instance;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Traits\Has_Accessors;
use Kestrel\AmazonS3\Settings\Debug_Mode;
use Kestrel\AmazonS3\Settings\Offload_Downloadables;
use WC_Product_Download;
use WP_Post;

/**
 * Object representation of a local file.
 *
 * This is a wrapper around a WordPress attachment post object that interacts with S3 data.
 *
 * @since 3.0.0
 *
 * @method string get_downloadable_id()
 * @method string get_key()
 * @method string get_bucket()
 * @method string get_region()
 * @method string get_entity_tag()
 * @method string get_offloaded_status()
 * @method string get_queued_at()
 * @method string get_updated_at()
 * @method string get_remote_uri()
 * @method $this set_downloadable_id( string $downloadable_id )
 * @method $this set_key( string $key )
 * @method $this set_bucket( string $bucket )
 * @method $this set_region( string $region )
 * @method $this set_entity_tag( string $entity_tag )
 * @method $this set_offloaded_status( string $status )
 * @method $this set_queued_at( string $queued_at )
 * @method $this set_updated_at( string $updated_at )
 * @method $this set_remote_uri( string $remote_uri )
 */
final class Local_File {
	use Has_Accessors;

	use Has_Plugin_Instance;

	/** @var string */
	private const S3_META_KEY = '_kestrel_amazon_s3_storage_data';

	/** @var int downloadable ID (matches attachment post ID) */
	private int $id;

	/** @var WP_Post attachment post object */
	private WP_Post $attachment;

	/** @var bool|null flag whether the remote file exists */
	private ?bool $remote_exists = null;

	/** @var string product download ID that may be used by WooCommerce */
	protected string $downloadable_id = '';

	/** @var string remote S3 key */
	protected string $key = '';

	/** @var string S3 bucket name */
	protected string $bucket = '';

	/** @var string region the bucket belongs to */
	protected string $region = '';

	/** @var string remote S3 entity tag */
	protected string $entity_tag = '';

	/** @var string */
	protected string $queued_at = '';

	/** @var string */
	protected string $updated_at = '';

	/** @var string */
	protected string $offloaded_status = File_Status::UNHANDLED;

	/** @var string */
	protected string $remote_uri = '';

	/** @var File_Status|null cached status */
	private ?File_Status $status = null;

	/**
	 * Downloadable constructor.
	 *
	 * @since 3.0.0
	 *
	 * @param WP_Post $attachment
	 */
	private function __construct( WP_Post $attachment ) {

		$this->id         = $attachment->ID;
		$this->attachment = $attachment;

		$this->read();
	}

	/**
	 * Gets the ID of the downloadable.
	 *
	 * @since 3.0.0
	 *
	 * @return int
	 */
	public function id() : int {

		return $this->id;
	}

	/**
	 * Gets the name of the file.
	 *
	 * @since 3.0.0
	 *
	 * @return string
	 */
	public function name() : string {

		return basename( $this->path() );
	}

	/**
	 * Gets the URL of the file.
	 *
	 * @since 3.0.0
	 *
	 * @return string
	 */
	public function url() : string {

		$url = wp_get_attachment_url( $this->id );

		return $url ?: '';
	}

	/**
	 * Gets the path of the file.
	 *
	 * @since 3.0.0
	 *
	 * @return string
	 */
	public function path() : string {

		$path = get_attached_file( $this->id );

		return $path ?: '';
	}

	/**
	 * Returns the status of the file, based on its offload status and environment.
	 *
	 * @since 3.0.0
	 *
	 * @return File_Status
	 */
	public function status() : File_Status {

		if ( null !== $this->status ) {
			return $this->status;
		}

		if ( ! S3::is_connected() ) {
			$status = File_Status::DISCONNECTED;
		} elseif ( ! Offload_Downloadables::enabled() ) {
			$status = File_Status::DISABLED;
		} else {
			try {
				if ( $this->is_offloaded() && ! $this->remote_exists() ) {
					$status = File_Status::NOT_FOUND;
				} else {
					$status = $this->get_offloaded_status();
				}
			} catch ( Exception $exception ) {
				if ( Debug_Mode::enabled() ) {
					Logger::warning( $exception->getMessage() );
				}

				$status = File_Status::FAILED;
			}
		}

		$this->status = File_Status::get( $status );

		return $this->status;
	}

	/**
	 * Gets a downloadable instance from a WooCommerce product downloadable.
	 *
	 * @since 3.0.0
	 *
	 * @param mixed|WC_Product_Download $source
	 * @return self
	 */
	public static function from_product_downloadable( $source ) : ?self {

		if ( ! $source instanceof WC_Product_Download ) {
			return null;
		}

		$instance = self::from_url( $source->get_file() );

		if ( $instance ) {
			$instance->set_downloadable_id( $source->get_id() );
		}

		return $instance;
	}

	/**
	 * Gets a downloadable instance from a WordPress attachment.
	 *
	 * @since 3.0.0
	 *
	 * @param int|mixed|WP_Post $source
	 * @return self|null
	 */
	public static function from_attachment( $source ) : ?self {

		if ( is_numeric( $source ) ) {
			$source = get_post( $source );
		}

		if ( ! $source instanceof WP_Post || $source->post_type !== 'attachment' ) {
			return null;
		}

		return new self( $source );
	}

	/**
	 * Gets a downloadable instance from a file URL.
	 *
	 * @since 3.0.0
	 *
	 * @param mixed|string $source
	 * @return self|null
	 */
	public static function from_url( $source ) : ?self {

		if ( ! Strings::is_url( $source ) ) {
			return null;
		}

		return self::from_attachment( attachment_url_to_postid( $source ) );
	}

	/**
	 * Reads the S3 data from the attachment.
	 *
	 * @since 3.0.0
	 *
	 * @return void
	 */
	private function read() : void {

		$data = get_post_meta( $this->id, self::S3_META_KEY, true );

		if ( ! is_array( $data ) ) {
			$data = [];
		}

		$data = wp_parse_args( $data, [
			'bucket'            => '',
			'downloadable_id'   => '',
			'entity_tag'        => '',
			'key'               => '',
			'offload_status'    => File_Status::UNHANDLED,
			'region'            => '',
			'remote_uri'        => '',
			'status_updated_at' => '',
		] );

		foreach ( $data as $property => $value ) {
			if ( property_exists( $this, $property ) ) {
				$this->$property = $value;
			}
		}
	}

	/**
	 * Saves S3 data for the attachment.
	 *
	 * @since 3.0.0
	 *
	 * @return bool
	 */
	public function save() : bool {

		$this->set_updated_at( gmdate( 'c' ) );

		return (bool) update_post_meta( $this->id, self::S3_META_KEY, $this->to_array() );
	}

	/**
	 * Checks the flag whether the file has been offloaded to S3.
	 *
	 * @since 3.0.0
	 *
	 * @return bool
	 */
	public function is_offloaded() : bool {

		return File_Status::OFFLOADED === $this->get_offloaded_status();
	}

	/**
	 * Determines if the file is not handled by S3.
	 *
	 * @since 3.0.0
	 *
	 * @return bool
	 */
	public function is_unhandled() : bool {

		return File_Status::UNHANDLED === $this->get_offloaded_status();
	}

	/**
	 * Determines if the file exists in the S3 bucket.
	 *
	 * @since 3.0.0
	 *
	 * @return bool
	 * @throws File_Exception
	 */
	public function remote_exists() : bool {

		if ( is_bool( $this->remote_exists ) ) {
			return $this->remote_exists;
		}

		if ( ! $this->is_offloaded() || empty( $this->bucket ) || empty( $this->key ) ) {
			$this->remote_exists = false;
		} elseif ( ! S3::is_connected() ) {
			$this->remote_exists = false;
			throw new File_Exception( 'S3 client is not connected.' );
		} else {
			try {
				$this->remote_exists = S3::client()->doesObjectExist( $this->bucket, $this->key );
			} catch ( Exception $exception ) {
				$this->remote_exists = false;
				throw new File_Exception( sprintf( 'Could not determine if the remote file exists for local file #%d: %s', $this->id(), $exception->getMessage() ), $exception ); // phpcs:ignore
			}
		}

		return $this->remote_exists;
	}

	/**
	 * Returns the remote file for the current local file instance.
	 *
	 * @since 3.0.0
	 *
	 * @return Remote_File|null
	 * @throws File_Exception
	 */
	public function get_remote() : ?Remote_File {

		if ( ! $this->remote_exists() ) {
			return null;
		}

		$args = [
			'bucket' => $this->bucket,
			'key'    => $this->key,
		];

		if ( $region = $this->region ) {
			$args['region'] = $region;
		}

		return Remote_File::get( $args );
	}

}
