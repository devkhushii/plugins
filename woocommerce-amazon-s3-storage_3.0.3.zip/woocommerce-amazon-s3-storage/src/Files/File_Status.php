<?php
/**
 * Amazon S3 Storage for WooCommerce
 *
 * This source file is subject to the GNU General Public License v3.0 that is bundled with this plugin in the file license.txt.
 *
 * Please do not modify this file if you want to upgrade this plugin to newer versions in the future.
 * If you want to customize this file for your needs, please review our developer documentation.
 * Join our developer program at https://kestrelwp.com/developers
 *
 * @author    Kestrel
 * @copyright Copyright (c) 2012-2024 Kestrel Commerce LLC [hey@kestrelwp.com]
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

declare( strict_types = 1 );

namespace Kestrel\AmazonS3\Files;

defined( 'ABSPATH' ) or exit;

use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Traits\Has_Named_Constructors;

/**
 * Offloaded file statuses.
 *
 * @since 3.0.0
 *
 * @method static File_Status UNKNOWN()
 * @method static File_Status UNHANDLED()
 * @method static File_Status SHORTCODE()
 * @method static File_Status DISCONNECTED()
 * @method static File_Status DISABLED()
 * @method static File_Status QUEUED()
 * @method static File_Status PROCESSING()
 * @method static File_Status FAILED()
 * @method static File_Status NOT_FOUND()
 * @method static File_Status OFFLOADED()
 */
class File_Status {
	use Has_Named_Constructors;

	/** @var string status unknown */
	public const UNKNOWN = 'unknown';

	/** @var string file not meant for offloading, or status undetermined */
	public const UNHANDLED = 'unhandled';

	/** @var string the file is actually handled by a shortcode, not an offloaded local file */
	public const SHORTCODE = 'shortcode';

	/** @var string special status when the client has been disconnected and the status is not known */
	public const DISCONNECTED = 'disconnected';

	/** @var string offloading disabled */
	public const DISABLED = 'disabled';

	/** @var string file queued for offloading */
	public const QUEUED = 'queued';

	/** @var string offloading in progress */
	public const PROCESSING = 'processing';

	/** @var string offloading failed */
	public const FAILED = 'failed';

	/** @var string remote file not found */
	public const NOT_FOUND = 'not_found';

	/** @var string offloading complete */
	public const OFFLOADED = 'offloaded';

	/**
	 * Attempts to create an instance of the class from a status.
	 *
	 * @since 3.0.0
	 *
	 * @param File_Status|mixed|string $status
	 * @return File_Status
	 */
	public static function get( $status ) : self {

		if ( $status instanceof self ) {
			return $status;
		}

		if ( is_string( $status ) ) {
			$status = strtolower( $status );
		}

		switch ( $status ) {
			case self::UNHANDLED:
				return self::UNHANDLED();
			case self::SHORTCODE:
				return self::SHORTCODE();
			case self::DISCONNECTED:
				return self::DISCONNECTED();
			case self::DISABLED:
				return self::DISABLED();
			case self::QUEUED:
				return self::QUEUED();
			case self::PROCESSING:
				return self::PROCESSING();
			case self::FAILED:
				return self::FAILED();
			case self::NOT_FOUND:
				return self::NOT_FOUND();
			case self::OFFLOADED:
				return self::OFFLOADED();
			case self::UNKNOWN:
			default:
				return self::UNKNOWN();
		}
	}

	/**
	 * Retrieves the label for the status.
	 *
	 * @since 3.0.0
	 *
	 * @return string
	 */
	public function label() : string {

		switch ( $this->name() ) {
			case self::UNHANDLED:
				return __( 'Unhandled', 'woocommerce-amazon-s3-storage' );
			case self::SHORTCODE:
				return __( 'Shortcode', 'woocommerce-amazon-s3-storage' );
			case self::DISCONNECTED:
				return __( 'Disconnected', 'woocommerce-amazon-s3-storage' );
			case self::DISABLED:
				return __( 'Disabled', 'woocommerce-amazon-s3-storage' );
			case self::QUEUED:
				return __( 'Queued', 'woocommerce-amazon-s3-storage' );
			case self::PROCESSING:
				return __( 'Processing', 'woocommerce-amazon-s3-storage' );
			case self::FAILED:
				return __( 'Failed', 'woocommerce-amazon-s3-storage' );
			case self::NOT_FOUND:
				return __( 'Not found', 'woocommerce-amazon-s3-storage' );
			case self::OFFLOADED:
				return __( 'Offloaded', 'woocommerce-amazon-s3-storage' );
			case self::UNKNOWN:
			default:
				return __( 'Unknown', 'woocommerce-amazon-s3-storage' );
		}
	}

	/**
	 * Retrieves the description for the status.
	 *
	 * @since 3.0.0
	 *
	 * @return string
	 */
	public function description() : string {

		switch ( $this->name() ) {
			case self::UNHANDLED:
				return __( 'File not meant for offloading, or status undetermined.', 'woocommerce-amazon-s3-storage' );
			case self::SHORTCODE:
				return __( 'File is handled via S3 shortcode directly.', 'woocommerce-amazon-s3-storage' );
			case self::DISCONNECTED:
				return __( 'Not connected to Amazon S3, file status unknown.', 'woocommerce-amazon-s3-storage' );
			case self::DISABLED:
				return __( 'Offloading to Amazon S3 is disabled.', 'woocommerce-amazon-s3-storage' );
			case self::QUEUED:
				return __( 'File queued for offloading to AWS S3.', 'woocommerce-amazon-s3-storage' );
			case self::PROCESSING:
				return __( 'Offloading to AWS S3 in progress.', 'woocommerce-amazon-s3-storage' );
			case self::FAILED:
				return __( 'Offloading to AWS S3 failed.', 'woocommerce-amazon-s3-storage' );
			case self::NOT_FOUND:
				return __( 'Remote file not found on AWS S3.', 'woocommerce-amazon-s3-storage' );
			case self::OFFLOADED:
				return __( 'File offloaded to AWS S3.', 'woocommerce-amazon-s3-storage' );
			case self::UNKNOWN:
			default:
				return __( 'Status unknown.', 'woocommerce-amazon-s3-storage' );
		}
	}

	/**
	 * Retrieves the color for the status.
	 *
	 * @since 3.0.0
	 *
	 * @return string
	 */
	private function color() : string {

		switch ( $this->name() ) {
			case self::QUEUED:
				return '#2271b1';
			case self::PROCESSING:
				return '#DBA617';
			case self::DISCONNECTED:
			case self::FAILED:
			case self::NOT_FOUND:
				return '#D63638';
			case self::SHORTCODE:
			case self::OFFLOADED:
				return '#00A32A';
			case self::UNKNOWN:
			case self::UNHANDLED:
			case self::DISABLED:
			default:
				return '#C3C4C7';
		}
	}

	/**
	 * Outputs the status as HTML.
	 *
	 * @since 3.0.0
	 *
	 * @return string
	 */
	public function html() : string {

		$styles = [
			'background-color:' . $this->color(),
			'border-radius: 3px',
			'color: #FFFFFF',
			'padding: 2px 5px',
		];

		if ( 'disabled' === $this->name() ) {
			$name = 'offload-disabled'; // prevents a CSS class conflict with WC
		} else {
			$name = $this->name();
		}

		$html  = '<span class="offload-status status-' . esc_attr( $name ) . '" style="' . implode( ';', $styles ) . '">';
		$html .= esc_html( $this->label() );
		$html .= '</span>';

		return $html;
	}

}
