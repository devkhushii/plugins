<?php
/**
 * Amazon S3 Storage for WooCommerce
 *
 * This source file is subject to the GNU General Public License v3.0 that is bundled with this plugin in the file license.txt.
 *
 * Please do not modify this file if you want to upgrade this plugin to newer versions in the future.
 * If you want to customize this file for your needs, please review our developer documentation.
 * Join our developer program at https://kestrelwp.com/developers
 *
 * @author    Kestrel
 * @copyright Copyright (c) 2012-2024 Kestrel Commerce LLC [hey@kestrelwp.com]
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

declare( strict_types = 1 );

namespace Kestrel\AmazonS3\Files;

defined( 'ABSPATH' ) or exit;

use Exception;
use Kestrel\AmazonS3\Files\Exceptions\File_Exception;
use Kestrel\AmazonS3\S3;
use Kestrel\AmazonS3\Scoped\Aws\Result;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Http\Url;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Logger;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Traits\Has_Accessors;
use Kestrel\AmazonS3\Settings\Debug_Mode;
use Kestrel\AmazonS3\Settings\Default_Bucket;
use Kestrel\AmazonS3\Settings\Default_Region;
use Kestrel\AmazonS3\Settings\URL_Validity_Period;

/**
 * Object representation of a remote file hosted on S3.
 *
 * @since 3.0.0
 *
 * @method string get_key()
 * @method string get_bucket()
 * @method string get_region()
 * @method $this set_key( string $key )
 * @method $this set_bucket( string $bucket )
 * @method $this set_region( string $region )
 */
final class Remote_File {
	use Has_Accessors;

	/** @var string */
	protected string $region;

	/** @var string */
	protected string $bucket;

	/** @var string */
	protected string $key;

	/**
	 * Constructor.
	 *
	 * @since 3.0.0
	 *
	 * @phpstan-param array{
	 *     region?: string,
	 *     bucket: string,
	 *     key: string,
	 * } $args
	 *
	 * @param array<string, string> $args
	 */
	private function __construct( array $args ) {

		$args = wp_parse_args( $args, [
			'region' => Default_Region::name(),
			'bucket' => Default_Bucket::name(),
			'key'    => '',
		] );

		$this->region = $args['region'];
		$this->bucket = $args['bucket'];
		$this->key    = $args['key'];
	}

	/**
	 * Gets a remote file instance.
	 *
	 * @since 3.0.0
	 *
	 * @phpstan-param array{
	 *     region?: string,
	 *     bucket: string,
	 *     key: string,
	 * } $args
	 *
	 * @param array<string, mixed> $args
	 * @return Remote_File
	 */
	public static function get( array $args ) : Remote_File {

		return new self( $args );
	}

	/**
	 * Returns the object data from S3.
	 *
	 * @since 3.0.0
	 *
	 * @return Result
	 * @throws File_Exception
	 */
	public function data() : Result {

		try {
			/** @var Result $result */
			$result = S3::client( [ 'region' => $this->region ] )->getObject( [
				'Bucket' => $this->bucket,
				'Key'    => $this->key,
			] );
		} catch ( Exception $exception ) {

			$message = sprintf( 'Could not retrieve the remote file: %s', $exception->getMessage() );

			if ( Debug_Mode::enabled() ) {
				Logger::error( $message, null, [
					'region' => $this->region,
					'bucket' => $this->bucket,
					'key'    => $this->key,
				] );
			}

			throw new File_Exception( $message, $exception ); // phpcs:ignore
		}

		return $result;
	}

	/**
	 * Returns a URL pointing to the S3 console for the remote file.
	 *
	 * @since 3.0.0
	 *
	 * @return string
	 */
	public function console_url() : string {

		try {
			$url = Url::from_string( sprintf( 'https://%s.console.aws.amazon.com/s3/object/%s', $this->region, rawurlencode( $this->bucket ) ) );
		} catch ( Exception $exception ) {
			return '';
		}

		$url->add_query_parameters( [
			'region' => $this->region,
			'prefix' => $this->key,
		] );

		return $url->to_string();
	}

	/**
	 * Retrieves the URL to download the remote file.
	 *
	 * This will generate a signed URL that is valid for a certain period of time as per plugin settings.
	 *
	 * @since 3.0.0
	 *
	 * @return string
	 * @throws Exception|File_Exception
	 */
	public function download_url() : string {

		$expires    = sprintf( '+%d minutes', URL_Validity_Period::minutes() );
		$client     = S3::client( [ 'region' => $this->region ] );
		$get_object = $client->getCommand( 'GetObject', [
			'Bucket' => $this->bucket,
			'Key'    => $this->key,
		] );

		$request = $client->createPresignedRequest( $get_object, $expires );
		$url     = (string) $request->getUri();

		if ( empty( $url ) ) {
			throw new File_Exception( 'The remote URL is empty' );
		}

		return $url;
	}

}
