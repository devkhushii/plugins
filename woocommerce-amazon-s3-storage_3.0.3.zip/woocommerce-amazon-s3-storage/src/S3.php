<?php
/**
 * Amazon S3 Storage for WooCommerce
 *
 * This source file is subject to the GNU General Public License v3.0 that is bundled with this plugin in the file license.txt.
 *
 * Please do not modify this file if you want to upgrade this plugin to newer versions in the future.
 * If you want to customize this file for your needs, please review our developer documentation.
 * Join our developer program at https://kestrelwp.com/developers
 *
 * @author    Kestrel
 * @copyright Copyright (c) 2012-2024 Kestrel Commerce LLC [hey@kestrelwp.com]
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

declare( strict_types = 1 );

namespace Kestrel\AmazonS3;

defined( 'ABSPATH' ) or exit;

use Exception;
use Kestrel\AmazonS3\S3\Bucket;
use Kestrel\AmazonS3\S3\Region;
use Kestrel\AmazonS3\Scoped\Aws\S3\S3MultiRegionClient;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Cache;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Logger;
use Kestrel\AmazonS3\Settings\Credentials;
use Kestrel\AmazonS3\Settings\Debug_Mode;
use Kestrel\AmazonS3\Settings\Default_Region;

/**
 * Amazon S3 client.
 *
 * @since 3.0.0
 */
final class S3 {

	/** @var bool|null */
	private static ?bool $is_connected = null;

	/**
	 * Gets the S3 client.
	 *
	 * @link https://docs.aws.amazon.com/sdk-for-php/v3/developer-guide/guide_configuration.html
	 * @link https://docs.aws.amazon.com/sdkref/latest/guide/creds-config-files.html
	 *
	 * @since 3.0.0
	 *
	 * @param array<string, mixed> $args
	 * @return S3MultiRegionClient
	 */
	public static function client( array $args = [] ) : S3MultiRegionClient {

		$args['version'] = 'latest';
		// PHP 7.4 will be deprecated in future versions and the SDK may be sending some deprecated warnings which would add noise to the logs
		$args['suppress_php_deprecation_warnings'] = true;
		// some hosts have `open_basedir` restrictions that prevent the use of `~/.aws/credentials` and `~/.aws/config` files: we don't need those
		$args['use_aws_shared_config_files'] = false;
		// see https://docs.aws.amazon.com/sdkref/latest/guide/feature-smart-config-defaults.html this should further prevent the SDK from reading from the filesystem (should be the default value though)
		$args['defaults_mode'] = 'legacy';
		// see https://github.com/aws/aws-sdk-php/issues/1659#issuecomment-507453483 this should disable client-side monitoring and prevent the SDK from reading from the filesystem
		$args['csm'] = false;
		// we don't need to collect stats for the client
		$args['stats'] = false;

		if ( self::debug_mode() ) {
			$args['debug'] = [
				'logfn'        => [ Logger::class, 'debug' ],
				'stream_size'  => 0,
				'scrub_auth'   => true,
				'auth_headers' => [
					'X-My-Secret-Header' => '[REDACTED]', // this is a fake header to mask the auth headers
				],
				'auth_strings' => [
					'/SuperSecret=[A-Za-z0-9]{20}/i' => 'SuperSecret=[REDACTED]', // this is a fake auth string to mask the auth strings
				],
			];
		}

		/**
		 * Filters the arguments for the S3 client.
		 *
		 * Note that the configured credentials won't be included in this filter for security reasons.
		 * However, you can override the `credentials` key in the array to provide alternative credentials.
		 *
		 * @since 3.0.3
		 *
		 * @param array<string, mixed> $args
		 */
		$args = (array) apply_filters( 'woocommerce_amazon_s3_client_args', $args );

		return new S3MultiRegionClient( wp_parse_args( $args, [
			'region'      => Default_Region::name(),
			'credentials' => [
				'key'    => Credentials::access_key_id(),
				'secret' => Credentials::secret_access_key(),
			],
		] ) );
	}

	/**
	 * Determines if the client is in debug mode.
	 *
	 * @since 3.0.1
	 *
	 * @return bool
	 */
	private static function debug_mode() : bool {

		/**
		 * Filters the debug mode for the S3 client.
		 *
		 * @since 3.0.1
		 *
		 * @param bool $client_debug_mode
		 * @param bool $plugin_debug_mode
		 */
		return (bool) apply_filters( 'woocommerce_amazon_s3_client_debug_mode', false, Debug_Mode::enabled() );
	}

	/**
	 * Determines if the client is connected to the S3 service.
	 *
	 * @since 3.0.0
	 *
	 * @return bool
	 */
	public static function is_connected() : bool {

		if ( is_bool( self::$is_connected ) ) {
			return self::$is_connected;
		}

		if ( ! Credentials::configured() ) {
			self::$is_connected = false;
		} elseif ( isset( $_POST['access_key_id'], $_POST['secret_access_key'] ) || ( isset( $_GET['page'], $_GET['tab'] ) && $_GET['tab'] === 'amazon_s3_storage' ) ) { // phpcs:ignore
			self::$is_connected = self::test_connection(); // do not cache value in transient while updating credentials or on the settings page
		} else {
			// @phpstan-ignore-next-line WP constant
			self::$is_connected = wc_string_to_bool( Cache::key( 'connection' )->remember( fn() => self::test_connection(), true, 5 * MINUTE_IN_SECONDS ) );
		}

		return self::$is_connected;
	}

	/**
	 * Tests the connection to the S3 service.
	 *
	 * @since 3.0.1
	 *
	 * @return bool
	 */
	private static function test_connection() : bool {

		$client = self::client();

		try {
			$client->listBuckets();

			$connected = true;
		} catch ( Exception $exception ) {
			if ( Debug_Mode::enabled() ) {
				Logger::warning( 'Cannot connect to S3: ' . $exception->getMessage() );
			}

			$connected = false;
		}

		return $connected;
	}

	/**
	 * Purges S3 caches.
	 *
	 * @since 3.0.0
	 *
	 * @return void
	 */
	public static function purge() : void {

		self::$is_connected = null;

		Cache::key( 'connection' )->forget();

		Bucket::purge();
		Region::purge();
	}

}
