<?php
/**
 * Amazon S3 Storage for WooCommerce
 *
 * This source file is subject to the GNU General Public License v3.0 that is bundled with this plugin in the file license.txt.
 *
 * Please do not modify this file if you want to upgrade this plugin to newer versions in the future.
 * If you want to customize this file for your needs, please review our developer documentation.
 * Join our developer program at https://kestrelwp.com/developers
 *
 * @author    Kestrel
 * @copyright Copyright (c) 2012-2024 Kestrel Commerce LLC [hey@kestrelwp.com]
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

declare( strict_types = 1 );

namespace Kestrel\AmazonS3\Admin;

defined( 'ABSPATH' ) or exit;

use Kestrel\AmazonS3\Files\Local_File;
use Kestrel\AmazonS3\Plugin;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Plugin\Traits\Is_Handler;
use WP_Post;

/**
 * Media Gallery handler.
 *
 * @since 3.0.0
 */
final class Media_Gallery {
	use Is_Handler;

	/**
	 * Constructor.
	 *
	 * @since 3.0.0
	 *
	 * @param Plugin $plugin plugin instance
	 */
	protected function __construct( Plugin $plugin ) {

		self::$plugin = $plugin;

		self::add_action( 'attachment_fields_to_edit', [ $this, 'add_offloaded_attachment_data' ], PHP_INT_MAX, 2 );
	}

	/**
	 * Appends offloaded attachment data to the media editor fields.
	 *
	 * @since 3.0.0
	 *
	 * @param array<string, mixed>|mixed $media_editor_fields
	 * @param mixed|WP_Post $attachment_post
	 * @return array<string, mixed>|mixed
	 */
	protected function add_offloaded_attachment_data( $media_editor_fields, $attachment_post ) {

		if ( ! is_array( $media_editor_fields ) || ! $attachment_post instanceof WP_Post || $attachment_post->post_type !== 'attachment' ) {
			return $media_editor_fields;
		}

		$local_file = Local_File::from_attachment( $attachment_post );

		// skip displaying any information to avoid confusion with non-offloaded files (like images, non-product related files, etc.)
		if ( ! $local_file || $local_file->is_unhandled() ) {
			return $media_editor_fields;
		}

		$media_editor_fields[ self::plugin()->key() ] = [
			'label' => __( 'Amazon S3:', 'woocommerce-amazon-s3-storage' ),
			'input' => 'html',
			'html'  => $this->get_offloaded_attachment_data_html( $local_file ),
		];

		return $media_editor_fields;
	}

	/**
	 * Returns the HTML for the offloaded attachment data.
	 *
	 * @since 3.0.0
	 *
	 * @param Local_File $file
	 * @return string
	 */
	private function get_offloaded_attachment_data_html( Local_File $file ) : string {

		ob_start();

		?>
		<ul style="margin-top: 7px;">
			<li><?php echo $file->status()->html(); // phpcs:ignore?></li>
		</ul>
		<?php

		return ob_get_clean();
	}

}
