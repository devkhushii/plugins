<?php
/**
 * Amazon S3 Storage for WooCommerce
 *
 * This source file is subject to the GNU General Public License v3.0 that is bundled with this plugin in the file license.txt.
 *
 * Please do not modify this file if you want to upgrade this plugin to newer versions in the future.
 * If you want to customize this file for your needs, please review our developer documentation.
 * Join our developer program at https://kestrelwp.com/developers
 *
 * @author    Kestrel
 * @copyright Copyright (c) 2012-2024 Kestrel Commerce LLC [hey@kestrelwp.com]
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

declare( strict_types = 1 );

namespace Kestrel\AmazonS3\Admin\Modals;

defined( 'ABSPATH' ) or exit;

use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Traits\Is_Singleton;
use Kestrel\AmazonS3\Settings\Default_Region;
use Kestrel\AmazonS3\Settings\Shortcode_Bucket;

/**
 * Product Shortcode modal.
 *
 * @since 3.0.0
 */
final class Product_Shortcode {
	use Is_Singleton;

	/**
	 * Outputs the modal template.
	 *
	 * @since 3.0.0
	 *
	 * @return void
	 */
	public function output_template() : void {

		$region = Default_Region::name();
		$bucket = Shortcode_Bucket::name();

		?>
		<script type='text/html' id='tmpl-wc-amazon-s3-storage-shortcode-modal'>
			<div class='wc-backbone-modal wc-amazon-s3-storage-shortcode-modal'>
				<div class='wc-backbone-modal-content'>
					<section class='wc-backbone-modal-main' role='main'>
						<header class='wc-backbone-modal-header'>
							<h1>
								<# if ( data.action === 'edit' ) { #>
								<?php esc_html_e( 'Edit S3  File', 'woocommerce-amazon-s3-storage' ); ?>
								<# } else { #>
								<?php esc_html_e( 'Add S3 File', 'woocommerce-amazon-s3-storage' ); ?>
								<# } #>
							</h1>

							<button class="modal-close modal-close-link dashicons dashicons-no-alt">
								<span class="screen-reader-text"><?php esc_html_e( 'Close modal panel', 'woocommerce' ); // phpcs:ignore?></span>
							</button>
						</header>
						<article>
							<div class="shortcode-container">
								<span class="shortcode-text"></span>
							</div>

							<form class="shortcode-form" method="post" action="#">
								<div class="panel woocommerce_options_panel">
									<div class="options_group">
										<?php
										woocommerce_wp_text_input(
										[
											'id'          => 'bucket',
											'label'       => __( 'Bucket Name', 'woocommerce-amazon-s3-storage' ),
											'description' => __(
											'Leave this field empty to use the default bucket.',
											'woocommerce-amazon-s3-storage'
											),
											'value'       => '{{ data.shortcode.bucket }}',
											'placeholder' => $bucket,
										]
										);

										woocommerce_wp_select(
											[
												'id'      => 'region',
												'label'   => __( 'S3 Region', 'woocommerce-amazon-s3-storage' ),
												'class'   => 'select wc-enhanced-select',
												'description' => __(
													'Select the S3 region to use.',
													'woocommerce-amazon-s3-storage'
												),
												'options' => [
													'' => __(
														'Default',
														'woocommerce-amazon-s3-storage'
													),
												] + [ $region => $region ],
											]
										);

										woocommerce_wp_text_input(
											[
												'id'    => 'object',
												'label' => __( 'Object', 'woocommerce-amazon-s3-storage' ),
												'value' => '{{ data.shortcode.object }}',
												'description' => __(
													'Relative path to the S3 object.',
													'woocommerce-amazon-s3-storage'
												),
												'placeholder' => _x(
													'path/filename.ext',
													'shortcode object param placeholder',
													'woocommerce-amazon-s3-storage'
												),
												'custom_attributes' => [
													'required' => 'required',
												],
											]
										);
										?>
									</div>
								</div>

								<input class="screen-reader-text" type="submit" name="submit"/>
							</form>
						</article>
						<footer>
							<div class="inner">
								<div class="wc-action-button-group">
							<span class="wc-action-button-group__items">
								<?php
								printf(
											'<a class="button button-secondary button-large copy-shortcode" href="#" data-tip="%1$s">%2$s</a>',
											esc_attr__( 'Copied!', 'woocommerce-amazon-s3-storage' ),
											esc_html__( 'Copy shortcode', 'woocommerce-amazon-s3-storage' )
										);
								?>
							</span>
								</div>

								<a class="button button-primary button-large add-file" href="#">
									<# if ( data.action === 'edit' ) { #>
									<?php
									esc_html_e( 'Update file', 'woocommerce-amazon-s3-storage' );
									?>
									<# } else { #>
									<?php
									esc_html_e( 'Add file', 'woocommerce-amazon-s3-storage' );
									?>
									<# } #>
								</a>
							</div>
						</footer>
					</section>
				</div>
			</div>
			<div class="wc-backbone-modal-backdrop modal-close"></div>
		</script>
		<?php
	}

}
