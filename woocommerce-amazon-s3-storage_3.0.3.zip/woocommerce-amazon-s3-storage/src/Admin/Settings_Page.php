<?php
/**
 * Amazon S3 Storage for WooCommerce
 *
 * This source file is subject to the GNU General Public License v3.0 that is bundled with this plugin in the file license.txt.
 *
 * Please do not modify this file if you want to upgrade this plugin to newer versions in the future.
 * If you want to customize this file for your needs, please review our developer documentation.
 * Join our developer program at https://kestrelwp.com/developers
 *
 * @author    Kestrel
 * @copyright Copyright (c) 2012-2024 Kestrel Commerce LLC [hey@kestrelwp.com]
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

declare( strict_types = 1 );

namespace Kestrel\AmazonS3\Admin;

defined( 'ABSPATH' ) or exit;

use Exception;
use Kestrel\AmazonS3\Admin;
use Kestrel\AmazonS3\S3;
use Kestrel\AmazonS3\S3\Bucket;
use Kestrel\AmazonS3\S3\Exceptions\Client_Exception;
use Kestrel\AmazonS3\Scoped\Aws\Result;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Logger;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\WooCommerce\Settings\Settings_Page as Abstract_Settings_Page;
use Kestrel\AmazonS3\Settings\Debug_Mode;
use Kestrel\AmazonS3\Settings\Default_Bucket;
use Kestrel\AmazonS3\Settings\Default_Region;
use WC_Admin_Settings;

/**
 * Amazon S3 Storage for WooCommerce settings page.
 *
 * @since 3.0.0
 */
final class Settings_Page extends Abstract_Settings_Page {

	/** @var string setting page ID */
	protected const TAB_ID = Admin::SETTINGS_PAGE_TAB_ID;

	/** @var string setting page position */
	protected const TAB_POSITION = 'integration';

	/**
	 * Registers scripts for the settings page.
	 *
	 * @since 3.0.0
	 *
	 * @return void
	 */
	protected function register_scripts() : void {

		if ( ! self::is_current_screen() ) {
			return;
		}

		wp_enqueue_script( self::plugin()->handle( 'settings' ), self::plugin()->assets_url( '/js/admin/settings.min.js' ), [ 'jquery' ], self::plugin()->version(), true );
	}

	/**
	 * Returns the settings page sections.
	 *
	 * @since 3.0.0
	 *
	 * @return array<string, string>
	 */
	protected function get_own_sections() {

		return [
			'' => __( 'Amazon S3 Storage', 'woocommerce-amazon-s3-storage' ),
		];
	}

	/**
	 * Outputs the settings page.
	 *
	 * Ensures the S3 caches are purged before outputting the settings so a fresh list of buckets can be displayed.
	 *
	 * @since 3.0.1
	 * @internal
	 *
	 * @return void
	 */
	public function output() {

		S3::purge();

		parent::output();
	}

	/**
	 * Saves the settings.
	 *
	 * @since 3.0.0
	 * @internal
	 *
	 * @return void
	 */
	public function save() {

		$posted_data = $_POST; // phpcs:ignore

		if ( isset( $posted_data[ Default_Bucket::SETTING_NAME ], $posted_data['new_bucket'] ) && '' === $posted_data[ Default_Bucket::SETTING_NAME ] ) {

			$bucket_name    = sanitize_key( $posted_data['new_bucket'] );
			$default_region = $posted_data[ Default_Region::SETTING_NAME ] ?? Default_Region::name();
			$bucket_region  = isset( $posted_data['new_bucket_region'] ) ? sanitize_key( $posted_data['new_bucket_region'] ) : $default_region;

			// ignore when the name is empty as it may be intentional
			if ( '' !== trim( $bucket_name ) && '' !== trim( $bucket_region ) ) {

				$debug_mode = wc_string_to_bool( $posted_data[ Debug_Mode::SETTING_NAME ] ?? false );

				try {

					$this->create_bucket( $bucket_name, $bucket_region, $debug_mode );

					// causes settings to save the default bucket to the newly created one
					$_POST[ Default_Bucket::SETTING_NAME ] = $bucket_name;

				} catch ( Exception $exception ) {
					/* translators: Placeholders: %1$s - AWS S3 bucket name - %2$s - Error message shown to admins */
					WC_Admin_Settings::add_error( sprintf( __( 'Could not create bucket "%1$s": %2$s', 'woocommerce-amazon-s3-storage' ), $bucket_name, $exception->getMessage() ) );
				}
			}
		}

		// not real settings, so by removing them from posted data they will be ignored by any further handling
		unset( $_POST['new_bucket'], $_POST['new_bucket_region'] );

		S3::purge();

		parent::save();
	}

	/**
	 * Creates a new bucket from settings.
	 *
	 * @NOTE consider moving to {@see S3} or dedicated buckets handler.
	 *
	 * @since 3.0.0
	 *
	 * @param string $bucket_name
	 * @param string $region
	 * @param bool $debug_mode
	 * @return void
	 * @throws Client_Exception
	 */
	private function create_bucket( string $bucket_name, string $region, bool $debug_mode ) : void {

		if ( ! S3::is_connected() ) {
			throw new Client_Exception( __( 'Not connected to AWS S3. Please verify your credentials before creating a new bucket.', 'woocommerce-amazon-s3-storage' ) ); // phpcs:ignore
		}

		try {

			$client = S3::client( [ 'region' => $region ] );
			$args   = [
				'Bucket'                    => $bucket_name,
				'CreateBucketConfiguration' => [
					'LocationConstraint' => $region,
				],
			];

			if ( $debug_mode ) {
				Logger::info( sprintf( 'Creating bucket "%s"', $bucket_name ), null, $args );
			}

			/** @var Result $result */
			$result = $client->createBucket( $args );

			$client->waitUntil( 'BucketExists', [ 'Bucket' => $bucket_name ] );

		} catch ( Exception $exception ) {

			$error_message = $exception->getMessage();

			if ( $debug_mode ) {
				Logger::error( sprintf( 'Could not create a new bucket: %s.', $error_message ) );
			}

			if ( false !== strpos( $error_message, '409 Conflict' ) ) {
				throw new Client_Exception( __( 'Bucket already exists in AWS. Please choose a unique name for your bucket.', 'woocommerce-amazon-s3-storage' ), $exception ); // phpcs:ignore
			}

			throw new Client_Exception( __( 'An AWS S3 error occurred. Please verify your AWS settings or try with another region.', 'woocommerce-amazon-s3-storage' ), $exception ); // phpcs:ignore
		}

		if ( $debug_mode ) {
			Logger::info( sprintf( 'Bucket "%s" created in "%s" region.', $bucket_name, $region ), null, $result->toArray() );
		}

		S3::purge();

		// @phpstan-ignore-next-line the setting type supports adding a choice
		Default_Bucket::instance()->get_type()->add_choice( $bucket_name, $bucket_name );
	}

}
