<?php
/**
 * Amazon S3 Storage for WooCommerce
 *
 * This source file is subject to the GNU General Public License v3.0 that is bundled with this plugin in the file license.txt.
 *
 * Please do not modify this file if you want to upgrade this plugin to newer versions in the future.
 * If you want to customize this file for your needs, please review our developer documentation.
 * Join our developer program at https://kestrelwp.com/developers
 *
 * @author    Kestrel
 * @copyright Copyright (c) 2012-2024 Kestrel Commerce LLC [hey@kestrelwp.com]
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

declare( strict_types = 1 );

namespace Kestrel\AmazonS3\Admin;

defined( 'ABSPATH' ) or exit;

use Exception;
use Kestrel\AmazonS3\Admin\Modals\Product_Shortcode;
use Kestrel\AmazonS3\Files\File_Status;
use Kestrel\AmazonS3\Files\Local_File;
use Kestrel\AmazonS3\S3;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Helpers\Strings;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Plugin;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Plugin\Traits\Is_Handler;
use Kestrel\AmazonS3\Settings\Offload_Downloadables;
use Kestrel\AmazonS3\Shortcode;
use WC_Product;
use WC_Product_Download;
use WC_Product_Variable;
use WP_Post;
use WP_Screen;

/**
 * WooCommerce Products admin handler.
 *
 * @since 3.0.0
 */
final class Products {
	use Is_Handler;

	/**
	 * Constructor.
	 *
	 * @since 3.0.0
	 *
	 * @param Plugin $plugin
	 */
	protected function __construct( Plugin $plugin ) {

		self::$plugin = $plugin;

		self::add_action( 'admin_enqueue_scripts', [ $this, 'add_product_scripts' ] );
		self::add_action( 'admin_footer', [ $this, 'add_product_shortcode_modal_template' ] );
	}

	/**
	 * Determines if the current page is the product edit screen.
	 *
	 * @since 3.0.0
	 *
	 * @return bool
	 */
	private function is_product_edit_screen() : bool {
		global $current_screen;

		return $current_screen instanceof WP_Screen && 'product' === $current_screen->id;
	}

	/**
	 * Adds a product shortcode modal template to the product edit screen.
	 *
	 * @since 3.0.0
	 *
	 * @return void
	 */
	protected function add_product_shortcode_modal_template() : void {

		if ( ! $this->is_product_edit_screen() ) {
			return;
		}

		Product_Shortcode::instance()->output_template();
	}

	/**
	 * Enqueues scripts and styles for the product edit screen.
	 *
	 * @since 3.0.0
	 *
	 * @return void
	 */
	protected function add_product_scripts() : void {
		global $post;

		if ( ! $this->is_product_edit_screen() ) {
			return;
		}

		$product         = $post instanceof WP_Post ? wc_get_product( $post ) : null;
		$products_script = self::plugin()->handle( 'admin-products' );
		$modal_script    = self::plugin()->handle( 'admin-product-shortcode-modal' );

		wp_enqueue_style( $products_script, self::plugin()->assets_url( '/css/admin/products.css' ), [], self::plugin()->version() );

		// legacy script: to be removed in a future version, and possibly merged in the main JS products handler
		wp_register_script( $modal_script, self::plugin()->assets_url( '/js/admin/product-shortcode-modal.min.js' ), [ 'jquery-tiptip', 'wc-clipboard', 'wc-backbone-modal' ], self::plugin()->version(), true );
		wp_localize_script( $modal_script, 'wcS3StorageMetaBoxesProduct', [
			'addFileBtnText' => __( 'Add S3 file shortcode', 'woocommerce-amazon-s3-storage' ),
		] );

		wp_enqueue_script( $products_script, self::plugin()->assets_url( '/js/admin/products.min.js' ), [ $modal_script ], self::plugin()->version(), true );
		wp_localize_script( $products_script, self::plugin()->key( 'admin_products' ), [
			'is_connected' => S3::is_connected(),
			'data'         => $this->get_product_downloadables_data( $product ?: null ),
			'placeholders' => [
				'disconnected' => File_Status::DISCONNECTED()->html(),
				'unhandled'    => File_Status::UNHANDLED()->html(),
				'unknown'      => File_Status::UNKNOWN()->html(),
				'shortcode'    => File_Status::SHORTCODE()->html(),
			],
			'i18n'         => [
				's3_status'                 => __( 'S3 status', 'woocommerce-amazon-s3-storage' ),
				'add_shortcode_button_text' => __( 'Add S3 file shortcode', 'woocommerce-amazon-s3-storage' ),
			],
		] );
	}

	/**
	 * Returns all the product downloads for a product and its children, if any.
	 *
	 * @since 3.0.2
	 *
	 * @param WC_Product $product
	 * @return array<string, WC_Product_Download>
	 */
	private function get_product_downloads( WC_Product $product ) : array {

		$product_downloads = $product->get_downloads();

		if ( $product instanceof WC_Product_Variable ) {
			$product_downloads_variations = [];

			foreach ( $product->get_children() as $variation_id ) {
				if ( $variation_product = wc_get_product( $variation_id ) ) {
					$product_downloads_variations = array_merge( $product_downloads_variations, $variation_product->get_downloads() );
				}
			}

			$product_downloads = array_merge( $product_downloads, $product_downloads_variations );
		}

		return $product_downloads;
	}

	/**
	 * Returns the offloaded product data for the specified product inclusive of any children variations data.
	 *
	 * @since 3.0.0
	 *
	 * @param WC_Product|null $product
	 * @return array<int, array<string, string>>
	 */
	private function get_product_downloadables_data( ?WC_Product $product ) : array {

		$offload_data = [];

		if ( ! $product ) {
			return $offload_data;
		}

		foreach ( $this->get_product_downloads( $product ) as $product_download ) {

			$downloadable_id = $product_download->get_id();

			if ( empty( $downloadable_id ) ) {
				continue;
			}

			$downloadable_file = $product_download->get_file();
			$unknown_status    = [
				'id'     => $downloadable_id,
				'status' => File_Status::UNKNOWN()->html(),
			];

			if ( Strings::is_shortcode( $downloadable_file, Shortcode::NAME ) ) {
				$offload_data[] = [
					'id'     => $downloadable_id,
					'status' => File_Status::SHORTCODE()->html(),
				];
			} elseif ( Strings::is_url( $downloadable_file ) ) {
				if ( ! Offload_Downloadables::enabled() ) {
					$offload_data[] = [
						'id'     => $downloadable_id,
						'status' => File_Status::DISABLED()->html(),
					];
				} else {
					try {
						$local_file     = Local_File::from_url( $downloadable_file );
						$remote_file    = $local_file->get_remote();
						$remote_url     = $remote_file ? $remote_file->console_url() : '';
						$offload_status = $remote_url ? '<a href="' . esc_url( $remote_url ) . '" target="_blank">' . $local_file->status()->html() . '</a>' : $local_file->status()->html();
						$offload_data[] = [
							'id'     => $downloadable_id,
							'status' => $offload_status,
						];
					} catch ( Exception $exception ) {
						$offload_data[] = $unknown_status;
					}
				}
			} else {
				$offload_data[] = $unknown_status;
			}
		}

		return $offload_data;
	}

}
