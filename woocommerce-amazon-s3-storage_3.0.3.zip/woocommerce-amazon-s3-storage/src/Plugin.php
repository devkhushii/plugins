<?php
/**
 * Amazon S3 Storage for WooCommerce
 *
 * This source file is subject to the GNU General Public License v3.0 that is bundled with this plugin in the file license.txt.
 *
 * Please do not modify this file if you want to upgrade this plugin to newer versions in the future.
 * If you want to customize this file for your needs, please review our developer documentation.
 * Join our developer program at https://kestrelwp.com/developers
 *
 * @author    Kestrel
 * @copyright Copyright (c) 2012-2024 Kestrel Commerce LLC [hey@kestrelwp.com]
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

declare( strict_types = 1 );

namespace Kestrel\AmazonS3;

use Kestrel\AmazonS3\Admin\Media_Gallery;
use Kestrel\AmazonS3\Files\Downloads;
use Kestrel\AmazonS3\Files\Uploader;
use Kestrel\AmazonS3\Lifecycle\Migrations\Update_To_Version_2_0_0;
use Kestrel\AmazonS3\Lifecycle\Migrations\Update_To_Version_2_1_5;
use Kestrel\AmazonS3\Lifecycle\Migrations\Update_To_Version_3_0_0;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\WooCommerce\Extension;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\WooCommerce\Features\Feature;

defined( 'ABSPATH' ) or exit;

/**
 * Amazon S3 Storage for WooCommerce plugin.
 *
 * @since 3.0.0
 */
final class Plugin extends Extension {

	/** @var string plugin ID */
	protected const ID = 'woocommerce_amazon_s3_storage';

	/** @var string plugin version */
	protected const VERSION = '3.0.3';

	/** @var string plugin text domain */
	protected const TEXT_DOMAIN = 'woocommerce-amazon-s3-storage';

	/** @var string URL pointing to the plugin's documentation */
	protected const DOCUMENTATION_URL = 'https://woocommerce.com/document/amazon-s3-storage/';

	/** @var string URL pointing to the plugin's support */
	protected const SUPPORT_URL = 'https://woocommerce.com/my-account/contact-support/?select=amazon-s3-storage';

	/** @var string URL pointing to the plugin's sales page */
	protected const SALES_PAGE_URL = 'https://woocommerce.com/products/amazon-s3-storage/';

	/** @var string URL pointing to the plugin's reviews */
	protected const REVIEWS_URL = 'https://woocommerce.com/products/amazon-s3-storage/#comments';

	/** @var bool|null */
	protected ?bool $is_multilingual = true;

	/**
	 * Plugin constructor.
	 *
	 * @since 3.0.0
	 *
	 * @param array<string, mixed> $args
	 */
	protected function __construct( array $args = [] ) {

		$args = wp_parse_args( $args, [
			'admin'       => [
				'handler' => Admin::class,
			],
			'lifecycle'   => [
				'migrations' => [
					'2.0.0' => Update_To_Version_2_0_0::class,
					'2.1.5' => Update_To_Version_2_1_5::class,
					'3.0.0' => Update_To_Version_3_0_0::class,
				],
			],
			'woocommerce' => [
				'supported_features' => [
					Feature::CART_CHECKOUT_BLOCKS,
					Feature::HPOS,
				],
			],
		] );

		parent::__construct( $args );

		$this->define_legacy_constants();
	}

	/**
	 * Gets the plugin name.
	 *
	 * @since 3.0.0
	 *
	 * @return string
	 */
	public function name() : string {

		return __( 'Amazon S3 Storage for WooCommerce', 'woocommerce-amazon-s3-storage' );
	}

	/**
	 * Gets the settings URL.
	 *
	 * @since 3.0.0
	 *
	 * @return string
	 */
	public function settings_url() : string {

		return admin_url( 'admin.php?page=wc-settings&tab=' . Admin::SETTINGS_PAGE_TAB_ID );
	}

	/**
	 * Initializes the plugin.
	 *
	 * @since 3.0.0
	 *
	 * @return void
	 */
	protected function initialize() : void {

		parent::initialize();

		Product::initialize( $this );
		Media_Gallery::initialize( $this );
		Uploader::initialize( $this );
		Downloads::initialize( $this );
		Shortcode::initialize( $this );
	}

	/**
	 * Defines legacy constants used in older versions of the plugin.
	 *
	 * @NOTE these are deprecated and should not be used in new code.
	 *
	 * @since 3.0.0
	 *
	 * @return void
	 */
	private function define_legacy_constants() : void {

		$constants = [
			'\WC_AMAZON_S3_STORAGE_BASENAME' => $this->absolute_dir_path(),
			'\WC_AMAZON_S3_STORAGE_FILE'     => $this->absolute_file_path(),
			'\WC_AMAZON_S3_STORAGE_PATH'     => $this->relative_file_path(),
			'\WC_AMAZON_S3_STORAGE_URL'      => $this->base_url(),
			'\WC_AMAZON_S3_STORAGE_VERSION'  => $this->version(),
		];

		foreach ( $constants as $constant => $value ) {
			if ( ! defined( $constant ) ) {
				define( $constant, $value );
			}
		}
	}

}
