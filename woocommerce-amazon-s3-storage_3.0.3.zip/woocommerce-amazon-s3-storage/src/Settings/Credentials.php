<?php
/**
 * Amazon S3 Storage for WooCommerce
 *
 * This source file is subject to the GNU General Public License v3.0 that is bundled with this plugin in the file license.txt.
 *
 * Please do not modify this file if you want to upgrade this plugin to newer versions in the future.
 * If you want to customize this file for your needs, please review our developer documentation.
 * Join our developer program at https://kestrelwp.com/developers
 *
 * @author    Kestrel
 * @copyright Copyright (c) 2012-2024 Kestrel Commerce LLC [hey@kestrelwp.com]
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

declare( strict_types = 1 );

namespace Kestrel\AmazonS3\Settings;

defined ( 'ABSPATH' ) or exit;

use Kestrel\AmazonS3\S3;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Plugin\Settings\Field;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Plugin\Settings\Setting;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Plugin\Settings\Settings_Group;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Plugin\Settings\Stores\Option;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Plugin\Settings\Types\Credential;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Plugin\Settings\Types\Text;

/**
 * Handles the Amazon S3 credentials.
 *
 * @since 3.0.0
 */
class Credentials extends Settings_Group {

	/** @var string */
	public const SETTING_NAME = 'credentials';

	/** @var string */
	public const ACCESS_MODE_SETTING_NAME = 'access_mode';

	/** @var string */
	public const ACCESS_KEY_ID_SETTING_NAME = 'access_key_id';

	/** @var string */
	public const SECRET_ACCESS_KEY_SETTING_NAME = 'secret_access_key';

	/**
	 * Credentials constructor.
	 *
	 * @since 3.0.0
	 */
	public function __construct() {

		$access_mode_description =
			'<div id="access_mode_constant" class="description">' . __( 'Enter your Amazon S3 credentials in the fields below to connect to Amazon S3 storage. They will be stored securely in your WordPress database.', 'woocommerce-amazon-s3-storage' ) . '</div>' .
			'<div id="access_mode_database" class="description">' .
				/* translators: Placeholders: %1$s - opening HTML strong tag, %2$s - closing HTML strong tag, %3$s - opening HTML code tag, %4$s - closing HTML code tag */
				sprintf( __( '%1$sAdvanced:%2$s Edit your %3$swp-config.php%4$s and define there the constants %3$sAMAZON_S3_ACCESS_KEY_ID%4$s and %3$sAMAZON_S3_ACCESS_KEY_SECRET%4$s containing your Amazon S3 credentials.', 'woocommerce-amazon-s3-storage' ),
					'<strong>',
					'</strong>',
					'<code>',
					'</code>'
				) .
			'</div>';

		parent::__construct(
			new Option( self::plugin()->key( self::SETTING_NAME ) ),
			[
				self::ACCESS_MODE_SETTING_NAME       => new Setting( [
					'name'         => self::ACCESS_MODE_SETTING_NAME,
					'title'        => __( 'Credentials location', 'woocommerce-amazon-s3-storage' ),
					'instructions' => __( 'Choose where to store your Amazon S3 credentials.', 'woocommerce-amazon-s3-storage' ),
					'description'  => $access_mode_description,
					'default'      => 'database',
					'type'         => new Text( [
						'field'   => Field::RADIO,
						'choices' => [
							'database' => __( 'Save credentials to database (encrypted)', 'woocommerce-amazon-s3-storage' ),
							'constant' => __( 'Manually add constants to your WordPress configuration file (unencrypted)', 'woocommerce-amazon-s3-storage' ),
						],
					] ),
				] ),
				self::ACCESS_KEY_ID_SETTING_NAME     => new Setting( [
					'name'         => self::ACCESS_KEY_ID_SETTING_NAME,
					'title'        => __( 'Access key ID', 'woocommerce-amazon-s3-storage' ),
					'type'         => new Credential( [ 'encrypted' => true ] ),
					'description'  => __( 'Enter your Amazon S3 access key ID.', 'woocommerce-amazon-s3-storage' ),
					'instructions' => __( 'Your Amazon Web Services access key ID.', 'woocommerce-amazon-s3-storage' ),
				] ),
				self::SECRET_ACCESS_KEY_SETTING_NAME => new Setting( [
					'name'         => self::SECRET_ACCESS_KEY_SETTING_NAME,
					'title'        => __( 'Secret access key', 'woocommerce-amazon-s3-storage' ),
					'type'         => new Credential( [ 'encrypted' => true ] ),
					'description'  => __( 'Enter your Amazon S3 secret access key.', 'woocommerce-amazon-s3-storage' ),
					'instructions' => __( 'Your Amazon Web Services secret access key ID.', 'woocommerce-amazon-s3-storage' ),
				] ),
			],
		);
	}

	/**
	 * Determines if the credentials are configured.
	 *
	 * @NOTE: this does not validate the credentials ({@see S3::is_connected()}).
	 *
	 * @since 3.0.0
	 *
	 * @return bool
	 */
	public static function configured() : bool {

		return ! empty( self::access_key_id() ) && ! empty( self::secret_access_key() );
	}

	/**
	 * Gets the access key ID.
	 *
	 * @since 3.0.0
	 *
	 * @return string|null
	 */
	public static function access_key_id() : ?string {

		if ( 'constant' === self::instance()->get_setting( self::ACCESS_MODE_SETTING_NAME )->format() ) {
			return defined( 'AMAZON_S3_ACCESS_KEY_ID' ) && is_string( \AMAZON_S3_ACCESS_KEY_ID ) ? \AMAZON_S3_ACCESS_KEY_ID : null;
		}

		return self::instance()->get_setting( self::ACCESS_KEY_ID_SETTING_NAME )->format();
	}

	/**
	 * Gets the secret access key.
	 *
	 * @since 3.0.0
	 *
	 * @return string|null
	 */
	public static function secret_access_key() : ?string {

		if ( 'constant' === self::instance()->get_setting( self::ACCESS_MODE_SETTING_NAME )->format() ) {
			return defined( 'AMAZON_S3_ACCESS_KEY_SECRET' ) && is_string( \AMAZON_S3_ACCESS_KEY_SECRET ) ? \AMAZON_S3_ACCESS_KEY_SECRET : null;
		}

		return self::instance()->get_setting( self::SECRET_ACCESS_KEY_SETTING_NAME )->format();
	}


}
