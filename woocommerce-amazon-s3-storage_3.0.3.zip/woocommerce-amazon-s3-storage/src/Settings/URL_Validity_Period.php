<?php
/**
 * Amazon S3 Storage for WooCommerce
 *
 * This source file is subject to the GNU General Public License v3.0 that is bundled with this plugin in the file license.txt.
 *
 * Please do not modify this file if you want to upgrade this plugin to newer versions in the future.
 * If you want to customize this file for your needs, please review our developer documentation.
 * Join our developer program at https://kestrelwp.com/developers
 *
 * @author    Kestrel
 * @copyright Copyright (c) 2012-2024 Kestrel Commerce LLC [hey@kestrelwp.com]
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

declare( strict_types = 1 );

namespace Kestrel\AmazonS3\Settings;

defined( 'ABSPATH' ) or exit;

use Kestrel\AmazonS3\S3;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Plugin\Settings\Setting;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Plugin\Settings\Stores\Option;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Plugin\Settings\Types\Integer;

/**
 * URL validity period setting.
 *
 * @since 3.0.0
 */
final class URL_Validity_Period extends Setting {

	/** @var string */
	public const SETTING_NAME = 'url_validity_period';

	/**
	 * Setting constructor.
	 *
	 * @since 3.0.0
	 */
	public function __construct() {

		parent::__construct( [
			'name'              => self::SETTING_NAME,
			'title'             => __( 'URL validity period', 'woocommerce-amazon-s3-storage' ),
			'description'       => __( 'The number of minutes that a generated URL is valid for.', 'woocommerce-amazon-s3-storage' ),
			'instructions'      => __( 'Enter the number of minutes that a generated AWS S3 URL is valid for (up to 7 days).', 'woocommerce-amazon-s3-storage' ),
			'default'           => 1,
			'display_condition' => fn () => S3::is_connected(),
			'store'             => new Option( self::plugin()->key( self::SETTING_NAME ) ),
			'type'              => new Integer( [
				'min'  => 1,
				'max'  => 7 * 60 * 24,
				'step' => 1,
			] ),
		] );
	}

	/**
	 * Returns the number of minutes that a generated URL is valid for.
	 *
	 * @since 3.0.0
	 *
	 * @return int
	 */
	public static function minutes() : int {

		$value = intval( self::instance()->get_value() );

		return max( 1, min( 7 * 60 * 24, intval( $value ) ) );
	}

}
