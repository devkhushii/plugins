<?php
/**
 * Amazon S3 Storage for WooCommerce
 *
 * This source file is subject to the GNU General Public License v3.0 that is bundled with this plugin in the file license.txt.
 *
 * Please do not modify this file if you want to upgrade this plugin to newer versions in the future.
 * If you want to customize this file for your needs, please review our developer documentation.
 * Join our developer program at https://kestrelwp.com/developers
 *
 * @author    Kestrel
 * @copyright Copyright (c) 2012-2024 Kestrel Commerce LLC [hey@kestrelwp.com]
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

declare( strict_types = 1 );

namespace Kestrel\AmazonS3\Settings;

defined( 'ABSPATH' ) or exit;

use Kestrel\AmazonS3\S3;
use Kestrel\AmazonS3\S3\Bucket;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Plugin\Settings\Field;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Plugin\Settings\Setting;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Plugin\Settings\Stores\Option;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Plugin\Settings\Types\Text;

/**
 * AWS S3 Bucket setting.
 *
 * @since 3.0.0
 */
final class Default_Bucket extends Setting {

	/** @var string */
	public const SETTING_NAME = 'default_bucket';

	/**
	 * Setting constructor.
	 *
	 * @since 3.0.0
	 */
	public function __construct() {

		parent::__construct( [
			'name'              => self::SETTING_NAME,
			'title'             => __( 'S3 bucket', 'woocommerce-amazon-s3-storage' ),
			'description'       => __( 'Files offloaded to S3 will be uploaded to the chosen bucket.', 'woocommerce-amazon-s3-storage' ),
			'instructions'      => __( 'Select the default bucket to use for automatic uploads to S3.', 'woocommerce-amazon-s3-storage' ),
			'default'           => $this->default_choice(),
			'display_condition' => fn() => S3::is_connected(),
			'store'             => new Option( self::plugin()->key( self::SETTING_NAME ) ),
			'type'              => new Text( [
				'field'   => Field::SELECT,
				'choices' => $this->choices(),
			] ),
		] );
	}

	/**
	 * Returns the default choice.
	 *
	 * @since 3.0.2
	 *
	 * @return string
	 */
	private function default_choice() : string {

		$choices = $this->choices();

		if ( count( $choices ) <= 1 ) {
			return '';
		}

		return (string) array_keys( $choices )[1];
	}

	/**
	 * Lists all the setting choices.
	 *
	 * @since 3.0.0
	 *
	 * @return array<string, string>
	 */
	private function choices() : array {

		$buckets = Bucket::all();
		$choices = [
			'' => __( 'Create a new bucket&hellip;', 'woocommerce-amazon-s3-storage' ),
		];

		foreach ( array_keys( $buckets ) as $bucket_name ) {
			// @TODO consider appending the region to the bucket name, however must ensure that there results are cached to avoid unnecessary S3 requests
			$choices[ $bucket_name ] = $bucket_name;
		}

		return $choices;
	}

	/**
	 * Returns the default bucket name.
	 *
	 * @since 3.0.0
	 *
	 * @return string
	 */
	public static function name() : string {

		return self::instance()->get_value() ?: '';
	}

	/**
	 * Checks if the default bucket exists.
	 *
	 * @since 3.0.0
	 *
	 * @return bool
	 */
	public static function exists() : bool {

		$name    = self::name();
		$buckets = Bucket::all();

		return isset( $buckets[ $name ] );
	}

	/**
	 * Gets the default bucket as an object.
	 *
	 * @since 3.0.0
	 *
	 * @return Bucket|null
	 */
	public static function get() : ?Bucket {

		return Bucket::find( self::name() );
	}

}
