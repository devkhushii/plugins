<?php
/**
 * Amazon S3 Storage for WooCommerce
 *
 * This source file is subject to the GNU General Public License v3.0 that is bundled with this plugin in the file license.txt.
 *
 * Please do not modify this file if you want to upgrade this plugin to newer versions in the future.
 * If you want to customize this file for your needs, please review our developer documentation.
 * Join our developer program at https://kestrelwp.com/developers
 *
 * @author    Kestrel
 * @copyright Copyright (c) 2012-2024 Kestrel Commerce LLC [hey@kestrelwp.com]
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

declare( strict_types = 1 );

namespace Kestrel\AmazonS3\Settings;

defined( 'ABSPATH' ) or exit;

use Kestrel\AmazonS3\S3;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Plugin\Settings\Setting;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Plugin\Settings\Stores\Option;
use Kestrel\AmazonS3\Scoped\Kestrel\Fenix\Plugin\Settings\Types\Boolean;

/**
 * Download method setting.
 *
 * @since 3.0.0
 */
final class Download_Method extends Setting {

	/** @var string */
	public const SETTING_NAME = 'download_method';

	/**
	 * Setting constructor.
	 *
	 * @since 3.0.0
	 */
	public function __construct() {

		parent::__construct( [
			'name'              => self::SETTING_NAME,
			'title'             => __( 'Force redirect method', 'woocommerce-amazon-s3-storage' ),
			'description'       => __( 'Use the "Redirect only" download method for S3 files.', 'woocommerce-amazon-s3-storage' ),
			'instructions'      => __( 'Recommended when downloading media files from S3.', 'woocommerce-amazon-s3-storage' ),
			'default'           => 'no',
			'display_condition' => fn () => S3::is_connected(),
			'store'             => new Option( self::plugin()->key( self::SETTING_NAME ) ),
			'type'              => new Boolean(),
		] );
	}

	/**
	 * Determines if the "Redirect only" download method should be forced.
	 *
	 * @since 3.0.0
	 *
	 * @return bool
	 */
	public static function force_redirect_only() : bool {

		return wc_string_to_bool( self::instance()->get_value() );
	}
}
