<?php

use BrizyPlaceholders\ContentPlaceholder;
use BrizyPlaceholders\ContextInterface;

class BrizyPro_Content_Placeholders_MenuLoop extends Brizy_Content_Placeholders_Abstract
{
    public function support($placeholderName)
    {
        return 'menu_loop' === $placeholderName;
    }

    public function getValue(ContextInterface $context, ContentPlaceholder $contentPlaceholder)
    {
        $isRecursiveCall = $contentPlaceholder->getAttribute('recursive');
        if ($isRecursiveCall) {
            $placeholder = $context->searchPlaceholderByNameAndAttr('menu_loop', 'menuId', $context->getMenuUid());

            return $this->handleRecursiveCall($context, $placeholder);
        } else {
            return $this->handleMenuLoop($context, $contentPlaceholder);
        }
    }

    /**
     * @param ContextInterface $context
     * @param $menuId
     * @param ContentPlaceholder $contentPlaceholder
     *
     * @return string
     */
    protected function loop(
        ContextInterface $context,
        ContentPlaceholder $contentPlaceholder,
        $menuUid,
        $menuId,
        $itemParent = 0
    ) {
        $replacer = new \BrizyPlaceholders\Replacer($context->getProvider());
        $content = '';

        $menuItems = wp_get_nav_menu_items($menuId);
        _wp_menu_item_classes_by_context($menuItems);
        foreach ($menuItems as $menuItem) {
            if ($menuItem->menu_item_parent != $itemParent) {
                continue;
            }
            $newContext = Brizy_Content_ContextFactory::createContext(
                $context->getProject(),
                $context->getEntity(),
                true,
                $context,
                $contentPlaceholder
            );
            $newContext->setProvider($context->getProvider());
            $newContext->setMenuItem($menuItem);
            $newContext->setMenuId($menuId);
            $newContext->setMenuUid($menuUid);
            $content .= $replacer->replacePlaceholders($contentPlaceholder->getContent(), $newContext);
        }

        return $content;
    }

    private function handleMenuLoop(ContextInterface $context, ContentPlaceholder $contentPlaceholder)
    {
        $menuUid = $contentPlaceholder->getAttribute('menuId', true);
        $menuIds = get_terms(['meta_key' => 'brizy_uid', 'meta_value' => $menuUid, 'fields' => 'ids']);
        $menuId = array_pop($menuIds);
        if ($menuId) {
            return $this->loop($context, $contentPlaceholder, $menuUid, $menuId, 0);
        }

        return '';
    }

    private function handleRecursiveCall(ContextInterface $context, ContentPlaceholder $contentPlaceholder)
    {
        $menuId = $context->getMenuId();
        $parentMenuItemId = $context->getMenuItem();
        $menuUid = $context->getMenuUid();
        if ($menuId) {
            return $this->loop($context, $contentPlaceholder, $menuUid, $menuId, $parentMenuItemId->ID);
        }
    }

}
